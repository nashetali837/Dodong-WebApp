import { ApiProperty } from "@nestjs/swagger";
import { BaseEntity } from "src/core/entity/base.entity";
import { Column, Entity, Unique } from "typeorm";

@Entity({
  name: "otp",
})
export class OTP extends BaseEntity {
  @ApiProperty()
  @Unique("user_unique_mobile_number", ["mobNumber"])
  @Column({ nullable: false })
  mobileNumber: string;

  @ApiProperty()
  @Column({ nullable: false })
  otp: string;
}
