import {
  Body,
  Controller,
  HttpCode,
  Logger,
  Patch,
  Post,
  UsePipes,
  ValidationPipe,
} from "@nestjs/common";
import { OtpService } from "./otp.service";
import {
  ApiExtraModels,
  ApiBadRequestResponse,
  ApiCreatedResponse,
  ApiNoContentResponse,
  ApiForbiddenResponse,
  ApiNotFoundResponse,
  ApiTags,
} from "@nestjs/swagger";
import { VerifyOtpDto } from "src/claim-shop/dtos/verify-otp.dto";
import { CreateOTPDto } from "./dtos/create-otp.dto";
import { OTP } from "./enitities/otp.entity";
import { AwsService } from "./../aws/aws.service";
@ApiTags("OTP")
@Controller("otp")
export class OtpController {
  private readonly logger = new Logger(OtpController.name);

  constructor(
    private readonly otpService: OtpService,
    private readonly awsService: AwsService
  ) {}
  @Post("/verification")
  @ApiExtraModels(CreateOTPDto)
  @ApiBadRequestResponse({ description: "Error: Bad Request" })
  @ApiCreatedResponse({
    description: "The record has been successfully created.",
    type: OTP,
  })
  @UsePipes(
    new ValidationPipe({
      whitelist: true,
      transform: true,
      forbidNonWhitelisted: true,
    })
  )
  async verificationAndSendOtp(
    @Body() createOTPDto: CreateOTPDto
  ): Promise<OTP> {
    const otpRecord: OTP = await this.otpService.create(createOTPDto);
    const res = await this.awsService.sendSMS(otpRecord);
    delete otpRecord.otp;
    return { ...otpRecord, ...res };
  }

  @Patch("/verify-otp")
  @ApiNoContentResponse()
  @ApiForbiddenResponse({ description: "Forbidden." })
  @ApiNotFoundResponse({ description: "Not found" })
  @ApiBadRequestResponse({ description: "Error: Bad Request" })
  @HttpCode(204)
  @UsePipes(
    new ValidationPipe({
      whitelist: true,
      transform: true,
      forbidNonWhitelisted: true,
    })
  )
  async verifyOtp(@Body() verifyOtpDto: VerifyOtpDto): Promise<void> {
    await this.otpService.verifyOTP(
      verifyOtpDto.mobileNumber,
      verifyOtpDto.otp
    );
  }
}
