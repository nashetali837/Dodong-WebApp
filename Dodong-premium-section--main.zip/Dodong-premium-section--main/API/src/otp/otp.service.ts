import {
  BadRequestException,
  Injectable,
  Logger,
  NotFoundException,
} from "@nestjs/common";
import { InjectRepository } from "@nestjs/typeorm";
import { Repository, Equal } from "typeorm";
import { OTP } from "./enitities/otp.entity";
import { CreateOTPDto } from "./dtos/create-otp.dto";
import { UpdateOTPDto } from "./dtos/update-otp.dto";
import { QueryOTPDto } from "./dtos/query-otp.dto";
import { generate } from "otp-generator";

@Injectable()
export class OtpService {
  private readonly logger = new Logger(OtpService.name);

  constructor(
    @InjectRepository(OTP)
    private readonly otpRepository: Repository<OTP>
  ) {}

  async create(createOTPDto: CreateOTPDto): Promise<OTP> {
    try {
      const otp = generate(6, {
        upperCaseAlphabets: false,
        specialChars: false,
        lowerCaseAlphabets: false,
      });

      const mobileNumber = createOTPDto.mobileNumber;
      let claimShop = await this.findOneUsingMobileNumber(mobileNumber);

      if (!claimShop) {
        claimShop = await this.otpRepository.create({
          mobileNumber: mobileNumber,
          otp: otp,
        });
      } else {
        claimShop.otp = otp;
      }

      const savedRecord = await this.otpRepository.save(claimShop);
      return savedRecord;
    } catch (error) {
      this.logger.error(error, error?.stack);
      throw error;
    }
  }

  async findAll(query: QueryOTPDto): Promise<OTP[]> {
    try {
      const queryBuilderObj = this.otpRepository.createQueryBuilder("t");
      queryBuilderObj.where({ ...query });
      queryBuilderObj.addOrderBy("t.id", "ASC");
      return queryBuilderObj.getMany();
    } catch (error) {
      this.logger.error(error, error?.stack);
      throw error;
    }
  }

  async findByFilter(query: QueryOTPDto): Promise<OTP[]> {
    try {
      const queryBuilderObj = this.otpRepository.createQueryBuilder("t");
      queryBuilderObj.where({ ...query });
      queryBuilderObj.addOrderBy("t.id", "ASC");
      return queryBuilderObj.getMany();
    } catch (error) {
      this.logger.error(error, error?.stack);
      throw error;
    }
  }

  async findOne(id: number): Promise<OTP> {
    try {
      let otpRecord;
      try {
        otpRecord = await this.otpRepository.findOneOrFail({
          where: {
            id: Equal(id),
          },
        });
      } catch (err) {
        throw new NotFoundException(
          `Could not find a record with id: ${id}`
        );
      }

      return otpRecord;
    } catch (error) {
      this.logger.error(error, error?.stack);
      throw error;
    }
  }

  async findOneUsingMobileNumber(mobileNumber: string): Promise<OTP | null> {
    try {
      const otpRecord = await this.otpRepository.findOne({
        where: {
          mobileNumber: Equal(mobileNumber),
        },
      });

      return otpRecord;
    } catch (error) {
      this.logger.error(error, error?.stack);
      throw error;
    }
  }

  async verifyOTP(mobileNumber: string, otp: string): Promise<OTP | null> {
    try {
      const otpRecord = await this.otpRepository.findOne({
        where: {
          mobileNumber: Equal(mobileNumber),
          otp: Equal(otp),
        },
      });

      if (!otpRecord) {
        throw new BadRequestException("OTP is invalid.");
      }

      this.remove(otpRecord.id);
      return otpRecord;
    } catch (error) {
      this.logger.error(error, error?.stack);
      throw error;
    }
  }

  async update(id: number, updateOTPDto: UpdateOTPDto): Promise<void> {
    try {
      await this.findOne(id);
      await this.otpRepository.update(id, updateOTPDto);
    } catch (error) {
      this.logger.error(error, error?.stack);
      throw error;
    }
  }

  async remove(id: number): Promise<void> {
    try {
      await this.findOne(id);
      await this.otpRepository.delete(id);
    } catch (error) {
      this.logger.error(error, error?.stack);
      throw error;
    }
  }
}
