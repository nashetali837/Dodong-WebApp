import { ApiProperty, PartialType } from '@nestjs/swagger';
import { CreateOTPDto } from './create-otp.dto';
import { IsBoolean, IsNotEmpty, IsOptional } from 'class-validator';

export class UpdateOTPDto extends PartialType(CreateOTPDto) {
  @ApiProperty({ required: false })
  @IsOptional()
  @IsBoolean()
  @IsNotEmpty()
  isClaimed?: boolean;
}
