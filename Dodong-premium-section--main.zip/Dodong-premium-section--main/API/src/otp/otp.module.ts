import { Module } from "@nestjs/common";
import { OtpService } from "./otp.service";
import { TypeOrmModule } from "@nestjs/typeorm";
import { OTP } from "./enitities/otp.entity";
import { OtpController } from "./otp.controller";
import { AwsModule } from "src/aws/aws.module";

@Module({
  imports: [TypeOrmModule.forFeature([OTP]), AwsModule],
  providers: [OtpService],
  exports: [OtpService],
  controllers: [OtpController],
})
export class OtpModule {}
