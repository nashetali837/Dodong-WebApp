const newrelic = require("newrelic");
import * as dotenv from "dotenv";
import { Logger } from "@nestjs/common";
import { NestFactory } from "@nestjs/core";
import { NestExpressApplication } from "@nestjs/platform-express";
import {
  DocumentBuilder,
  SwaggerCustomOptions,
  SwaggerModule,
} from "@nestjs/swagger";
import * as compression from "compression";
import helmet from "helmet";
import { AppModule } from "./app.module";
import * as bodyParser from "body-parser";
import { NewrelicInterceptor } from './core/interceptor/newrelic.interceptor'

dotenv.config();
const appLogger = new Logger("Application Bootstrap");
process.on("warning", (warning: Error) => {
  appLogger.error({ type: "warning" });
  appLogger.error(warning);
});

process.on("unhandledRejection", (reason, promise) => {
  appLogger.error({ type: "unhandledRejection", promise: promise });
  appLogger.error(reason);
});

process.on("uncaughtException", (error: Error) => {
  appLogger.error({ type: "uncaughtException" });
  appLogger.error(error);
});

async function bootstrap() {
  const app: NestExpressApplication = await NestFactory.create(AppModule);

  app.setGlobalPrefix("/v1");
  app.use(
    helmet({
      contentSecurityPolicy: false,
    })
  );
  app.enableCors({
    methods: ["POST", "GET", "PUT", "PATCH", "DELETE"],
    origin: "*",
  });

  app.disable("x-powered-by");
  app.use(compression());

  app.use(bodyParser.json({ limit: "20mb" }));
  app.use(bodyParser.urlencoded({ limit: "20mb", extended: true }));

  const config = new DocumentBuilder()
    .setTitle("DoDong Premium Section")
    .setDescription(
      `Official API. <br> Swagger json file [json](${process.env.NODE_ENV === "local" ? "http://" : "https://"}${process.env.HOST ? `${process.env.HOST}` : "localhost"}${process.env.NODE_ENV === "local" ? ":3000" : ""}/api-json).`
    )
    .addServer(
      `${process.env.NODE_ENV === "local" ? "http://" : "https://"}${process.env.HOST ? `${process.env.HOST}` : "localhost"}${process.env.NODE_ENV === "local" ? ":3000" : ""}`
    )
    .setVersion("1.0")
    .build();

  const customOption: SwaggerCustomOptions = {
    customCss: `
          @import url('https://fonts.googleapis.com/css2?family=Roboto+Condensed:ital,wght@0,100..900;1,100..900&display=swap');
          .topbar  {
            display: none;
          }
          .response-col_status { padding-top: 13px !important; }
          .renderedMarkdown p { margin-top: 0 !important; }
          code span { font-size: 13px; font-weight: 500; letter-spacing: .5px; line-height: 20px; }
          *:not(.highlight-code *) {
            font-family: 'Encode Sans Condensed', sans-serif;
          }
        `,
    customSiteTitle: "DoDong Premium Section API",
  };

  const document = SwaggerModule.createDocument(app, config);
  SwaggerModule.setup("api", app, document, customOption);

  app.useGlobalInterceptors(new NewrelicInterceptor())

  const port = parseInt(process.env.PORT, 10) || 3000;
  await app.listen(port);
}

bootstrap();
