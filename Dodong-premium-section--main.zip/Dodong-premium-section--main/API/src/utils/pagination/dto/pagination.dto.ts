import { ApiProperty } from '@nestjs/swagger'
import { Type } from 'class-transformer'
import { IsOptional, IsPositive, Max, Min } from 'class-validator'

export const LIMIT_MIN = 10
export const LIMIT_MAX = 100

export class PaginationDto {
  @Type(() => Number)
  @IsOptional()
  @IsPositive()
  @ApiProperty({ required: false })
  @Min(LIMIT_MIN)
  @Max(LIMIT_MAX)
  limit?: number

  @Type(() => Number)
  @IsOptional()
  @IsPositive()
  @ApiProperty({ required: false })
  @Min(1)
  page?: number

  @IsOptional()
  route?: string
}
