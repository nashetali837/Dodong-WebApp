import { BadRequestException, Injectable } from "@nestjs/common";
import { ConfigService } from "@nestjs/config";
import * as querystring from "node:querystring";
import { Repository, SelectQueryBuilder } from "typeorm";
import { LIMIT_MAX, LIMIT_MIN, PaginationDto } from "./dto/pagination.dto";
import { IPaginationLink } from "./interface/pagination-link-interface";
import { IPaginationMeta } from "./interface/pagination-meta-interface";
import PaginationResult from "./interface/pagination-result-interface";

@Injectable()
export class PaginationService {
  constructor(private readonly configService: ConfigService) {}

  private getLinks(
    reqQueryObj: { [key: string]: any },
    option: PaginationDto,
    pages: { totalPages: number; page: number },
  ): IPaginationLink {
    const { limit, route } = option;
    const { totalPages, page } = pages;

    let links: IPaginationLink = {
      current: "",
      first: "",
      last: "",
      next: "",
      previous: "",
    };

    const concreteLinks = {
      current: `${this.configService.get<string>("appUrl")}${this.serializeQueryString(reqQueryObj, page, limit, route)}`,
      first: `${this.configService.get<string>("appUrl")}${this.serializeQueryString(reqQueryObj, 1, limit, route)}`,
    };

    if (totalPages > 0) {
      concreteLinks["last"] =
        `${this.configService.get<string>("appUrl")}${this.serializeQueryString(
          reqQueryObj,
          totalPages,
          limit,
          route,
        )}`;
    }

    const previousPage = page - 1 > 0 ? page - 1 : null;
    if (previousPage) {
      concreteLinks["previous"] =
        `${this.configService.get<string>("appUrl")}${this.serializeQueryString(
          reqQueryObj,
          previousPage,
          limit,
          route,
        )}`;
    }

    const nextPage = totalPages && page < totalPages ? page + 1 : null;
    if (nextPage) {
      concreteLinks["next"] =
        `${this.configService.get<string>("appUrl")}${this.serializeQueryString(reqQueryObj, nextPage, limit, route)}`;
    }

    links = { ...links, ...concreteLinks };

    return links;
  }

  private getMetaDetail(
    data: Array<any>,
    pages: { page: number; totalPages: number; totalCount: number },
  ): IPaginationMeta {
    const { page, totalCount, totalPages } = pages;

    return {
      itemsPerPage: data.length,
      totalItems: totalCount,
      currentPage: page,
      totalPages: totalPages,
    };
  }

  private serializeQueryString(
    reqQueryObj: { [key: string]: any } = {},
    page: number,
    limit: number,
    route?: string,
  ): string {
    const cloneReqObj = Object.keys(reqQueryObj).reduce((accu, currentKey) => {
      if (reqQueryObj[currentKey] === null) {
        return accu;
      }

      if (typeof reqQueryObj[currentKey] === "object") {
        if (!Object?.keys(reqQueryObj[currentKey])?.length) {
          return accu;
        }

        accu[currentKey] = JSON.stringify(reqQueryObj[currentKey]);
      } else {
        accu[currentKey] = reqQueryObj[currentKey];
      }

      return accu;
    }, {});

    delete cloneReqObj["route"];

    const queryString = querystring.stringify(
      { ...cloneReqObj, page, limit },
      "&",
      "=",
      {
        encodeURIComponent: querystring.escape,
      },
    );

    return route?.length > 0 ? route + "?" + queryString : queryString;
  }

  async paginate<T>(
    repoOrQueryBuilder: SelectQueryBuilder<T> | Repository<T>,
    reqQueryObj: PaginationDto,
  ): Promise<PaginationResult<T>> {
    const { limit = LIMIT_MIN, page = 1, route = "" } = reqQueryObj;

    if (limit > LIMIT_MAX) {
      throw new BadRequestException(
        undefined,
        `Limit value should be less than or equal to ${LIMIT_MAX}`,
      );
    }

    if (limit < LIMIT_MIN) {
      throw new BadRequestException(
        undefined,
        `Limit value should be greater than or equal to ${LIMIT_MIN}`,
      );
    }

    if (repoOrQueryBuilder instanceof SelectQueryBuilder) {
      const skip = Math.max(0, (page - 1) * limit);
      const totalCount = await repoOrQueryBuilder.getCount();
      const totalPages = Math.ceil(totalCount / limit);

      repoOrQueryBuilder.skip(skip).take(limit);

      const result = await repoOrQueryBuilder.getMany();

      const meta: IPaginationMeta = this.getMetaDetail(result, {
        page,
        totalPages,
        totalCount,
      });

      const links: IPaginationLink = this.getLinks(
        reqQueryObj,
        { limit, page, route },
        {
          totalPages,
          page,
        },
      );

      if (result.length && page > totalPages) {
        throw new BadRequestException(
          undefined,
          `Request page value is greater than the last page, available last page is ${totalPages}`,
        );
      }

      return {
        items: result,
        meta,
        links,
      };
    }
  }
}
