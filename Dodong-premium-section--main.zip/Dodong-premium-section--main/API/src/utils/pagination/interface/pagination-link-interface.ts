export interface IPaginationLink {
  first: string
  current: string
  previous?: string
  next?: string
  last?: string
}
