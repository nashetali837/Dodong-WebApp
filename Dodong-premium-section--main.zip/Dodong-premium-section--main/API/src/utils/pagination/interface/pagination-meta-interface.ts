export interface IPaginationMeta {
  itemsPerPage: number
  totalItems: number
  currentPage: number
  totalPages: number
}
