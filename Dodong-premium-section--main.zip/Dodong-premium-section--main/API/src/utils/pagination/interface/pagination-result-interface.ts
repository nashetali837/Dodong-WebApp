import { IPaginationLink } from './pagination-link-interface'
import { IPaginationMeta } from './pagination-meta-interface'

export default interface IPaginationResult<T> {
  items: T[]
  meta: IPaginationMeta
  links: IPaginationLink
}
