import {
  Body,
  Controller,
  Delete,
  Get,
  HttpCode,
  Logger,
  Param,
  Patch,
  Post,
  Query,
  UsePipes,
  ValidationPipe,
} from "@nestjs/common";
import { CategoryService } from "./category.service";
import { CreateCategoryDto } from "./dtos/create-category.dto";
import {
  ApiExtraModels,
  ApiBadRequestResponse,
  ApiCreatedResponse,
  ApiOkResponse,
  ApiForbiddenResponse,
  ApiNotFoundResponse,
  ApiNoContentResponse,
  ApiTags,
} from "@nestjs/swagger";
import { Category } from "./entities/category.entity";
import { QueryCategoryDto } from "./dtos/query-category.dto";
import { UpdateCategoryDto } from "./dtos/update-category.dto";

@ApiTags("Category")
@Controller("categories")
export class CategoryController {
  private readonly logger = new Logger(CategoryController.name);

  constructor(private readonly categoryService: CategoryService) {}

  @Post()
  @ApiExtraModels(CreateCategoryDto)
  @ApiBadRequestResponse({ description: "Error: Bad Request" })
  @ApiCreatedResponse({
    description: "The record has been successfully created.",
    type: Category,
  })
  @UsePipes(
    new ValidationPipe({
      whitelist: true,
      transform: true,
      forbidNonWhitelisted: true,
    })
  )
  async create(
    @Body() createCategoryDto: CreateCategoryDto
  ): Promise<Category> {
    return await this.categoryService.create(createCategoryDto);
  }

  @ApiOkResponse()
  @ApiForbiddenResponse({ description: "Forbidden." })
  @Get("filter")
  async filter(
    @Query(
      new ValidationPipe({
        whitelist: true,
        transform: true,
        forbidNonWhitelisted: true,
        forbidUnknownValues: true,
      })
    )
    query: QueryCategoryDto
  ) {
    this.logger.log(`filtering Category: ${JSON.stringify(query)}`);

    return await this.categoryService.findByFilter(query);
  }

  @ApiOkResponse({ type: Category })
  @ApiForbiddenResponse({ description: "Forbidden." })
  @ApiNotFoundResponse({ description: "Not found" })
  @Get(":id")
  async findOne(@Param("id") id: string): Promise<Category> {
    return await this.categoryService.findOne(+id);
  }

  @ApiNoContentResponse()
  @ApiForbiddenResponse({ description: "Forbidden." })
  @ApiNotFoundResponse({ description: "Not found" })
  @ApiBadRequestResponse({ description: "Error: Bad Request" })
  @Patch(":id")
  @HttpCode(204)
  @UsePipes(
    new ValidationPipe({
      transform: true,
      whitelist: true,
      forbidUnknownValues: true,
      forbidNonWhitelisted: true,
    })
  )
  async update(
    @Param("id") id: string,
    @Body() updateCategoryDto: UpdateCategoryDto
  ): Promise<void> {
    await this.categoryService.update(+id, updateCategoryDto);
  }

  @ApiNoContentResponse()
  @ApiForbiddenResponse({ description: "Forbidden." })
  @ApiNotFoundResponse({ description: "Not found" })
  @Delete(":id")
  @HttpCode(204)
  async remove(@Param("id") id: string) {
    return await this.categoryService.remove(+id);
  }
}
