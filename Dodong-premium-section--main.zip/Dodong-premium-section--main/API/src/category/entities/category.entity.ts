import { SubCategory } from "src/sub-category/entities/sub-category.entity";
import { ApiProperty } from "@nestjs/swagger";
import { ClaimShop } from "src/claim-shop/enitities/claim-shop.entity";
import { BaseEntity } from "src/core/entity/base.entity";
import { Column, Entity, ManyToMany, OneToMany } from "typeorm";

@Entity({
  name: "category",
})
export class Category extends BaseEntity {
  @ApiProperty()
  @Column({ nullable: false })
  label: string;

  @ManyToMany(() => ClaimShop, (claimShop) => claimShop.categories)
  claimShops: ClaimShop[];

  @ApiProperty({ type: () => SubCategory, isArray: true })
  @OneToMany((type) => SubCategory, (subCategory) => subCategory.category, {
    cascade: true,
    eager: true,
  })
  subCategories: SubCategory[];
}
