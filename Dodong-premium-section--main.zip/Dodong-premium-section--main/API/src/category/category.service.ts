import {
  HttpException,
  Injectable,
  Logger,
  NotFoundException,
} from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Category } from './entities/category.entity';
import { Equal, Repository } from 'typeorm';
import { CreateCategoryDto } from './dtos/create-category.dto';
import { QueryCategoryDto } from './dtos/query-category.dto';
import { UpdateCategoryDto } from './dtos/update-category.dto';

@Injectable()
export class CategoryService {
  private readonly logger = new Logger(CategoryService.name);

  constructor(
    @InjectRepository(Category)
    private readonly categoryRepository: Repository<Category>,
  ) {}
  async create(createCategoryDto: CreateCategoryDto): Promise<Category> {
    try {
      const category = await this.categoryRepository.create(createCategoryDto);

      return await this.categoryRepository.save(category);
    } catch (error) {
      this.logger.error(error, error?.stack);
      throw error;
    }
  }

  async findAll(query: QueryCategoryDto): Promise<Category[]> {
    try {
      const queryBuilderObj = this.categoryRepository.createQueryBuilder('t');
      queryBuilderObj.where({ ...query });
      queryBuilderObj.addOrderBy('t.id', 'ASC');
      return queryBuilderObj.getMany();
    } catch (error) {
      this.logger.error(error, error?.stack);
      throw error;
    }
  }

  async findByFilter(query: QueryCategoryDto): Promise<Category[]> {
    try {
      const { label } = query;
      const queryBuilderObj = this.categoryRepository.createQueryBuilder('t');

      if (label && label.length) {
        queryBuilderObj.where(`t.name ILIKE :label`, {
          label: `%${label}%`,
        });
      }
      queryBuilderObj.addOrderBy('t.id', 'ASC');
      return queryBuilderObj.getMany();
    } catch (error) {
      this.logger.error(error, error?.stack);
      throw error;
    }
  }

  async findOne(id: number): Promise<Category> {
    try {
      let category;
      try {
        category = await this.categoryRepository.findOneOrFail({
          where: {
            id: Equal(id),
          },
        });
      } catch (err) {
        throw new NotFoundException(
          `Could not find a record with id: ${id}`,
        );
      }

      return category;
    } catch (error) {
      this.logger.error(error, error?.stack);
      throw error;
    }
  }

  async update(
    id: number,
    updateCategoryDto: UpdateCategoryDto,
  ): Promise<void> {
    try {
      await this.findOne(id);
      const updateResult = await this.categoryRepository.update(
        id,
        updateCategoryDto,
      );

      if (updateResult.affected < 1) {
        throw new HttpException(`Unable to update`, 500);
      }
    } catch (error) {
      this.logger.error(error, error?.stack);
      throw error;
    }
  }

  async remove(id: number): Promise<void> {
    try {
      await this.findOne(id);
      await this.categoryRepository.delete(id);
    } catch (error) {
      this.logger.error(error, error?.stack);
      throw error;
    }
  }
}
