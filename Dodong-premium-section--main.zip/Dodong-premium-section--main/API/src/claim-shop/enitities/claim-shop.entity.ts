import { ApiProperty } from "@nestjs/swagger";
import { Category } from "src/category/entities/category.entity";
import { BaseEntity } from "src/core/entity/base.entity";
import { SubCategory } from "src/sub-category/entities/sub-category.entity";
import { Column, Entity, JoinTable, ManyToMany } from "typeorm";
import { ClaimShopMetaInfo } from "../dtos/update-claim-shop.dto";

@Entity({
  name: "claimshop",
})
export class ClaimShop extends BaseEntity {
  @ApiProperty()
  @Column({ nullable: false })
  name: string;

  @ApiProperty()
  @Column({ nullable: false })
  intro: string;

  @ApiProperty()
  @Column({ nullable: false })
  address: string;

  @ApiProperty()
  @Column({ nullable: false })
  city: string;

  @ApiProperty()
  @Column({ nullable: false })
  state: string;

  @ApiProperty()
  @Column({ nullable: false })
  pin: string;

  @ApiProperty()
  @Column({ nullable: false })
  shopType: string;

  @ManyToMany(() => Category, (category) => category.claimShops)
  @JoinTable({
    name: "claimshop_category",
    joinColumn: { name: "claimshop_id", referencedColumnName: "id" },
    inverseJoinColumn: { name: "category_id", referencedColumnName: "id" },
  })
  categories: Category[];

  @ManyToMany(() => SubCategory, (subCategory) => subCategory.claimShops)
  @JoinTable({
    name: "claimshop_subcategory",
    joinColumn: { name: "claimshop_id", referencedColumnName: "id" },
    inverseJoinColumn: {
      name: "subcategory_id",
      referencedColumnName: "id",
    },
  })
  subCategories: SubCategory[];

  @ApiProperty()
  @Column({ nullable: false })
  shopOwnerName: string;

  @ApiProperty()
  @Column({ nullable: false })
  shopOwnerContactNumber: string;

  @ApiProperty()
  @Column({ nullable: false })
  shopOwnerCancelledChequeImage: string;

  @ApiProperty()
  @Column({ nullable: false })
  storeFrontPicture: string;

  @ApiProperty()
  @Column({ nullable: false, type: "double precision" })
  lat: number;

  @ApiProperty()
  @Column({ nullable: false, type: "double precision" })
  long: number;

  @ApiProperty()
  @Column({ nullable: false })
  capturedAddress: string;

  @ApiProperty()
  @Column({ nullable: false, default: false })
  isClaimed: boolean;

  @Column("jsonb", { nullable: false, default: {} })
  metaInfo?: ClaimShopMetaInfo;
}
