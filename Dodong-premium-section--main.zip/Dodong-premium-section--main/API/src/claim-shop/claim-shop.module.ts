import { Module } from "@nestjs/common";
import { ClaimShopService } from "./claim-shop.service";
import { ClaimShopController } from "./claim-shop.controller";
import { ClaimShop } from "./enitities/claim-shop.entity";
import { TypeOrmModule } from "@nestjs/typeorm";
import { AwsModule } from "src/aws/aws.module";
import { OtpModule } from "src/otp/otp.module";
import { PaginationModule } from "src/utils/pagination/pagination-util.module";

@Module({
  imports: [
    TypeOrmModule.forFeature([ClaimShop]),
    AwsModule,
    OtpModule,
    PaginationModule,
  ],
  providers: [ClaimShopService],
  controllers: [ClaimShopController],
  exports: [ClaimShopService],
})
export class ClaimShopModule {}
