import { Test, TestingModule } from '@nestjs/testing';
import { ClaimShopService } from './claim-shop.service';

describe('ClaimShopService', () => {
  let service: ClaimShopService;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [ClaimShopService],
    }).compile();

    service = module.get<ClaimShopService>(ClaimShopService);
  });

  it('should be defined', () => {
    expect(service).toBeDefined();
  });
});
