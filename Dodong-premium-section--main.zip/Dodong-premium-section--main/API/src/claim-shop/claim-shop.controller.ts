import {
  Body,
  Controller,
  Delete,
  Get,
  HttpCode,
  Logger,
  Param,
  Patch,
  Post,
  Query,
  Req,
  UsePipes,
  ValidationPipe,
} from "@nestjs/common";
import {
  ApiBadRequestResponse,
  ApiCreatedResponse,
  ApiExtraModels,
  ApiForbiddenResponse,
  ApiNoContentResponse,
  ApiNotFoundResponse,
  ApiOkResponse,
  ApiTags,
} from "@nestjs/swagger";
import { ClaimShopService } from "./claim-shop.service";
import { CreateCliamShopDto } from "./dtos/create-claim-shop.dto";
import { ClaimShop } from "./enitities/claim-shop.entity";
import { UpdateCliamShopDto } from "./dtos/update-claim-shop.dto";
import { QueryCliamShopDto } from "./dtos/query-claim-shop.dto";
import { VerificationCliamShopDto } from "./dtos/verification-claim-shop.dto";
import { OTP } from "src/otp/enitities/otp.entity";
import { VerifyOtpDto } from "./dtos/verify-otp.dto";
import { QuerySimilarShopsDto } from "./dtos/query-similar-shops.dto";

@ApiTags("Claim Shop")
@Controller("claim-shops")
export class ClaimShopController {
  private readonly logger = new Logger(ClaimShopController.name);

  constructor(private readonly claimShopService: ClaimShopService) {}

  @Post()
  @ApiExtraModels(CreateCliamShopDto)
  @ApiBadRequestResponse({ description: "Error: Bad Request" })
  @ApiCreatedResponse({
    description: "The record has been successfully created.",
    type: ClaimShop,
  })
  @UsePipes(
    new ValidationPipe({
      whitelist: true,
      transform: true,
      forbidNonWhitelisted: true,
    })
  )
  async create(
    @Body() createCliamShopDto: CreateCliamShopDto
  ): Promise<ClaimShop> {
    return await this.claimShopService.create(createCliamShopDto);
  }

  @ApiOkResponse()
  @ApiForbiddenResponse({ description: "Forbidden." })
  @Get("filter")
  async filter(
    @Query(
      new ValidationPipe({
        whitelist: true,
        transform: true,
        forbidNonWhitelisted: true,
        forbidUnknownValues: true,
      })
    )
    query: QueryCliamShopDto,
    @Req() req,
  ) {
    this.logger.log(`filtering claim-shops: ${JSON.stringify(query)}`);
    query.route = req.route.path;
    return await this.claimShopService.findByFilter(query);
  }

  @ApiOkResponse()
  @ApiForbiddenResponse({ description: "Forbidden." })
  @Get("similar-shops")
  async similarShopsFilter(
    @Query(
      new ValidationPipe({
        whitelist: true,
        transform: true,
        forbidNonWhitelisted: true,
        forbidUnknownValues: true,
      })
    )
    query: QuerySimilarShopsDto,
    @Req() req,
  ) {
    this.logger.log(`similarShops filtering: ${JSON.stringify(query)}`);
    query.route = req.route.path;
    return await this.claimShopService.similarShopsFilter(query);
  }

  @ApiOkResponse({ type: ClaimShop })
  @ApiForbiddenResponse({ description: "Forbidden." })
  @ApiNotFoundResponse({ description: "Not found" })
  @Get(":id")
  async findOne(@Param("id") id: string): Promise<ClaimShop> {
    return await this.claimShopService.findOne(+id);
  }

  @ApiNoContentResponse()
  @ApiForbiddenResponse({ description: "Forbidden." })
  @ApiNotFoundResponse({ description: "Not found" })
  @ApiBadRequestResponse({ description: "Error: Bad Request" })
  @Patch(":id")
  @HttpCode(204)
  @UsePipes(
    new ValidationPipe({
      transform: true,
      whitelist: true,
      forbidUnknownValues: true,
      forbidNonWhitelisted: true,
    })
  )
  async update(
    @Param("id") id: string,
    @Body() updateCliamShopDto: UpdateCliamShopDto
  ): Promise<void> {
    await this.claimShopService.update(+id, updateCliamShopDto);
  }

  @ApiNoContentResponse()
  @ApiForbiddenResponse({ description: "Forbidden." })
  @ApiNotFoundResponse({ description: "Not found" })
  @Delete(":id")
  @HttpCode(204)
  async remove(@Param("id") id: string) {
    return await this.claimShopService.remove(+id);
  }

  @Post("/verification")
  @ApiExtraModels(VerificationCliamShopDto)
  @ApiBadRequestResponse({ description: "Error: Bad Request" })
  @ApiCreatedResponse({
    description: "The record has been successfully created.",
    type: ClaimShop,
  })
  @UsePipes(
    new ValidationPipe({
      whitelist: true,
      transform: true,
      forbidNonWhitelisted: true,
    })
  )
  async verificationAndSendOtp(
    @Body() verificationCliamShopDto: VerificationCliamShopDto
  ): Promise<ClaimShop> {
    return await this.claimShopService.verificationAndSendOtp(
      verificationCliamShopDto
    );
  }

  @Patch("/verify-otp/:id")
  @ApiNoContentResponse()
  @ApiForbiddenResponse({ description: "Forbidden." })
  @ApiNotFoundResponse({ description: "Not found" })
  @ApiBadRequestResponse({ description: "Error: Bad Request" })
  @HttpCode(204)
  @UsePipes(
    new ValidationPipe({
      whitelist: true,
      transform: true,
      forbidNonWhitelisted: true,
    })
  )
  async verifyOtp(
    @Param("id") id: string,
    @Body() verifyOtpDto: VerifyOtpDto
  ): Promise<void> {
    await this.claimShopService.verifyOtp(+id, verifyOtpDto);
  }
}
