import { VerifyOtpDto } from "./dtos/verify-otp.dto";
import { AwsService } from "./../aws/aws.service";
import { CreateCliamShopDto } from "./dtos/create-claim-shop.dto";
import {
  BadRequestException,
  Injectable,
  Logger,
  NotFoundException,
} from "@nestjs/common";
import { ClaimShop } from "./enitities/claim-shop.entity";
import { InjectRepository } from "@nestjs/typeorm";
import { Equal, ILike, Repository } from "typeorm";
import { UpdateCliamShopDto } from "./dtos/update-claim-shop.dto";
import { QueryCliamShopDto } from "./dtos/query-claim-shop.dto";
import { VerificationCliamShopDto } from "./dtos/verification-claim-shop.dto";
import { OtpService } from "src/otp/otp.service";
import { OTP } from "src/otp/enitities/otp.entity";
import { QuerySimilarShopsDto } from "./dtos/query-similar-shops.dto";
import { PaginationService } from "src/utils/pagination/pagination-util.service";
import IPaginationResult from "src/utils/pagination/interface/pagination-result-interface";

@Injectable()
export class ClaimShopService {
  private readonly logger = new Logger(ClaimShopService.name);

  constructor(
    @InjectRepository(ClaimShop)
    private readonly claimShopRepository: Repository<ClaimShop>,
    private readonly awsService: AwsService,
    private readonly otpService: OtpService,
    private paginationService: PaginationService,
  ) {}

  async create(createCliamShopDto: CreateCliamShopDto): Promise<ClaimShop> {
    try {
      const existingClaimShop = await this.claimShopRepository.findOneBy({
        shopOwnerContactNumber: createCliamShopDto.shopOwnerContactNumber,
      });

      if (existingClaimShop) {
        throw new BadRequestException(
          "Shop with that mobile number already exists.",
        );
      }

      const claimShop =
        await this.claimShopRepository.create(createCliamShopDto);

      const savedClaimShop = await this.claimShopRepository.save(claimShop);

      const shopOwnerCancelledChequeImageUrl = await this.awsService.upload(
        `${savedClaimShop.id}-cheque`,
        savedClaimShop.shopOwnerCancelledChequeImage,
      );
      const storeFrontPictureUrl = await this.awsService.upload(
        `${savedClaimShop.id}-store-picture`,
        savedClaimShop.storeFrontPicture,
      );

      return await this.claimShopRepository.save({
        ...savedClaimShop,
        shopOwnerCancelledChequeImage: shopOwnerCancelledChequeImageUrl,
        storeFrontPicture: storeFrontPictureUrl,
      });
    } catch (error) {
      this.logger.error(error, error?.stack);
      throw error;
    }
  }

  async findAll(query: QueryCliamShopDto): Promise<ClaimShop[]> {
    try {
      const queryBuilderObj = this.claimShopRepository.createQueryBuilder("t");
      queryBuilderObj.where({ ...query });
      queryBuilderObj.addOrderBy("t.id", "ASC");
      return queryBuilderObj.getMany();
    } catch (error) {
      this.logger.error(error, error?.stack);
      throw error;
    }
  }

  async findByFilter(
    query: QueryCliamShopDto,
  ): Promise<IPaginationResult<ClaimShop>> {
    try {
      const { name } = query;

      const queryBuilderObj = this.claimShopRepository.createQueryBuilder("t");
      queryBuilderObj.leftJoinAndSelect("t.categories", "c");
      queryBuilderObj.leftJoinAndSelect("t.subCategories", "sc");

      if (name && name.length) {
        queryBuilderObj.where(`t.name ILIKE :name`, {
          name: `%${name}%`,
        });
      }

      queryBuilderObj.addOrderBy("t.id", "ASC");
      queryBuilderObj.groupBy("");

      const results = await this.paginationService.paginate<ClaimShop>(
        queryBuilderObj,
        query,
      );

      return results;
    } catch (error) {
      this.logger.error(error, error?.stack);
      throw error;
    }
  }

  async similarShopsFilter(
    query: QuerySimilarShopsDto
  ): Promise<IPaginationResult<ClaimShop>> {
    try {
      const { categoryIds, subCategoryIds, currentShopId } = query;
      const queryBuilderObj = this.claimShopRepository.createQueryBuilder("t");
      queryBuilderObj.leftJoinAndSelect("t.categories", "c");
      queryBuilderObj.leftJoinAndSelect("t.subCategories", "sc");

      if (categoryIds && categoryIds.length) {
        queryBuilderObj.andWhere(`c.id IN (:...categoryIds)`, {
          categoryIds: categoryIds,
        });
      }

      if (subCategoryIds && subCategoryIds.length) {
        queryBuilderObj.andWhere(`sc.id IN (:...subCategoryIds)`, {
          subCategoryIds: subCategoryIds,
        });
      }

      queryBuilderObj.andWhere(`t.id <> :currentShopId`, {
        currentShopId: currentShopId,
      });

      queryBuilderObj.addOrderBy("t.id", "ASC");
      queryBuilderObj.select([
        "t.id",
        "t.name",
        "t.address",
        "t.lat",
        "t.long",
      ]);

      return await this.paginationService.paginate<ClaimShop>(
        queryBuilderObj,
        query,
      );
    } catch (error) {
      this.logger.error(error, error?.stack);
      throw error;
    }
  }

  async findOne(id: number): Promise<ClaimShop> {
    try {
      let claimShop;
      try {
        claimShop = await this.claimShopRepository.findOneOrFail({
          where: {
            id: Equal(id),
          },
          relations: ["categories", "subCategories"],
        });
      } catch (err) {
        throw new NotFoundException(`Could not find a record with id: ${id}`);
      }

      return claimShop;
    } catch (error) {
      this.logger.error(error, error?.stack);
      throw error;
    }
  }

  async update(
    id: number,
    updateCliamShopDto: UpdateCliamShopDto,
  ): Promise<ClaimShop> {
    try {
      const claimShop = await this.findOne(id);

      if (updateCliamShopDto?.storeFrontPicture) {
        updateCliamShopDto.storeFrontPicture = await this.awsService.upload(
          `${id}-store-picture`,
          updateCliamShopDto.storeFrontPicture,
        );
      }

      if (updateCliamShopDto?.shopOwnerCancelledChequeImage) {
        updateCliamShopDto.shopOwnerCancelledChequeImage =
          await this.awsService.upload(
            `${id}-cheque`,
            updateCliamShopDto.shopOwnerCancelledChequeImage,
          );
      }

      const savedClaimShop = await this.claimShopRepository.save({
        ...claimShop,
        ...updateCliamShopDto,
      });

      return savedClaimShop;
    } catch (error) {
      this.logger.error(error, error?.stack);
      throw error;
    }
  }

  async remove(id: number): Promise<void> {
    try {
      await this.findOne(id);
      await this.claimShopRepository.delete(id);
    } catch (error) {
      this.logger.error(error, error?.stack);
      throw error;
    }
  }

  async verificationAndSendOtp(
    verificationCliamShopDto: VerificationCliamShopDto,
  ): Promise<ClaimShop> {
    try {
      const existingClaimShop = await this.claimShopRepository.findOneBy({
        shopOwnerContactNumber: verificationCliamShopDto.shopOwnerContactNumber,
        address: ILike(verificationCliamShopDto.address),
      });

      if (!existingClaimShop) {
        throw new NotFoundException(
          "The record with given details could not be found.",
        );
      }

      const otpRecord: OTP = await this.otpService.create({
        mobileNumber: verificationCliamShopDto.shopOwnerContactNumber,
      });

      const res = await this.awsService.sendSMS(otpRecord);

      return { ...existingClaimShop, ...res };
    } catch (error) {
      this.logger.error(error, error?.stack);
      throw error;
    }
  }

  async verifyOtp(id: number, verifyOtpDto: VerifyOtpDto): Promise<void> {
    try {
      await this.otpService.verifyOTP(
        verifyOtpDto.mobileNumber,
        verifyOtpDto.otp,
      );

      await this.findOne(id);
      await this.claimShopRepository.update({ id: id }, { isClaimed: true });
    } catch (error) {
      this.logger.error(error, error?.stack);
      throw error;
    }
  }
}
