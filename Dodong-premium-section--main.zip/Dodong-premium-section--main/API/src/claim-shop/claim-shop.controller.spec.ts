import { Test, TestingModule } from '@nestjs/testing';
import { ClaimShopController } from './claim-shop.controller';

describe('ClaimShopController', () => {
  let controller: ClaimShopController;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      controllers: [ClaimShopController],
    }).compile();

    controller = module.get<ClaimShopController>(ClaimShopController);
  });

  it('should be defined', () => {
    expect(controller).toBeDefined();
  });
});
