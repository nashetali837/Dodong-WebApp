import { ApiProperty } from "@nestjs/swagger";
import { Transform } from "class-transformer";
import { IsNotEmpty, IsString, Matches } from "class-validator";

export class VerificationCliamShopDto {
  @ApiProperty({ required: true })
  @IsNotEmpty()
  @IsString()
  @Transform(({ value }) => value?.trim())
  address: string;

  @ApiProperty({ required: true })
  @IsNotEmpty()
  @IsString()
  @Transform(({ value }) => value?.trim())
  @Matches(/^\+([1-9]{1})(\d{1,2})([1-9]{1})(\d{9})$/, {
    message:
      "Please provide a valid shop owner contact number with country code.",
  })
  shopOwnerContactNumber: string;
}
