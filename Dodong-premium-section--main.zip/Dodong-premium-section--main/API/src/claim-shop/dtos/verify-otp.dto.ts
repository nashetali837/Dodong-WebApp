import { ApiProperty } from "@nestjs/swagger";
import { Transform } from "class-transformer";
import {
  IsNotEmpty,
  IsString,
  Matches,
  MaxLength,
  MinLength,
} from "class-validator";

export class VerifyOtpDto {
  @ApiProperty({ required: true })
  @IsNotEmpty()
  @IsString()
  @Transform(({ value }) => value?.trim())
  @MinLength(6)
  @MaxLength(6)
  otp: string;

  @ApiProperty({ required: true })
  @IsNotEmpty()
  @IsString()
  @Transform(({ value }) => value?.trim())
  @Matches(/^\+([1-9]{1})(\d{1,2})([1-9]{1})(\d{9})$/, {
    message:
      "Please provide a valid shop owner contact number with country code.",
  })
  mobileNumber: string;
}
