import { ApiProperty } from "@nestjs/swagger";
import { Transform } from "class-transformer";
import { IsOptional, IsPositive } from "class-validator";
import { PaginationDto } from "src/utils/pagination/dto/pagination.dto";

export class QuerySimilarShopsDto extends PaginationDto {
  @ApiProperty({ required: false, isArray: true })
  @Transform(({ value }) => {
    if (typeof value === "string") {
      value = [value];
    }

    return value.map(Number);
  })
  @IsOptional()
  @IsPositive({ each: true })
  categoryIds?: number[];

  @ApiProperty({ required: false, isArray: true })
  @Transform(({ value }) => {
    if (typeof value === "string") {
      value = [value];
    }

    return value.map(Number);
  })
  @IsOptional()
  @IsPositive({ each: true })
  subCategoryIds?: number[];

  @ApiProperty({ required: true })
  @Transform(({ value }) => {
    return Number(value);
  })
  @IsOptional()
  @IsPositive()
  currentShopId: number;
}
