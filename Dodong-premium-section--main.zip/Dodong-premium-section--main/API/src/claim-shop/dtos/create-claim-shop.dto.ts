import { ApiProperty } from "@nestjs/swagger";
import { Transform, Type } from "class-transformer";
import {
  ArrayMinSize,
  IsArray,
  IsLatitude,
  IsLongitude,
  IsNotEmpty,
  IsString,
  Matches,
} from "class-validator";
import { Category } from "src/category/entities/category.entity";
import { SubCategory } from "src/sub-category/entities/sub-category.entity";

export class CreateCliamShopDto {
  @ApiProperty({ required: true })
  @IsNotEmpty()
  @IsString()
  @Transform(({ value }) => value?.trim())
  name: string;

  @ApiProperty({ required: true })
  @IsNotEmpty()
  @IsString()
  @Transform(({ value }) => value?.trim())
  intro: string;

  @ApiProperty({ required: true })
  @IsNotEmpty()
  @IsString()
  @Transform(({ value }) => value?.trim())
  address: string;

  @ApiProperty({ required: true })
  @IsNotEmpty()
  @IsString()
  @Transform(({ value }) => value?.trim())
  city: string;

  @ApiProperty({ required: true })
  @IsNotEmpty()
  @IsString()
  @Transform(({ value }) => value?.trim())
  state: string;

  @ApiProperty({ required: true })
  @IsNotEmpty()
  @IsString()
  @Transform(({ value }) => value?.trim())
  @Matches(/^[1-9][0-9]{5}$/, {
    message: "Pin should be of six digit numbers.",
  })
  pin: string;

  @ApiProperty({ required: true })
  @IsNotEmpty()
  @IsString()
  @Transform(({ value }) => value?.trim())
  shopType: string;

  @ApiProperty({ type: Category, required: true, isArray: true })
  @IsNotEmpty()
  @IsArray()
  @ArrayMinSize(1)
  categories: Category[];

  @ApiProperty({ type: SubCategory, required: true, isArray: true })
  @IsNotEmpty()
  @IsArray()
  @ArrayMinSize(1)
  subCategories: SubCategory[];

  @ApiProperty({ required: true })
  @IsNotEmpty()
  @IsString()
  @Transform(({ value }) => value?.trim())
  shopOwnerName: string;

  @ApiProperty({ required: true })
  @IsNotEmpty()
  @IsString()
  @Transform(({ value }) => value?.trim())
  @Matches(/^\+([1-9]{1})(\d{1,2})([1-9]{1})(\d{9})$/, {
    message:
      "Please provide a valid shop owner contact number with country code.",
  })
  shopOwnerContactNumber: string;

  @ApiProperty({ required: true })
  @IsNotEmpty()
  @IsString()
  @Transform(({ value }) => value?.trim())
  @Matches(/^data:image\/\w+;base64,/, {
    message: "Please provide a valid cancelled cheque image.",
  })
  shopOwnerCancelledChequeImage: string;

  @ApiProperty({ required: true })
  @IsNotEmpty()
  @IsString()
  @Transform(({ value }) => value?.trim())
  @Matches(/^data:image\/\w+;base64,/, {
    message: "Please provide a valid store front picture.",
  })
  storeFrontPicture: string;

  @ApiProperty({ required: true })
  @Type(() => Number)
  @IsLatitude()
  lat: number;

  @ApiProperty({ required: true })
  @Type(() => Number)
  @IsLongitude()
  long: number;

  @ApiProperty({ required: true })
  @IsNotEmpty()
  @IsString()
  @Transform(({ value }) => value?.trim())
  capturedAddress: string;
}
