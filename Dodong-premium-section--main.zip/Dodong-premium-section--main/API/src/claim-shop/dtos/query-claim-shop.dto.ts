import { ApiProperty } from "@nestjs/swagger";
import { Transform } from "class-transformer";
import { IsOptional, IsPositive, IsString } from "class-validator";
import { PaginationDto } from "src/utils/pagination/dto/pagination.dto";

export class QueryCliamShopDto extends PaginationDto {
  @ApiProperty({ required: false })
  @IsOptional()
  @IsString()
  name?: string;
}
