import { ApiProperty, PartialType } from "@nestjs/swagger";
import { CreateCliamShopDto } from "./create-claim-shop.dto";
import { IsBoolean, IsNotEmpty, IsOptional } from "class-validator";

export class ClaimShopMetaInfo {
  isPaid?: boolean;
  razorpay_payment_id?: string;
  razorpay_signature?: string;
  razorpay_subscription_id?: string;
  isTrail?: boolean;
  trailStartedAt?: Date;
}

export class UpdateCliamShopDto extends PartialType(CreateCliamShopDto) {
  @ApiProperty({ required: false })
  @IsOptional()
  @IsBoolean()
  @IsNotEmpty()
  isClaimed?: boolean;

  @ApiProperty({ required: false })
  @IsOptional()
  metaInfo?: ClaimShopMetaInfo;
}
