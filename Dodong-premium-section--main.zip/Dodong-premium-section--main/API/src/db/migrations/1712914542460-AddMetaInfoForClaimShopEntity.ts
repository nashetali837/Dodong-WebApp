import { MigrationInterface, QueryRunner } from "typeorm";

export class AddMetaInfoForClaimShopEntity1712914542460 implements MigrationInterface {
    name = 'AddMetaInfoForClaimShopEntity1712914542460'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "claimshop" ADD "metaInfo" jsonb NOT NULL DEFAULT '{}'`);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "claimshop" DROP COLUMN "metaInfo"`);
    }

}
