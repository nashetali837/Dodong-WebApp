import { MigrationInterface, QueryRunner } from 'typeorm';

export class AddOTPEntity1711777317572 implements MigrationInterface {
  name = 'AddOTPEntity1711777317572';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `CREATE TABLE "otp" ("id" SERIAL NOT NULL, "createdAt" TIMESTAMP NOT NULL DEFAULT now(), "updatedAt" TIMESTAMP NOT NULL DEFAULT now(), "mobileNumber" character varying NOT NULL, "otp" character varying NOT NULL, CONSTRAINT "user_unique_mobile_number" UNIQUE ("mobileNumber"), CONSTRAINT "PK_32556d9d7b22031d7d0e1fd6723" PRIMARY KEY ("id"))`,
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`DROP TABLE "otp"`);
  }
}
