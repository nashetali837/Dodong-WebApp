import { MigrationInterface, QueryRunner } from 'typeorm';

export class AddEntitites1711878644723 implements MigrationInterface {
  name = 'AddEntitites1711878644723';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `CREATE TABLE "category" ("id" SERIAL NOT NULL, "createdAt" TIMESTAMP NOT NULL DEFAULT now(), "updatedAt" TIMESTAMP NOT NULL DEFAULT now(), "label" character varying NOT NULL, CONSTRAINT "PK_9c4e4a89e3674fc9f382d733f03" PRIMARY KEY ("id"))`,
    );
    await queryRunner.query(
      `CREATE TABLE "claimshop" ("id" SERIAL NOT NULL, "createdAt" TIMESTAMP NOT NULL DEFAULT now(), "updatedAt" TIMESTAMP NOT NULL DEFAULT now(), "name" character varying NOT NULL, "intro" character varying NOT NULL, "address" character varying NOT NULL, "city" character varying NOT NULL, "state" character varying NOT NULL, "pin" character varying NOT NULL, "shopType" character varying NOT NULL, "shopOwnerName" character varying NOT NULL, "shopOwnerContactNumber" character varying NOT NULL, "shopOwnerCancelledChequeImage" character varying NOT NULL, "storeFrontPicture" character varying NOT NULL, "lat" double precision NOT NULL, "long" double precision NOT NULL, "capturedAddress" character varying NOT NULL, "isClaimed" boolean NOT NULL DEFAULT false, CONSTRAINT "PK_643e577da730e04e7cd0f3dd33b" PRIMARY KEY ("id"))`,
    );
    await queryRunner.query(
      `CREATE TABLE "subcategory" ("id" SERIAL NOT NULL, "createdAt" TIMESTAMP NOT NULL DEFAULT now(), "updatedAt" TIMESTAMP NOT NULL DEFAULT now(), "label" character varying NOT NULL, CONSTRAINT "PK_5ad0b82340b411f9463c8e9554d" PRIMARY KEY ("id"))`,
    );
    await queryRunner.query(
      `CREATE TABLE "claimshop_category" ("claimshop_id" integer NOT NULL, "category_id" integer NOT NULL, CONSTRAINT "PK_ea61e70740a9223a66ac95833ea" PRIMARY KEY ("claimshop_id", "category_id"))`,
    );
    await queryRunner.query(
      `CREATE INDEX "IDX_d90948552b93fa95c238c0dbfa" ON "claimshop_category" ("claimshop_id") `,
    );
    await queryRunner.query(
      `CREATE INDEX "IDX_ff6fb3814fb2e34dc82dff9f7d" ON "claimshop_category" ("category_id") `,
    );
    await queryRunner.query(
      `CREATE TABLE "claimshop_subcategory" ("claimshop_id" integer NOT NULL, "subcategory_id" integer NOT NULL, CONSTRAINT "PK_08aa650b2f964e579a3d6e6b125" PRIMARY KEY ("claimshop_id", "subcategory_id"))`,
    );
    await queryRunner.query(
      `CREATE INDEX "IDX_931ebd2d1806dfda8d4b5c829e" ON "claimshop_subcategory" ("claimshop_id") `,
    );
    await queryRunner.query(
      `CREATE INDEX "IDX_a1f680ca516e9c2a4e61926317" ON "claimshop_subcategory" ("subcategory_id") `,
    );
    await queryRunner.query(
      `ALTER TABLE "claimshop_category" ADD CONSTRAINT "FK_d90948552b93fa95c238c0dbfa1" FOREIGN KEY ("claimshop_id") REFERENCES "claimshop"("id") ON DELETE CASCADE ON UPDATE CASCADE`,
    );
    await queryRunner.query(
      `ALTER TABLE "claimshop_category" ADD CONSTRAINT "FK_ff6fb3814fb2e34dc82dff9f7df" FOREIGN KEY ("category_id") REFERENCES "category"("id") ON DELETE NO ACTION ON UPDATE NO ACTION`,
    );
    await queryRunner.query(
      `ALTER TABLE "claimshop_subcategory" ADD CONSTRAINT "FK_931ebd2d1806dfda8d4b5c829ec" FOREIGN KEY ("claimshop_id") REFERENCES "claimshop"("id") ON DELETE CASCADE ON UPDATE CASCADE`,
    );
    await queryRunner.query(
      `ALTER TABLE "claimshop_subcategory" ADD CONSTRAINT "FK_a1f680ca516e9c2a4e619263173" FOREIGN KEY ("subcategory_id") REFERENCES "subcategory"("id") ON DELETE NO ACTION ON UPDATE NO ACTION`,
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "claimshop_subcategory" DROP CONSTRAINT "FK_a1f680ca516e9c2a4e619263173"`,
    );
    await queryRunner.query(
      `ALTER TABLE "claimshop_subcategory" DROP CONSTRAINT "FK_931ebd2d1806dfda8d4b5c829ec"`,
    );
    await queryRunner.query(
      `ALTER TABLE "claimshop_category" DROP CONSTRAINT "FK_ff6fb3814fb2e34dc82dff9f7df"`,
    );
    await queryRunner.query(
      `ALTER TABLE "claimshop_category" DROP CONSTRAINT "FK_d90948552b93fa95c238c0dbfa1"`,
    );
    await queryRunner.query(
      `DROP INDEX "public"."IDX_a1f680ca516e9c2a4e61926317"`,
    );
    await queryRunner.query(
      `DROP INDEX "public"."IDX_931ebd2d1806dfda8d4b5c829e"`,
    );
    await queryRunner.query(`DROP TABLE "claimshop_subcategory"`);
    await queryRunner.query(
      `DROP INDEX "public"."IDX_ff6fb3814fb2e34dc82dff9f7d"`,
    );
    await queryRunner.query(
      `DROP INDEX "public"."IDX_d90948552b93fa95c238c0dbfa"`,
    );
    await queryRunner.query(`DROP TABLE "claimshop_category"`);
    await queryRunner.query(`DROP TABLE "subcategory"`);
    await queryRunner.query(`DROP TABLE "claimshop"`);
    await queryRunner.query(`DROP TABLE "category"`);
  }
}
