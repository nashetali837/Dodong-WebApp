export class GoogleApisConfigService {
  private static endpoints = {
    addressLookup: `https://maps.googleapis.com/maps/api/geocode/json`,
    distanceMatrix: `https://maps.googleapis.com/maps/api/distancematrix/json`,
  };

  static getEndpoint(endpointKey: string): string {
    if (!(endpointKey in this.endpoints)) {
      throw new Error(`${endpointKey} endpoint key doesn't exists`);
    }
    return this.endpoints[endpointKey];
  }
}
