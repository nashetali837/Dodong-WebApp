import { Controller, Get, Logger, Query } from '@nestjs/common';
import { GoogleApisService } from './google-apis.service';
import {
  ApiForbiddenResponse,
  ApiNotFoundResponse,
  ApiOkResponse,
  ApiTags,
} from '@nestjs/swagger';

@ApiTags('Google APIs')
@Controller('google-apis')
export class GoogleApisController {
  private readonly logger = new Logger(GoogleApisController.name);

  constructor(private readonly googleApisService: GoogleApisService) {}

  @ApiOkResponse({ type: '' })
  @ApiForbiddenResponse({ description: 'Forbidden.' })
  @ApiNotFoundResponse({ description: 'Not found' })
  @Get('address-lookup')
  async addressLookup(
    @Query('lat') lat: number,
    @Query('long') long: number,
  ): Promise<any> {
    return await this.googleApisService.addressLookup(+lat, +long);
  }

  @ApiOkResponse({ type: '' })
  @ApiForbiddenResponse({ description: 'Forbidden.' })
  @ApiNotFoundResponse({ description: 'Not found' })
  @Get('distance-matrix')
  async distanceMatrix(
    @Query('origins') origins: string,
    @Query('destinations') destinations: string,
  ): Promise<any> {
    return await this.googleApisService.distanceMatrix(origins, destinations);
  }
}
