import { HttpService } from "@nestjs/axios";
import { HttpException, Injectable, Logger } from "@nestjs/common";
import { AxiosInstance, AxiosRequestConfig } from "axios";
import { lastValueFrom, map } from "rxjs";
import { GoogleApisConfigService } from "./google-apis.config";

@Injectable()
export class HttpGoogleApisService {
  private readonly logger = new Logger(HttpGoogleApisService.name);

  constructor(private http: HttpService) {
    this.configureRequestInterceptor(<AxiosInstance>this.http.axiosRef);
    this.configureResponseInterceptor(<AxiosInstance>this.http.axiosRef);
  }

  private configureRequestInterceptor(axios: AxiosInstance): void {
    axios.interceptors.request.use((request) => {
      const log = {
        method: request?.method,
        baseURL: request?.baseURL,
        url: request?.url,
        payload: request?.data,
      };
      this.logger.log({ message: "Google API service", data: log });
      return request;
    });
  }

  private configureResponseInterceptor(axios: AxiosInstance): void {
    axios.interceptors.response.use(
      (response) => {
        const log = {
          status: response?.status,
          statusText: response?.statusText,
          methods: response?.config?.method,
          data: response?.data,
          baseURL: response?.config?.baseURL,
          url: response?.config?.url,
          payload: response?.config?.data,
        };
        this.logger.log({ message: "Google API response", data: log });
        return response;
      },
      (error) => {
        const errorLog = {
          status: error?.status || error?.response?.status,
          statusText: error?.response?.statusText,
          methods: error?.response?.config?.method,
          baseURL: error?.response?.config?.baseURL,
          url: error?.response?.config?.url,
          payload: error?.response?.config?.data,
        };

        this.logger.error(
          `Google APIS reques: ${errorLog.baseURL}/${errorLog.url} failed with status ${errorLog.status} : ${errorLog.payload}`
        );
        throw new HttpException(
          error?.response?.data?.errors || error?.message,
          error?.response?.status
        );
      }
    );
  }

  private getConfig(): AxiosRequestConfig {
    return {
      headers: { "Content-Type": "application/json" },
    };
  }

  private getUrl(endpointKey: string) {
    if (!process.env.GOOGLE_API_KEY) {
      throw new Error(`Google API Key not found.`);
    }

    const url: URL = new URL(GoogleApisConfigService.getEndpoint(endpointKey));
    url.searchParams.append("key", process.env.GOOGLE_API_KEY);

    return url;
  }

  async addressLookup(lat: number, long: number): Promise<any> {
    const url: URL = this.getUrl("addressLookup");
    url.searchParams.append("latlng", `${lat},${long}`);
    const urlStr = url.toString();

    try {
      return await lastValueFrom(
        this.http
          .get(urlStr, { ...this.getConfig() })
          .pipe(map((response) => response.data))
      );
    } catch (err) {
      this.logger.error(err, err?.stack);
      throw err;
    }
  }

  async distanceMatrix(origin: string, destination: string): Promise<any> {
    const url: URL = this.getUrl("distanceMatrix");
    url.searchParams.append("origins", origin);
    url.searchParams.append("destinations", destination);
    const urlStr: string = url.toString();

    try {
      return await lastValueFrom(
        this.http
          .get(urlStr, { ...this.getConfig() })
          .pipe(map((response) => response.data))
      );
    } catch (err) {
      this.logger.error(err, err?.stack);
      throw err;
    }
  }
}
