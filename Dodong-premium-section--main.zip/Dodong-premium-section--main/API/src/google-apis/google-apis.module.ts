import { Module } from '@nestjs/common';
import { GoogleApisService } from './google-apis.service';
import { GoogleApisController } from './google-apis.controller';
import { HttpGoogleApisService } from './http-google-apis.service';
import { HttpModule } from '@nestjs/axios';

@Module({
  imports: [HttpModule.register({})],
  providers: [GoogleApisService, HttpGoogleApisService],
  controllers: [GoogleApisController],
  exports: [GoogleApisService],
})
export class GoogleApisModule {}
