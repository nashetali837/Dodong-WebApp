import { Injectable, Logger } from '@nestjs/common';
import { HttpGoogleApisService } from './http-google-apis.service';

@Injectable()
export class GoogleApisService {
  private readonly logger = new Logger(GoogleApisService.name);

  constructor(private httpGoogleApisService: HttpGoogleApisService) {}

  async addressLookup(lat: number, long: number): Promise<any> {
    try {
      return await this.httpGoogleApisService.addressLookup(lat, long);
    } catch (err) {
      this.logger.error(err, err?.stack);
      throw err;
    }
  }

  async distanceMatrix(origins: string, destinations: string): Promise<any> {
    try {
      return await this.httpGoogleApisService.distanceMatrix(
        origins,
        destinations,
      );
    } catch (err) {
      this.logger.error(err, err?.stack);
      throw err;
    }
  }
}
