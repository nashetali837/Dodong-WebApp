import {
  Controller,
  Logger,
  Post,
  UsePipes,
  ValidationPipe,
} from "@nestjs/common";
import { RazorpayService } from "./razorpay.service";
import {
  ApiBadRequestResponse,
  ApiCreatedResponse,
  ApiTags,
} from "@nestjs/swagger";
import { CreateSubscriptionDto } from "./dtos/create-subscription.dto";

@ApiTags("Razorpay APIs")
@Controller("razorpay")
export class RazorpayController {
  private readonly logger = new Logger(RazorpayController.name);

  constructor(private readonly razorpayService: RazorpayService) {}

  @Post("/subscriptions")
  @ApiBadRequestResponse({ description: "Error: Bad Request" })
  @ApiCreatedResponse({
    description: "The record has been successfully created.",
    type: CreateSubscriptionDto,
  })
  @UsePipes(
    new ValidationPipe({
      whitelist: true,
      transform: true,
      forbidNonWhitelisted: true,
    })
  )
  async createSubscription(): Promise<CreateSubscriptionDto> {
    const subscriptionData = await this.razorpayService.createSubscription();
    return { ...subscriptionData, key_id: process.env.RAZORPAY_KEY_ID };
  }
}
