import { Injectable, Logger } from "@nestjs/common";
import { InjectRazorpay } from "nestjs-razorpay";
import Razorpay from "razorpay";

@Injectable()
export class RazorpayService {
  private readonly logger = new Logger(RazorpayService.name);

  constructor(@InjectRazorpay() private readonly razorpayClient: Razorpay) {}

  async createSubscription(): Promise<any> {
    try {
      return await this.razorpayClient.subscriptions.create({
        plan_id: process.env.RAZORPAY_PLAN_ID,
        customer_notify: 1,
        total_count: 1,
      });
    } catch (err) {
      this.logger.error(err, err?.stack);
      throw err;
    }
  }
}
