export class CreateSubscriptionDto {
  id: string;
  entity: string;
  plan_id: string;
  status: string;
  quantity: number;
  notes: [];
  auth_attempts: number;
  total_count: number;
  paid_count: number;
  customer_notify: boolean;
  created_at: number;
  short_url: string;
  has_scheduled_changes: boolean;
  source: string;
  remaining_count: number;
}
