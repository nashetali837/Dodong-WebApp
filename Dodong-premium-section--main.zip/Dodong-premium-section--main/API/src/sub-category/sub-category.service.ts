import {
  HttpException,
  Injectable,
  Logger,
  NotFoundException,
} from "@nestjs/common";
import { SubCategory } from "./entities/sub-category.entity";
import { CreateSubCategoryDto } from "./dtos/create-sub-category.dto";
import { Equal, Repository } from "typeorm";
import { InjectRepository } from "@nestjs/typeorm";
import { QuerySubCategoryDto } from "./dtos/query-sub-category.dto";
import { UpdateSubCategoryDto } from "./dtos/update-sub-category.dto";

@Injectable()
export class SubCategoryService {
  private readonly logger = new Logger(SubCategoryService.name);

  constructor(
    @InjectRepository(SubCategory)
    private readonly subCategoryRepository: Repository<SubCategory>,
  ) {}
  async create(
    createSubCreateSubCategoryDto: CreateSubCategoryDto,
  ): Promise<SubCategory> {
    try {
      const subCategory = await this.subCategoryRepository.create(
        createSubCreateSubCategoryDto,
      );

      return await this.subCategoryRepository.save(subCategory);
    } catch (error) {
      this.logger.error(error, error?.stack);
      throw error;
    }
  }

  async findAll(query: QuerySubCategoryDto): Promise<SubCategory[]> {
    try {
      const queryBuilderObj =
        this.subCategoryRepository.createQueryBuilder("t");
      queryBuilderObj.where({ ...query });
      queryBuilderObj.addOrderBy("t.id", "ASC");
      return queryBuilderObj.getMany();
    } catch (error) {
      this.logger.error(error, error?.stack);
      throw error;
    }
  }

  async findByFilter(query: QuerySubCategoryDto): Promise<SubCategory[]> {
    try {
      const { label, categoryIds } = query;
      const queryBuilderObj =
        this.subCategoryRepository.createQueryBuilder("t");

      if (label && label.length) {
        queryBuilderObj.andWhere(`t.name ILIKE :label`, {
          label: `%${label}%`,
        });
      }

      if (categoryIds && categoryIds.length) {
        queryBuilderObj.andWhere(`t.categoryId IN (:...categoryIds)`, {
          categoryIds: categoryIds,
        });
      }

      queryBuilderObj.addOrderBy("t.id", "ASC");
      return queryBuilderObj.getMany();
    } catch (error) {
      this.logger.error(error, error?.stack);
      throw error;
    }
  }

  async findOne(id: number): Promise<SubCategory> {
    try {
      let subCategory;
      try {
        subCategory = await this.subCategoryRepository.findOneOrFail({
          where: {
            id: Equal(id),
          },
        });
      } catch (err) {
        throw new NotFoundException(
          `Could not find a record with id: ${id}`,
        );
      }

      return subCategory;
    } catch (error) {
      this.logger.error(error, error?.stack);
      throw error;
    }
  }

  async update(
    id: number,
    updateSubCategoryDto: UpdateSubCategoryDto,
  ): Promise<void> {
    try {
      await this.findOne(id);
      const updateResult = await this.subCategoryRepository.update(
        id,
        updateSubCategoryDto,
      );

      if (updateResult.affected < 1) {
        throw new HttpException(`Unable to update`, 500);
      }
    } catch (error) {
      this.logger.error(error, error?.stack);
      throw error;
    }
  }

  async remove(id: number): Promise<void> {
    try {
      await this.findOne(id);
      await this.subCategoryRepository.delete(id);
    } catch (error) {
      this.logger.error(error, error?.stack);
      throw error;
    }
  }
}
