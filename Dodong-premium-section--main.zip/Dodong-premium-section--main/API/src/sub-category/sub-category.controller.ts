import {
  Body,
  Controller,
  Delete,
  Get,
  HttpCode,
  HttpException,
  Logger,
  Param,
  Patch,
  Post,
  Query,
  UsePipes,
  ValidationPipe,
} from "@nestjs/common";
import { SubCategoryService } from "./sub-category.service";
import { CreateSubCategoryDto } from "./dtos/create-sub-category.dto";
import { SubCategory } from "./entities/sub-category.entity";
import {
  ApiBadRequestResponse,
  ApiCreatedResponse,
  ApiExtraModels,
  ApiForbiddenResponse,
  ApiNoContentResponse,
  ApiNotFoundResponse,
  ApiOkResponse,
  ApiTags,
} from "@nestjs/swagger";
import { QuerySubCategoryDto } from "./dtos/query-sub-category.dto";
import { UpdateSubCategoryDto } from "./dtos/update-sub-category.dto";

@ApiTags("Sub Category")
@Controller("sub-categories")
export class SubCategoryController {
  private readonly logger = new Logger(SubCategoryController.name);

  constructor(private readonly subCategoryService: SubCategoryService) {}

  @Post()
  @ApiExtraModels(CreateSubCategoryDto)
  @ApiBadRequestResponse({ description: "Error: Bad Request" })
  @ApiCreatedResponse({
    description: "The record has been successfully created.",
    type: SubCategory,
  })
  @UsePipes(
    new ValidationPipe({
      whitelist: true,
      transform: true,
      forbidNonWhitelisted: true,
    }),
  )
  async create(
    @Body() createSubCategoryDto: CreateSubCategoryDto,
  ): Promise<SubCategory> {
      return await this.subCategoryService.create(createSubCategoryDto);
  }

  @ApiOkResponse()
  @ApiForbiddenResponse({ description: "Forbidden." })
  @Get("filter")
  async filter(
    @Query(
      new ValidationPipe({
        whitelist: true,
        transform: true,
        forbidNonWhitelisted: true,
        forbidUnknownValues: true,
      }),
    )
    query: QuerySubCategoryDto,
  ) {
    this.logger.log(`filtering SubCategory: ${JSON.stringify(query)}`);

    return await this.subCategoryService.findByFilter(query);
  }

  @ApiOkResponse({ type: SubCategory })
  @ApiForbiddenResponse({ description: "Forbidden." })
  @ApiNotFoundResponse({ description: "Not found" })
  @Get(":id")
  async findOne(@Param("id") id: string): Promise<SubCategory> {
    return await this.subCategoryService.findOne(+id);
  }

  @ApiNoContentResponse()
  @ApiForbiddenResponse({ description: "Forbidden." })
  @ApiNotFoundResponse({ description: "Not found" })
  @ApiBadRequestResponse({ description: "Error: Bad Request" })
  @Patch(":id")
  @HttpCode(204)
  @UsePipes(
    new ValidationPipe({
      transform: true,
      whitelist: true,
      forbidUnknownValues: true,
      forbidNonWhitelisted: true,
    }),
  )
  async update(
    @Param("id") id: string,
    @Body() updateSubCategoryDto: UpdateSubCategoryDto,
  ): Promise<void> {
    await this.subCategoryService.update(+id, updateSubCategoryDto);
  }

  @ApiNoContentResponse()
  @ApiForbiddenResponse({ description: "Forbidden." })
  @ApiNotFoundResponse({ description: "Not found" })
  @Delete(":id")
  @HttpCode(204)
  async remove(@Param("id") id: string) {
    return await this.subCategoryService.remove(+id);
  }
}
