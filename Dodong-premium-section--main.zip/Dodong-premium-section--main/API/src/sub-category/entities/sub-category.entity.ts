import { Category } from "src/category/entities/category.entity";
import { ApiProperty } from "@nestjs/swagger";
import { ClaimShop } from "src/claim-shop/enitities/claim-shop.entity";
import { BaseEntity } from "src/core/entity/base.entity";
import { Column, Entity, ManyToMany, ManyToOne } from "typeorm";

@Entity({
  name: "subcategory",
})
export class SubCategory extends BaseEntity {
  @ApiProperty()
  @Column({ nullable: false })
  label: string;

  @ManyToMany(() => ClaimShop, (claimShop) => claimShop.subCategories)
  claimShops: ClaimShop[];

  @ApiProperty({ required: true })
  @Column({ nullable: false })
  categoryId: number;

  @ApiProperty({ type: () => Category })
  @ManyToOne((type) => Category, (category) => category.subCategories)
  category: Category;
}
