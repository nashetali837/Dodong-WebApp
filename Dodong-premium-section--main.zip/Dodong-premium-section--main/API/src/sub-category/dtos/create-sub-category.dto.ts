import { ApiProperty } from "@nestjs/swagger";
import { Transform } from "class-transformer";
import { IsNotEmpty, IsPositive, IsString } from "class-validator";

export class CreateSubCategoryDto {
  @ApiProperty({ required: true })
  @IsNotEmpty()
  @IsString()
  @Transform(({ value }) => value?.trim())
  label: string;

  @ApiProperty({ required: true })
  @IsPositive()
  categoryId: number;
}
