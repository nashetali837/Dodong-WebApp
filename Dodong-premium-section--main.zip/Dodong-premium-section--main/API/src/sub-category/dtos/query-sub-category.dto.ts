import { ApiProperty } from "@nestjs/swagger";
import { Transform } from "class-transformer";
import { IsOptional, IsPositive, IsString } from "class-validator";

export class QuerySubCategoryDto {
  @ApiProperty({ required: false })
  @IsOptional()
  @IsString()
  label?: string;

  @ApiProperty({ required: false, isArray: true })
  @Transform(({ value }) => {
    if (typeof value === "string") {
      value = [value];
    }

    return value.map(Number);
  })
  @IsOptional()
  @IsPositive({ each: true })
  categoryIds?: number[];
}
