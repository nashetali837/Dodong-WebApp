import * as dotenv from "dotenv";
import {
  TypeOrmModuleAsyncOptions,
  TypeOrmModuleOptions,
} from "@nestjs/typeorm";
import * as path from "path";
import { PostgresConnectionOptions } from "typeorm/driver/postgres/PostgresConnectionOptions";

dotenv.config();

const distPath = "dist";
const buildPath = ".build";
let entitiesPath = "/src/**/*.entity.{js,ts}";
let migrations = `/src/db/migrations/*.js`;

if (__dirname.includes(".build")) {
  entitiesPath = path.join(buildPath, entitiesPath);
  migrations = path.join(buildPath, migrations);
} else {
  entitiesPath = path.join(distPath, entitiesPath);
  migrations = path.join(distPath, migrations);
}

export const ormConfig: PostgresConnectionOptions = {
  type: "postgres",
  host: process.env.DATABASE_HOST,
  port: parseInt(process.env.DATABASE_PORT, 10) || 5432,
  username: process.env.DATABASE_USERNAME,
  password: process.env.DATABASE_PASSWORD,
  database: process.env.DATABASE_NAME,
  synchronize: false,
  entities: [entitiesPath],
  migrations: [migrations],
  migrationsTableName: "type_orm_migration",
  logging: false,
  connectTimeoutMS: 1000,
  // ssl: true,
  // extra: {
  //   ssl: {
  //     rejectUnauthorized: false,
  //   },
  // },
};

export const typeORMAsyncConfig: TypeOrmModuleAsyncOptions = {
  useFactory: async (): Promise<TypeOrmModuleOptions> => {
    return ormConfig;
  },
};
