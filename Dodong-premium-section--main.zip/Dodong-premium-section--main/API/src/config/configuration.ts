import * as dotenv from "dotenv";
import { ThrottlerModuleOptions } from "@nestjs/throttler";

dotenv.config();

export interface AppConfigInterface {
  env: string;
  host: string;
  port: number;
  appUrl: string;
  throttle: ThrottlerModuleOptions;
}

export default () => ({
  env: process.env.NODE_ENV || "production",
  host: process.env.HOST || "localhost",
  port: parseInt(process.env.PORT) || 3000,
  get appUrl() {
    return `${this.env === "local" ? "http://" : "https://"}${this.host}${this.env === "local" ? `:${this.port}` : ""}`;
  },
  throttle: <ThrottlerModuleOptions>(<unknown>{
    ttl: process.env.THROTTLE_TTL || 60,
    limit: process.env.THROTTLE_LIMIT || 30,
  }),
});
