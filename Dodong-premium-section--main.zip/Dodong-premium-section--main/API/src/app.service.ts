import { Injectable } from "@nestjs/common";
import { ConfigService } from "@nestjs/config";

@Injectable()
export class AppService {
  constructor(private readonly configService: ConfigService) {}
  welcome(): string {
    return `Welcome to Premium Section API, please visit <a href="http://${this.configService.get<string>(
      "appUrl"
    )}/api">API Doc</a> for swagger doc!`;
  }
}
