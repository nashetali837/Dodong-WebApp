import { Module } from "@nestjs/common";
import { AppController } from "./app.controller";
import { AppService } from "./app.service";
import configuration from "./config/configuration";
import { ConfigModule } from "@nestjs/config";
import { ClaimShopModule } from "./claim-shop/claim-shop.module";
import { TypeOrmModule } from "@nestjs/typeorm";
import { typeORMAsyncConfig } from "./config/typeorm.config";
import { CategoryModule } from "./category/category.module";
import { SubCategoryModule } from "./sub-category/sub-category.module";
import { GoogleApisModule } from "./google-apis/google-apis.module";
import { OtpModule } from "./otp/otp.module";
import { RazorpayModule } from "nestjs-razorpay";
import { RazorpayServiceModule } from "./razorpay/razorpay.module";
import { AwsModule } from "./aws/aws.module";

@Module({
  imports: [
    ConfigModule.forRoot({
      load: [configuration],
      isGlobal: true,
    }),
    TypeOrmModule.forRootAsync(typeORMAsyncConfig),
    ClaimShopModule,
    CategoryModule,
    SubCategoryModule,
    GoogleApisModule,
    OtpModule,
    RazorpayServiceModule,
    RazorpayModule.forRoot({
      key_id: process.env.RAZORPAY_KEY_ID,
      key_secret: process.env.RAZORPAY_KEY_SECRET,
    }),
    AwsModule,
  ],
  controllers: [AppController],
  providers: [AppService],
})
export class AppModule {}
