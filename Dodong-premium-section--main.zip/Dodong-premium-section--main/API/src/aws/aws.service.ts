import { Injectable, Logger } from "@nestjs/common";
import {
  PutObjectCommand,
  PutObjectCommandInput,
  S3Client,
} from "@aws-sdk/client-s3";
import { ConfigService } from "@nestjs/config";
import {
  SNSClient,
  PublishCommand,
  PublishCommandOutput,
} from "@aws-sdk/client-sns";
import { OTP } from "src/otp/enitities/otp.entity";

@Injectable()
export class AwsService {
  private readonly logger = new Logger(AwsService.name);
  private readonly s3Clinet = new S3Client({
    region: this.configService.getOrThrow("AWS_S3_REGION"),
  });
  private readonly snsClinet = new SNSClient({
    region: this.configService.getOrThrow("AWS_S3_REGION"),
  });

  constructor(private readonly configService: ConfigService) {}

  async upload(key: string, content: string): Promise<string> {
    try {
      const params: PutObjectCommandInput = {
        Body: Buffer.from(
          content.replace(/^data:image\/\w+;base64,/, ""),
          "base64"
        ),
        Bucket: process.env.BUCKET_NAME,
        Key: key,
        ContentEncoding: "base64",
        ContentType: content?.split(";")?.[0]?.split(":")?.[1] || "image/jpeg",
        ACL: "public-read",
      };

      await this.s3Clinet.send(new PutObjectCommand(params));
      return `${process.env.IMAGES_URL_PREFIX}/${key}`;
    } catch (err) {
      this.logger.error(err, err?.stack);
      throw err;
    }
  }

  async sendSMS(otpRecord: OTP): Promise<PublishCommandOutput> {
    try {
      const params = {
        Message: `Please enter the OTP code: ${otpRecord.otp} to confirm your mobile number.`,
        PhoneNumber: otpRecord.mobileNumber,
        MessageAttributes: {
          "AWS.SNS.SMS.SMSType": {
            DataType: "String",
            StringValue: "Transactional",
          },
        },
      };

      const command: PublishCommand = new PublishCommand(params);
      const message = await this.snsClinet.send(command);

      return message;
    } catch (err) {
      this.logger.error(err, err?.stack);
      throw err;
    }
  }
}
