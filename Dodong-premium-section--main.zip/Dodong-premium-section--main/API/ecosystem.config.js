module.exports = {
  apps: [
    {
      name: "premium_section",
      script: "dist/src/main.js",
      instances: 1,
      exec_mode: "cluster",
      env: {
        NODE_ENV: "prod",
        PORT: 3000,
      },
    },
  ],
};
