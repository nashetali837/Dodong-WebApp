import { DataSource } from 'typeorm';
import { ormConfig } from './src/config/typeorm.config';

export default new DataSource(ormConfig);
