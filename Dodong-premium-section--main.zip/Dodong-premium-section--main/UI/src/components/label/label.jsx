const Label = ({ children }) => {
  return (
    <label className="font-normal text-xs text-[#8D8A95]">{children}</label>
  );
};

export default Label;
