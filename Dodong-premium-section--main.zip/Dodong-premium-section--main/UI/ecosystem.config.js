module.exports = {
  apps: [
    {
      name: "React.js App",
      script: "serve -s build",
    },
  ],
};
