import React from "react";
import styled from "styled-components";
import MediaQuery from "@/components/sections/MediaQuery";

export const TabsWrapper = styled.div`
  padding-left: 1rem;
  padding-right: 1rem;
`;

export const TabSection = styled.div`
  background: ${(props) => props.theme.colors.lightGray};
  border-radius: ${(props) => props.theme.borderRadius.lg};
  padding: 0.25rem;
  max-width: 448px;
  margin: auto;
  display: flex;
  display: -webkit-flex;
  width: 100%;
  margin-bottom: 2rem;
`;

const TabButton = styled.button`
  color: ${(props) => props.theme.colors.darkGray};
  height: 40px;
  text-align: center;
  border-radius: ${(props) => props.theme.borderRadius.md};
  flex: 1;

  ${MediaQuery.phone} {
    padding: 0 6px;
  }

  &.active {
    background: ${(props) => props.theme.colors.white};
    color: ${(props) => props.theme.colors.black};
  }
`;

type TabsProps = {
  modes: any;
  currentTab: string;
  onChange: (id: string) => void;
};
export type ModeProps = {
  label: string;
  id: string;
  icon: JSX.Element;
  count?: number;
};

const Tabs = ({ currentTab = "post", onChange, modes = [] }: TabsProps) => {
  return (
    <TabsWrapper>
      <TabSection>
        {modes.map((mode: ModeProps, k: number) => {
          return (
            <TabButton
              key={mode.id}
              onClick={() => onChange(mode.id)}
              className={currentTab === mode.id ? "active" : ""}
            >
              {mode.label} {mode.count !== undefined ? `(${mode.count})` : ""}
            </TabButton>
          );
        })}
      </TabSection>
    </TabsWrapper>
  );
};

export default Tabs;
