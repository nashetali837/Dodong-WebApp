import React from "react";
import styled, { css } from "styled-components";
import Link from "next/link";
import MediaQuery from "@/components/sections/MediaQuery";

import { Icons } from "@/components/icons";

export const ButtonPrimary = styled.button`
  border-radius: ${(props) => props.theme.borderRadius?.button};
  border: none;
  background: ${(props) => props.theme.colors?.primary};
  color: ${(props) => props.theme.colors?.white};
  font-weight: 500;
  font-size: 14px;
  line-height: 24px;
  padding: 8px 12px;
  box-shadow: 0px 1px 2px -1px rgba(17, 12, 34, 0.08);
  font-family: ${(props) => props.theme.font?.body};
  width: 120px;

  .loader-icon {
    display: inline-block;
    margin-left: 0.5rem;
  }

  &.borderButton {
    color: ${(props) => props.theme.colors?.black};
    background: ${(props) => props.theme.colors?.white};
    border: 1px solid ${(props) => props.theme.colors?.border};
  }
  &.w-auto {
    width: auto;
  }
  &.addshop {
    width: 100%;
    margin-top: 0.3rem;
    position: relative;
    z-index: 7;
  }
  &.post-btn {
    ${MediaQuery.xs} {
      width: 105px;
    }
  }
`;

export const ShopButton = styled(ButtonPrimary)`
  width: 80px;
  background: linear-gradient(
      180deg,
      rgba(255, 255, 255, 0.2) 0%,
      rgba(255, 255, 255, 0) 100%
    ),
    ${(props) => props.theme.colors?.primary};

  svg {
    vertical-align: middle;
    display: inline-block;
    font-size: 16px;
  }
`;

export const ShopLink = styled(Link)`
  width: 80px;
  border-radius: ${(props) => props.theme.borderRadius?.button};
  border: none;
  background: ${(props) => props.theme.colors?.primary};
  color: ${(props) => props.theme.colors?.white};
  font-weight: 500;
  font-size: 14px;
  line-height: 24px;
  padding: 8px 12px;
  box-shadow: 0px 1px 2px -1px rgba(17, 12, 34, 0.08);
  background: linear-gradient(
      180deg,
      rgba(255, 255, 255, 0.2) 0%,
      rgba(255, 255, 255, 0) 100%
    ),
    ${(props) => props.theme.colors?.primary};

  svg {
    vertical-align: middle;
    display: inline-block;
    font-size: 16px;
  }
`;

export interface ButtonProps {
  label: string;
  form?: string;
  disabled?: boolean;
  loading?: boolean;
  type: "button" | "submit" | "reset" | undefined;
  onClick?: () => void;
  style?: string;
  labelStyle?: string;
}
const PrimaryButton = ({
  label,
  form,
  style = "",
  labelStyle = "",
  loading = false,
  disabled = false,
  type = "button",
  onClick,
}: ButtonProps) => {
  return (
    <ButtonPrimary
      form={form}
      type={type}
      onClick={onClick}
      disabled={disabled}
      className={`${style}`}
    >
      <span className={`${labelStyle}`}>{label}</span>
      {loading && <Icons.spinner className="animate-spin loader-icon" />}
    </ButtonPrimary>
  );
};

export default PrimaryButton;
