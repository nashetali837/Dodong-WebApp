"use client";
import React, { useEffect, useState } from "react";
import { RiCloseLine } from "react-icons/ri";
import { useRouter } from "next/router";
import styled from "styled-components";
import { Icons } from "@/components/icons";

const ModalWrapper = styled.div`
  position: fixed;
  left: 0px;
  top: 0px;
  width: 100%;
  height: 100dvh;
  transition: visibility 0s ease-out 300ms, opacity 300ms;
  visibility: hidden;
  opacity: 0;
  vertical-align: middle;
`;

export default function Modal(props: {
  open?: boolean;
  fullScreen?: boolean;
  hideCloseButton?: boolean;
  onClose?: () => void;
  children: any;
}) {
  const [openModal, toggleModal] = useState<boolean | undefined>(props?.open);
  const router = useRouter();

  const close = () => {
    toggleModal(false);

    if (props?.onClose) {
      props.onClose();
    }
    // Enable body scrolling when the modal is closed
    document.body.classList.remove("body-no-scroll");
  };

  useEffect(() => {
    toggleModal(props?.open);

    if (!props?.open && props?.onClose) {
      props.onClose();
    }
    // Disable body scrolling when the modal is open
    if (props?.open) {
      document.body.classList.add("body-no-scroll");
    } else {
      document.body.classList.remove("body-no-scroll");
    }
  }, [props?.open]);

  useEffect(() => {
    router.events.on("routeChangeComplete", close);
    return () => {
      router.events.off("routeChangeComplete", close);
    };
  }, []);

  if (!openModal) {
    return null;
  }

  return (
    <>
      <div
        className={`${
          openModal ? "fade-in-transition" : "fade-out-transition"
        } h-screen fade-in-transition w-full justify-center align-middle fixed top-0 z-50 overflow-hidden modalpopup`}
      >
        <div
          className="bg-black bg-opacity-50 fixed duration-150 h-full my-auto top-0 bottom-0 w-full left-0"
          style={{ zIndex: 20 }}
        >
          {!props?.fullScreen && (
            <div className="py-5 px-2 cursor-pointer mx-auto flex justify-end max-w-7xl z-40">
              {!props?.hideCloseButton && (
                <div className="bg-white p-1 rounded-md" onClick={close}>
                  <RiCloseLine className="text-black text-2xl" />
                </div>
              )}
            </div>
          )}
          <section
            style={{ zIndex: 120 }}
            className={`align-middle self-center relative mx-auto overflow-hidden flex justify-center flex-col items-center ${
              !props?.fullScreen
                ? "max-w-7xl rounded-xl px-4"
                : "max-w-full h-full bg-white fullScreenOpened"
            }`}
          >
            {props?.fullScreen && (
              <div className="cursor-pointer w-full flex absolute right-0 top-0 bg-white justify-end">
                <div
                  className="bg-white p-1 border my-2 mx-2 lg:mx-3 rounded-md z-40 closebtn"
                  onClick={close}
                >
                  <RiCloseLine className="text-black text-2xl" />
                </div>
              </div>
            )}
            {props.children}
          </section>
        </div>
      </div>

      {/* <ModalWrapper className="ModalWrapper">
        {!props?.fullScreen && (
          <div className="">
            {!props?.hideCloseButton && (
              <div className="" onClick={close}>
                <Icons.close size={20} />
              </div>
            )}
          </div>
        )}
      </ModalWrapper> */}
    </>
  );
}
