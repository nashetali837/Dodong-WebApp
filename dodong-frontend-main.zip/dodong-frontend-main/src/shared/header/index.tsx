"use client";
import React, { useEffect, useState } from "react";
import { AiOutlineShoppingCart } from "react-icons/ai";

import { useDispatch, useSelector } from "react-redux";
import { getRequest } from "@/lib/networkHelper";
import { EndPoints } from "@/lib/apiConstants";
import {
  saveUser,
  saveProfile,
  toggleCreatePostModal,
  saveProfessional,
  saveProfileProgress,
} from "@/lib/redux/slices/user-slice";
import HeaderSearch from "./header-search";
import HeaderUserComponent from "./header-user";
import HeaderActions from "./header-actions";
import HeaderLogo from "./header-logo";
import { toast } from "react-toastify";
import Modal from "@/shared/modal";
import CreatePost from "@/components/storefront/post/create";
import { checkAuth } from "@/lib/redux/slices/auth-slice";
import useAuth from "@/components/auth/hooks/useAuth";
import styled from "styled-components";
import { Icons } from "@/components/icons";
import { Flex } from "@/components/sections/Styled";
import MediaQuery from "@/components/sections/MediaQuery";

const HeaderSection = styled.header`
  border-bottom: 1px solid ${(props) => props.theme.colors.lightGray};
  margin: 0 0 1.5rem;
  padding: 1rem 0.75rem;
  ${Flex("row", "center", "space-between")};
  gap: 1rem;

  ${MediaQuery.phone} {
    gap: 0.5rem;
  }

  .toggleSelection {
    height: 40px;
    button {
      padding: 0;
      margin: 0;
    }
  }
`;

const Cart = styled.button`
  padding: 0.5rem;
  border-radius: ${(props) => props.theme.borderRadius?.button};
  border: 1px solid ${(props) => props.theme.colors.border};
  color: #4f4b5c;
  ${Flex("row", "center", "space-between")};
  gap: 0.5rem;
  svg {
    display: inline-block;
  }
  ${MediaQuery.phone} {
    display: none;
  }
`;

const HeaderRightSection = styled.div`
  ${Flex("row", "center", "space-between")};
  gap: 1rem;
  position: relative;
  ${MediaQuery.phone} {
    gap: 0.5rem;
  }
`;

const Header = () => {
  const dispatch = useDispatch();
  const { createPostModal } = useSelector((state: any) => state.user);
  const { authToken, isLoggedIn } = useAuth();
  const [openMenu, setOpenMenu] = useState(false);

  useEffect(() => {
    dispatch(checkAuth());
  }, [dispatch]);

  useEffect(() => {
    const fetchProfile = async () => {
      if (!authToken) {
        return null;
      }

      const res = await getRequest(EndPoints.profile, authToken);
      console.log(res, "res");

      dispatch(saveUser(res.data.user) as any);
      dispatch(saveProfile(res.data.profile) as any);
      dispatch(saveProfessional(res.data.professional) as any);
      dispatch(saveProfileProgress(res.data.profileCompletion) as any);
      return res.data;
    };
    if (isLoggedIn) {
      fetchProfile();
    }
  }, [authToken, dispatch, isLoggedIn]);

  return (
    <React.Fragment>
      <HeaderSection className="">
        <HeaderLogo />

        <HeaderRightSection>
          {false && (
            <>
              <Cart
                onClick={() => {
                  toast.info("New feature coming soon!");
                }}
              >
                <Icons.cart size={20} />
                <span>New Delhi</span>
                <Icons.downarrow size={22} />
              </Cart>
              <HeaderSearch />
            </>
          )}

          {/* add state for login  */}
          {isLoggedIn ? (
            <HeaderUserComponent
              openMenu={openMenu}
              setOpenMenu={setOpenMenu}
            />
          ) : (
            <HeaderActions />
          )}
        </HeaderRightSection>
      </HeaderSection>
      <Modal
        fullScreen={true}
        key={"create-post-modal"}
        open={createPostModal}
        onClose={() => {
          dispatch(toggleCreatePostModal(false));
        }}
      >
        <CreatePost />
      </Modal>
    </React.Fragment>
  );
};

export default Header;
