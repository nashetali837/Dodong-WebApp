import Link from "next/link";
import React from "react";
import AppLogo from "@/shared/logo";
import styled from "styled-components";

const SubTitle = styled.em`
  color: #cc7a00;
  font-size: 10px;
  display: block;
  text-align: center;
`;

const Logo = styled(Link)`
  display: inline-block;
`;

const HeaderLogo = () => {
  return (
    <Logo href="/">
      <AppLogo />
      <SubTitle>Go online Do dong</SubTitle>
    </Logo>
  );
};

export default HeaderLogo;
