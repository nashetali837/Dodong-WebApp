import { UserType } from "@/lib/types";
import React, { useState, useEffect, useRef } from "react";
import { useDispatch, useSelector } from "react-redux";
import {
  UserProfile,
  toggleCreatePostModal,
  toggleEditProfileModal,
} from "@/lib/redux/slices/user-slice";
import Link from "next/link";
import PrimaryButton from "@/shared/buttons/primary";
import Image from "next/image";
import { DEFAULT_PROFILE_PIC } from "@/lib/constants";
import { toast } from "react-toastify";
import Dropdown from "@/shared/input-groups/dropdown";
import useAuth from "@/components/auth/hooks/useAuth";
import CircularProgressBar from "@/components/sections/CircularProgressBar";
import styled from "styled-components";
import { Icons } from "@/components/icons";
import CustomSelect from "../input-groups/custom-select";
import Modal from "../modal";
import { HeadingLg } from "@/components/sections/Styled";
import { Flex } from "@/components/sections/Styled";
import MediaQuery from "@/components/sections/MediaQuery";
import { useRouter } from "next/router";
import GetNotifications from "@/components/sections/GetNotifications";

const BorderBox = styled.div`
  padding: 0.5rem;
  border-radius: ${(props) => props.theme.borderRadius?.button};
  border: 1px solid ${(props) => props.theme.colors.border};
  width: 40px;
  text-align: center;
  cursor: pointer;
  position: relative;
  svg {
    displya: inline-block;
  }
  &.toggleSelection {
    background: red;
  }
`;

const ProfilePic = styled(Link)`
  img {
    border-radius: ${(props) => props.theme.borderRadius?.md};
    object-fit: cover;
    height: 40px;
  }
  ${MediaQuery.xs} {
    display: none;
  }
`;

const Button = styled.button``;

const ButtonGroup = styled.div`
  ${Flex("row")};
  gap: 1rem;
  > ${Button} {
    flex: 1;
  }
`;

const HeaderUserComponent = ({ setOpenMenu, openMenu }: any) => {
  const { logout } = useAuth();
  const router = useRouter();
  const {
    user,
    userProfile,
  }: {
    user: UserType;
    userProfile: UserProfile;
    authToken: string;
  } = useSelector((state: any) => state.user);

  const isProfileComplete = false;

  const dispatch = useDispatch();
  const stats = [
    {
      label: "Posts",
      value: userProfile?.totalPosts || 0,
    },
    {
      label: "Followers",
      value: userProfile?.followers || 0,
    },
    {
      label: "Following",
      value: userProfile?.following || 0,
    },
  ];

  const handleConfirmLogout = () => {
    logout(); // Perform logout
    setOpenMenu(false); // Close any menu if needed
  };

  const handleLogout = () => {
    logout();
    setOpenMenu(false);
    router.push("/");
  };

  // const handleLogout = () => {
  //   <Modal fullScreen={true} key="post_modal">
  //     <HeadingLg>Sign Out</HeadingLg>
  //     <p>Are you sure to Sign Out now?</p>
  //     <ButtonGroup>
  //       <Button onClick={handleConfirmLogout}>Yes</Button>{" "}
  //       <Button>Cancel</Button>
  //     </ButtonGroup>
  //   </Modal>;
  // };

  const profileLink = `${process.env.NEXT_PUBLIC_WEBSITE_URL}/profile/${userProfile?.userProfileID}`;

  return (
    <>
      <GetNotifications />

      <PrimaryButton
        label="Post / Share"
        onClick={() => {
          dispatch(toggleCreatePostModal(true));
        }}
        type="button"
        style="post-btn"
      />
      <div
        onClick={() => {
          dispatch(toggleEditProfileModal(true));
        }}
        style={{ cursor: "pointer" }}
      >
        <CircularProgressBar onLogout={handleLogout} />
      </div>
      <ProfilePic href={profileLink}>
        <Image
          width={40}
          height={40}
          alt="Picture of the author"
          src={userProfile?.avatar || DEFAULT_PROFILE_PIC}
        />
      </ProfilePic>
      {/* <Dropdown
        user={user}
        userProfile={userProfile}
        handleLogout={handleLogout}
      /> */}
      <CustomSelect
        list={[
          {
            label: "Profile",
            id: "profile",
            link: `/profile/${userProfile?.userProfileID}`,
          },
          {
            label: "Account Settings",
            id: "accountSettings",
            link: `/account-settings`,
          },
          {
            label: "Dodong Premium",
            id: "dodongPremium",
            link: `https://premium.dodong.in/`,
          },
          {
            label: "Privacy Policy",
            id: "privacyPolicy",
            link: `/privacy`,
          },
          {
            label: "Terms And Conditions And Content Policy",
            id: "terms",
            link: `/terms`,
          },

          {
            label: "Sign Out",
            id: "signout",
            onclick: () => handleLogout(),
            // icon: <Icons.signout size={18} />,
          },
        ]}
      >
        <BorderBox>
          <Icons.menu size={20} />
        </BorderBox>
      </CustomSelect>
    </>
  );
};

export default HeaderUserComponent;
