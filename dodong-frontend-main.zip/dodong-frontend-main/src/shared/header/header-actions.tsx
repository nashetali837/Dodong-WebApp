import React from "react";
import { toggleLoginModal } from "@/lib/redux/slices/user-slice";
import { GiHamburgerMenu } from "react-icons/gi";
import { useDispatch } from "react-redux";
import PrimaryButton from "@/shared/buttons/primary";

const HeaderActions = () => {
  const dispatch = useDispatch();

  return (
    <PrimaryButton
      style="px-4 xl:px-5"
      label="Login to start"
      type="button"
      onClick={() => {
        dispatch(toggleLoginModal(true));
      }}
    />
    // <div className="flex justify-between">
    //   <div className="flex flex-col lg:mx-4 my-auto">
    //     <div
    //       className="cursor-pointer"
    //       onClick={() => {
    //         dispatch(toggleLoginModal(true));
    //       }}
    //     >

    //     </div>
    //   </div>

    //   <div className="flex flex-col lg:ml-4">
    //     <button
    //       type="button"
    //       className="text-sm font-bold text-center truncate border shadow-lg h-full hover:shadow-2xl border-gray-200 p-2 rounded-lg"
    //     >
    //       <GiHamburgerMenu className="text-xl text-orange-500" />
    //     </button>
    //   </div>
    // </div>
  );
};

export default HeaderActions;
