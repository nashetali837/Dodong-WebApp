import React, { useState, useRef, useEffect } from "react";
import styled from "styled-components";

const Button = styled.button`
  outline: none;
  border: none;
  color: ${(props) => props.theme.colors?.black};
`;

export const SelectedWrapper = styled.div`
  transition-timing-function: cubic-bezier(0.4, 0, 1, 1);
  transition-duration: 75ms;
  border-radius: 1rem;
  padding: 0.35rem 0;
  background: #fff;
  border: 1px solid ${(props) => props.theme.colors?.border};
  color: #4f4b5c;
  min-width: 122px;
  position: absolute;
  text-align: left;
  right: 0px;
  box-shadow: 0px 20px 24px -16px rgba(17, 12, 34, 0.1);
  .selectable > div,
  .selectable > a {
    padding: 0.4rem 1rem 0.4rem 0.75rem;
    white-space: nowrap;
    cursor: pointer;
    display: block;

    svg {
      width: 20px;
      margin-right: 0.5rem;
      display: inline-block;
    }
  }
`;

interface Props {
  options: {
    label: String;
    icon?: string;
    value: String;
  }[];
  selectedOption?: String;
}

const colorOptions = [
  { value: "ocean", label: "Ocean", color: "#00B8D9", isFixed: true },
  { value: "blue", label: "Blue", color: "#0052CC", isDisabled: true },
  { value: "purple", label: "Purple", color: "#5243AA" },
  { value: "red", label: "Red", color: "#FF5630", isFixed: true },
  { value: "orange", label: "Orange", color: "#FF8B00" },
  { value: "yellow", label: "Yellow", color: "#FFC400" },
  { value: "green", label: "Green", color: "#36B37E" },
  { value: "forest", label: "Forest", color: "#00875A" },
  { value: "slate", label: "Slate", color: "#253858" },
  { value: "silver", label: "Silver", color: "#666666" },
];

const list = [
  { label: "Edit", id: "edit" },
  { label: "Report", id: "edit" },
  { label: "Disconnect", id: "edit" },
  { label: "Add to favorites", id: "edit" },
  { label: "Go to post", id: "edit" },
  { label: "Share to", id: "edit" },
  { label: "Copy link", id: "edit" },
  { label: "Embed", id: "edit" },
  { label: "About this account", id: "edit" },
];

const CustomSelect = (props: any) => {
  // const [open, setOpen] = useState(false);
  const [isOpen, setIsOpen] = useState(false);

  const sectionRef = useRef<HTMLDivElement | null>(null);

  const toggleSection = () => {
    setIsOpen(!isOpen);
  };

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (
        sectionRef.current &&
        !sectionRef.current.contains(event.target as Node)
      ) {
        setIsOpen(false);
      }
    };

    window.addEventListener("click", handleClickOutside);

    return () => {
      window.removeEventListener("click", handleClickOutside);
    };
  }, []);

  return (
    <div className="relative inline-block toggleSelection" ref={sectionRef}>
      <Button
        onClick={toggleSection}
        type="button"
        id="menu-button"
        aria-expanded="true"
        aria-haspopup="true"
      >
        {props.children}
      </Button>

      {/* <!--
    Dropdown menu, show/hide based on menu state.

    Entering: "transition ease-out duration-100"
      From: "transform opacity-0 scale-95"
      To: "transform opacity-100 scale-100"
    Leaving: "transition ease-in duration-75"
      From: "transform opacity-100 scale-100"
      To: "transform opacity-0 scale-95"
  --> */}
      <SelectedWrapper
        style={{ zIndex: isOpen ? 1000 : -1 }}
        className={`${
          isOpen
            ? "transition ease-in duration-75 transform opacity-100 scale-100"
            : "transition ease-out duration-100 transform opacity-0 scale-95"
        } SelectedWrapper`}
        role="menu"
        aria-orientation="vertical"
        aria-labelledby="menu-button"
        tabIndex={-1}
      >
        {/* <!-- Active: "bg-gray-100 text-gray-900", Not Active: "text-gray-700" --> */}
        {props.list.map((listItem: any, k: number) => (
          <div key={k} role="none" className="selectable">
            {listItem.link && (
              <a
                href={listItem.link}
                role="menuitem"
                tabIndex={-1}
                id="menu-item-0"
              >
                {listItem.icon} {listItem.label}
              </a>
            )}
            {listItem.onclick && (
              <div onClick={listItem.onclick}>
                {listItem.icon} {listItem.label}
              </div>
            )}
          </div>
        ))}
      </SelectedWrapper>
    </div>
  );
};
export default CustomSelect;
