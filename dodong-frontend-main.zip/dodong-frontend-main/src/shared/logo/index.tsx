import Image from "next/image";
import React from "react";
import Logo from "../../../public/images/common/logo.svg";

const AppLogo = () => {
  return <Image src={Logo} height={24} width={152} alt="DoDong" />;
};
export default AppLogo;
