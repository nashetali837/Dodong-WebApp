import React from "react";
import styled from "styled-components";

export const Title = styled.h3`
  font-weight: 600;
  margin-bottom: 1.5rem;
`;

type HeadingProps = {
  title: string;
  icon: React.ReactNode;
};

const Heading = (props: HeadingProps) => {
  return (
    <div className="flex">
      <div className="my-auto">{props.icon}</div>
      <Title className="text-lg">{props.title}</Title>
    </div>
  );
};

const SubHeading = (props: HeadingProps) => {
  return <div className="text-lg font-semibold">{props.title}</div>;
};

export { Heading, SubHeading };
