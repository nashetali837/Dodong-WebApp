import Image from "next/image";
import React from "react";
import styled from "styled-components";
import { VideoWrapper as Video } from "@/components/storefront/post/create/UploadImage";
import { Icons } from "@/components/icons";
import { CenterNav } from "@/pages/product/[slug]";
import { Flex } from "@/components/sections/Styled";
import Slider from "react-slick";
import VideoPlayer from "@/components/sections/VideoPlayer";

const SliderWrapper = styled(Slider)`
  .slick-dots {
    bottom: 0.75rem;
  }
  .slick-dots li {
    margin: 0px;
    width: 0.75rem;
  }
  .slick-slide {
    height: inherit;
  }
  .slick-track {
    ${Flex("row", "", "")}
  }
  .slick-dots li.slick-active button:before,
  .slick-dots li button:before {
    color: ${(props) => props.theme.colors?.white};
    font-size: 9px;
  }
  .slick-prev {
    left: 1rem !important;
  }
  .slick-next {
    right: 1rem;
  }

  img,
  video {
    width: 100%;
    min-height: 300px;
    height: 100%;
    background: #333;
    object-fit: contain;
    object-position: center;
  }
`;

const VideoWrapper = styled(Video)`
  video {
    border-radius: ${(props) => props.theme.borderRadius.lg};
    border-top-left-radius: 0;
    border-top-right-radius: 0;
  }
`;

const ImageWrapper = styled.div`
  position: relative;
`;

export default function ImageCarousal({
  images,
  height = 300,
  width = 400,
  style,
}: {
  images?: string[];
  style?: string;
  height?: number;
  width?: number;
}) {
  const NextArrow = (props: any) => {
    const { className, onClick } = props;
    return (
      <CenterNav className={className} onClick={onClick}>
        <Icons.arrowright />
      </CenterNav>
    );
  };

  const PrevArrow = (props: any) => {
    const { className, onClick } = props;
    return (
      <CenterNav className={className} onClick={onClick}>
        <Icons.arrowleft />
      </CenterNav>
    );
  };

  const settings = {
    dots: true,
    infinite: true,
    arrows: true,
    // autoplay: true,
    // fade: true,
    // speed: 500,
    slidesToShow: 1,
    slidesToScroll: 1,
    nextArrow: <NextArrow />,
    prevArrow: <PrevArrow />,
  };

  const videoExtensions =
    /\.(mp4|webm|ogg|avi|mov|flv|mkv|wmv|mpg|mpeg|3gp|mp3)$/i;

  return (
    <SliderWrapper {...settings} className="SliderWrapper">
      {images?.map((image, k) => (
        <div key={`post_${k}`}>
          {image.match(videoExtensions) ? (
            <VideoWrapper>
              <VideoPlayer src={image} />
            </VideoWrapper>
          ) : (
            <ImageWrapper>
              <Image
                src={image}
                height={height}
                width={width}
                alt="post.post image"
                className={
                  style ?? "rounded-bl-xl object-cover rounded-br-xl w-fit"
                }
              />
            </ImageWrapper>
          )}
        </div>
      ))}
    </SliderWrapper>
  );
}
