import React, { useState } from "react";
import { useForm, UseFormReturn } from "react-hook-form";
import { toast } from "react-toastify";
import * as yup from "yup";
import { yupResolver } from "@hookform/resolvers/yup";
import { useDispatch, useSelector } from "react-redux";

import { EndPoints } from "@/lib/apiConstants";
import useAuth from "../auth/hooks/useAuth";
import { postRequest } from "@/lib/networkHelper";
import {
  UserProfessional,
  saveProfessional,
} from "@/lib/redux/slices/user-slice";
import ErrorText from "../form/ErrorText";
import FooterNav from "../sections/FooterButtons";
import PrimaryButton from "@/shared/buttons/primary";
import { Form } from "./Styled";

const schema = yup.object().shape({
  occupation: yup
    .string()
    .nullable()
    .matches(/^[A-Za-z ]*$/, "Occupation Type is not valid"),
  company: yup.string().nullable(),
  jobLocation: yup.string().nullable(),
  officialMobileNumber: yup
    .string()
    .nullable()
    .matches(/^[0-9]{10}$/, "Phone number is not valid"),
  brandDetails: yup.string().nullable(),
  others: yup.string().nullable(),
});

interface FormData {
  occupation?: string | null | undefined;
  company?: string | null | undefined;
  jobLocation?: string | null | undefined;
  officialMobileNumber?: string | null | undefined;
  brandDetails?: string | null | undefined;
  others?: string | null | undefined;
  // Define other fields as needed
}

const InputField: React.FC<{
  label: string;
  name: keyof FormData;
  type: string;
  register: any;
  value: string | null | undefined;
  onChange?: (e: React.ChangeEvent<HTMLInputElement>) => void;
  required?: boolean; // Add a required prop
  error?: string; // Add an error prop
}> = ({ label, name, type, register, value, onChange, required, error }) => (
  <div>
    <label htmlFor={name}>
      {label} {required && <span className="text-danger">*</span>}
    </label>
    <input
      type={type}
      id={name as string}
      {...register(name, { required })} // Register the input as required
      value={value}
      onChange={onChange}
    />

    {error && <ErrorText errorMessage={error} />}
  </div>
);

const ProfessionalDetailsForm: React.FC<{
  onFormSubmitSuccess: () => void;
}> = ({ onFormSubmitSuccess }) => {
  const {
    register,
    handleSubmit,
    formState: { errors },
  }: UseFormReturn<FormData> = useForm<FormData>({
    resolver: yupResolver(schema),
  });

  const { authToken } = useAuth();

  const {
    userProfessional,
  }: {
    userProfessional: UserProfessional;
  } = useSelector((state: any) => state.user);

  const dispatch = useDispatch();

  const [formData, setFormData] = useState<FormData>({
    occupation: userProfessional?.occupationType || "",
    company: userProfessional?.companyName || "",
    jobLocation: userProfessional?.jobLocation || "",
    officialMobileNumber: userProfessional?.officialMobileNumber || "",
    brandDetails: userProfessional?.brandDetails || "",
    others: userProfessional?.others || "",
  });

  // Update the form data and save it whenever a field changes
  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    const newData = { ...formData, [name]: value };
    setFormData(newData);
  };

  // Submit handler to process the form data
  const onSubmit = (data: FormData) => {
    if (Object.values(data).some((value) => value !== "")) {
      postRequest(EndPoints.businessProfile, data, authToken)
        .then((res) => {
          console.log(res);
          toast.success("Professional profile updated successfully", {
            type: "success",
          });

          const updatedProfessional = { ...userProfessional, ...formData };
          dispatch(saveProfessional(updatedProfessional));

          // Call the callback function to update the tab state
          onFormSubmitSuccess();
        })
        .catch((err) => {
          console.log(err);
          toast("Something went wrong", {
            type: "error",
          });
        });
    } else {
      toast("At least one field should be updated", {
        type: "error",
      });
    }
  };

  return (
    <Form id="personal-form" onSubmit={handleSubmit(onSubmit)}>
      <InputField
        label="Occupation Type"
        name="occupation"
        type="text"
        register={register}
        value={formData.occupation}
        onChange={handleInputChange}
        error={errors.occupation ? errors.occupation.message : ""}
        // required
        // error={errors.occupation ? "Occupation Type is required" : ""}
      />
      <InputField
        label="Company Name"
        type="text"
        name="company"
        register={register}
        value={formData.company}
        onChange={handleInputChange}
        error={errors.company ? errors.company.message : ""}
      />
      <InputField
        label="Job Location"
        name="jobLocation"
        type="text"
        register={register}
        value={formData.jobLocation}
        onChange={handleInputChange}
        error={errors.jobLocation ? errors.jobLocation.message : ""}
      />
      <InputField
        label="Official Phone number"
        name="officialMobileNumber"
        type="tel"
        register={register}
        value={formData.officialMobileNumber}
        // error={errors.officialMobileNumber?.message}
        onChange={handleInputChange}
        error={
          errors.officialMobileNumber ? errors.officialMobileNumber.message : ""
        }
      />
      <InputField
        label="Brand Preferences"
        name="brandDetails"
        type="text"
        register={register}
        value={formData.brandDetails}
        onChange={handleInputChange}
        error={errors.brandDetails ? errors.brandDetails.message : ""}
      />
      <InputField
        label="Other Details"
        name="others"
        type="text"
        register={register}
        value={formData.others}
        onChange={handleInputChange}
        error={errors.others ? errors.others.message : ""}
      />

      <FooterNav>
        <PrimaryButton type="submit" label="Save" />
      </FooterNav>
    </Form>
  );
};

export default ProfessionalDetailsForm;
