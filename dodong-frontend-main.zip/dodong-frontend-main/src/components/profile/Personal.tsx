import React from "react";
import TextInput from "@/shared/input-groups/TextInput";

type ProfessionalProfileProps = {
  forms?: any;
  handleSubmit: (event: React.FormEvent<HTMLFormElement>) => void;
};

export default function PersonalProfile({
  handleSubmit,
}: ProfessionalProfileProps) {
  const forms = [
    {
      label: "Name",
      placeholder: "",
      type: "text",
      id: "names",
      required: true,
      half: false,
    },
    {
      label: "Display Name",
      placeholder: "",
      type: "text",
      id: "displayName",
      required: false,
      half: true,
    },
    // {
    //   label: "Phone number",
    //   placeholder: "",
    //   type: "number",
    //   id: "phoneNumber",
    //   required: false,
    //   half: true,
    // },
    // {
    //   label: "Email Address",
    //   placeholder: "",
    //   type: "email",
    //   id: "email",
    //   required: false,
    //   half: true,
    // },
    {
      label: "Date of Birth",
      placeholder: "",
      type: "date",
      id: "dob",
      required: false,
      half: true,
    },
    {
      label: "About me (Short Intro)",
      placeholder: "",
      type: "text",
      id: "bio",
      required: false,
      half: false,
    },
    {
      label: "Facebook URL",
      placeholder: "",
      type: "text",
      id: "facebookURL",
      required: false,
      half: false,
    },
    {
      label: "LinkedIn URL",
      placeholder: "",
      type: "text",
      id: "LinkedInURL",
      required: false,
      half: false,
    },
    {
      label: "Twitter Handle",
      placeholder: "",
      type: "text",
      id: "twitterHandle",
      required: false,
      half: false,
    },
  ];

  return (
    <form id="personal-form" onSubmit={handleSubmit} className="w-full">
      <div className="w-full gap-8 flex flex-col justify-between text-orange-593500 font-semibold">
        <div className="grid grid-cols-2 gap-3">
          {forms.map((form: any, k: number) => (
            <div
              key={"field_" + form.id}
              className={form.half ? "col-span-1" : "col-span-2"}
            >
              <TextInput
                inputStyle=""
                id={form.id}
                autoFocus={k === 0}
                label={form.label}
                required={form.required}
                type={form.type}
                placeholder={form.placeholder}
                defaultValue={form.defaultValue}
              />
            </div>
          ))}
        </div>
      </div>
    </form>
  );
}
