import styled from "styled-components";
import MediaQuery from "../sections/MediaQuery";

export const Form = styled.form`
  display: grid;
  grid-template-columns: repeat(2, minmax(0, 1fr));
  gap: 1.5rem;
  padding-bottom: 3.75rem;

  &#personal-form {
    > div {
      &:nth-of-type(4),
      &:nth-of-type(5) {
        grid-column: span 1 / span 1;
        ${MediaQuery.phone} {
          grid-column: span 2 / span 2;
        }
      }
    }
  }

  ${MediaQuery.phone} {
    padding-bottom: 0px;
    gap: 1rem;
  }

  > div {
    grid-column: span 2 / span 2;
    &:nth-of-type(2),
    &:nth-of-type(3) {
      grid-column: span 1 / span 1;
      ${MediaQuery.phone} {
        grid-column: span 2 / span 2;
      }
    }
  }
`;
