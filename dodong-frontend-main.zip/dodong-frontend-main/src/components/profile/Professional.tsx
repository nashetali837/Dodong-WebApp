import React from "react";
import TextInput from "@/shared/input-groups/TextInput";

type PersonalProfileProps = {
  handleSubmitProfessional: (event: React.FormEvent<HTMLFormElement>) => void;
};

export default function ProfessionalProfile({
  handleSubmitProfessional,
}: PersonalProfileProps) {
  const forms = [
    {
      label: "Occupation Type",
      placeholder: "Shop owner",
      type: "text",
      id: "occupation",
      required: true,
    },
    {
      label: "Company Name",
      placeholder: "Spark Fireworks",
      type: "text",
      id: "company",
      required: false,
    },
    {
      label: "Job Location",
      placeholder: "Hyderabad",
      type: "text",
      id: "jobLocation",
      required: false,
    },
    {
      label: "Official Phone number",
      placeholder: "+91 9xxxxxxxxxx",
      type: "text",
      id: "phoneNumber",
      required: false,
    },
    {
      label: "Brand Details",
      placeholder: "Tell us about your business",
      type: "textarea",
      id: "brandDetails",
      required: false,
    },
    {
      label: "Others",
      placeholder: "Tell us about your business",
      type: "textarea",
      id: "other",
      required: false,
    },
  ];

  return (
    <form
      id="professional-form"
      onSubmit={handleSubmitProfessional}
      className="w-full flex flex-col gap-8 justify-between h-[30rem] text-orange-593500 font-semibold"
    >
      {forms.map((form: any, k: number) => (
        <div key={"field_" + form.id} className="grid gap-1">
          <TextInput
            id={form.id}
            inputStyle="h-9 border-gray-100"
            autoFocus={k === 0}
            label={form.label}
            required={form.required}
            type={form.type}
            placeholder={form.placeholder}
          />
        </div>
      ))}
    </form>
  );
}
