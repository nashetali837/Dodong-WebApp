import React, { useEffect, useState } from "react";
import ErrorText from "../form/ErrorText";
import FooterNav from "../sections/FooterButtons";
import PrimaryButton from "@/shared/buttons/primary";
import { EndPoints } from "@/lib/apiConstants";
import useAuth from "../auth/hooks/useAuth";
import { postRequest } from "@/lib/networkHelper";
import { toast } from "react-toastify";

import { saveProfile, UserProfile } from "@/lib/redux/slices/user-slice";
import { useForm, UseFormReturn } from "react-hook-form";
import { Form } from "./Styled";
import moment from "moment";
import { useSelector, useDispatch } from "react-redux";
import * as yup from "yup";
import { yupResolver } from "@hookform/resolvers/yup";

const schema = yup.object({
  name: yup
    .string()
    .nullable()
    .matches(/^[A-Za-z ]*$/, "Name can only contain alphabets"),
  facebookURL: yup
    .string()
    .nullable()
    .test("isValidFacebookURL", "Invalid Facebook URL", function (value) {
      if (value) {
        return /^(https?:\/\/)?(www\.)?facebook.com\/[A-Za-z0-9-_ ]+$/.test(
          value
        );
      }
      return true; // Field is optional and can be empty
    }),
  LinkedInURL: yup
    .string()
    .nullable()
    .test("isValidLinkedInURL", "Invalid LinkedIn URL", function (value) {
      if (value) {
        return /^(https?:\/\/)?(www\.)?linkedin.com\/in\/[[A-Za-z0-9-_ ]+$/.test(
          value
        );
      }
      return true; // Field is optional and can be empty
    }),
  twitterHandle: yup
    .string()
    .nullable()
    .test("isValidTwitterHandle", "Invalid Twitter Handle", function (value) {
      if (value) {
        return /^(https?:\/\/)?(www\.)?twitter.com\/[A-Za-z0-9-_ ]+$/.test(
          value
        );
      }
      return true; // Field is optional and can be empty
    }),
});

interface FormData {
  bio?: string | null | undefined;
  name?: string | null | undefined;
  displayName?: string | null | undefined;
  dateOfBirth?: string | null | undefined;
  facebookURL?: string | null | undefined;
  LinkedInURL?: string | null | undefined;
  twitterHandle?: string | null | undefined;
}

const InputField: React.FC<{
  label: string;
  name?: keyof FormData;
  type: string;
  register?: any;
  value: string | null | undefined;
  disabled?: boolean;
  onChange?: (e: React.ChangeEvent<HTMLInputElement>) => void;
  required?: boolean; // Add a required prop
  error?: string; // Add an error prop
}> = ({
  label,
  name,
  type,
  register,
  value,
  disabled,
  onChange,
  required,
  error,
}) => (
  <div>
    <label htmlFor={name}>
      {label} {required && <span className="text-danger">*</span>}
    </label>
    <input
      type={type}
      id={name as string}
      // check for dob
      min={name === "dateOfBirth" ? "1900-01-01" : undefined}
      max={
        name === "dateOfBirth"
          ? moment().subtract(18, "years").format("YYYY-MM-DD")
          : undefined
      }
      {...register?.(name, { required })} // Register the input as required
      value={value}
      disabled={disabled}
      onChange={onChange}
    />

    {error && <ErrorText errorMessage={error} />}
  </div>
);

const PersonalDetailsForm: React.FC<{
  user: any;
  onFormSubmitSuccess: () => void;
}> = ({ user, onFormSubmitSuccess }) => {
  const {
    register,
    handleSubmit,
    formState: { errors },
  }: UseFormReturn<FormData> = useForm<FormData>({
    resolver: yupResolver(schema),
  });

  const {
    user: userData,
    userProfile,
  }: {
    user: any;
    userProfile: UserProfile;
  } = useSelector((state: any) => state.user);

  const dispatch = useDispatch();
  const { authToken } = useAuth();
  const [formData, setFormData] = useState<FormData>({
    name: userProfile?.name || "",
    displayName: userData?.displayName || "",
    dateOfBirth:
      userProfile?.dateOfBirth ||
      moment().subtract(18, "years").format("YYYY-MM-DD"),
    bio: userProfile?.bio || "",
    facebookURL: userProfile?.facebookURL || "",
    LinkedInURL: userProfile?.LinkedInURL || "",
    twitterHandle: userProfile?.twitterHandle || "",
    ...user?.userProfile,
  });

  // Update the form data and save it whenever a field changes
  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    const newData = { ...formData, [name]: value };
    setFormData(newData);
  };

  // Submit handler to process the form data
  const onSubmit = (data: FormData) => {
    if (Object.values(data).some((value) => value !== "")) {
      postRequest(EndPoints.updateProfile, data, authToken)
        .then((res) => {
          console.log(res);
          toast.success("Personal profile updated successfully", {
            type: "success",
          });

          const updatedProfile = { ...userProfile, ...formData };
          dispatch(saveProfile(updatedProfile));
          // Call the callback function to update the tab state
          onFormSubmitSuccess();
        })
        .catch((err) => {
          console.log(err);
          toast("Something went wrong", {
            type: "error",
          });
        });
    } else {
      toast("At least one field should be updated", {
        type: "error",
      });
    }
  };

  return (
    <Form id="personal-form" onSubmit={handleSubmit(onSubmit)}>
      <InputField
        label="About me (Short Intro)"
        name="bio"
        type="text"
        register={register}
        value={formData.bio}
        onChange={handleInputChange}
      />
      <InputField
        label="Name"
        name="name"
        type="text"
        register={register}
        value={formData.name}
        onChange={handleInputChange}
        error={errors.name ? errors.name.message : ""}
        // required
        // error={errors.name ? "Name is required" : ""}
      />
      <InputField
        label="Display Name"
        type="text"
        name="displayName"
        register={register}
        value={formData.displayName}
        onChange={handleInputChange}
      />
      <InputField
        label="Phone Number"
        type="text"
        value={userData?.mobileNumber}
        disabled
      />
      <InputField
        label="Email Address"
        type="text"
        value={userData?.email}
        disabled
      />
      <InputField
        label="Date of Birth"
        name="dateOfBirth"
        type="date"
        register={register}
        value={formData.dateOfBirth}
        onChange={handleInputChange}
      />

      <InputField
        label="Facebook URL"
        name="facebookURL"
        type="text"
        register={register}
        value={formData.facebookURL}
        onChange={handleInputChange}
        error={errors.facebookURL ? errors.facebookURL.message : ""}
      />
      <InputField
        label="LinkedIn URL"
        name="LinkedInURL"
        type="text"
        register={register}
        value={formData.LinkedInURL}
        onChange={handleInputChange}
        error={errors.LinkedInURL ? errors.LinkedInURL.message : ""}
      />
      <InputField
        label="Twitter Handle"
        name="twitterHandle"
        type="text"
        register={register}
        value={formData.twitterHandle}
        onChange={handleInputChange}
        error={errors.twitterHandle ? errors.twitterHandle.message : ""}
      />

      <FooterNav>
        <PrimaryButton type="submit" label="Next" />
      </FooterNav>
    </Form>
  );
};

export default PersonalDetailsForm;
