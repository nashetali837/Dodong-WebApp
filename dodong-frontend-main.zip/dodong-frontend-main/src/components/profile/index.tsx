import React, { useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import Starter from "./ui/starter";
import Info from "./ui/info";
import Invite from "./ui/invite";
import { toggleEditProfileModal } from "@/lib/redux/slices/user-slice";
import Modal from "@/shared/modal";

const UpdateProfile = (props: any) => {
  const { openEditProfileModal } = useSelector((state: any) => state.user);
  const dispatch = useDispatch();

  const [step, setStep] = useState<number>(1);

  const handleNext = () => {
    setStep(step + 1);
  };

  const handlePrev = () => {
    setStep(step - 1);
  };

  const handleSkip = () => {
    setStep(4);
  };

  const handleInvite = () => {
    setStep(3);
  };

  const handleFinish = () => {
    setStep(1);
  };

  const handleClose = () => {
    dispatch(toggleEditProfileModal(false));
    setStep(1);
  };

  return (
    <>
      {step === 1 && (
        <Modal
          hideCloseButton
          open={openEditProfileModal}
          onClose={handleClose}
        >
          <Starter
            step={step}
            onNext={handleNext}
            handleInvite={handleInvite}
            handleClose={handleClose}
          />
        </Modal>
      )}
      {step === 2 && (
        <Modal fullScreen open={openEditProfileModal} onClose={handleClose}>
          <Info
            onNext={handleNext}
            onPrev={handlePrev}
            handleClose={handleClose}
          />
        </Modal>
      )}
      {step === 3 && (
        <Modal
          hideCloseButton
          open={openEditProfileModal}
          onClose={handleClose}
        >
          <Invite handleClose={handleClose} />
        </Modal>
      )}
    </>
  );
};

export default UpdateProfile;
