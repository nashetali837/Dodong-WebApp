import React from "react";
import { Icons } from "@/components/icons";
import styled from "styled-components";
import { EmailShareButton, WhatsappShareButton } from "react-share";
import { Flex } from "@/components/sections/Styled";
import MediaQuery from "@/components/sections/MediaQuery";
import { UserProfile } from "@/lib/redux/slices/user-slice";
import { useSelector } from "react-redux";

export const InviteSection = styled.div`
  padding: 2rem;
  max-width: 445px;
  width: 100%;
  margin: auto;
  background: ${(props) => props.theme.colors.white};
  border-radius: ${(props) => props.theme.borderRadius.md};

  ${MediaQuery.phone} {
    padding: 2rem 1rem;
  }
`;

export const ModalHead = styled.div`
  ${Flex("row", "center", " space-between")};
  margin-bottom: 1.25rem;
`;

export const SubTitle = styled.p`
  margin: 1.5rem 0 1rem;
`;

export const InviteBox = styled.div`
  ${Flex("row", "center", "")};
  gap: 0.75rem;
  font-size: 18px;
  color: ${(props) => props.theme.colors.black};
  margin-top: 1rem;

  ${MediaQuery.phone} {
    font-size: 17px;
    margin-top: 1rem;
  }
  button {
    text-align: left;
  }
`;

export const Icon = styled.div`
  width: 40px;
  height: 40px;
  border: 1px solid ${(props) => props.theme.colors.border};
  border-radius: ${(props) => props.theme.borderRadius.md};
  ${Flex("row", "center", "center")};
  font-size: 22px;
  position: relative;
`;

export default function Step1({
  onNext,
  onPrev,
  handleClose,
}: {
  onNext?: () => void;
  onPrev?: () => void;
  handleClose: () => void;
}) {
  const {
    user,
    userProfile,
  }: {
    user: any;
    userProfile: UserProfile;
  } = useSelector((state: any) => state.user);
  const domin = process.env.NEXT_PUBLIC_WEBSITE_URL || "https://dodong.in";
  const url = `Web Link: ${domin}/profile/${userProfile?.userProfileID}`;

  const invitationText = `📣 Discover with dodong! 🌟🛍️💡

App Link: https://play.google.com/store/apps/details?id=com.dodong
  
Follow me for local shop finds, product experiences, and collections on dodong. Let's explore together and make amazing discoveries! 🤝🌍✨
  
#dodongApp #ShopLocal #DiscoverWithDodong  

`;

  const subject = encodeURIComponent("Check out dodong App!");
  const body = encodeURIComponent(invitationText);
  const mailtoLink = `mailto:?subject=${subject}&body=${body}${url}`;
  const smsLink = `sms:?body=${body}${url}`;

  return (
    <InviteSection>
      <ModalHead>
        <span className="black">Invite friends</span>
        <button onClick={handleClose} className="cursor-pointer">
          &#10005;
        </button>
      </ModalHead>
      <SubTitle>
        Invite your friends to grow your network to follow your account. You can
        also connect with them to let them add you to their network.
      </SubTitle>
      {/* <InviteBox>
        <Icon>
          <Icons.user />
        </Icon>
        Follow Connects
      </InviteBox> */}

      <InviteBox>
        <Icon>
          <Icons.Whatsapp />
        </Icon>
        <WhatsappShareButton url={url} title={invitationText}>
          Invite friends by whatsapp
        </WhatsappShareButton>
      </InviteBox>

      <InviteBox>
        <Icon>
          <Icons.email />
        </Icon>
        <a href={mailtoLink} target="_blank" rel="noreferrer">
          Invite friends by email
        </a>
      </InviteBox>

      <InviteBox>
        <Icon>
          <Icons.chat />
        </Icon>
        <a href={smsLink} target="_blank" rel="noreferrer">
          Invite friends by sms
        </a>
      </InviteBox>
      {/* <InviteBox>
        <Icon>
          <Icons.more />
        </Icon>
        Invite friends by...
      </InviteBox> */}
    </InviteSection>
  );
}
