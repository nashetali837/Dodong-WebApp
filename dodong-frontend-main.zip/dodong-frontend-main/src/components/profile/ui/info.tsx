"use client";
import React, { useState } from "react";
import styled from "styled-components";

import { useSelector } from "react-redux";
import { RootState } from "@/lib/redux/store/store";
import Tabs from "@/shared/buttons/tabs";

import PersonalDetailsForm from "../PersonalDetailsForm";
import ProfessionalDetailsForm from "../ProfessionalDetailsForm";

export const PopupHeader = styled.div`
  position: sticky;
  left: 0px;
  top: 0px;
  padding: 1rem;
  padding-right: 2.75rem;
  background: ${(props) => props.theme.colors.white};
  color: ${(props) => props.theme.colors.black};
  border-bottom: 1px solid ${(props) => props.theme.colors.border};
  width: 100%;
  z-index: 3;
`;

const Content = styled.div`
  max-width: 44.75rem;
  padding: 1rem;
  width: 100%;
`;

export default function Step1({
  step,
  onNext,
  onPrev,
  handleClose,
}: {
  step?: any;
  onNext?: () => void;
  onPrev?: () => void;
  handleClose: () => void;
}) {
  const { user, userProfile } = useSelector((state: RootState) => state);
  const [tab, setTab] = useState<boolean>(false);

  const handlePersonalFormSubmit = () => {
    setTab(true);
  };

  const handleProfessionalFormSubmit = () => {
    handleClose();
  };

  const handleTab = (val: boolean): void => {
    setTab(val);
  };

  const _renderModes = () => {
    const modes = [
      { label: "Personal", id: "Personal" },
      { label: "Professional", id: "Professional" },
    ];

    return (
      <Tabs
        modes={modes}
        currentTab={tab === false ? "Personal" : "Professional"}
        onChange={(id) => {
          handleTab(id === "Professional" ? true : false);
        }}
      />
    );
  };

  return (
    <section
      className={`w-full h-full overflow-y-scroll relative flex flex-col items-center`}
    >
      <PopupHeader className="black">
        When you add details about you, your connects will be engaged more with
        your profile
      </PopupHeader>

      <Content>
        {_renderModes()}
        {tab ? (
          <ProfessionalDetailsForm
            onFormSubmitSuccess={handleProfessionalFormSubmit}
          />
        ) : (
          <>
            <PersonalDetailsForm
              user={user}
              onFormSubmitSuccess={handlePersonalFormSubmit}
            />
          </>
        )}
      </Content>
    </section>
  );
}
