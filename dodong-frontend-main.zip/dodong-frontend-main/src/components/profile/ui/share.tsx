import React from "react";
import Image from "next/image";
//import squareProfile from "@/images/profile/square-profile.svg";
import squareProfile from "../../../../public/images/profile/square-profile.svg";
import fiftypercentage from "../../../../public/images/profile/50percentage.svg";

export default function Step1({
  onPrev,
  onFinish,
  handleClose,
}: {
  onPrev: () => void;
  onFinish: () => void;
  handleClose: () => void;
}) {
  return (
    <section className="w-full h-full overflow-x-scroll bg-profile-back flex flex-col pb-20 items-center">
      <button
        onClick={handleClose}
        className="ml-auto mr-5 mt-2 cursor-pointer"
      >
        &#10005;
      </button>
      <header className="flex flex-row justify-center items-center w-full mt-10">
        {/* <figure className='bg-red-500'> */}
        <Image
          src={squareProfile}
          alt="Picture of the author"
          width={40}
          height={40}
          className="rounded bg-red-100 bg-auto"
        />
        {/* </figure> */}
        <h3 className="mr-10 ml-10 font-medium">
          Invite your friends to grow your network to follow your account. You
          can also connect with them to let them add you to their network.
        </h3>
        {/* <button 
          className="w-1/12 inline-flex  items-center justify-center rounded-full bg-orange-500 px-5 py-2.5 text-center text-sm font-medium text-white hover:bg-[#24292F]/90 focus:outline-none focus:ring-4 focus:ring-[#24292F]/50 disabled:opacity-50 dark:hover:bg-[#050708]/30 dark:focus:ring-slate-500"
         >
            Save
         </button>   */}
        <Image
          src={fiftypercentage}
          alt="Picture of the author"
          width={40}
          height={40}
          className="rounded bg-red-100 bg-auto"
        />
      </header>
      <main
        className={`mt-10 flex flex-col justify-center items-center w-3/5 h-full`}
      >
        {/* <CreatePost viewHeader={false} /> */}
      </main>
    </section>
  );
}
