import React, { useRef, useState } from "react";
import styled from "styled-components";
import { toast } from "react-toastify";
import { setServers } from "dns";
import { useSelector, useDispatch } from "react-redux";
import { useRouter } from "next/router";
import Image from "next/image";

import UploadNewImage from "../../../../public/images/upload.svg";
import {
  InviteSection as Profile,
  InviteBox as InviteBoxes,
  Icon,
  SubTitle,
  ModalHead,
} from "./invite";
import { FlexBoxCenter } from "@/components/sections/Styled";
import { Icons } from "@/components/icons";
import { uploadImage } from "@/components/storefront/post/create/UploadImage";
import { ImageDiscard } from "@/components/storefront/post/create/UploadImage";
// import { updateDraft } from "@/lib/redux/slices/draft-slice";
import {
  saveProfile,
  toggleCreatePostModal,
  UserProfileProgress,
} from "@/lib/redux/slices/user-slice";
import { EndPoints } from "@/lib/apiConstants";
import { postRequest } from "@/lib/networkHelper";
import useAuth from "@/components/auth/hooks/useAuth";
import { Flex } from "@/components/sections/Styled";
import MediaQuery from "@/components/sections/MediaQuery";

const InviteBox = styled(InviteBoxes)`
  cursor: pointer;
`;

export const Avatar = styled.div`
  height: 155px;
  width: 155px;
  border: 5px solid ${(props) => props.theme.colors.white};
  border-radius: ${(props) => props.theme.borderRadius.lg};
  background: ${(props) => props.theme.colors.lightGray};
  -moz-box-shadow: 0px 4px 9px -4px rgba(0, 0, 0, 0.25);
  -webkit-box-shadow: 0px 4px 9px -4px rgba(0, 0, 0, 0.25);
  box-shadow: 0px 4px 9px -4px rgba(0, 0, 0, 0.25);
  ${Flex("row", "center")}
  display: flex;
  display: -webkit-flex;
  align-items: center;
  justify-content: center;

  ${MediaQuery.phone} {
    height: 120px;
    width: 120px;
  }

  img {
    border-radius: inherit;
  }

  &.isUserImage {
    img {
      width: 100%;
      height: 100%;
      object-fit: cover;
      object-position: center;
    }
  }
`;

const Button = styled.button`
  color: ${(props) => props.theme.colors.black};
  border: 1px solid ${(props) => props.theme.colors.border};
  border-radius: ${(props) => props.theme.borderRadius.button};
  padding: 9px;
  max-width: 200px;
  width: 100%;
  margin-left: 1rem;

  &.isUserImage {
    background: ${(props) => props.theme.colors?.primary};
    color: ${(props) => props.theme.colors?.white};
  }
`;

const ImageUpload = styled.div`
  position: relative;
`;

const CompleteText = styled.span`
  font-size: 12px;
  display: block;
  color: #8d8a95;
`;

const CompleteIcon = styled.div`
  background: ${(props) => props.theme.colors?.primary};
  color: ${(props) => props.theme.colors?.white};
  height: 16px;
  width: 16px;
  border-radius: 6px;
  position: absolute;
  top: 0;
  right: 0;

  svg {
    height: 16px;
    width: 16px;
  }
`;

export default function Step1({
  step,
  onNext,
  setStep,
  handleInvite,
  handleClose,
}: {
  step?: any;
  onNext?: () => void;
  setStep?: any;
  handleInvite?: () => void;
  handleClose: () => void;
}) {
  const { userProfile } = useSelector((state: any) => state.user);
  const {
    userProfileProgress,
  }: {
    userProfileProgress: UserProfileProgress;
  } = useSelector((state: any) => state.user);

  const inputRef = useRef<HTMLInputElement | null>(null);
  const [image, setImage] = useState<string>(userProfile?.avatar);
  const [loading, setLoading] = useState(false); // Add loading state
  const dispatch = useDispatch();
  const { authToken } = useAuth();
  const router = useRouter();

  const onPhotoUpload = async (e: any) => {
    setLoading(true);
    try {
      let uploadedURL = await uploadImage(e);

      setImage(uploadedURL);
    } finally {
      setLoading(false);
    }
  };

  const SaveImage = () => {
    const updatedProfile = { ...userProfile, avatar: image };
    dispatch(saveProfile(updatedProfile));
    updateProfilePicture();
  };

  const resetImage = () => {
    setImage("");
  };

  const onClickHandler = () => {
    // Trigger the file input click event
    inputRef.current?.click();
  };

  const updateProfilePicture = () => {
    const data = {
      avatar: image,
    };

    postRequest(EndPoints.updateProfile, data, authToken)
      .then((res) => {
        console.log(res);
        toast.success("Profile Picture successfully updated", {
          type: "success",
        });
      })

      .catch((err) => {
        console.log(err);
        toast("Something went wrong", {
          type: "error",
        });
      });
  };

  return (
    <>
      <Profile>
        <ModalHead>
          <span className="black">Complete Profile</span>
          <button onClick={handleClose} className="cursor-pointer">
            &#10005;
          </button>
        </ModalHead>
        <FlexBoxCenter>
          <ImageUpload>
            <Avatar className={image ? "isUserImage" : undefined}>
              {loading ? (
                <Icons.spinner size={20} className="animate-spin" />
              ) : (
                <Image
                  src={image || UploadNewImage}
                  alt="Picture of the author"
                  width={58}
                  height={58}
                />
              )}
            </Avatar>

            {image && (
              <ImageDiscard onClick={resetImage}>
                <Icons.close className="text-white text-2xl" />
              </ImageDiscard>
            )}
          </ImageUpload>

          <input
            id="imageUpload"
            ref={inputRef}
            className="hidden"
            placeholder="Upload"
            onChange={onPhotoUpload}
            type="file"
            accept="image/*"
          />

          {image ? (
            <Button className="isUserImage" onClick={SaveImage}>
              Save
            </Button>
          ) : (
            <Button onClick={onClickHandler}>Upload Image</Button>
          )}
        </FlexBoxCenter>
        <SubTitle>
          You now have only 4 steps to complete to connect with your viewers on
          Dodong. Let’s get started.
        </SubTitle>
        <p>
          <span className="black">0 to 3</span> Easy Profile Setup
        </p>

        <InviteBox onClick={onNext}>
          <Icon>
            <Icons.usercircle />
            {userProfileProgress?.profileSteps?.completeProfile && (
              <CompleteIcon>
                <Icons.check />
              </CompleteIcon>
            )}
          </Icon>

          <div>
            {userProfileProgress?.profileSteps?.completeProfile && (
              <CompleteText>Completed</CompleteText>
            )}
            <p>Update your profile</p>
          </div>
        </InviteBox>

        <InviteBox
          onClick={() => {
            dispatch(toggleCreatePostModal(true));
            handleClose();
          }}
        >
          <Icon>
            <Icons.image />
            {userProfileProgress?.profileSteps?.createFirstPost && (
              <CompleteIcon>
                <Icons.check />
              </CompleteIcon>
            )}
          </Icon>

          <div>
            {userProfileProgress?.profileSteps?.createFirstPost && (
              <CompleteText>Completed</CompleteText>
            )}
            <p>Create an engaging post</p>
          </div>
        </InviteBox>
        {false && (
          <InviteBox
            onClick={() => {
              router.push("/");
              handleClose();
            }}
          >
            <Icon>
              <Icons.link />
            </Icon>
            Share your new post to other platforms
          </InviteBox>
        )}

        <InviteBox onClick={handleInvite}>
          <Icon>
            <Icons.user />
            {userProfileProgress?.profileSteps?.profileShared && (
              <CompleteIcon>
                <Icons.check />
              </CompleteIcon>
            )}
          </Icon>
          <div>
            {userProfileProgress?.profileSteps?.profileShared && (
              <CompleteText>Completed</CompleteText>
            )}
            <p>Invite friends to follow you</p>
          </div>
        </InviteBox>
      </Profile>
    </>
  );
}
