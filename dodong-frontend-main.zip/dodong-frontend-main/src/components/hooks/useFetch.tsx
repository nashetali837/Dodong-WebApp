import { useState, useEffect, useCallback } from "react";

interface Props {
  url: string;
  method?: string;
  body?: any;
  headers?: any;
  dependencies?: any;
}

const useFetch = ({
  url,
  method = "GET",
  body = null,
  headers = {
    "Content-Type": "application/json",
  },
  dependencies = [],
}: Props) => {
  const [data, setData] = useState([]);
  const [loading, setLoading] = useState(true);

  const fetchData = useCallback(
    () => async () => {
      try {
        const response = await fetch(url, {
          method,
          body,
          headers: {
            "Content-Type": "application/json",
            ...headers,
          },
        }).then((res) => {
          if (res.status === 200) {
            return res.json();
          }
          if (res.status === 401) {
            // logout user
            localStorage.removeItem("authToken");
          } else {
            throw new Error("Something went wrong");
          }
        });
        const data = await response.json();
        setData(data);
        setLoading(false);
      } catch (error) {
        console.log(error);
        setData([]);
      }
    },
    [body, headers, method, url]
  );

  useEffect(() => {
    fetchData();
  }, [fetchData]);

  return {
    data,
    loading,
    reload: () => {
      fetchData();
    },
  };
};

export default useFetch;
