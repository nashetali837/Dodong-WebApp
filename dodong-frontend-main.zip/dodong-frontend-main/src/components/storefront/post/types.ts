type PostProps = {
  // Locations(Locations: any, arg1: string): unknown;
  Locations: { name: string; country: string; state: string };
  profile: {
    name: string;
    avatar?: string;
    displayName: string;
    followers: string;
    following: string;
    totalPosts: string;
    imageURL: string;
    distance: string;
    userID: string;
  };
  shopURL: string;
  shopID: number;
  product: {
    price: string;
    productName: string;
  };
  post: {
    imageURL: string[];
    description: string;
    liked: boolean;
    likes: string;
    comments: string;
    shares: string;
  };
  id: number;
  liked: boolean;
  authorId: string;
  productID: number;
  resourceID: number;
};

type UserType = {
  id: number;
  email: string;
  mobileNumber: string;
  password?: string;
  emailVerified: boolean;
  userType: Role;
  createdAt?: Date;
  lastLogin?: Date;
  OTP: string | null;
  OTPExpiry?: Date | null;
};

type Role = {
  ADMIN: "ADMIN";
  USER: "USER";
};

export type { PostProps, UserType, Role };
