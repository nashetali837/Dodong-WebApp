import React from "react";
import UserDisplay from "./UserDisplay";
import { AiOutlinePlus } from "react-icons/ai";
import { PostProps } from "../types";
import styled from "styled-components";
import { Flex } from "@/components/sections/Styled";
import { Icons } from "@/components/icons";

const UserConnect = styled.div`
  background: ${(props) => props.theme.colors?.white};
  padding: 1rem;
  border-radius: ${(props) => props.theme.borderRadius?.lg};
  z-index: 4;
  position: absolute;
  max-width: 365px;
  width: 100%;
  box-shadow: 0px 14.266619682312012px 34.08136749267578px 0px
    rgba(114, 121, 146, 0.2154);
  top: calc(100% - 1.5rem);
`;

const TopSection = styled.div`
  ${Flex("row", "", "space-between")};
  gap: 0.25rem;
`;

const Button = styled.button`
  box-shadow: 0px 1px 1px 0px rgba(0, 0, 0, 0.1);
  border-radius: ${(props) => props.theme.borderRadius?.button};
  border: 1px solid ${(props) => props.theme.colors?.border};
  color: ${(props) => props.theme.colors?.black};
  width: 99px;
  svg {
    display: inline-block;
  }
`;

const InfoBox = styled.div`
  ${Flex("row", "", "")};
  text-align: left;
  gap: 2rem;
  margin-top: 1rem;
`;

const Count = styled.div``;

const Number = styled.span`
  color: ${(props) => props.theme.colors?.black};
  display: block;
`;

export default function UserInfo({
  post,
  stats,
}: {
  post: PostProps;
  stats: any;
}) {
  return (
    <UserConnect className="UserConnect">
      <TopSection>
        <UserDisplay post={post} />
        <Button>
          <Icons.plus size={16} /> Connect
        </Button>
      </TopSection>

      {stats && (
        <InfoBox>
          {stats.map((stat: any, k: number) => (
            <Count key={`stat_${k}`}>
              <Number>{stat.value || 0}</Number> {stat.label}
            </Count>
          ))}
        </InfoBox>
      )}
    </UserConnect>
  );
}
