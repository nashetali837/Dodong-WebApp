import { DEFAULT_PROFILE_PIC } from "@/lib/constants";
import Image from "next/image";
import Link from "next/link";
import React from "react";
import { PostProps } from "../types";
import styled from "styled-components";
import { ProductTitle as UserTitle } from "@/pages/product/[slug]";
import { MapBox, UserProfilePic } from "@/components/sections/Styled";
import { Map } from "@/pages/product/[slug]";

export default function UserDisplay({
  post,
  user,
  hideLocation,
  location,
  profilePic,
  onClick,
}: {
  post?: PostProps;
  user?: any;
  location?: string;
  profilePic?: string;
  hideLocation?: boolean;
  onClick?: () => void;
}) {
  const id = user?.id || post?.profile?.userID;
  const profileLink = `${process.env.NEXT_PUBLIC_WEBSITE_URL}/profile/${id}`;
  return (
    <div className="flex items-center userDisplay">
      <UserProfilePic className="userProfile" onClick={onClick}>
        <Image
          src={profilePic || post?.profile?.imageURL || DEFAULT_PROFILE_PIC}
          width={30}
          height={30}
          alt="profile image"
        />
      </UserProfilePic>

      <div className="text-left ml-2">
        <Link href={profileLink}>
          <UserTitle>
            {user
              ? user?.profile?.name || user?.name
              : post?.profile?.displayName || post?.profile?.name}
          </UserTitle>
        </Link>
        {!hideLocation && (location || post?.profile?.distance) && (
          <MapBox>
            <Map />
            {location ? location : post?.profile?.distance}
          </MapBox>
        )}
      </div>
    </div>
  );
}
