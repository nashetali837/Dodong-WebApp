import React from "react";
import { toast } from "react-toastify";
import { PostProps } from "../types";
import UserDisplay from "./UserDisplay";
import { Icons } from "@/components/icons";
import useAuth from "@/components/auth/hooks/useAuth";
import CustomSelect from "@/shared/input-groups/custom-select";

export default function UserBlock({
  post,
  toggle,
  children,
  removeBorder,
  hideLocation,
  location,
  hideSave,
  hideDescription,
}: {
  post: PostProps;
  toggle?: any;
  children?: React.ReactNode;
  removeBorder?: boolean;
  hideLocation?: boolean;
  location?: string;
  hideSave?: boolean;
  hideDescription?: boolean;
}) {
  const link = `${process.env.NEXT_PUBLIC_WEBSITE_URL}/?postID=${post?.resourceID}`;
  const { isLoggedIn } = useAuth();

  const copylink = (e: any) => {
    navigator.clipboard.writeText(link);
    toast.success("Link Copied");
  };

  return (
    <div
      className={`bg-white userBlock ${
        !removeBorder && "post-border"
      } p-3 rounded-tl-xl rounded-tr-xl`}
    >
      <div
        className={`flex justify-between items-center ${
          !hideDescription && "mb-4"
        }`}
      >
        <UserDisplay
          post={post}
          location={post?.Locations?.name}
          onClick={() => toggle((state: any) => !state)}
        />

        {isLoggedIn && (
          <div className="flex">
            {false && !hideSave && (
              <Icons.bookmark className="cursor-pointer black mr-2" size={18} />
            )}
            <CustomSelect
              list={[
                // {
                //   label: "Report",
                //   id: "Report",
                //   icon: <Icons.report size={20} />,
                //   link: "#",
                // },
                // {
                //   label: "Share to",
                //   id: "ShareTo",
                //   icon: <Icons.link size={20} />,
                //   link: link,
                // },
                {
                  label: "Copy link",
                  id: "CopyLink",
                  icon: <Icons.copylink size={18} />,
                  onclick: copylink,
                },
                // {
                //   label: "About this account",
                //   id: "AboutThisAccount",
                //   icon: <Icons.warning size={20} />,
                //   link: "#",
                // },
              ]}
            >
              <Icons.tdots className="cursor-pointer" size={18} />
            </CustomSelect>
          </div>
        )}
      </div>
      {!hideDescription && (
        <div className="text-sm text-left">{post.post.description}</div>
      )}
      {children}
    </div>
  );
}
