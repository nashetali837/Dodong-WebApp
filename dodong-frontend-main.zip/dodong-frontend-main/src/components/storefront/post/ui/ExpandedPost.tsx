import ImageCarousal from "@/shared/carousal";
import EmojiPicker from "emoji-picker-react";
import React, { useEffect, useState } from "react";
import UserBlock from "./UserBlock";
import UserInfo from "./UserInfo";
import { AiOutlineSend } from "react-icons/ai";
import { PostProps } from "../types";
import { BsEmojiSmile } from "react-icons/bs";
import UserDisplay from "./UserDisplay";
import { getRequest, postRequest, deleteRequest } from "@/lib/networkHelper";
import { EndPoints } from "@/lib/apiConstants";
import moment from "moment";
import InfiniteScroll from "react-infinite-scroll-component";
import Spinner from "@/shared/loading/spinner";
import useAuth from "@/components/auth/hooks/useAuth";
import { ShopLink } from "@/shared/buttons/primary";
import styled from "styled-components";
import { Icons } from "@/components/icons";
import { useRouter } from "next/router";
import { FlexBoxCenter } from "@/components/sections/Styled";
import { useSelector } from "react-redux";
import CustomSelect from "@/shared/input-groups/custom-select";
import { UserProfile } from "@/lib/redux/slices/user-slice";
import { Flex } from "@/components/sections/Styled";
import { toast } from "react-toastify";
import MediaQuery from "@/components/sections/MediaQuery";
import { PostOptionWrapper, PostCircleBox } from "..";
import PostLikeDislike from "@/components/sections/PostLikeDislike";
import PostShare from "@/components/sections/SocialShare";

export const ShopButton = styled(ShopLink)`
  position: absolute;
  z-index: 1;
  bottom: 1rem;
  left: 1rem;
`;

const ExpandedPostWrapper = styled.div`
  background: #fff;
  width: 100%;
  padding: 0 2rem;
  height: 100vh;
  border-top-left-radius: 16px;
  border-top-right-radius: 16px;
  ${Flex("row", "flex-start", "space-between")};
  gap: 1.5rem;

  .ml-10 {
    margin-left: 49px;
  }
  .userBlock {
    padding: 1.5rem 0 0;
  }

  ${MediaQuery.phone} {
    flex-wrap: wrap;
    display: block;
    padding: 0 1rem;
    overflow: auto;
  }
  @media (min-width: 768px) {
    .infinite-scroll-component__outerdiv {
      overflow: auto;
      max-height: 70vh;
    }
  }
`;

const ProfileBoxBottom = styled.div`
  ${Flex("row", "flex-end", "space-between")};
  padding: 0.75rem;
  position: absolute;
  width: 100%;
  bottom: 5px;
`;

const Gallery = styled.div`
  width: 60%;
  img,
  video {
    height: calc(100vh - 77px);
    border-radius: 0px;
    ${MediaQuery.phone} {
      height: 300px;
      object-fit: cover;
    }
  }
  ${MediaQuery.phone} {
    width: 100%;
  }
`;

const Input = styled.input`
  padding: 1rem 2.75rem;
`;

const InfoSection = styled.div`
  width: 40%;
  ${MediaQuery.phone} {
    width: 100%;
  }
`;

const PostOption = styled(PostOptionWrapper)`
  .SelectedWrapper {
    bottom: -24px;
    right: 24px;
  }
`;

export default function ExpandedPost({
  currentPost,
}: {
  currentPost: PostProps;
}) {
  const [openPopup, setOpenPopup] = useState<boolean>(false);
  const [openEmojiSelect, setOpenEmojiSelect] = useState<boolean>(false);
  const [openEditEmojiSelect, setEditOpenEmojiSelect] =
    useState<boolean>(false);
  const [newComment, setNewComment] = useState<string>("");
  const [comments, setComments] = useState<any>([]);
  const [page, setPage] = useState<number>(1);
  const [hasMore, setHasMore] = useState<boolean>(false);
  const [loading, setLoading] = useState<boolean>(false);
  const { authToken } = useAuth();
  const [editCommentId, setEditCommentId] = useState(null);
  const [editedComment, setEditedComment] = useState("");
  const { userProfile } = useSelector((state: any) => state.user);
  const { isLoggedIn } = useAuth();

  const shopLink = `${process.env.NEXT_PUBLIC_WEBSITE_URL}/product/${currentPost.productID}?shopID=${currentPost.shopID}`;

  const fetchComments = async () => {
    setLoading(true);
    const url = `${EndPoints.getComments}?postID=${currentPost?.resourceID}`;
    const res = await getRequest(url, authToken);
    // Sort comments by their creation date (assuming there's a 'createdAt' property in the comment objects)
    const sortedComments = [...res.data.comments].sort(
      (a, b) =>
        new Date(b.createdAt as string).getTime() -
        new Date(a.createdAt as string).getTime()
    );

    // console.log(
    //   sortedComments,
    //   "sortedCommentssortedCommentssortedCommentssortedComments"
    // );

    setComments(sortedComments);
    // setComments([...res.data.comments]);
    setHasMore(res.data.hasMore ?? false);
    setLoading(false);
  };

  const addComment = async () => {
    try {
      if (comments === "") {
        return;
      }

      const res = await postRequest(
        EndPoints.addComment,
        {
          resourceID: currentPost?.resourceID,
          commentBody: newComment,
        },
        authToken
      );

      if (res.data.status === "success") {
        setNewComment("");
        fetchComments();
      }
    } catch (error: any) {
      const errorMessage =
        error?.response?.data?.message || "An error occurred";
      toast.error(errorMessage);
    }
  };

  const deleteComment = async (commentID: number) => {
    const res = await deleteRequest(
      `${EndPoints.deleteComment}?postID=${currentPost?.resourceID}&commentID=${commentID}`,
      authToken
    );

    if (res.data.status === "success") {
      setComments((prevComments: any) =>
        prevComments.filter((comment: any) => comment.commentID !== commentID)
      );
    }
  };

  const saveEditedComment = async (commentID: number) => {
    try {
      // Call the API to update the comment
      const updatePromise = postRequest(
        EndPoints.updateComment,
        {
          commentID: commentID,
          commentBody: editedComment,
        },
        authToken
      );

      // Update the comments in the state simultaneously with the API request
      const updatedComments = comments.map((comment: any) => {
        if (comment.commentID === commentID) {
          return {
            ...comment,
            body: editedComment,
          };
        }
        return comment;
      });

      // Wait for both the API request and state update to complete
      await Promise.all([updatePromise, setComments(updatedComments)]);

      // Clear the editing state after successful update
      setEditCommentId(null);
      setEditedComment("");
    } catch (error) {
      // Handle any error that may occur during the update process
      console.error("Error updating comment:", error);
      // You might want to show an error message to the user
    }
  };

  const cancelEdit = () => {
    // Clear the editing state
    setEditCommentId(null);
    setEditedComment("");
  };

  const handlePostShare = () => {
    if (!isLoggedIn) {
      toast.error("Please login to continue");
      return;
    }
  };

  const _renderPostActions = () => {
    return (
      <>
        <PostOption className="PostOptions">
          <PostLikeDislike post={currentPost} LikeCount={true} />
          <PostCircleBox onClick={handlePostShare}>
            {isLoggedIn ? (
              <CustomSelect
                list={[
                  {
                    id: "SocialShare",
                    link: "#",
                    icon: <PostShare postID={currentPost?.resourceID} />, // Assuming postID is a valid prop
                  },
                ]}
              >
                <Icons.link
                  size={20}
                  style={{ marginBottom: "-5px" }}
                  className="cursor-pointer"
                />
              </CustomSelect>
            ) : (
              <Icons.link size={20} className="cursor-pointer" />
            )}
          </PostCircleBox>
        </PostOption>
      </>
    );
  };

  // ... existing code ...

  useEffect(() => {
    fetchComments();
  }, []);

  const sortedComments = comments
    .slice()
    .sort(
      (a: { commentID: number }, b: { commentID: number }) =>
        b.commentID - a.commentID
    );

  return (
    <>
      <ExpandedPostWrapper>
        <Gallery className="relative">
          <ImageCarousal
            width={400}
            height={800}
            images={currentPost?.post?.imageURL}
          />
          <ProfileBoxBottom>
            <ShopLink href={shopLink}>
              <Icons.shop size={18} /> <span>Shop</span>
            </ShopLink>
            {_renderPostActions()}
          </ProfileBoxBottom>
        </Gallery>
        <InfoSection>
          <UserBlock
            post={currentPost}
            toggle={setOpenPopup}
            removeBorder
            hideSave
          />
          {/* {openPopup && <UserInfo post={currentPost} stats={[]} />} */}

          <div className="flex mt-5 relative">
            <BsEmojiSmile
              onClick={() => setOpenEmojiSelect(!openEmojiSelect)}
              className="absolute text-2xl top-3.5 left-3 cursor-pointer"
            />
            <Input
              value={newComment}
              onChange={(e: any) => setNewComment(e.target.value)}
              onFocus={() => setOpenEmojiSelect(false)}
              placeholder="Write a comment..."
            />
            <button
              onClick={addComment}
              disabled={newComment.length === 0}
              className="absolute right-2 shadow-md top-1.5 rounded-xl text-xl bg-amber-500 p-2"
            >
              <AiOutlineSend className="text-white" />
            </button>
          </div>

          {openEmojiSelect && (
            <EmojiPicker
              width="100%"
              onEmojiClick={(e) => {
                setOpenEmojiSelect(false);
                setNewComment(newComment + " " + e.emoji + " ");
              }}
            />
          )}
          {loading ? (
            <div className="mt-10">
              <Spinner />
            </div>
          ) : (
            <InfiniteScroll
              dataLength={comments.length}
              next={() => {
                setPage(page + 1);
                fetchComments();
              }}
              hasMore={hasMore}
              loader={<h4>Loading...</h4>}
              endMessage={
                <p className="text-center text-gray-500 py-6">
                  No more comments!
                </p>
              }
            >
              {sortedComments.map((comment: any, key: number) => {
                const test = moment(comment?.createdAt);
                const today = moment();
                // Calculate the difference between test date and today in days
                const daysDiff = today.diff(test, "days");

                // Determine the output format based on the difference in days
                let days;
                if (daysDiff === 0) {
                  days = "Today";
                } else if (daysDiff === 1) {
                  days = "Yesterday";
                } else if (daysDiff <= 7) {
                  days = `${daysDiff} Days`;
                } else if (daysDiff > 7 && daysDiff <= 30) {
                  const weeksDiff = Math.floor(daysDiff / 7);
                  days = `${weeksDiff} ${weeksDiff === 1 ? "Week" : "Weeks"}`;
                } else {
                  const monthsDiff = Math.floor(daysDiff / 30);
                  days = `${monthsDiff} ${
                    monthsDiff === 1 ? "Month" : "Months"
                  }`;
                }

                const isEditing = comment.commentID === editCommentId;

                return (
                  <div className="py-4" key={`comment-${key}`}>
                    <FlexBoxCenter>
                      <UserDisplay
                        post={currentPost}
                        profilePic={userProfile?.avatar}
                        user={{
                          name: comment?.profile?.displayName,
                          displayName: comment?.profile?.displayName,
                          id: comment?.userProfileID,
                        }}
                        hideLocation
                      />
                      {comment?.userProfileID ===
                        userProfile?.userProfileID && (
                        <CustomSelect
                          list={[
                            {
                              label: "Edit",
                              id: "edit",
                              onclick: () =>
                                setEditCommentId(comment.commentID),
                            },
                            {
                              label: "Delete",
                              id: "delete",
                              onclick: () => deleteComment(comment.commentID),
                            },
                          ]}
                        >
                          <div className="flex flex-col">
                            <div className="text-sm font-bold text-center cursor-pointer">
                              <Icons.tdots className="text-xl cursor-pointer" />
                            </div>
                          </div>
                        </CustomSelect>
                      )}
                    </FlexBoxCenter>
                    {isEditing ? (
                      <>
                        <div className="flex mt-5 relative">
                          <BsEmojiSmile
                            onClick={() =>
                              setEditOpenEmojiSelect(!openEditEmojiSelect)
                            }
                            className="absolute text-2xl top-3.5 left-3 cursor-pointer"
                          />
                          <Input
                            value={editedComment}
                            placeholder="Write a comment..."
                            onChange={(e: any) =>
                              setEditedComment(e.target.value)
                            }
                            onFocus={() => setEditOpenEmojiSelect(false)}
                          />

                          <button
                            onClick={() => cancelEdit()}
                            className="absolute right-10 top-1.5 text-xl p-2"
                          >
                            <Icons.close />
                          </button>
                          <button
                            onClick={() =>
                              saveEditedComment(comment?.commentID)
                            }
                            disabled={editedComment.length === 0}
                            className="absolute right-2 shadow-md top-1.5 rounded-xl text-xl bg-amber-500 p-2"
                          >
                            <AiOutlineSend className="text-white" />
                          </button>
                        </div>

                        {openEditEmojiSelect && (
                          <EmojiPicker
                            width="100%"
                            onEmojiClick={(e) => {
                              setEditOpenEmojiSelect(false);
                              setEditedComment(
                                editedComment + " " + e.emoji + " "
                              );
                            }}
                          />
                        )}
                      </>
                    ) : (
                      // <div>
                      //   <input
                      //     type="text"
                      //     onFocus={() => setOpenEmojiSelect(false)}
                      //     className="my-2"
                      //     value={editedComment}
                      //     onChange={(e) => setEditedComment(e.target.value)}
                      //   />
                      // </div>
                      <div className=" ml-10">{comment?.body}</div>
                    )}
                    <div className="flex items-center gap-3 ml-10 mt-2">
                      <p>{days}</p>

                      {false && (
                        <div className="flex items-center gap-1 cursor-pointer">
                          <Icons.heart /> Like
                        </div>
                      )}
                    </div>
                  </div>
                );
              })}
            </InfiniteScroll>
          )}
        </InfoSection>
      </ExpandedPostWrapper>
    </>
  );
}
