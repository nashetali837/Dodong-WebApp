"use client";
import React, { useState } from "react";
import { PostProps } from "./types";
import ImageCarousal from "../../../shared/carousal";
import { useSelector } from "react-redux";
import { toast } from "react-toastify";
import UserBlock from "./ui/UserBlock";
import UserInfo from "./ui/UserInfo";
import useAuth from "@/components/auth/hooks/useAuth";
import { Icons } from "@/components/icons";
import { useRouter } from "next/router";
import styled from "styled-components";
import { Flex } from "@/components/sections/Styled";
import { ShopButton } from "@/shared/buttons/primary";
import PostLikeDislike from "@/components/sections/PostLikeDislike";
import CustomSelect from "@/shared/input-groups/custom-select";
import PostShare from "@/components/sections/SocialShare";
import { SelectedWrapper } from "@/shared/input-groups/custom-select";

export const PostOptionWrapper = styled.div`
  background: ${(props) => props.theme.colors?.white}50;
  border: 1px solid ${(props) => props.theme.colors?.white};
  color: ${(props) => props.theme.colors?.black};
  padding: 0.25rem;
  ${Flex("column", "", "")}
  gap: 4px;
  border-radius: 10rem;
`;

const StoreFrontWrapper = styled.div`
  .slick-arrow {
    display: none;
  }
`;

const PostOptions = styled(PostOptionWrapper)`
  position: absolute;
  right: 1rem;
  top: 50%;
  transform: translateY(-50%);
  -webkit-transform: translateY(-50%);
  padding: 0.25rem;
`;

export const PostCircleBox = styled.button`
  width: 40px;
  min-height: 40px;
  border-radius: 50%;
  background: ${(props) => props.theme.colors?.white};
  color: ${(props) => props.theme.colors?.black};
  text-align: center;
  padding: 0.5rem;
  outline: none;
  border: none;

  svg {
    margin: auto;
  }
`;

const ShopButtonSection = styled.div`
  position: absolute;
  left: 1.125rem;
  bottom: 1.125rem;
  ${Flex("row", "center")};
  gap: 1rem;
  color: ${(props) => props.theme.colors?.white};

  svg {
    display: inline-block;
  }
`;

const Price = styled.div`
  ${Flex("row", "center")};
  gap: 0.25rem;
`;

const LinkCount = styled.div`
  text-align: center;
`;

const SocialShareWrapper = styled(SelectedWrapper)`
  bottom: -75%;
`;

const Post = ({
  post,
  selectPost,
  openPost,
}: {
  post: PostProps;
  selectPost: () => void;
  openPost: () => void;
}): JSX.Element => {
  const { user }: any = useSelector((state) => state);
  const { isLoggedIn } = useAuth();

  const [viewPopup, setViewPopup] = React.useState<boolean>(false);
  const router = useRouter();

  const handlePostClick = () => {
    if (!isLoggedIn) {
      toast.error("Please login to continue");
      return;
    }
    selectPost();
    openPost();
  };

  const handlePostShare = () => {
    if (!isLoggedIn) {
      toast.error("Please login to continue");
      return;
    }
  };

  const shopLink = `product/${post.productID}?shopID=${post.shopID}`;

  const handleShopLink = () => {
    if (!isLoggedIn) {
      toast.error("Please login to continue");
      return;
    }

    router.push(shopLink);
  };

  const stats = [
    {
      label: "Posts",
      value: post.profile.totalPosts || 0,
    },
    {
      label: "Followers",
      value: post.profile.followers,
    },
    {
      label: "Following",
      value: post.profile.followers,
    },
  ];

  const [showOther, setShowOther] = useState(false);

  const _renderPostActions = () => {
    return (
      <>
        <PostOptions className="PostOptions">
          <PostLikeDislike post={post} LikeCount={true} />
          <PostCircleBox onClick={handlePostClick}>
            <Icons.message size={20} />
          </PostCircleBox>
          <PostCircleBox onClick={handlePostShare}>
            {isLoggedIn ? (
              <CustomSelect
                list={[
                  // {
                  //   label: "Share friends",
                  //   id: "ShareFriends",
                  //   link: "#",
                  //   icon: <Icons.user size={20} />,
                  // },
                  // {
                  //   label: "Other",
                  //   id: "Other",
                  //   onclick: () => setShowOther(true),
                  //   icon: <Icons.tdots size={20} />,
                  // },
                  // showOther &&
                  {
                    id: "SocialShare",
                    link: "#",
                    icon: <PostShare postID={post?.resourceID} />, // Assuming postID is a valid prop
                  },
                ]}
              >
                <Icons.link
                  size={20}
                  style={{ marginBottom: "-5px" }}
                  className="cursor-pointer"
                />
              </CustomSelect>
            ) : (
              <Icons.link size={20} className="cursor-pointer" />
            )}
          </PostCircleBox>
        </PostOptions>
      </>
    );
  };

  return (
    <StoreFrontWrapper
      className="relative md:rounded-xl StoreFrontPost"
      id={post.post.shares}
      style={{ marginBottom: "1.5rem" }}
    >
      {/* Profile section */}
      <div className="relative">
        <UserBlock post={post} toggle={setViewPopup} />
        {false && viewPopup && <UserInfo post={post} stats={stats} />}
      </div>

      {/* Post */}
      <div className="relative rounded-bl-xl rounded-br-xl">
        <ImageCarousal height={200} images={post.post.imageURL} />
        {/* Shop Button */}
        <ShopButtonSection>
          <ShopButton onClick={handleShopLink}>
            <Icons.shop className="text-xl" /> <span>Shop</span>
          </ShopButton>
          {parseInt(post.product.price) > 0 && (
            <Price>
              <Icons.rupee size={16} /> <span> {post.product.price}</span>
              <s></s>
            </Price>
          )}
        </ShopButtonSection>
        {_renderPostActions()}
      </div>
    </StoreFrontWrapper>
  );
};

export default Post;
