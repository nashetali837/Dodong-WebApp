import React, { useEffect, useRef, useState } from "react";
import axios from "axios";
import Image from "next/image";
import { useDispatch, useSelector } from "react-redux";
import PrimaryButton from "@/shared/buttons/primary";
import { updateDraft, deleteDraft } from "@/lib/redux/slices/draft-slice";
import UploadSVG from "../../../../../public/images/upload-image.svg";
import FooterNav from "@/components/sections/FooterButtons";
import styled from "styled-components";
import { Icons } from "@/components/icons";
import { toast } from "react-toastify";
import CategorySubcategory from "@/components/sections/CategorySubcategory";
import { Input } from ".";
import { ButtonPrimary } from "@/shared/buttons/primary";
import { Flex } from "@/components/sections/Styled";
import MediaQuery from "@/components/sections/MediaQuery";
import { PostGallery } from "@/pages/profile/[user_id]";
import VideoPlayer from "@/components/sections/VideoPlayer";

const PostUpload = styled.div`
  display: grid;
  grid-template-columns: repeat(4, minmax(0, 1fr));
  column-gap: 1.5rem;
  margin-bottom: 2rem;

  ${MediaQuery.laptop} {
    grid-template-columns: repeat(3, minmax(0, 1fr));
  }

  ${MediaQuery.tablet} {
    column-gap: 1rem;
    margin-bottom: 1.5rem;
  }

  ${MediaQuery.xs} {
    grid-template-columns: repeat(2, minmax(0, 1fr));
  }

  &.experiences {
    video {
      height: 320px;
    }
  }
  height: 270px;
`;

const Header = styled.div`
  ${Flex("row", "center", "")};
  gap: 3rem;
  margin-bottom: 1.5rem;
  ${MediaQuery.phone} {
    gap: 1rem;
  }
`;

const Loader = styled.div`
  ${Flex("row", "center", "center")};
  height: 100%;
`;

export const BrowseImage = styled.div`
  width: 100%;
  margin: auto;
  border: 1px dashed #e2e2e4;
  border-radius: ${(props) => props.theme.borderRadius.lg};
  flex-direction: column;
  height: 55%;
  padding: 2rem;

  button {
    width: 219px;
    margin: 0px auto;
  }
`;

const OtherBrowserImage = styled(BrowseImage)`
  max-width: 488px;
`;

const PlusIcon = styled.div`
  width: 100px;
  height: 100px;
  background: linear-gradient(
      180deg,
      rgba(255, 255, 255, 0.2) 0%,
      rgba(255, 255, 255, 0) 100%
    ),
    #ff9800;
  box-shadow: 0px 1px 2px -1px rgba(17, 12, 34, 0.08);
  border-radius: ${(props) => props.theme.borderRadius.round};
  color: ${(props) => props.theme.colors.white};
  margin: auto;
  position: relative;
  transform: translateY(-50%);
  top: 50%;

  ${MediaQuery.tablet} {
    width: 50px;
    height: 50px;
  }

  svg {
    font-size: 40px;
    margin: auto;
    position: relative;
    transform: translateY(-50%);
    top: 50%;

    ${MediaQuery.tablet} {
      font-size: 20px;
    }
  }
`;

export const VideoWrapper = styled.div`
  width: 100%;
  height: 100%;
  > video {
    width: 100%;
    min-height: 270px;
    height: 100%;
    border-radius: ${(props) => props.theme.borderRadius.lg};
    object-fit: cover;
  }
`;

const ImgWrapper = styled.div`
  border: 1px solid #e2e2e4;
  border-radius: ${(props) => props.theme.borderRadius.lg};
  position: relative;
  img,
  video {
    object-fit: cover;
    object-position: center;
    height: 100%;
    min-height: 270px;
    width: 100%;
    border-radius: ${(props) => props.theme.borderRadius.lg};
  }
`;

const ContentColumn = styled.div`
  > .p-2 {
    padding: 0px;
  }
  label {
    font-weight: 400;
  }
  textarea {
    border: 1px solid ${(props) => props.theme.colors.border};
    border-radius: ${(props) => props.theme.borderRadius.button};
    padding: 0.5rem 1rem;
    width: 100%;
    outline: none;
    height: 88px;
    margin-bottom: 2rem;
  }
`;

export const ImageDiscard = styled.div`
  background: rgba(0, 0, 0, 0.75);
  border: 1px solid ${(props) => props.theme.colors.black};
  border-radius: ${(props) => props.theme.borderRadius.button};
  box-shadow: 0px 1px 2px -1px rgba(17, 12, 34, 0.08);
  position: absolute;
  top: 10px;
  right: 10px;
  cursor: pointer;
`;

const Section = styled.div`
  // padding: 0 2rem 2rem;
  max-width: 1400px;
  padding: 0 1rem 2rem;
  margin: auto;

  ${MediaQuery.tablet} {
    padding: 0 1rem 1rem;
  }

  ${BrowseImage} {
    width: 100%;
    height: 100%;
  }
`;

const FlexBox = styled.div`
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 1.5rem;
  margin: 1.5rem 0 0;

  ${MediaQuery.phone} {
    grid-template-columns: 1fr;
  }
`;

const TextArea = styled.textarea`
  border: 1px solid ${(props) => props.theme.colors.border};
  border-radius: ${(props) => props.theme.borderRadius.button};
  padding: 0.5rem 1rem;
  width: 100%;
  outline: none;
  height: 88px;
  margin-bottom: 2rem;
`;

const Star = styled(Icons.star)`
  color: ${(props) => props.theme.colors.black};
`;

const SolidStar = styled(Icons.solidstar)`
  color: ${(props) => props.theme.colors.primary};
`;

const StarSection = styled.div`
  display: flex;
  display: -webkit-flex;
  gap: 8px;
  margin-top: 0.35rem;
`;

const Tags = styled.div`
  display: flex;
  display: -webkit-flex;
  gap: 8px;
  flex-wrap: wrap;
  margin-top: 2rem;
  span {
    display: inline-block;
    border: 1px solid ${(props) => props.theme.colors.border};
    padding: 0.25rem 0.5rem;
    border-radius: ${(props) => props.theme.borderRadius.button};
    &:nth-of-type(2n + 1) {
      background: linear-gradient(
          180deg,
          rgba(255, 255, 255, 0.2) 0%,
          rgba(255, 255, 255, 0) 100%
        ),
        #ececed;
    }
  }
`;

// check login
const uploadImage = async (e: any) => {
  // upload file
  let file = e.target.files[0];

  const res = await fetch("/api/upload-s3", {
    headers: {
      "Content-Type": "multipart/form-data",
    },
    method: "POST",
    body: JSON.stringify({
      file: {
        name: "images/" + file.name,
        type: file.type,
      },
    }),
  })
    .then((res) => res.json())
    .catch((err) => {
      console.log(err);
    });

  const url = res.url;

  await axios
    .put(url, file, {
      headers: {
        "Content-Type": file.type,
        "Access-Control-Allow-Origin": "*",
      },
    })
    .catch((err) => {
      console.log(err);
    });

  let uploadedURL =
    "https://post-uploads.s3.ap-northeast-1.amazonaws.com/images/" +
    encodeURI(file.name);

  return uploadedURL;
};

const UploadPage = (props: any) => {
  const { draft }: any = useSelector((state: any) => state.draft);
  const inputRef = useRef<HTMLInputElement | null>(null);
  const [loading, setLoading] = useState(false); // Add loading state

  useEffect(() => {
    if (draft?.images) {
      props.moveForward(draft?.images);
    }
  }, []);

  const onPhotoUpload = async (e: any) => {
    setLoading(true);
    try {
      let uploadedURL = await uploadImage(e);
      props.moveForward([uploadedURL]);
    } finally {
      setLoading(false); // Set loading back to false when upload is complete
    }
  };

  return (
    <div className=" w-full h-full my-auto md:flex items-center px-4 justify-center align-middle">
      <OtherBrowserImage className="flex items-center justify-center align-middle">
        {loading ? (
          <Icons.spinner size={20} className="animate-spin" />
        ) : (
          <>
            <Image
              alt="image-upload"
              className="self-center align-middle mx-auto"
              src={UploadSVG}
              width={150}
              height={150}
            />

            <input
              id="imageUpload"
              ref={inputRef}
              className="hidden"
              placeholder="Upload"
              onChange={onPhotoUpload}
              type="file"
              accept="image/*, video/*"
              multiple
            />
            <p className="mx-auto text-center mb-3 text-sm">
              Drag your images / videos here
            </p>
            <PrimaryButton
              style="block m-auto"
              label="Browse"
              onClick={() => {
                inputRef.current?.click();
              }}
              type="button"
            />
          </>
        )}
      </OtherBrowserImage>
    </div>
  );
};

const SelectCategory = (props: any) => {
  const inputRef = useRef<HTMLInputElement | null>(null);
  const dispatch = useDispatch();
  const [images, setImages] = useState(props.images || []);
  const [loading, setLoading] = useState(false); // Add loading state

  const onPhotoUpload = async (e: any) => {
    setLoading(true);
    try {
      let uploadedURL = await uploadImage(e);
      setImages([...images, uploadedURL]);
    } finally {
      setLoading(false);
    }
  };

  const onPhotoDelete = (index: any) => {
    images.splice(index, 1);
    dispatch(updateDraft({ ...images }));
  };

  return (
    <>
      <Section>
        <Header>
          <CategorySubcategory row={true} />
          <ButtonPrimary
            className="borderButton"
            onClick={() => {
              dispatch(deleteDraft());
              props.moveBackward();
            }}
          >
            Clear All
          </ButtonPrimary>
        </Header>

        <PostUpload>
          <ImageContainer key="upload-image">
            {loading ? (
              <Loader>
                <Icons.spinner size={20} className="animate-spin" />
              </Loader>
            ) : (
              <PlusIcon
                onClick={() => {
                  inputRef.current?.click();
                }}
              >
                <Icons.plus />
              </PlusIcon>
            )}
          </ImageContainer>

          {images?.map((image: string, key: number) => {
            const videoExtensions =
              /\.(mp4|webm|ogg|avi|mov|flv|mkv|wmv|mpg|mpeg|3gp|mp3)$/i;

            return (
              <ImageContainer key={key}>
                {image.match(videoExtensions) ? (
                  <VideoWrapper>
                    <VideoPlayer src={image} />
                  </VideoWrapper>
                ) : (
                  <Image
                    src={image}
                    width={1200}
                    height={1200}
                    alt="post image"
                  />
                )}

                <ImageDiscard
                  onClick={() => {
                    if (images.length === 1) {
                      dispatch(deleteDraft());
                      props.moveBackward();
                    } else {
                      onPhotoDelete(key);
                    }
                  }}
                >
                  <Icons.close className="text-white text-2xl" />
                </ImageDiscard>
              </ImageContainer>
            );
          })}
        </PostUpload>
        {/* add more */}

        <div className="flex justify-between py-3">
          <button className="flex hover:bg-gray-50 p-2 duration-100">
            <input
              className="hidden"
              ref={inputRef}
              id="uploadAnotherPic"
              onChange={onPhotoUpload}
              type="file"
              accept="image/*, video/*"
            />
          </button>
        </div>
      </Section>
      <FooterNav>
        <PrimaryButton
          label="Next"
          onClick={() => props.moveForward(images)}
          type="button"
        />
      </FooterNav>
    </>
  );
};

const UploadDiscovery = (props: any) => {
  const { draft }: any = useSelector((state) => state);
  const inputRef = useRef<HTMLInputElement | null>(null);
  const dispatch = useDispatch();

  const [rating, setRating] = useState(draft?.draft?.rating || 0);
  const [image, setImage] = useState("");
  const [video, setVideo] = useState("");
  const [loading, setLoading] = useState(false); // Add loading state

  const videoExtensions =
    /\.(mp4|webm|ogg|avi|mov|flv|mkv|wmv|mpg|mpeg|3gp|mp3)$/i;

  useEffect(() => {
    if (
      props.images?.[0] &&
      props.images[0].match(videoExtensions) &&
      draft?.draft?.resourceType === "DISCOVERY"
    ) {
      // If it's a video extension, set it as video
      setVideo(props.images[0]);
    } else if (
      props.images?.[0] &&
      draft?.draft?.resourceType === "DISCOVERY"
    ) {
      // If it's not a video extension, set it as image
      setImage(props.images[0]);
    }
  }, [draft?.draft?.resourceType, props.images]);

  const onCloseImageVideo = () => {
    setImage("");
    setVideo("");
    dispatch(updateDraft({ images: [] }));
  };

  const handleRating = (value: any) => {
    setRating(value);
    dispatch(updateDraft({ rating: value }));
  };

  const onChange = (e: any) => {
    const { value } = e.target;
    dispatch(updateDraft({ description: value }));
  };

  const onPhotoUpload = async (e: any) => {
    setLoading(true); // Set loading to true while uploading
    try {
      const uploadedURL = await uploadImage(e);

      if (uploadedURL.match(videoExtensions)) {
        setVideo(uploadedURL);
        setImage("");
      } else {
        setImage(uploadedURL);
        setVideo("");
      }

      dispatch(updateDraft({ images: [uploadedURL] }));
    } finally {
      setLoading(false); // Set loading back to false when upload is complete
    }
  };

  return (
    <>
      <Section>
        <CategorySubcategory row={true} />
        <FlexBox>
          {video ? (
            <VideoWrapper>
              <VideoPlayer src={video} />
              <ImageDiscard onClick={onCloseImageVideo}>
                <Icons.close className="text-white text-2xl" />
              </ImageDiscard>
            </VideoWrapper>
          ) : image ? (
            <ImageContainer className="relative">
              <Image
                src={image}
                width={1200}
                height={1200}
                alt="discovery image"
              />
              <ImageDiscard onClick={onCloseImageVideo}>
                <Icons.close className="text-white text-2xl" />
              </ImageDiscard>
            </ImageContainer>
          ) : (
            <BrowseImage className="flex items-center justify-center align-middle">
              {loading ? (
                <Icons.spinner size={20} className="animate-spin" />
              ) : (
                <>
                  <Image
                    alt="image-upload"
                    className="self-center align-middle mx-auto"
                    src={UploadSVG}
                    width={150}
                    height={150}
                  />
                  <input
                    id="imageUpload"
                    ref={inputRef}
                    className="hidden"
                    placeholder="Upload"
                    onChange={onPhotoUpload}
                    type="file"
                    accept="image/*, video/*"
                  />
                  <p className="mx-auto text-center mb-3 text-sm">
                    Drag your images / videos here
                  </p>
                  <PrimaryButton
                    style="block m-auto"
                    label="Browse"
                    onClick={() => {
                      inputRef.current?.click();
                    }}
                    type="button"
                  />
                </>
              )}
            </BrowseImage>
          )}

          {/* Close button */}
          <ContentColumn>
            <Input
              label="I discovered"
              id="name"
              textarea
              onChange={onChange}
              defaultValue={draft?.draft?.description}
              placeholder="Enter description"
            />

            <p>I want to rate it</p>

            <StarSection>
              {[...Array(5)].map((_, index) => {
                const ratingValue = index + 1;
                const Icon = ratingValue <= rating ? SolidStar : Star;

                return (
                  <Icon
                    size={32}
                    key={`star-${index}`}
                    onClick={() => handleRating(ratingValue)}
                  />
                );
              })}
            </StarSection>
            {false && (
              <Tags>
                <span>Easy</span>
                <span>Value for money</span>
                <span>Meets expectations</span>
                <span>Always recommended</span>
              </Tags>
            )}
          </ContentColumn>
        </FlexBox>
      </Section>
      <FooterNav>
        <PrimaryButton
          label="Next"
          onClick={() => {
            if (image || video) {
              props.moveForward([image || video]);
            } else {
              toast.error("Upload image / video");
            }
          }}
          type="button"
        />
      </FooterNav>
    </>
  );
};

const UploadExperience = (props: any) => {
  const { draft }: any = useSelector((state) => state);
  const inputRef = useRef<HTMLInputElement | null>(null);
  const dispatch = useDispatch();
  const videoExtensions =
    /\.(mp4|webm|ogg|avi|mov|flv|mkv|wmv|mpg|mpeg|3gp|mp3)$/i;

  const [rating, setRating] = useState(0);
  const [image, setImage] = useState("");
  const [video, setVideo] = useState("");
  const [loading, setLoading] = useState(false); // Add loading state

  useEffect(() => {
    if (
      props.images?.[0] &&
      props.images[0].match(videoExtensions) &&
      draft?.draft?.resourceType === "EXPERIENCE"
    ) {
      // If it's a video extension, set it as video
      setVideo(props.images[0]);
    } else if (
      props.images?.[0] &&
      draft?.draft?.resourceType === "EXPERIENCE"
    ) {
      // If it's not a video extension, set it as image
      setImage(props.images[0]);
    }
  }, [draft?.draft?.resourceType, props.images]);

  const onCloseImageVideo = () => {
    setImage("");
    setVideo("");
    dispatch(updateDraft({ images: [] }));
  };

  const handleRating = (value: any) => {
    setRating(value);
    dispatch(updateDraft({ rating: value }));
  };

  const onChange = (e: any) => {
    const { value } = e.target;
    dispatch(updateDraft({ description: value }));
  };

  const onPhotoUpload = async (e: any) => {
    setLoading(true); // Set loading to true while uploading
    try {
      const uploadedURL = await uploadImage(e);

      if (uploadedURL.match(videoExtensions)) {
        setVideo(uploadedURL);
        setImage("");
      } else {
        setImage(uploadedURL);
        setVideo("");
      }

      dispatch(updateDraft({ images: [uploadedURL] }));
    } finally {
      setLoading(false); // Set loading back to false when upload is complete
    }
  };

  return (
    <>
      <Section>
        <CategorySubcategory row={true} />
        <FlexBox>
          {video ? (
            <VideoWrapper>
              <VideoPlayer src={video} />
              <ImageDiscard onClick={onCloseImageVideo}>
                <Icons.close className="text-white text-2xl" />
              </ImageDiscard>
            </VideoWrapper>
          ) : image ? (
            <ImageContainer className="relative">
              <Image
                src={image}
                width={1200}
                height={1200}
                alt="experience image"
              />
              <ImageDiscard onClick={onCloseImageVideo}>
                <Icons.close className="text-white text-2xl" />
              </ImageDiscard>
            </ImageContainer>
          ) : (
            <BrowseImage className="flex items-center justify-center align-middle">
              {loading ? (
                <Icons.spinner size={20} className="animate-spin" />
              ) : (
                <>
                  <Image
                    alt="image-upload"
                    className="self-center align-middle mx-auto"
                    src={UploadSVG}
                    width={150}
                    height={150}
                  />
                  <input
                    id="imageUpload"
                    ref={inputRef}
                    className="hidden"
                    placeholder="Upload"
                    onChange={onPhotoUpload}
                    type="file"
                    accept="image/*, video/*"
                  />
                  <p className="mx-auto text-center mb-3 text-sm">
                    Drag your images / videos here
                  </p>
                  <PrimaryButton
                    style="block m-auto"
                    label="Browse"
                    onClick={() => {
                      inputRef.current?.click();
                    }}
                    type="button"
                  />
                </>
              )}
            </BrowseImage>
          )}

          {/* Close button */}
          <ContentColumn>
            <Input
              label="I discovered"
              id="name"
              textarea
              onChange={onChange}
              placeholder="Enter description"
            />

            <p>I want to rate it</p>

            <StarSection>
              {[...Array(5)].map((_, index) => {
                const ratingValue = index + 1;
                const Icon = ratingValue <= rating ? SolidStar : Star;

                return (
                  <Icon
                    size={32}
                    key={`star-${index}`}
                    onClick={() => handleRating(ratingValue)}
                  />
                );
              })}
            </StarSection>
            {false && (
              <Tags>
                <span>Easy</span>
                <span>Value for money</span>
                <span>Meets expectations</span>
                <span>Always recommended</span>
              </Tags>
            )}
          </ContentColumn>
        </FlexBox>
      </Section>
      <FooterNav>
        <PrimaryButton
          label="Next"
          onClick={() => {
            if (image || video) {
              props.moveForward([image || video]);
            } else {
              toast.error("Upload image / video");
            }
          }}
          type="button"
        />
      </FooterNav>
    </>
  );
};

const ImageContainer = (props: any) => {
  return <ImgWrapper>{props.children}</ImgWrapper>;
};

export {
  UploadPage,
  SelectCategory,
  uploadImage,
  UploadDiscovery,
  UploadExperience,
};
