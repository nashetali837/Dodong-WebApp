import React from "react";
import GooglePlacesAutocomplete from "react-google-places-autocomplete";
import { useDispatch, useSelector } from "react-redux";
import { ProductInfo } from "./addProduct";
import {
  SelectCategory,
  UploadPage,
  UploadDiscovery,
  UploadExperience,
} from "./UploadImage";
import { ShopInfo } from "./ShopInformation";
import { Settings } from "./Settings";
import Tabs, { TabSection } from "@/shared/buttons/tabs";
import { updateDraft } from "@/lib/redux/slices/draft-slice";
import styled from "styled-components";
import { PopupHeader } from "@/components/profile/ui/info";
import { deleteDraft } from "@/lib/redux/slices/draft-slice";

const CreatPost = styled.div`
  overflow-y: auto;
  ${TabSection} {
    margin: 1.25rem auto;
  }
`;

const Input = (props: any) => {
  if (props.type === "select") {
    return (
      <div className="p-2">
        <div className="py-1">
          <label htmlFor={props.id} className="text-sm">
            {props.label}
          </label>
        </div>
        <div>
          <select
            multiple={props.multiple}
            id={props.id}
            required={props.required}
            onChange={props.onChange}
            className="w-full duration-200 text-gray-800 p-2 border border-neutral-400 rounded-md"
          >
            {props.options.map((option: any, key: number) => (
              <option key={key} value={option.value}>
                {option.label}
              </option>
            ))}
          </select>
        </div>
      </div>
    );
  }
  if (props.type === "google-places") {
    return (
      <div className="p-2">
        <div className="py-1">
          <label htmlFor={props.id} className="text-sm">
            {props.label}
          </label>
        </div>
        <div>
          <GooglePlacesAutocomplete
            minLengthAutocomplete={3}
            apiKey={process.env.GOOGLE_API_KEY}
            selectProps={{
              onChange: props.onChange,
              placeholder: props.placeholder,
              className:
                "w-full duration-200 text-gray-800 border border-neutral-400 rounded-md",
            }}
            debounce={500}
            apiOptions={{
              language: "en",
              region: "IN",
              version: "3",
            }}
          />
        </div>
      </div>
    );
  }

  return (
    <div className="p-2">
      <div className="py-1">
        <label htmlFor={props.id} className="text-sm">
          {props.label}
        </label>
      </div>
      {props.textarea ? (
        <textarea
          id={props.id}
          onChange={props.onChange}
          defaultValue={props.defaultValue}
          className=""
          placeholder={props.placeholder}
        />
      ) : (
        <input
          id={props.id}
          type={props.type || "text"}
          maxLength={props.maxLength}
          min={props.minLength}
          onChange={props.onChange}
          required={props.required || false}
          defaultValue={props.defaultValue}
          className=""
          placeholder={props.placeholder}
        />
      )}
    </div>
  );
};

const CreatePost = ({ viewHeader = true }: { viewHeader?: boolean }) => {
  const dispatch = useDispatch();
  const { draft }: any = useSelector((state: any) => state.draft);
  const [post, setPost] = React.useState<{
    title: string;
    images: string[];
    product?: any;
  }>({
    title: "",
    images: draft?.images || [],
  });

  const [loading, setLoading] = React.useState<boolean>(false);
  const [postType, setPostType] = React.useState<string>("Post");
  const [resourceType, setResourceType] = React.useState<string>("POST");

  const [tabPages, setTabPages] = React.useState<{ [key: string]: number }>({
    Post: 0,
    Discoveries: 0,
    Experiences: 0,
    Collections: 0,
  });

  const [currentPage, setCurrentPage] = React.useState<number>(0);

  const moveForward = () => {
    if (currentPage === 4) {
      return;
    }
    if (currentPage === 0) {
      if (postType === "Discoveries" || postType === "Experiences") {
        setTabPages((prevPages) => ({ ...prevPages, [postType]: 2 }));
        return setCurrentPage(currentPage + 2);
      }
    }
    if (currentPage === 2) {
      setTabPages((prevPages) => ({ ...prevPages, [postType]: 2 }));
      return setCurrentPage(currentPage + 2);
    }
    setTabPages((prevPages) => ({ ...prevPages, [postType]: currentPage + 1 }));
    setCurrentPage(currentPage + 1);
  };

  const moveBackward = () => {
    if (currentPage === 0) {
      return;
    }
    if (currentPage === 2) {
      if (postType === "Discoveries" || postType === "Experiences") {
        setTabPages((prevPages) => ({ ...prevPages, [postType]: 0 }));
        return setCurrentPage(currentPage - 2);
      }
    }
    if (currentPage === 4) {
      setTabPages((prevPages) => ({ ...prevPages, [postType]: 2 }));
      return setCurrentPage(currentPage - 2);
    }
    setTabPages((prevPages) => ({ ...prevPages, [postType]: currentPage - 1 }));
    setCurrentPage(currentPage - 1);
  };

  let StartingPage;

  switch (postType) {
    case "Discoveries":
      StartingPage = UploadDiscovery;
      break;
    case "Experiences":
      StartingPage = UploadExperience;
      break;
    default:
      StartingPage = UploadPage;
      break;
  }

  const FORM: any = {
    0: {
      component: (
        <StartingPage
          images={post.images}
          moveForward={(images: any) => {
            console.log(images);
            setPost({ ...post, images: images });
            dispatch(updateDraft({ images, resourceType }));
            moveForward();
          }}
          moveBackward={moveBackward}
        />
      ),
      label:
        "Create a post that highlights your favorite local shops! Share what you recently purchased, provide shopping tips, recommend standout products, and recount your unique shopping experiences. By doing so, you'll help these local businesses shine and introduce them to your followers. Let's come together to support and promote our local shops",
    },

    1: {
      component: (
        <SelectCategory
          images={post.images}
          moveForward={(images: any) => {
            console.log("--> images: ", images);
            setPost({ ...post, images: images });
            dispatch(updateDraft({ images, resourceType }));

            moveForward();
          }}
          moveBackward={moveBackward}
        />
      ),
      label:
        "You can add posts, discoveries, collections to profile for your viewers to connect with you.",
    },

    2: {
      component: (
        <ProductInfo
          images={post.images}
          moveForward={(postData: any) => {
            setPost({ ...post, product: postData });
            moveForward();
          }}
          moveBackward={(postData: any) => {
            setPost({ ...post, product: postData });
            moveBackward();
          }}
        />
      ),
      label:
        "Enter all details about the product for your viewers best experience",
    },

    3: {
      component: (
        <ShopInfo
          product={post?.product}
          images={post.images}
          moveForward={(shopData: any) => {
            setPost({ ...post, ...shopData });
            dispatch(updateDraft({ ...post, ...shopData, resourceType }));
            console.log("post", JSON.stringify({ ...post, ...shopData }));
            moveForward();
          }}
          moveBackward={moveBackward}
        />
      ),
      label:
        "You can add posts, discoveries, collections to profile for your viewers to connect with you.",
    },

    4: {
      component: (
        <Settings
          product={post?.product}
          images={post.images}
          moveForward={moveForward}
          moveBackward={moveBackward}
        />
      ),
      label: "Guide the users so that they don’t do generic post",
    },
  };

  const _renderModes = () => {
    const modes = [
      { label: "Post", id: "Post", type: "POST" },
      { label: "Discoveries", id: "Discoveries", type: "DISCOVERY" },
      { label: "Experiences", id: "Experiences", type: "EXPERIENCE" },
      // { label: "Collections", id: "Collections", type: "COLLECTION" },
    ];

    return (
      <Tabs
        modes={modes}
        currentTab={postType}
        onChange={(id: string) => {
          setPostType(id);
          setCurrentPage(tabPages[id]);
          const mode = modes.find((mode) => mode.id === id);
          if (mode) {
            setResourceType(mode.type);
            dispatch(updateDraft({ resourceType: mode.type }));
            dispatch(deleteDraft());
          }
        }}
      />
    );
  };

  const progress = (currentPage / Object.keys(FORM).length) * 100;

  return (
    <CreatPost className="bg-white h-full w-full CreatPost">
      {viewHeader && (
        <PopupHeader>
          {FORM[currentPage as keyof typeof FORM].label}
        </PopupHeader>
      )}

      {_renderModes()}

      {FORM[currentPage as keyof typeof FORM].component}
    </CreatPost>
  );
};

export default CreatePost;

export { Input };
