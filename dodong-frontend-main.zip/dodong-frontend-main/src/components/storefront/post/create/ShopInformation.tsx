import styled from "styled-components";
import { EndPoints } from "@/lib/apiConstants";
import { postRequest } from "@/lib/networkHelper";
import { useEffect, useState } from "react";
import { Icons } from "@/components/icons";
import { useDispatch, useSelector } from "react-redux";
import { updateDraft } from "@/lib/redux/slices/draft-slice";
import { toast } from "react-toastify";
import { Input } from ".";
import GoogleMapReact from "google-map-react";
import useAuth from "@/components/auth/hooks/useAuth";
import PrimaryButton from "@/shared/buttons/primary";
import { geocodeByAddress, getLatLng } from "react-google-places-autocomplete";
import FooterNav from "@/components/sections/FooterButtons";
import CategorySubcategory from "@/components/sections/CategorySubcategory";
import MediaQuery from "@/components/sections/MediaQuery";

const PinPoint = styled.div`
  svg {
    color: ${(props) => props.theme.colors.primary};
  }
`;

const CategorySubcategoryStyled = styled(CategorySubcategory)`
  display: grid;
  grid-column: 1 / -1;
  grid-template-columns: repeat(2, minmax(0, 1fr));
  gap: 1rem;
  ${MediaQuery.phone} {
    grid-template-columns: 1fr;
    gap: 0rem;
  }
`;

const ShopInfo = (props: any) => {
  const { draft = {} }: any = useSelector((state: any) => state.draft);
  const { authToken } = useAuth();
  const dispatch = useDispatch();
  const [shops, setShops] = useState([]);
  const categories = props.categories;
  const subCategories = props.subCategories;
  const [newShop, setNewShop] = useState({
    name: "",
    contact: "",
    email: "",
    address: "",
    bio: "",
    website: "",
    categoryID: draft?.categoryID,
    subCategoryID: draft?.subCategoryID,
  });

  const [location, setLocation] = useState({
    lat: 10.99835602,
    lng: 77.01502627,
  });

  const onChange = (e: any) => {
    setNewShop({ ...newShop, [e.target.id]: e.target.value });
  };

  useEffect(() => {
    if (newShop.address) {
      geocodeByAddress(newShop.address)
        .then((results) => getLatLng(results[0]))
        .then(({ lat, lng }) => setLocation({ lat, lng }))
        .catch((error) => console.log("Error geocoding address:", error));
    }
  }, [newShop.address]);

  const createNewShopHandler = () => {
    if (!newShop.name) {
      toast.error("Please enter the shop name");
      return;
    }

    if (!newShop.address) {
      toast.error("Please enter the shop location");
      return;
    }

    const data = {
      ...newShop,
      location: {
        latitude: location.lat,
        longitude: location.lng,
        name: newShop.address, // from google maps
      },
    };

    postRequest(EndPoints.createShop, data, authToken)
      .then((res) => {
        console.log("New shop created:", res);
        toast.success("New Shop created", {
          type: "success",
        });
        dispatch(
          updateDraft({
            shopID: res.data.shopID,
          })
        );
        props.moveForward();
      })
      .catch((err) => {
        console.log(err);
        toast.error("Something went wrong", {
          type: "error",
        });
      });
  };

  return (
    <div>
      {/* inputs in two columns */}
      <div className="grid grid-cols-1 md:grid-cols-2 md:gap-6">
        <div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-x-4 gap-y-0">
            <Input
              label="Shop Name"
              id="name"
              placeholder=""
              required
              onChange={onChange}
            />

            <Input
              id="localAddress"
              type="google-places"
              label="Area"
              required
              onChange={(e: any) => {
                setNewShop({ ...newShop, address: e.value.description });
              }}
              placeholder="Select Location"
            />

            <Input
              label="Contact"
              id="contact"
              type="tel"
              placeholder=""
              maxLength={13}
              onChange={onChange}
            />

            <Input
              label="Email"
              id="email"
              type="email"
              placeholder=""
              onChange={onChange}
            />

            <Input
              label="Description"
              id="bio"
              placeholder=""
              onChange={onChange}
            />

            <Input
              label="Website"
              id="website"
              type="url"
              placeholder=""
              onChange={onChange}
            />

            <CategorySubcategoryStyled label />

            {/* <Input
              label="Category"
              required
              id="categoryds"
              type="select"
              // defaultValue={product?.categoryID}
              options={
                categories?.map((category: any) => {
                  return {
                    label: category.name,
                    value: parseInt(category.id),
                  };
                }) || []
              }
              onChange={(e: any) => {
                console.log(typeof e.target.value);
                setNewShop({
                  ...newShop,
                  categoryID: parseInt(e.target.value),
                });
              }}
              placeholder="Select"
            /> */}

            {/* <Input
              label="Sub-Category"
              id="sub_categorysd"
              required
              type="select"
              options={
                subCategories?.map((category: any) => {
                  return {
                    label: category.name,
                    value: parseInt(category.id),
                  };
                }) || []
              }
              onChange={(e: any) => {
                setNewShop({
                  ...newShop,
                  subCategoryID: parseInt(e.target.value),
                });
              }}
              placeholder="Select"
            /> */}
          </div>
        </div>
        <div className="pt-4 flex flex-col gap-1">
          <GoogleMapReact
            bootstrapURLKeys={{
              key: `${process.env.GOOGLE_API_KEY}`,
            }}
            // onChange={(e: any) => {
            //   console.log("e", e);
            //   setLocation({ ...e.center });
            // }}  // TODO
            defaultCenter={location}
            defaultZoom={17}
            center={location} // Set the center prop to update the map center dynamically
          >
            <PinPoint {...location}>
              <Icons.map className="text-xl text-black" />
            </PinPoint>
          </GoogleMapReact>
        </div>
      </div>
      <FooterNav>
        <PrimaryButton
          style="borderButton"
          label="Back"
          onClick={props.handleShopBack}
          type="button"
        />
        <PrimaryButton
          label="Next"
          onClick={createNewShopHandler}
          type="submit"
        />
      </FooterNav>
    </div>
  );
};

export { ShopInfo };
