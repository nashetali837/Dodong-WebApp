// /components/NoSSR.js

import dynamic from "next/dynamic";

const NoSSR = ({ children }: { children: any }) => <>{children}</>;

export default dynamic(() => Promise.resolve(NoSSR), { ssr: false });
