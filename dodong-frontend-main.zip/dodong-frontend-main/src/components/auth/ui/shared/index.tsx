import React from "react";
import styled from "styled-components";

const Separator = styled.div`
  position: relative;
  margin: 1.5rem 0;
  text-align: center;
  z-index: 1;

  &::before {
    content: "";
    position: absolute;
    top: 50%;
    width: 100%;
    left: 0px;
    height: 1px;
    background: ${(props) => props.theme.colors?.border};
    z-index: -1;
  }
`;

const Title = styled.span`
  background: ${(props) => props.theme.colors?.white};
  display: inline-block;
  padding: 0 0.5rem;
  font-size: 12px;
`;

export default function SeparatorLine({ label = "OR" }: { label?: string }) {
  return (
    <Separator>
      <Title>{label}</Title>
    </Separator>
  );
}
