"use client";
import React from "react";
import { FacebookProvider } from "react-facebook";
import dynamic from "next/dynamic";
import { useDispatch } from "react-redux";
import { GoogleLogin } from "@react-oauth/google";

import { EndPoints } from "@/lib/apiConstants";
import { saveUser, toggleLoginModal } from "@/lib/redux/slices/user-slice";
import { updateAuthState } from "@/lib/redux/slices/auth-slice";
import { toast } from "react-toastify";
import { facebookAppId } from "@/components/auth/facebook";
import { AuthModalType } from "../..";
import {
  CheckBoxGroup,
  Label,
  CheckBox,
  SocialLoginButton,
} from "@/components/sections/Styled";
import styled from "styled-components";
import { Flex } from "@/components/sections/Styled";
import { Icons } from "@/components/icons";
import { useRouter } from "next/router";

const GoogleLoginButton = styled(SocialLoginButton)`
  .googleicon {
    position: absolute;
    z-index: -1;
  }
  > div:nth-of-type(1) {
    filter: opacity(0);
  }
  div {
    margin: 0px;
    border: none;
    background: transparent;
    &:hover {
      background: transparent;
    }
    iframe {
      width: 2.875rem !important;
      height: 2.875rem !important;
      filter: opacity(0);
      border-radius: 12px;
    }

    span {
      display: none;
    }
  }
`;

const SocialLogin = styled.div`
  ${Flex("row", "center")};
  gap: 1rem;
`;

const SignUp = styled.div`
  text-align: center;
  margin: 2rem 0;
`;

const Link = styled.button`
  color: ${(props) => props.theme.colors.primary};
  cursor: pointer;
  border: none;
  outline: none;
  display: contents;
`;

const FacebookButton = dynamic(() => import("@/components/auth/facebook"), {
  ssr: false,
});

const SocialLoginComponent = (props: any) => {
  const dispatch = useDispatch();
  const router = useRouter();
  const handleLinkClick = () => {
    // Perform the action to toggle the login modal
    dispatch(toggleLoginModal(false));

    router.push(`/terms`);

    // window.location.href = `${process.env.NEXT_PUBLIC_WEBSITE_URL}/terms`;
    // window.open(`${process.env.NEXT_PUBLIC_WEBSITE_URL}/terms`, "_blank");
  };

  const responseSuccessGoogle = (response: any) => {
    console.log("Google auth response", response);

    fetch(EndPoints.googleAuth, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ tokenId: response.credential }),
    })
      .then((res) => {
        if (res.status === 200) {
          return res.json();
        }
        throw new Error("Google authentication failed");
      })
      .then((resJson) => {
        console.log("Google auth response", resJson);
        if (resJson) {
          dispatch(
            updateAuthState({ authToken: resJson.token, isLoggedIn: true })
          );
          dispatch(saveUser(resJson.user));
          dispatch(toggleLoginModal(false));
          toast.success("Google login successful!");
        }
      })
      .catch((error) => {
        console.log("Google auth error", error);
        toast.error("Google login failed. Please try again!");
      });
  };

  const responseFailGoogle = () => {
    toast.error("Google login failed. Please try again!");
  };

  return (
    <React.Fragment>
      <SocialLogin className="SocialLogin">
        <GoogleLoginButton className="googleloginbtn">
          <GoogleLogin
            onSuccess={responseSuccessGoogle}
            onError={responseFailGoogle}
          />
          <Icons.googleicon className="googleicon" size={22} />
        </GoogleLoginButton>

        <FacebookProvider appId={facebookAppId}>
          <FacebookButton />
        </FacebookProvider>
      </SocialLogin>
      <SignUp>
        {props.authType === AuthModalType.LOGIN
          ? "Don't have an account? "
          : "Already have an account? "}

        <Link
          onClick={() => {
            props.switch(
              props.authType === AuthModalType.SIGNUP
                ? AuthModalType.LOGIN
                : AuthModalType.SIGNUP
            );
          }}
        >
          {props.authType === AuthModalType.LOGIN ? "Sign up" : "Sign in"}
        </Link>
      </SignUp>
      {props.authType === AuthModalType.LOGIN && (
        <CheckBoxGroup>
          <CheckBox id="agreed" type="checkbox" value="" />
          <Label htmlFor="agreed">
            I have read and understood the{" "}
            <Link onClick={handleLinkClick}>Terms and Privacy Policy</Link>
          </Label>
        </CheckBoxGroup>
      )}
    </React.Fragment>
  );
};

export default SocialLoginComponent;
