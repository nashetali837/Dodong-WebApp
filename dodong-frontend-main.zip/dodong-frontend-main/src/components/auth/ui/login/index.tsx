"use client";

import React, { useState } from "react";
import z, { ZodError } from "zod";
import { toast } from "react-toastify";
import { useRouter } from "next/navigation";
import { useMutation } from "@tanstack/react-query";
import { userSignInSchema } from "@/lib/validations/auth";
import { postRequest } from "@/lib/networkHelper";
import { EndPoints } from "@/lib/apiConstants";
import axios from "axios";
import { useDispatch } from "react-redux";
import {
  saveUser,
  toggleForgotPasswordModal,
  toggleLoginModal,
} from "@/lib/redux/slices/user-slice";
import { updateAuthState } from "@/lib/redux/slices/auth-slice";
import { fromZodError } from "zod-validation-error";
import TextInput from "@/shared/input-groups/TextInput";
import PrimaryButton from "@/shared/buttons/primary";
import styled from "styled-components";
import { Flex } from "@/components/sections/Styled";
import { ButtonPrimary } from "@/shared/buttons/primary";
import { CheckBoxGroup, Label, CheckBox } from "@/components/sections/Styled";
import ErrorText from "@/components/form/ErrorText";

export const ModalForm = styled.form`
  display: grid;
  gap: 1.5rem;

  label {
    font-size: 12px;
  }
  ${ButtonPrimary} {
    width: 100%;
    background: linear-gradient(
        180deg,
        rgba(255, 255, 255, 0.2) 0%,
        rgba(255, 255, 255, 0) 100%
      ),
      ${(props) => props.theme.colors?.primary};
    line-height: 28px;
  }
`;
const Footer = styled.div`
  ${Flex("row", "", "space-between")};
  margin-top: 1.5rem;
`;

const Button = styled.button`
  color: ${(props) => props.theme.colors?.black};
`;

interface UserAuthFormProps extends React.HTMLAttributes<HTMLDivElement> {}

type userSignInSchema = z.infer<typeof userSignInSchema>;

export function UserLoginForm({ className, ...props }: UserAuthFormProps) {
  const dispatch = useDispatch();
  const [loading, setLoading] = useState(false);
  const [errorText, setErrorText] = useState();

  const mutation = useMutation({
    mutationFn: (data: userSignInSchema) => {
      return postRequest(EndPoints.login, data);
    },
    onSuccess: (response) => {
      console.log(response.data, "returned data");
      dispatch(updateAuthState({ authToken: response.data.token }));
      dispatch(
        saveUser({
          ...response.data,
        })
      );
      dispatch(toggleLoginModal(false));
      toast.success("Login Successful");
      setLoading(false);
    },

    onError: (error: any) => {
      console.log(error.response?.data);
      if (axios.isAxiosError(error)) {
        // toast.error(error.response?.data.message);
        setErrorText(error.response?.data.message);
      }
      if (error instanceof ZodError) {
        console.log(fromZodError(error));
        return toast.error("Please enter valid data");
      }
      setLoading(false);
    },
  });

  const handleSubmit = (event: React.FormEvent<HTMLFormElement>): any => {
    event.preventDefault();
    setLoading(true);

    try {
      const data = {
        email: (event.target as HTMLFormElement).email.value,
        password: (event.target as HTMLFormElement).password.value,
      };

      if (!data.email || !data.password) {
        toast.error("Please enter all the fields");
        setLoading(false);
        return;
      }

      const isValidData = userSignInSchema.parse(data);
      mutation.mutate(isValidData);
    } catch (error: any) {
      if (error instanceof ZodError) {
        const validationError = fromZodError(error);
        setLoading(false);
        // toast.error(validationError.message);
      }
    }
  };

  return (
    <>
      <ModalForm onSubmit={handleSubmit}>
        <TextInput
          id="email"
          label="Email Address"
          type="email"
          placeholder="Enter Email/Phone Number"
        />
        <div>
          <TextInput
            id="password"
            label="Password"
            type="password"
            placeholder="**********"
          />{" "}
          <ErrorText errorMessage={errorText} />
        </div>

        <PrimaryButton
          type="submit"
          disabled={loading}
          label="Sign In"
          loading={loading}
        />
      </ModalForm>

      <Footer>
        <CheckBoxGroup>
          <CheckBox id="link-checkbox" type="checkbox" value="" />
          <Label htmlFor="link-checkbox">Keep me logged in</Label>
        </CheckBoxGroup>

        <Button
          onClick={() => {
            dispatch(toggleForgotPasswordModal(true));
          }}
        >
          Forgot password?
        </Button>
      </Footer>
    </>
  );
}
