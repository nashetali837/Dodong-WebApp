"use client";

import { ModalForm } from "../login";
import * as React from "react";
import * as z from "zod";
import { userSignUpSchema } from "@/lib/validations/auth";
import { useMutation } from "@tanstack/react-query";
import { postRequest } from "@/lib/networkHelper";
import { EndPoints } from "@/lib/apiConstants";
import { ZodError } from "zod";
import axios from "axios";
import { toast } from "react-toastify";
import { useDispatch } from "react-redux";
import { saveUser, toggleLoginModal } from "@/lib/redux/slices/user-slice";
import TextInput from "@/shared/input-groups/TextInput";
import PrimaryButton from "@/shared/buttons/primary";
import { updateAuthState } from "@/lib/redux/slices/auth-slice";

interface UserAuthFormProps extends React.HTMLAttributes<HTMLDivElement> {
  switch: any;
}
type userSignUpSchema = z.infer<typeof userSignUpSchema>;

enum SignupFormTypes {
  email = "email",
  otp = "otp",
  userDetails = "userDetails",
}

const SignUpForms = {
  [SignupFormTypes.email]: {
    label: "",
    fields: [
      {
        label: "Enter Mobile Number",
        placeholder: "Mobile number",
        type: "number",
        id: "mobileNumber",
        required: true,
      },
      {
        label: "Enter Email Address",
        placeholder: "name@example.com",
        type: "email",
        required: true,
      },
    ],
    nextButtonLabel: "Send OTP",
    nextPage: SignupFormTypes.otp,
  },

  [SignupFormTypes.otp]: {
    label:
      "A four-digit code is sent to your email. Keep this window open while you check your email, and enter the code below.",
    fields: [
      {
        label: "OTP",
        placeholder: "X X X X",
        type: "number",
        id: "otp",
        required: true,
      },
    ],
    nextButtonLabel: "Submit",
    nextPage: SignupFormTypes.userDetails,
  },

  [SignupFormTypes.userDetails]: {
    label: "Final Step! Please enter below details and we are good to go!",
    fields: [
      {
        label: "Your Full Name",
        placeholder: "John Doe",
        type: "text",
        id: "name",
        required: true,
      },
      {
        label: "Password",
        placeholder: "**********",
        type: "password",
        id: "password",
        required: true,
      },
      {
        label: "Confirm Password",
        placeholder: "**********",
        type: "password",
        id: "confirmPassword",
        required: true,
      },
    ],
    nextButtonLabel: "Confirm",
    nextPage: SignupFormTypes.userDetails,
  },
};

export function UserSignupForm({ className, ...props }: UserAuthFormProps) {
  const dispatch = useDispatch();

  const [isLoading, setIsLoading] = React.useState<boolean>(false);
  const [form, setForm] = React.useState<SignupFormTypes>(
    SignupFormTypes.email
  );
  const [data, setData] = React.useState({
    email: "",
    otp: "",
    password: "",
    confirmPassword: "",
    name: "",
    mobileNumber: "",
    accessToken: "",
  });

  const mutation = useMutation({
    mutationFn: (formData: userSignUpSchema) => {
      return postRequest(EndPoints.signup, formData, data?.accessToken);
    },
    onSuccess: (data) => {
      setIsLoading(false);
      console.log(data, "returned data");
      // toast('Here is your toast.')
      toast.success(
        "Yay! Your account is created successfully. Welcome aboard"
      );

      dispatch(updateAuthState({ authToken: data.data.token }));
      dispatch(
        saveUser({
          ...data.data,
        })
      );

      dispatch(toggleLoginModal(false));
    },

    onError: (error: any) => {
      setIsLoading(false);

      if (error instanceof ZodError) {
        console.log(error.flatten(), "error");
        toast.error("Please valid data");
      }

      if (axios.isAxiosError(error)) {
        console.log("---", error);
        if (error.response?.data?.errors) {
          toast.error(error.response.data.errors[0].msg);
        } else {
          toast.error(error.response?.data.message);
        }
      } else {
        console.log("---", error);
      }
    },
  });

  const onChange = (event: any) => {
    setData({ ...data, [event.target.name]: event.target.value });
  };

  const sendOTP = async () => {
    try {
      let axiosResponse = await axios.post(EndPoints.verifyEmail, {
        email: data.email,
        mobileNumber: data.mobileNumber,
      });
      console.log("response", axiosResponse);

      if (axiosResponse.data.status === "success") {
        toast.success(axiosResponse.data.message);
        setIsLoading(false);
        setForm(SignUpForms[form].nextPage);
      } else {
        toast.error(axiosResponse.data.message);
        if (axiosResponse.data.data.alreadyUser) {
          props.switch();
        }
        setIsLoading(false);
      }
    } catch (error) {
      // @ts-ignore
      toast.error(error?.message || "Something went wrong. Please try again");
      setIsLoading(false);
    }
  };

  const verifyOTP = async () => {
    try {
      let axiosResponse = await axios.post(EndPoints.verifyOtp, {
        email: data.email,
        OTP: data.otp,
      });
      console.log("response", axiosResponse);

      if (axiosResponse.data.status === "success") {
        toast.success(axiosResponse.data.message);
        setIsLoading(false);
        setData({
          ...data,
          accessToken: axiosResponse.data.data.temporaryToken,
        });
        setForm(SignUpForms[form].nextPage);
      } else {
        toast.error(axiosResponse.data.message);
        setIsLoading(false);
      }
    } catch (error) {
      // @ts-ignore
      toast.error(error.message || "Something went wrong. Please try again");
      setIsLoading(false);
    }
  };

  const handleSubmit = (event: React.FormEvent<HTMLFormElement>): any => {
    event.preventDefault();
    setIsLoading(true);

    // After user enters email
    if (form === SignupFormTypes.email) {
      sendOTP();
      return;
    }

    // After user enters email
    if (form === SignupFormTypes.otp) {
      verifyOTP();
      return;
    }

    try {
      const formData = {
        password: (event.target as HTMLFormElement).password.value,
        // @ts-ignore
        name: (event.target as HTMLFormElement).name.value,
      };

      if (!formData.password || !formData.name) {
        setIsLoading(false);
        toast.error("Please enter all the fields");
        return;
      }

      console.log(
        "data.password",
        data.password,
        (event.target as HTMLFormElement).confirmPassword.value
      );

      if (
        data.password !==
        (event.target as HTMLFormElement).confirmPassword.value
      ) {
        setIsLoading(false);
        toast.error("Passwords do not match");
        return;
      }
      console.log("data", data);
      const isValidData = userSignUpSchema.parse(data);
      console.log("isValidData", isValidData);
      mutation.mutate(isValidData);
    } catch (error: any) {
      setIsLoading(false);
      console.log((error as ZodError).format());
      console.log(error);
      error.flatten().formErrors.length > 0 &&
        toast.error(error.flatten().formErrors[0]);
    }
  };
  return (
    <>
      <ModalForm onSubmit={handleSubmit}>
        <p>{SignUpForms[form].label}</p>
        {SignUpForms[form].fields.map((form: any, k: number) => (
          <TextInput
            key={"field_" + form.id}
            id={form.id}
            autoFocus={k === 0}
            label={form.label}
            required={form.required}
            type={form.type}
            placeholder={form.placeholder}
            onChange={onChange}
          />
        ))}
        <PrimaryButton
          type="submit"
          label={SignUpForms[form].nextButtonLabel}
          loading={isLoading}
          disabled={isLoading}
        />
      </ModalForm>
    </>
  );
}
