"use client";

import React, { useState } from "react";
import z, { ZodError } from "zod";
import { toast } from "react-toastify";
import { useMutation } from "@tanstack/react-query";
import { otpSchema } from "@/lib/validations/auth";
import { postRequest } from "@/lib/networkHelper";
import { EndPoints } from "@/lib/apiConstants";
import axios from "axios";
import { useDispatch } from "react-redux";
import { Icons } from "../../../icons";
import { ModalForm } from "../login";
import { ButtonPrimary } from "@/shared/buttons/primary";
import { Heading as Title } from "@/components/sections/Styled";
import styled from "styled-components";
import { fromZodError } from "zod-validation-error";

const Heading = styled(Title)`
  text-align: center;
  margin-bottom: 0px;
`;

type otpSchema = z.infer<typeof otpSchema>;

export function OtpAuthForm(props: {
  email: string;
  switch: any;
  forgotPassword?: boolean;
}) {
  const [loading, setLoading] = useState(false);

  const mutation = useMutation({
    mutationFn: (data: otpSchema) => {
      return postRequest(EndPoints.verifyOtp, data);
    },
    onSuccess: (response) => {
      console.log(response.data, "returned data");

      setLoading(false);
      props.switch({
        temporaryToken: response.data.data.temporaryToken,
      });
    },

    onError: (error: any) => {
      setLoading(false);
      console.log(error.response?.data);
      if (axios.isAxiosError(error)) {
        toast.error(error.response?.data.message);
      }
      setLoading(false);
      if (error instanceof ZodError) {
        console.log(fromZodError(error));
        return toast.error("Please enter valid data");
      }
    },
  });

  const handleSubmit = (event: React.FormEvent<HTMLFormElement>): any => {
    event.preventDefault();

    try {
      const data = {
        OTP: (event.target as HTMLFormElement).otp.value,
        email: props.email,
        forgotPassword: props.forgotPassword,
      };

      if (!data.OTP) {
        toast.error("Please enter all the fields");
        return;
      }

      setLoading(true);
      mutation.mutate(data);
    } catch (error: any) {
      if (error instanceof ZodError) {
        const validationError = fromZodError(error);
        setLoading(false);
        toast.error(validationError.message);
      }
    }
  };

  return (
    <ModalForm onSubmit={handleSubmit}>
      <Heading>Enter OTP received to {props.email}</Heading>
      <div className="grid gap-2">
        <div className="grid gap-1">
          <input
            id="otp"
            placeholder="OTP"
            className="bg-transparent text-734400 my-1 mb-2 block h-9 w-full rounded-md border border-734400 py-2 px-3 text-sm placeholder:text-734400 hover:border-734400 focus:border-734400 focus:outline-none"
            type="number"
            name="otp"
          />
        </div>
        <ButtonPrimary disabled={loading}>
          {loading && <Icons.spinner className="mr-2 h-4 w-4 animate-spin" />}
          Verify OTP
        </ButtonPrimary>
      </div>
    </ModalForm>
  );
}
