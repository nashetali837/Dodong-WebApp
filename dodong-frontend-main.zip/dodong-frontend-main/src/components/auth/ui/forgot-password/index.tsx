"use client";
import React, { useState } from "react";
import Image from "next/image";
import dodongLogo from "../../../../../public/images/common/dodong-logo.svg";
import { useDispatch, useSelector } from "react-redux";
import {
  toggleForgotPasswordModal,
  toggleLoginModal,
} from "@/lib/redux/slices/user-slice";
import { useRouter } from "next/router";
import { ForgotPasswordAuthForm } from "./forgot-password-form";
import { OtpAuthForm } from "./otp-form";
import { ResetPasswordForm } from "./reset-password-form";
import { Icons } from "@/components/icons";
import {
  ModalLoginPopUp,
  PopUpCloseButton,
  PopUpHeader,
  HeadingLg,
} from "@/components/sections/Styled";
import styled from "styled-components";
import { Button } from "@/components/sections/Styled";

const ForgotPasswordForm = styled(ModalLoginPopUp)`
  max-width: 384px;
`;

export default function ForgotPasswordModal() {
  const { openForgotPasswordModal } = useSelector((state: any) => state.user);
  const [state, setState] = useState({
    type: "forgot-password",
    email: "",
    temporaryToken: "",
  });
  const dispatch = useDispatch();
  const router = useRouter();

  if (!openForgotPasswordModal) {
    return <div />;
  }

  return (
    <>
      <div
        className={` h-screen fade-in-transition w-full justify-center align-middle absolute top-0 z-50 overflow-hidden`}
      >
        <div
          className="bg-black bg-opacity-50 py-5 px-2 fixed duration-150 top-0 h-screen w-full"
          style={{ zIndex: 20 }}
        >
          <ForgotPasswordForm className="ForgotPasswordForm">
            <Button
              onClick={() => {
                dispatch(toggleLoginModal(true));
                dispatch(toggleForgotPasswordModal(false));
              }}
            >
              <Icons.prev className="black" size={20} />
            </Button>

            <PopUpHeader>
              <Image
                src={dodongLogo}
                alt="Picture of the author"
                width={150}
                height={150}
              />
              <HeadingLg>Forgot Password?</HeadingLg>
              <p>Enter your registered email address to reset password</p>
            </PopUpHeader>
            {/* <PopUpCloseButton
              onClick={() => {
                dispatch(toggleForgotPasswordModal(false));
              }}
            >
              <Icons.close size={20} />
            </PopUpCloseButton> */}

            {state.type === "forgot-password" && (
              <ForgotPasswordAuthForm switch={setState} />
            )}
            {state.type === "verify-otp" && (
              <OtpAuthForm
                switch={(data: { temporaryToken: string }) =>
                  setState({
                    ...state,
                    temporaryToken: data.temporaryToken,
                    type: "reset-password",
                  })
                }
                email={state.email}
                forgotPassword={true}
              />
            )}
            {state.type === "reset-password" && (
              <ResetPasswordForm
                switch={() =>
                  setState({ ...state, type: "forgot-password", email: "" })
                }
                email={state.email}
                temporaryToken={state.temporaryToken}
              />
            )}
          </ForgotPasswordForm>
        </div>
      </div>
    </>
  );
}
