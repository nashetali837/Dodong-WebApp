"use client";

import React, { useState } from "react";
import z, { ZodError } from "zod";
import { toast } from "react-toastify";
import { useMutation } from "@tanstack/react-query";
import { userForgotPasswordSchema } from "@/lib/validations/auth";
import { postRequest } from "@/lib/networkHelper";
import { EndPoints } from "@/lib/apiConstants";
import axios from "axios";
import { useDispatch } from "react-redux";
import { Icons } from "../../../icons";
import { ModalForm } from "../login";
import styled from "styled-components";
import dodongLogo from "../../../public/images/common/dodong-logo.svg";
import { HeadingLg } from "@/components/sections/Styled";
import { ButtonPrimary } from "@/shared/buttons/primary";
import { fromZodError } from "zod-validation-error";

const PopUpForm = styled(ModalForm)`
  max-width: 384px;
`;

type userForgotPasswordSchema = z.infer<typeof userForgotPasswordSchema>;

export function ForgotPasswordAuthForm(props: { switch: any }) {
  const [loading, setLoading] = useState(false);

  const mutation = useMutation({
    mutationFn: (data: userForgotPasswordSchema) => {
      return postRequest(EndPoints.forgotPassword, data);
    },
    onSuccess: (response) => {
      console.log(response.data, "returned data");

      setLoading(false);
      props.switch((prev: any) => {
        return {
          ...prev,
          email: response.data.data.email,
          type: "verify-otp",
        };
      });
    },

    onError: (error: any) => {
      console.log(error.response?.data);
      if (axios.isAxiosError(error)) {
        toast.error(error.response?.data.message);
      }
      setLoading(false);
      if (error instanceof ZodError) {
        console.log(fromZodError(error));
        toast.error("Please enter valid data");
      }
    },
  });

  const handleSubmit = (event: React.FormEvent<HTMLFormElement>): any => {
    event.preventDefault();

    try {
      const data = {
        email: (event.target as HTMLFormElement).email.value,
      };

      if (!data.email) {
        toast.error("Please enter all the fields");
        return;
      }
      setLoading(true);

      mutation.mutate(data);
    } catch (error: any) {
      if (error instanceof ZodError) {
        const validationError = fromZodError(error);
        setLoading(false);
        toast.error(validationError.message);
      }
    }
  };

  return (
    <>
      <ModalForm onSubmit={handleSubmit}>
        <div>
          <label>Enter Email</label>
          <input
            id="email"
            placeholder="name@example.com"
            className="bg-transparent text-734400  block h-9 w-full rounded-md border border-734400 text-sm placeholder:text-734400 hover:border-734400 focus:border-734400 focus:outline-none"
            type="email"
            autoCapitalize="none"
            autoComplete="email"
            autoCorrect="off"
            name="email"
          />
        </div>

        <ButtonPrimary disabled={loading}>
          {loading && <Icons.spinner className="mr-2 h-4 w-4 animate-spin" />}
          Send OTP
        </ButtonPrimary>
      </ModalForm>
    </>
  );
}
