"use client";
import React, { useState } from "react";
import Image from "next/image";
import dodongLogo from "../../../public/images/common/dodong-logo.svg";
import { useDispatch, useSelector } from "react-redux";
import { toggleLoginModal } from "@/lib/redux/slices/user-slice";

import SocialLoginComponent from "./ui/social-login";
import SeparatorLine from "./ui/shared";
import { UserSignupForm } from "./ui/signup";
import { UserLoginForm } from "./ui/login";
import { CheckBoxGroup, Label, CheckBox } from "@/components/sections/Styled";
import { Icons } from "../icons";
import { useRouter } from "next/router";
import {
  HeadingLg,
  ModalLoginPopUp,
  PopUpCloseButton,
  PopUpHeader,
} from "../sections/Styled";

export enum AuthModalType {
  LOGIN = "LOGIN",
  SIGNUP = "SIGNUP",
  FORGOT_PASSWORD = "FORGOT_PASSWORD",
}

const LoginModal = () => {
  const { openLoginModal } = useSelector((state: any) => state.user);
  const [state, setState] = useState({
    type: AuthModalType.LOGIN,
  });

  const dispatch = useDispatch();
  // const userMessage =
  //   state.type === AuthModalType.LOGIN
  //     ? "Welcome back"
  //     : "We are so excited to onboard you";

  const userTitle =
    state.type === AuthModalType.LOGIN ? "Welcome to DoDong" : "Sign Up";

  return (
    <div
      className={`${
        openLoginModal ? "fade-in-transition" : "fade-out-transition"
      } h-screen fade-in-transition w-full justify-center align-middle absolute top-0 z-50 overflow-hidden`}
    >
      <div
        className="bg-black bg-opacity-50 py-5 px-2 fixed duration-150 top-0 h-screen w-full"
        style={{ zIndex: 20 }}
      >
        <ModalLoginPopUp className="ModalLoginPopup">
          <PopUpCloseButton
            onClick={() => {
              dispatch(toggleLoginModal(false));
            }}
          >
            <Icons.close size={20} />
          </PopUpCloseButton>

          <PopUpHeader>
            <Image
              src={dodongLogo}
              alt="Picture of the author"
              width={150}
              height={150}
            />
            <HeadingLg> {userTitle}</HeadingLg>
            {/* {userMessage} */}
          </PopUpHeader>

          {state.type === AuthModalType.SIGNUP ? (
            <UserSignupForm
              switch={() => {
                setState({ ...state, type: AuthModalType.LOGIN });
              }}
            />
          ) : (
            <UserLoginForm />
          )}

          <SeparatorLine />

          <SocialLoginComponent
            authType={state.type}
            switch={(changedType: AuthModalType) => {
              setState({ ...state, type: changedType });
            }}
          />
        </ModalLoginPopUp>
      </div>
    </div>
  );
};
export default LoginModal;
