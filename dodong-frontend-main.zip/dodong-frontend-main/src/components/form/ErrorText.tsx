import styled from "styled-components";
import PropTypes from "prop-types";

interface ErrorTextProps {
  errorMessage?: string; // Define a prop called errorMessage of type string
}

const ErrorMsg = styled.p`
  color: ${(props) => props.theme.colors.red};
  margin-top: 0.25rem;
`;

const ErrorText = (props: ErrorTextProps) => {
  return <ErrorMsg>{props.errorMessage}</ErrorMsg>;
};

export default ErrorText;
