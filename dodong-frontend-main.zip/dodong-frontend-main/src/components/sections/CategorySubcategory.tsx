import { useState, useEffect } from "react";
import Select from "react-select";
import { sendAPIRequest } from "../../../utils/apiService";
import { EndPoints } from "@/lib/apiConstants";
import styled, { css } from "styled-components";
import { useDispatch, useSelector } from "react-redux";
import { updateDraft } from "@/lib/redux/slices/draft-slice";
import MediaQuery from "./MediaQuery";

const RowSection = styled.div`
  display: flex;
  display: -webkit-flex;
  gap: 1rem;
  flex-direction: row;

  ${MediaQuery.xs} {
    flex-direction: column;
  }

  .inputSelect {
    // width: 30%;
    min-width: 180px;

    &.inputSubCat {
      // width: 40%;
      min-width: 220px;
    }
  }

  .default-select__dropdown-indicator {
    color: ${(props) => props.theme.colors.black};
  }
`;

const Section = styled.div`
  .inputSelect {
    text-transform: capitalize;
    > div {
      border-radius: ${(props) => props.theme.borderRadius.button};
    }
  }

  .default-select__control {
    min-height: 40px;
    border-color: ${(props) => props.theme.colors.border};
    &:hover,
    &:focus,
    &--is-focused {
      border-color: ${(props) => props.theme.colors.border};
    }
  }

  & .default-select__option {
    background-color: transparent;
    cursor: pointer;
    padding: 0.45rem;

    &:not(:last-child) {
      border-bottom: 1px solid ${(props) => props.theme.colors.border};
    }

    &:hover,
    &--is-selected {
      color: ${(props) => props.theme.colors.black};
      background-color: transparent;
    }
  }

  .default-select__indicator-separator {
    display: none;
  }

  ${(props: any) =>
    props.row &&
    css`
      flex-direction: row;
    `}
`;

type CategorySubcategoryProps = {
  label?: boolean;
  row?: boolean;
};

const CategorySubcategory = (props: CategorySubcategoryProps) => {
  const { draft }: any = useSelector((state) => state);
  const [categoriesData, setCategoriesData] = useState<null | any>(null);
  const [subcategoriesData, setSubcategoriesData] = useState<null | any>(null);
  const [selectedCategoryId, setSelectedCategoryId] = useState<number | null>(
    draft?.draft?.categoryID || null
  );

  console.log(draft?.draft?.categoryID, "draft?.draft?.categoryID");

  const dispatch = useDispatch();

  useEffect(() => {
    const fetchCategoriesData = async () => {
      try {
        const config = { endPoint: EndPoints.categories };
        const { data } = await sendAPIRequest({ config });
        setCategoriesData(data);
      } catch (e) {
        console.log(e);
      }
    };

    fetchCategoriesData();
  }, []);

  useEffect(() => {
    const fetchSubcategoriesData = async () => {
      try {
        const config = {
          endPoint: EndPoints.sub_categories,
          data: { categoryID: selectedCategoryId }, // Replace 1 with the selected category ID
        };
        const { data } = await sendAPIRequest({ config });
        setSubcategoriesData(data);
      } catch (e) {
        console.log(e);
      }
    };

    if (selectedCategoryId) {
      fetchSubcategoriesData();
    } else {
      setSubcategoriesData(null); // Reset subcategories data when no category is selected
    }
  }, [selectedCategoryId]);

  const handleCategoryChange = (e: any) => {
    setSelectedCategoryId(e.value);

    dispatch(
      updateDraft({
        categoryID: e.value,
        categoryName: e.label,
        subCategoryID: "",
        subCategoryName: "",
      })
    );
  };

  const handleSubCategoryChange = (e: any) => {
    setSelectedCategoryId(e.value);

    dispatch(
      updateDraft({
        subCategoryID: e.value,
        subCategoryName: e.label,
      })
    );
  };

  return (
    <Section {...props}>
      {props.label ? (
        <>
          <div className="p-2">
            <div className="py-1">
              <label htmlFor="categoryID" className="text-sm">
                Category
              </label>
            </div>
            <Select
              id="category"
              className="inputSelect"
              classNamePrefix="default-select"
              options={
                categoriesData?.categories?.map((category: any) => {
                  return {
                    label: category.name.toString(),
                    value: parseInt(category.id),
                  };
                }) || []
              }
              onChange={handleCategoryChange}
              defaultValue={
                !!draft?.draft?.categoryID && !!draft?.draft?.categoryName
                  ? {
                      value: draft?.draft?.categoryID,
                      label: draft?.draft?.categoryName,
                    }
                  : undefined // Set default value to undefined for placeholder text
              }
              placeholder="Select Category"
            />
          </div>

          <div className="p-2">
            <div className="py-1">
              <label htmlFor="categoryID" className="text-sm">
                Sub-Category
              </label>
            </div>

            <Select
              id="subcategory"
              className="inputSelect inputSubCat"
              classNamePrefix="default-select"
              placeholder="Sub - Select Category"
              options={
                subcategoriesData?.categories?.map((subcategory: any) => {
                  return {
                    label: subcategory.name.toString(),
                    value: parseInt(subcategory.id),
                  };
                }) || []
              }
              onChange={handleSubCategoryChange}
              defaultValue={
                !!draft?.draft?.subCategoryID && !!draft?.draft?.subCategoryName
                  ? {
                      value: draft?.draft?.subCategoryID,
                      label: draft?.draft?.subCategoryName,
                    }
                  : undefined
              }
            />
          </div>
        </>
      ) : (
        <RowSection>
          <Select
            id="category"
            className="inputSelect"
            classNamePrefix="default-select"
            options={
              categoriesData?.categories?.map((category: any) => {
                return {
                  label: category.name.toString(),
                  value: parseInt(category.id),
                };
              }) || []
            }
            placeholder={"Select Category"}
            onChange={handleCategoryChange}
            defaultValue={
              !!draft?.draft?.categoryID && !!draft?.draft?.categoryName
                ? {
                    value: draft?.draft?.categoryID,
                    label: draft?.draft?.categoryName,
                  }
                : undefined // Set default value to undefined for placeholder text
            }
          />
          <Select
            id="subcategory"
            className="inputSelect inputSubCat"
            classNamePrefix="default-select"
            placeholder="Sub - Select Category"
            options={
              subcategoriesData?.categories?.map((subcategory: any) => {
                return {
                  label: subcategory.name.toString(),
                  value: parseInt(subcategory.id),
                };
              }) || []
            }
            onChange={handleSubCategoryChange}
            defaultValue={
              !!draft?.draft?.subCategoryID && !!draft?.draft?.subCategoryName
                ? {
                    value: draft?.draft?.subCategoryID,
                    label: draft?.draft?.subCategoryName,
                  }
                : undefined
            }
          />
        </RowSection>
      )}
    </Section>
  );
};

export default CategorySubcategory;
