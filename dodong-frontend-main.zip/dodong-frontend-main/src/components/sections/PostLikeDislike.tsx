import React from "react";
import useAuth from "../auth/hooks/useAuth";
import { toast } from "react-toastify";
import { EndPoints } from "@/lib/apiConstants";
import { Icons } from "../icons";
import { Button as LikeButton } from "./Styled";
import styled from "styled-components";
import { PostCircleBox } from "../storefront/post";
import { postRequest } from "@/lib/networkHelper";

const Wrapper = styled.div`
  text-align: center;
  > span {
    display: block;
    margin-bottom: 0.25rem;
  }
  .red {
    color: ${(props) => props.theme.colors.red};
  }
`;

const Button = styled(LikeButton)`
  color: ${(props) => props.theme.colors.black};
`;

interface Post {
  resourceID: number;
  id: number;
  liked?: boolean;
  post: any;
}

interface PostLikeDislikeProps {
  post: Post; // Accept the entire post object as a prop
  LikeCount?: boolean;
}

const PostLikeDislike = ({ post, LikeCount }: PostLikeDislikeProps) => {
  const { authToken, isLoggedIn } = useAuth();

  const [liked, setLiked] = React.useState<boolean>(post?.liked || false); // Initialize liked as false
  const [likes, setLikes] = React.useState<number>(post?.post?.likes || 0); // Initialize likes with the provided likeCount

  const postLikeInteraction = () => {
    if (!isLoggedIn) {
      toast.error("Please login to continue");
      return;
    }
    postRequest(
      liked ? EndPoints.unlikePost : EndPoints.likePost,
      {
        postID: post.resourceID, // Use the resourceId prop
        // userId: user.id,
      },
      authToken
    );
    setLiked(!liked);
    setLikes(liked ? (likes > 0 ? likes - 1 : 0) : likes + 1);
  };

  return (
    <Wrapper>
      <PostCircleBox onClick={postLikeInteraction}>
        {liked ? (
          <Icons.fillheart className="red" size={20} />
        ) : (
          <Icons.heart size={20} />
        )}
      </PostCircleBox>
      {LikeCount && <span>{likes}</span>}
    </Wrapper>
  );
};

export default PostLikeDislike;
