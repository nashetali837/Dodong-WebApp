import { Icons } from "../icons";
import {
  WhatsappShareButton,
  FacebookShareButton,
  TwitterShareButton,
} from "react-share";
import styled from "styled-components";
import { Flex } from "./Styled";
import React from "react";

const SocialShare = styled.div`
  ${Flex("row", "center")}
  gap: 0.5rem;
  color: ${(props) => props.theme.colors.black};
  svg {
    margin: 0px !important;
  }
`;

interface PostShareProps {
  postID: number;
}

const PostShare: React.FC<PostShareProps> = ({ postID }) => {
  const link = `${process.env.NEXT_PUBLIC_WEBSITE_URL}/?postID=${postID}`;
  return (
    <SocialShare>
      <FacebookShareButton url={link}>
        <Icons.fb size={18} />
      </FacebookShareButton>
      <TwitterShareButton url={link}>
        <Icons.twitter size={18} />
      </TwitterShareButton>
      {/* <EmailShareButton url={link}>
        <Icons.email size={20} />
      </EmailShareButton> */}
      <a href={`sms:?body=${link}`} target="_blank" rel="noreferrer">
        <Icons.chat size={22} />
      </a>
      <WhatsappShareButton url={link}>
        <Icons.Whatsapp size={18} />
      </WhatsappShareButton>
    </SocialShare>
  );
};

export default PostShare;
