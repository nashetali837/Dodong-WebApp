import React, { useState } from "react";
import Slider from "react-slick";
import { Icons } from "@/components/icons";
import styled from "styled-components";
import { CenterNav } from "../../pages/product/[slug]";
import Modal from "@/shared/modal";
import MediaQuery from "./MediaQuery";

import { ShopButton } from "@/shared/buttons/primary";
import { Flex } from "./Styled";
import CustomSelect from "@/shared/input-groups/custom-select";
import {
  PostOptionWrapper as PostOptions,
  PostCircleBox,
} from "../storefront/post";
import Image from "next/image";
import Link from "next/link";
import useAuth from "../auth/hooks/useAuth";
import { useRouter } from "next/router";
import { toast } from "react-toastify";
import PostLikeDislike from "./PostLikeDislike";
import VideoPlayer from "./VideoPlayer";

const ImageWrapper = styled.div`
  position: relative;
  cursor: pointer;
  img,
  video {
    width: 120px;
    height: 140px;
    object-fit: cover;
    object-position: center;
    border-radius: ${(props) => props.theme.borderRadius?.lg};

    ${MediaQuery.tablet} {
      width: 70px;
      height: 70px;
    }
  }
`;

const Wrapper = styled.div`
  position: relative;
  margin-bottom: 1rem;
  .slick-slide {
    padding-right: 0.75rem;
  }

  .slick-track {
    margin-left: 0px;
  }

  .slick-arrow {
    ${MediaQuery.tablet} {
      display: none;
    }
  }
`;

const CenterWrapper = styled.div`
  max-width: 393px;
  position: relative;
  min-height: 300px;
`;

const CenterImageWrapper = styled.div`
  video,
  img {
    height: 100%;
    min-height: 300px;
    width: 100%;
    object-fit: cover;
    object-position: center;
    border-radius: 16px;
  }
`;

const PostWrapper = styled.iframe`
  border-radius: ${(props) => props.theme.borderRadius.lg};
  border: none;
`;

const ProfileBoxTop = styled.div`
  ${Flex("row", "center", "space-between")};
  padding: 0.75rem;
  position: absolute;
  top: 0px;
  width: 100%;
  opacity: 0;
`;

const ProfileBoxBottom = styled(ProfileBoxTop)`
  bottom: 0px;
  top: unset;
  align-items: flex-end;
  opacity: 0;
`;

const ProfilePic = styled.div`
  img {
    width: 32px;
    height: 32px;
    border-radius: 8px;
    object-fit: cover;
    object-position: center;
  }
`;
const Dots = styled(Icons.tdots)`
  color: white;
  font-size: 20px;
  cursor: pointer;
`;

const DiscoveryWrapper = styled.div`
  .modalpopup {
    left: 0px;
    position: fixed;

    .bg-white:not(.closebtn) {
      background: #000;
    }

    .centerModeSlider .slick-track {
      ${Flex("row", "center")}
    }
  }

  .slick-prev {
    left: 1rem;
  }
  .slick-next {
    right: 1rem;
  }

  .centerModeSlider .slick-slide {
    transform: scale(0.8);
    transition: all 0.4s ease-in-out;
  }

  .centerModeSlider .slick-current.slick-active {
    transform: scale(1);
    ${ProfileBoxTop}, ${ProfileBoxBottom} {
      opacity: 1;
    }
  }
`;

interface Post {
  post: any;
  id: number;
  title: string;
  imageURL: string;
}

interface PostProps {
  posts: Post[];
}

const DiscoveryPosts = ({ posts }: PostProps) => {
  const [viewPostModal, setViewPostModal] = useState<boolean>(false);
  const [currentMediaIndex, setCurrentMediaIndex] = useState<number>(0);
  const { isLoggedIn } = useAuth();
  const router = useRouter();

  const openMediaInPopup = (index: number) => {
    setCurrentMediaIndex(index);
    setViewPostModal(true);
  };

  const handleCloseModal = () => {
    setViewPostModal(false);
  };

  const NextArrow = (props: any) => {
    const { className, onClick } = props;
    return (
      <CenterNav className={className} onClick={onClick}>
        <Icons.arrowright />
      </CenterNav>
    );
  };

  const PrevArrow = (props: any) => {
    const { className, onClick } = props;
    return (
      <CenterNav className={className} onClick={onClick}>
        <Icons.arrowleft />
      </CenterNav>
    );
  };

  // const centerSettings = {
  //   slidesToShow: 3,
  //   slidesToScroll: 1,
  //   infinite: true,
  //   dots: false,
  //   centerMode: true,
  //   variableWidth: true,
  //   nextArrow: <NextArrow />,
  //   prevArrow: <PrevArrow />,
  // };

  const centerSettings = {
    centerMode: true,
    centerPadding: "150px",
    slidesToShow: 3,
    focusOnSelect: true,
    initialSlide: currentMediaIndex,
    dots: false,
    infinite: true,
    autoplay: true,
    autoplaySpeed: 2000,
    nextArrow: <NextArrow />,
    prevArrow: <PrevArrow />,
    responsive: [
      {
        breakpoint: 768,
        settings: {
          centerMode: true,
          centerPadding: "80px",
          slidesToShow: 2,
        },
      },
      {
        breakpoint: 480,
        settings: {
          centerMode: true,
          centerPadding: "60px",
          slidesToShow: 1,
        },
      },
    ],
    afterChange: (index: number) => {
      setCurrentMediaIndex(index);
    },
  };

  const settings = {
    slidesToShow: 3,
    slidesToScroll: 3,
    infinite: false,
    dots: false,
    nextArrow: <NextArrow />,
    prevArrow: <PrevArrow />,
    variableWidth: true,
    swipeToSlide: true,
    initialSlide: currentMediaIndex,
  };

  const videoExtensions =
    /\.(mp4|webm|ogg|avi|mov|flv|mkv|wmv|mpg|mpeg|3gp|mp3)$/i;
  return (
    <DiscoveryWrapper>
      <Wrapper>
        <Slider {...settings}>
          {posts.length > 0 ? (
            posts.map((mediaPost: any, postIndex: number) => (
              <div key={`post-${postIndex}`}>
                {mediaPost?.ResourceMedia.map(
                  (mediaObject: any, key: number) => {
                    const url =
                      mediaObject.mediaURL || "https://picsum.photos/200/100";

                    return (
                      <ImageWrapper
                        key={`postimage-${mediaPost?.productID}`}
                        onClick={() => openMediaInPopup(postIndex)}
                      >
                        {url.match(videoExtensions) ? (
                          <VideoPlayer src={url} />
                        ) : (
                          <Image
                            src={url}
                            width={1200}
                            height={1200}
                            alt="post image"
                          />
                        )}
                      </ImageWrapper>
                    );
                  }
                )}
              </div>
            ))
          ) : (
            <div>No Posts</div>
          )}
        </Slider>
      </Wrapper>

      <Modal fullScreen={true} open={viewPostModal} onClose={handleCloseModal}>
        <div style={{ width: "100%" }}>
          <Slider
            {...centerSettings}
            className="centerModeSlider"
            initialSlide={currentMediaIndex}
          >
            {posts.length > 0 ? (
              posts.map((mediaPost: any, postIndex: number) => (
                <div key={`modal-post-${postIndex}`}>
                  {mediaPost?.ResourceMedia.map(
                    (mediaObject: any, key: number) => {
                      const url =
                        mediaObject.mediaURL || "https://picsum.photos/200/100";

                      const shopLink = `${process.env.NEXT_PUBLIC_WEBSITE_URL}/product/${mediaPost?.productID}?shopID=${mediaPost?.shopID}`;
                      const profileLink = `${process.env.NEXT_PUBLIC_WEBSITE_URL}/profile/${mediaPost?.author?.userProfileID}`;

                      const handleShopLink = () => {
                        if (!isLoggedIn) {
                          toast.error("Please login to continue");
                          return;
                        }

                        router.push(shopLink);
                      };

                      return (
                        <CenterWrapper
                          key={`popupimage-${mediaPost?.productID}`}
                        >
                          <CenterImageWrapper>
                            {url.match(videoExtensions) ? (
                              <VideoPlayer src={url} />
                            ) : (
                              <Image
                                src={url}
                                width={393}
                                height={852}
                                alt="post image"
                              />
                            )}
                          </CenterImageWrapper>

                          <ProfileBoxTop>
                            {/* <UserBlock post={mediaPost} removeBorder hideSave /> */}
                            <ProfilePic>
                              <Link href={profileLink}>
                                <Image
                                  src={
                                    mediaPost?.profile?.imageURL ||
                                    mediaPost?.author?.avatar
                                  }
                                  width={32}
                                  height={32}
                                  alt="post image"
                                />
                              </Link>
                            </ProfilePic>
                            {false && isLoggedIn && (
                              <CustomSelect
                                list={[
                                  {
                                    label: "Report",
                                    id: "Report",
                                    link: "#",
                                    icon: <Icons.report size={20} />,
                                  },
                                  {
                                    label: "Share to",
                                    id: "ShareTo",
                                    link: "#",
                                    icon: <Icons.link size={20} />,
                                  },
                                ]}
                              >
                                <Dots className="cursor-pointer" />
                              </CustomSelect>
                            )}
                          </ProfileBoxTop>

                          <ProfileBoxBottom>
                            <ShopButton onClick={handleShopLink}>
                              <Icons.shop className="text-xl" />{" "}
                              <span>Shop</span>
                            </ShopButton>
                            <PostOptions className="PostOptions">
                              <PostLikeDislike
                                post={mediaPost}
                                LikeCount={false}
                              />
                              {/* <PostCircleBox>
                                <Icons.link size={20} />
                              </PostCircleBox> */}
                            </PostOptions>
                          </ProfileBoxBottom>
                        </CenterWrapper>
                      );
                    }
                  )}
                </div>
              ))
            ) : (
              <div>No Posts</div>
            )}
          </Slider>
        </div>
      </Modal>
    </DiscoveryWrapper>
  );
};

export default DiscoveryPosts;
