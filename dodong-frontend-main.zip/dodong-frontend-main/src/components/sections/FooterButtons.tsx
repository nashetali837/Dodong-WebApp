import styled, { css } from "styled-components";
import MediaQuery from "./MediaQuery";

const Section = styled.div`
  border-top: 1px solid ${(props) => props.theme.colors.border};
  width: 100%;
  position: fixed;
  bottom: 0;
  background: ${(props) => props.theme.colors.white};
  left: 0;

  ${MediaQuery.phone} {
    position: relative;
    margin-top: 1rem;
  }
`;

const Container = styled.div`
  display: grid;
  grid-template-columns: auto auto;
  justify-content: right;
  max-width: 1200px;
  margin: auto;
  padding: 1rem;

  > button:last-of-type {
    margin-left: 1rem;
  }
`;

const FooterNav = (props: any) => {
  return (
    <Section {...props}>
      <Container>{props.children}</Container>
    </Section>
  );
};

export default FooterNav;
