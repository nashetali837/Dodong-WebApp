import styled from "styled-components";

import Modal from "@/shared/modal";
import { InviteSection } from "../profile/ui/invite";
import { Title } from "@/shared/texts";
import { UserProfileProgress } from "@/lib/redux/slices/user-slice";
import { useSelector } from "react-redux/es/hooks/useSelector";

const Container = styled(InviteSection)`
  text-align: center;

  span {
    display: block;
  }
`;

const Iframe = styled.iframe`
  margin: auto;
  display: block;
`;

const Heading = styled(Title)`
  font-size: 25px;
  margin-bottom: 0px;
`;

const CelebratoryPopUp = () => {
  const {
    userProfileProgress,
  }: {
    userProfileProgress: UserProfileProgress;
  } = useSelector((state: any) => state.user);

  return (
    <Modal open={true} hideCloseButton>
      <Container>
        <Iframe
          width="150"
          height="150"
          src="https://lottie.host/?file=547b10b3-2d81-4e70-add4-05d42eb3bee8/vGNMhAt5gO.json"
        ></Iframe>
        <Heading>Congratulations</Heading>
        <p>
          <span>you have completed &quot;Step 1&quot;</span>
          <span> move to next steps to earn badges</span>
        </p>
      </Container>
    </Modal>
  );
};

export default CelebratoryPopUp;
