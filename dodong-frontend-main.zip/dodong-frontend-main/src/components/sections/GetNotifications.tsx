import React, { useState, useEffect, useRef } from "react";
import useAuth from "../auth/hooks/useAuth";
import { EndPoints } from "@/lib/apiConstants";
import { Icons } from "../icons";
import styled from "styled-components";

import { getRequest } from "@/lib/networkHelper";
import MediaQuery from "./MediaQuery";
import moment from "moment";
import Spinner from "@/shared/loading/spinner";
import { useRouter } from "next/router";

const SectionWrapper = styled.div``;

const Wrapper = styled.div`
  border: 1px solid ${(props) => props.theme.colors.border};
  padding: 1rem;
  border-radius: ${(props) => props.theme.borderRadius.lg};
  width: 400px;
  background: ${(props) => props.theme.colors.white};
  position: absolute;
  top: 45px;
  right: 0px;
  z-index: 9;
  max-height: 356px;
  overflow: auto;
  transition-timing-function: cubic-bezier(0.4, 0, 1, 1);
  transition-duration: 75ms;
  box-shadow: 0px 20px 24px -16px rgba(17, 12, 34, 0.1);
  -webkit-box-shadow: 0px 20px 24px -16px rgba(17, 12, 34, 0.1);

  ::-webkit-scrollbar {
    width: 0;
    height: 0;
  }

  ${MediaQuery.xs} {
    width: 260px;
  }
`;

const Title = styled.h3`
  margin-bottom: 1rem;
  font-weight: 600;
`;

const List = styled.div`
  display: grid;
  gap: 1rem;
  font-size: 12px;
`;

const BorderBox = styled.div`
  padding: 0.5rem;
  border-radius: ${(props) => props.theme.borderRadius?.button};
  border: 1px solid ${(props) => props.theme.colors.border};
  width: 40px;
  text-align: center;
  cursor: pointer;
  position: relative;
  svg {
    displya: inline-block;
  }
  &.toggleSelection {
    background: red;
  }
`;

const NotificationAlert = styled.div`
  height: 5px;
  width: 5px;
  border-radius: 50%;
  background: ${(props) => props.theme.colors.red};
  position: absolute;
  right: 11px;
  top: 8px;
`;

const GetNotifications = () => {
  const { authToken, logout } = useAuth();
  const router = useRouter();
  const [data, setData] = useState<any[]>([]); // Initialize data as an empty array
  const [loading, setLoading] = useState(true);
  const [isOpen, setIsOpen] = useState(false);
  const sectionRef = useRef<HTMLDivElement | null>(null);

  const toggleSection = () => {
    setIsOpen(!isOpen);
  };

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (
        sectionRef.current &&
        !sectionRef.current.contains(event.target as Node)
      ) {
        setIsOpen(false);
      }
    };

    window.addEventListener("click", handleClickOutside);

    return () => {
      window.removeEventListener("click", handleClickOutside);
    };
  }, []);

  const formatRelativeTime = (date: string) => {
    const currentDate = moment();
    const inputDate = moment(date);

    const diffInSeconds = currentDate.diff(inputDate, "seconds");
    if (diffInSeconds < 60) {
      return `${diffInSeconds}s ago`;
    }

    const diffInMinutes = currentDate.diff(inputDate, "minutes");
    if (diffInMinutes < 60) {
      return `${diffInMinutes}m ago`;
    }

    const diffInHours = currentDate.diff(inputDate, "hours");
    if (diffInHours < 24) {
      return `${diffInHours}h ago`;
    }

    const diffInDays = currentDate.diff(inputDate, "days");
    if (diffInDays < 7) {
      return `${diffInDays}d ago`;
    }

    const diffInWeeks = currentDate.diff(inputDate, "weeks");
    if (diffInWeeks < 4) {
      return `${diffInWeeks}w ago`;
    }
  };

  useEffect(() => {
    const fetchNotificationsData = async () => {
      try {
        const config = `${EndPoints.getNotifications}?page=1`;
        const { data } = await getRequest(config, authToken);
        setData(data?.notifications);
      } catch (error: any) {
        if (error?.response?.data?.message === "Unauthorized") {
          logout();
          router.push("/");
        }
      } finally {
        setLoading(false);
      }
    };

    fetchNotificationsData();
  }, []);

  return (
    <SectionWrapper ref={sectionRef}>
      <BorderBox onClick={toggleSection}>
        <Icons.heart size={20} className="black" />
        {data.length > 0 && <NotificationAlert />}
      </BorderBox>

      {isOpen && (
        <Wrapper>
          <Title>Notification</Title>
          {loading && <Spinner />}

          {data.length ? (
            <List>
              {data?.map((data: any, k: number) => {
                return (
                  <div key={`notification_${k}`}>
                    <div className="black">{data?.title}</div>
                    <div>{data.content}</div>
                    <span>{formatRelativeTime(data?.createdAt)}</span>
                  </div>
                );
              })}
            </List>
          ) : (
            <div className="text-center">No notifications to display</div>
          )}
        </Wrapper>
      )}
    </SectionWrapper>
  );
};

export default GetNotifications;
