import { Icons } from "../icons";
import styled from "styled-components";
import { Flex } from "./Styled";
import React, { useRef, useState, useCallback, HTMLProps } from "react";

const VideoWrapper = styled.div`
  position: relative;
`;

const Controller = styled.div`
  position: absolute;
  top: 0;
  bottom: 0;
  left: 0;
  right: 0;
  ${Flex("row", "center", "center")}
  cursor: pointer;
  color: ${(props) => props.theme.colors.white};

  .control-shown {
    opacity: 1;
  }
  .control-hidden {
    opacity: 0;
  }
  .video-control {
    background: rgba(0, 0, 0, 0.75);
    border: 1px solid ${(props) => props.theme.colors.black};
    border-radius: ${(props) => props.theme.borderRadius.round};
    box-shadow: 0px 1px 2px -1px rgba(17, 12, 34, 0.08);
    width: 40px;
    height: 40px;
    padding: 10px;
    transition: opacity 200ms linear;
  }
`;

interface VideoProps {
  src: string;
}

const VideoPlayer: React.FC<VideoProps> = ({ src }) => {
  const [isPlaying, setIsPlaying] = useState(false);
  const videoRef = useRef<HTMLVideoElement | null>(null);

  const playOrPause = useCallback(() => {
    if (videoRef.current?.paused || videoRef.current?.ended) {
      videoRef.current?.play();
    } else {
      videoRef.current?.pause();
    }
  }, []);

  const onPlay = useCallback(() => setIsPlaying(true), []);

  const onPause = useCallback(() => setIsPlaying(false), []);

  return (
    <VideoWrapper className="video-wrapper">
      <video
        onPlay={onPlay}
        onPause={onPause}
        ref={videoRef}
        className="video"
        src={src}
      />
      <Controller className="controls" onClick={playOrPause}>
        <Icons.play
          size={24}
          className={`video-control ${
            isPlaying ? "control-hidden" : "control-shown"
          }`}
        />
      </Controller>
    </VideoWrapper>
  );
};

export default VideoPlayer;
