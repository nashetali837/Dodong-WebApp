import React, { useState } from "react";
import { toast } from "react-toastify";
import { EndPoints } from "@/lib/apiConstants";
import dodongLogo from "../../../public/images/common/dodong-logo.svg";
import { postRequest } from "@/lib/networkHelper";
import { useDispatch } from "react-redux";
import { updateAuthState } from "@/lib/redux/slices/auth-slice";
import {
  saveUser,
  toggleForgotPasswordModal,
  toggleLoginModal,
} from "@/lib/redux/slices/user-slice";
import {
  HeadingLg,
  ModalLoginPopUp,
  PopUpCloseButton,
  PopUpHeader,
} from "./Styled";
import Image from "next/image";
import { useForm, Controller, SubmitHandler } from "react-hook-form";

interface LoginFormInputs {
  email: string;
  password: string;
}

const LoginForm: React.FC = () => {
  const dispatch = useDispatch();
  const {
    handleSubmit,
    control,
    formState: { errors },
  } = useForm<LoginFormInputs>();

  const [apiErrors, setApiErrors] = useState<{ [key: string]: string }>({});

  const onSubmit: SubmitHandler<LoginFormInputs> = async (data) => {
    console.log(data);
    try {
      // Send the data to the server using postRequest
      //   const response = await postRequest(EndPoints.login, data);

      // Handle success response here

      //   dispatch(updateAuthState({ authToken: response.data.token }));
      //   dispatch(
      //     saveUser({
      //       ...response.data,
      //     })
      //   );
      //   dispatch(toggleLoginModal(false));
      toast.success("Login Successful");

      // Clear API errors if any
      setApiErrors({});
    } catch (error: any) {
      // Handle any errors that occurred during the request
      if (error.response) {
        // The request was made, but the server responded with an error status code
        console.error("Server Error:", error.response.data);
        const apiErrors = error.response.data.errors || {};

        // Set API errors to display under respective inputs
        setApiErrors(apiErrors);
      } else if (error.request) {
        // The request was made, but no response was received
        console.error("Network Error:", error.request);
        toast.error("Network error. Please check your internet connection.");
      } else {
        // Something else happened in setting up the request
        console.error("Error:", error.message);
        toast.error("An error occurred. Please try again later.");
      }
    }
  };

  return (
    <>
      <PopUpHeader>
        <Image
          src={dodongLogo}
          alt="Picture of the author"
          width={150}
          height={150}
        />
        <HeadingLg>Welcome to Dodong</HeadingLg>
      </PopUpHeader>

      <form onSubmit={handleSubmit(onSubmit)}>
        <div>
          <label>Email</label>
          <Controller
            name="email"
            control={control}
            rules={{
              required: "Email is required",
              pattern: {
                value: /^\S+@\S+$/i,
                message: "Invalid email address",
              },
            }}
            render={({ field }) => (
              <>
                <input {...field} placeholder="Enter Email" />
                {apiErrors.email && <span>{apiErrors.email}</span>}
                {errors.email && <span>{errors.email.message}</span>}
              </>
            )}
          />
        </div>

        <div>
          <label>Password</label>
          <Controller
            name="password"
            control={control}
            rules={{
              required: "Password is required",
              minLength: {
                value: 6,
                message: "Password must be at least 6 characters",
              },
            }}
            render={({ field }) => (
              <>
                <input type="password" {...field} />
                {apiErrors.password && <span>{apiErrors.password}</span>}
                {errors.password && <span>{errors.password.message}</span>}
              </>
            )}
          />
        </div>

        <button type="submit">Log In</button>
      </form>
    </>
  );
};

export default LoginForm;
