import React, { useState, useEffect } from "react";
import useAuth from "../auth/hooks/useAuth";
import { toast } from "react-toastify";
import { EndPoints } from "@/lib/apiConstants";
import { Icons } from "../icons";
import { Button as LikeButton } from "./Styled";
import styled from "styled-components";
import { PostCircleBox } from "../storefront/post";
import { postRequest } from "@/lib/networkHelper";

const Wrapper = styled.div`
  > span {
    display: block;
    margin-bottom: 0.25rem;
  }
  .red {
    color: ${(props) => props.theme.colors.red};
  }
`;

const Box = styled(PostCircleBox)`
  border-radius: 8px;
  border: 1px solid ${(props) => props.theme.colors.border};
`;

const Button = styled(LikeButton)`
  color: ${(props) => props.theme.colors.black};
`;

interface AddRemoveWishlistProps {
  productID?: number;
  addedToWishlist?: boolean;
}

const AddRemoveWishlist = ({
  productID,
  addedToWishlist,
}: AddRemoveWishlistProps) => {
  const { authToken, isLoggedIn } = useAuth();
  const [wishlist, setWishlist] = useState<boolean | undefined>(undefined);

  useEffect(() => {
    if (addedToWishlist) {
      setWishlist(addedToWishlist);
    }
  }, [addedToWishlist]);

  const wishlistInteraction = () => {
    if (!isLoggedIn) {
      toast.error("Please login to continue");
      return;
    }
    postRequest(
      wishlist ? EndPoints.removeWishlist : EndPoints.addWishlist,
      {
        productID: productID,
      },
      authToken
    );
    setWishlist(!wishlist);
  };

  return (
    <Wrapper>
      <Box onClick={wishlistInteraction}>
        {wishlist ? <Icons.fillheart size={20} /> : <Icons.heart size={20} />}
      </Box>
    </Wrapper>
  );
};

export default AddRemoveWishlist;
