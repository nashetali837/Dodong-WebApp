import styled, { css } from "styled-components";
import { ButtonPrimary } from "@/shared/buttons/primary";
import MediaQuery from "./MediaQuery";

export const Flex = (
  direction = "row",
  align = "center",
  justify = "center",
  wrap = "nowrap"
) => css`
  display: flex;
  flex-direction: ${direction};
  align-items: ${align};
  justify-content: ${justify};
  flex-wrap: ${wrap};
`;

export const Heading = styled.h3`
  font-size: 1rem;
  font-weight: 600;
  color: ${(props) => props.theme.colors.black};
  margin-bottom: 1rem;
`;

export const HeadingLg = styled.h2`
  font-size: 1.5rem;
  font-weight: 700;
  margin: 0.5rem 0 0.1rem;
  color: ${(props) => props.theme.colors.black};
`;

export const StickyProducts = styled.div`
  position: sticky;
  top: 0px;
  height: 100vh;
  overflow-y: auto;
`;

export const Button = styled.button`
  outline: none;
  border: none;
`;

export const MapBox = styled.div`
  ${Flex("row", "", "")};
  gap: 0.2rem;
  font-size: 12px;

  svg {
    color: ${(props) => props.theme.colors?.primary};
  }
`;

export const WhiteMapBox = styled(MapBox)`
  padding: 0.15rem 0.25rem;
  background: rgba(0, 0, 0, 0.75);
  width: fit-content;
  position: absolute;
  bottom: 1rem;
  font-weight: 500;
  left: 1rem;
  border-radius: ${(props) => props.theme.borderRadius?.button};
  border: 1px solid ${(props) => props.theme.colors?.black};
  color: ${(props) => props.theme.colors?.white};

  svg {
    color: ${(props) => props.theme.colors?.white};
    margin-top: 0px;
  }
`;

export const CheckBoxGroup = styled.div`
  ${Flex("row", "")};
  gap: 0.5rem;

  input {
    margin-top: 4px;
  }
`;

export const CheckBox = styled.input`
  width: 1rem;
  height: 1rem;
`;

export const Label = styled.label`
  margin-bottom: 0px;
`;

export const SocialLoginButton = styled.div`
  width: 2.875rem;
  padding: 0.5rem;
  text-align: center;
  cursor: pointer;
  border-radius: ${(props) => props.theme.borderRadius?.md};
  border: 1px solid ${(props) => props.theme.colors?.border};
  height: 2.875rem;
  ${Flex("row", "center", "center")};
`;

export const UserProfilePic = styled.div`
  height: 40px;
  width: 40px;
  min-width: 40px;
  border-radius: ${(props) => props.theme.borderRadius?.md};
  background: ${(props) => props.theme.colors?.darkGray};
  align-self: flex-start;
  position: relative;
  cursor: pointer;

  img {
    width: 100%;
    height: 100%;
    object-fit: cover;
    border-radius: ${(props) => props.theme.borderRadius?.md};
  }
`;

// FlexBox CSS

export const FlexBoxCenter = styled.div`
  ${Flex("row", "center", "space-between")};
`;

export const ModalLoginPopUp = styled.div`
  background: ${(props) => props.theme.colors?.white};
  max-width: 552px;
  margin: auto;
  padding: 2rem;
  box-shadow: 0px 8px 11px -3px rgba(0, 0, 0, 0.1);
  border-radius: ${(props) => props.theme.borderRadius?.md};
  position: relative;
  z-index: 11;
  margin: 1px;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  -webkit-transform: translate(-50%, -50%);
  max-height: calc(100dvh - 1rem);
  overflow-y: auto;

  ::-webkit-scrollbar {
    width: 0;
  }

  ::-webkit-scrollbar-track {
    background: transparent;
  }

  ${MediaQuery.phone} {
    padding: 2rem 1rem;
  }
`;

export const PopUpCloseButton = styled.button`
  outline: none;
  border: none;
  position: absolute;
  right: 2rem;
  cursor: pointer;
  top: 2rem;
`;

export const PopUpHeader = styled.div`
  text-align: center;
  margin-bottom: 30px;
  img {
    margin: auto;
  }
`;
