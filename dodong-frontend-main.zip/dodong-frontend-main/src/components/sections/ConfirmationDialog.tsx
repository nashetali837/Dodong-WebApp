import styled from "styled-components";

import Modal from "@/shared/modal";
import { InviteSection } from "../profile/ui/invite";
import { Title } from "@/shared/texts";
import { ButtonPrimary } from "@/shared/buttons/primary";
import { Flex } from "./Styled";
import { useEffect, useState } from "react";

const Container = styled(InviteSection)`
  text-align: center;

  span {
    display: block;
  }
`;

const Heading = styled(Title)`
  font-size: 25px;
  margin-bottom: 0px;
`;

const ButtonWrapper = styled.div`
  ${Flex()};
  gap: 1rem;
  margin-top: 1.5rem;
  button {
    width: 9.5rem;
  }
`;

interface ConfirmationDialogProps {
  isOpen: boolean;
  deleteAccount: () => Promise<void>;
  onClose: () => void;
}

const ConfirmationDialog: React.FC<ConfirmationDialogProps> = ({
  isOpen,
  deleteAccount,
  onClose,
}) => {
  const [open, setOpen] = useState(isOpen);
  useEffect(() => {
    setOpen(isOpen);
  }, [isOpen]);

  const handleClose = () => {
    setOpen(false);
    onClose();
  };

  return (
    <Modal open={open} hideCloseButton>
      <Container>
        <Heading>Deactivate Your Account</Heading>
        <p>Are you sure to deactivate your account now?</p>
        <ButtonWrapper>
          <ButtonPrimary onClick={deleteAccount} className="borderButton">
            Yes
          </ButtonPrimary>
          <ButtonPrimary onClick={handleClose}>Cancel</ButtonPrimary>
        </ButtonWrapper>
      </Container>
    </Modal>
  );
};

export default ConfirmationDialog;
