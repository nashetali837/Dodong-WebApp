import { useEffect, useRef } from "react";
import styled from "styled-components";
import {
  toggleEditProfileModal,
  UserProfileProgress,
} from "@/lib/redux/slices/user-slice";
import { useDispatch, useSelector } from "react-redux";

const ProgressSection = styled.div`
  position: relative;

  &:after {
    position: absolute;
    top: 50%;
    left: 50%;
    font-size: 12px;
    transform: translate(-50%, -50%);
    content: attr(data-percent) "%";
  }
`;

const CircleBar = styled.svg`
  display: block;
  margin: 0 auto;
  overflow: hidden;
  transform: rotate(-90deg) rotateX(180deg);
`;

const Circle = styled.circle`
  stroke-dashoffset: 0;
  transition: stroke-dashoffset 1s ease;
  stroke: #4f4b5c;
  stroke-width: 1rem;
`;

const FilledCircle = styled(Circle)`
  stroke: #ececed;
`;

const CircularProgressBar = ({ onLogout }: { onLogout: () => void }) => {
  const barRef = useRef<SVGCircleElement>(null);
  const dispatch = useDispatch();

  const {
    userProfileProgress,
  }: {
    userProfileProgress: UserProfileProgress;
  } = useSelector((state: any) => state.user);

  useEffect(() => {
    const totalProgress = barRef.current?.getAttribute("stroke-dasharray");
    barRef.current!.style.strokeDashoffset = `${
      (Number(totalProgress) * userProfileProgress?.percent) / 100
    }`;
  }, [userProfileProgress?.percent]);

  useEffect(() => {
    if (userProfileProgress?.percent < 100) {
      dispatch(toggleEditProfileModal(true));
    }
  }, []);

  return (
    <>
      <ProgressSection data-percent={userProfileProgress?.percent}>
        <CircleBar
          width="40" /* Updated width */
          height="40" /* Updated height */
          viewBox="0 0 178 178" /* Updated viewBox */
          version="1.1"
          xmlns="http://www.w3.org/2000/svg"
        >
          <Circle
            r="80"
            cx="89"
            cy="89"
            fill="transparent"
            strokeDasharray="502.4"
            strokeDashoffset="0"
          ></Circle>
          <FilledCircle
            ref={barRef}
            r="80"
            cx="89"
            cy="89"
            fill="transparent"
            strokeDasharray="502.4"
            strokeDashoffset="0"
          ></FilledCircle>
        </CircleBar>
      </ProgressSection>
    </>
  );
};

export default CircularProgressBar;
