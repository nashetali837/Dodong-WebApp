import styled from "styled-components";

const ScrollBarContent = styled.div`
  overflow-y: auto;

  ::-webkit-scrollbar {
    width: 4px;
  }
  ::-webkit-scrollbar,
  ::-webkit-scrollbar-thumb {
    overflow: visible;
    border-radius: 4px;
  }
  ::-webkit-scrollbar-thumb {
    background: rgba(0, 0, 0, 0.2);
  }
`;

const CoverBar = styled.div`
  position: absolute;
  background: #fff;
  height: 100%;
  top: 0;
  right: 0;
  width: 4px;
  -webkit-transition: all 0.5s;
  opacity: 1;
`;

const ScrollBarWrapper = styled.div`
  position: relative;
  &:hover ${CoverBar} {
    opacity: 0;
    -webkit-transition: all 0.5s;
  }
`;

const CustomScrollbar = (props: any) => {
  return (
    <ScrollBarWrapper className="ScrollBarWrapper" {...props}>
      <ScrollBarContent> {props.children}</ScrollBarContent>
      <CoverBar />
    </ScrollBarWrapper>
  );
};

export const StickyScrollBar = styled(CustomScrollbar)`
  position: sticky;
  height: 100vh;
  top: 0px;

  ${ScrollBarContent} {
    overflow-y: auto;
  }
`;

export default CustomScrollbar;
