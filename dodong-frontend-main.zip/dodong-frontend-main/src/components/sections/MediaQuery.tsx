const sizes = {
  desktop: 80, //  1280
  laptop: 68.25, //  1092
  tablet: 48, //  768
  phone: 47.938, // 767
  xs: 30, // xs 480
};

const MediaQuery = {
  desktop: `@media (max-width: ${sizes.desktop}rem)`,
  laptop: `@media (max-width: ${sizes.laptop}rem)`,
  tablet: `@media (max-width: ${sizes.tablet}rem)`,
  phone: `@media (max-width: ${sizes.phone}rem)`,
  xs: `@media (max-width: ${sizes.xs}rem)`,
};

export default MediaQuery;
