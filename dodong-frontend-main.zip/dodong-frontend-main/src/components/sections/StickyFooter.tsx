import styled from "styled-components";
import Link from "next/link";
import { useState } from "react";
import { Icons } from "../icons";
import MediaQuery from "./MediaQuery";

const Footer = styled.div`
  background: rgba(0, 0, 0, 0.8);
  -webkit-backdrop-filter: blur(10px);
  backdrop-filter: blur(10px);
  color: ${(props) => props.theme.colors.primary};
  position: fixed;
  bottom: 0px;
  padding: 0.75rem;
  text-align: center;
  width: 100%;
  font-weight: 300;
  z-index: 11;
  display: none;
  ${MediaQuery.phone} {
    display: block;
  }

  svg {
    color: ${(props) => props.theme.colors.white};
    position: absolute;
    right: 0.5rem;
    top: 50%;
    transform: translateY(-50%);
    transform: -webkit-translateY(-50%);
    cursor: pointer;
  }
`;

const StickyFooter = () => {
  const [showPopup, setShowPopup] = useState<boolean>(true);

  if (!showPopup) return null;

  return (
    <Footer>
      <Link href="https://play.google.com/store/apps/details?id=com.dodong">
        Use the App
      </Link>

      <Icons.close size={22} onClick={() => setShowPopup(false)} />
    </Footer>
  );
};

export default StickyFooter;
