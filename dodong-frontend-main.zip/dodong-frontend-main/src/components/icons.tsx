import {
  AiFillGithub,
  AiOutlineGoogle,
  AiOutlinePlus,
  AiOutlineUserDelete,
  AiOutlineHeart,
  AiFillHeart,
  AiOutlineUserAdd,
  AiOutlineInfoCircle,
} from "react-icons/ai";
import { FaSpinner, FaRupeeSign } from "react-icons/fa";
import {
  BsFacebook,
  BsTwitter,
  BsStar,
  BsStarFill,
  BsWhatsapp,
  BsCheck,
} from "react-icons/bs";
import { RiMapPinLine, RiStore3Line } from "react-icons/ri";
import {
  HiOutlineArrowRight,
  HiOutlineArrowLeft,
  HiOutlineShoppingCart,
  HiOutlineUserCircle,
  HiOutlineCake,
} from "react-icons/hi";
import { RiCloseLine, RiWechatLine } from "react-icons/ri";
import { CiCircleList } from "react-icons/ci";
import {
  MdOutlineArrowBackIos,
  MdOutlineArrowForwardIos,
} from "react-icons/md";
import {
  HiOutlineEnvelope,
  HiOutlineChatBubbleOvalLeftEllipsis,
  HiOutlineBookmark,
} from "react-icons/hi2";

import { FiMoreHorizontal, FiLink2 } from "react-icons/fi";
import { CgImage } from "react-icons/cg";
import { TbDots, TbEdit } from "react-icons/tb";
import {
  PiArrowCircleUpRight,
  PiPlayBold,
  PiWarningOctagon,
  PiSignOutBold,
} from "react-icons/pi";
import { GiPauseButton, GiHamburgerMenu } from "react-icons/gi";
import { FcGoogle } from "react-icons/fc";
import { BiChevronDown } from "react-icons/bi";

export const Icons = {
  gitHub: AiFillGithub,
  spinner: FaSpinner,
  google: AiOutlineGoogle,
  fb: BsFacebook,
  twitter: BsTwitter,
  map: RiMapPinLine,
  next: HiOutlineArrowRight,
  prev: HiOutlineArrowLeft,
  plus: AiOutlinePlus,
  close: RiCloseLine,
  star: BsStar,
  solidstar: BsStarFill,
  play: PiPlayBold,
  pause: GiPauseButton,
  shop: RiStore3Line,
  circlelist: CiCircleList,
  arrowleft: MdOutlineArrowBackIos,
  arrowright: MdOutlineArrowForwardIos,
  cart: HiOutlineShoppingCart,
  heart: AiOutlineHeart,
  fillheart: AiFillHeart,
  user: AiOutlineUserAdd,
  Whatsapp: BsWhatsapp,
  check: BsCheck,
  email: HiOutlineEnvelope,
  chat: RiWechatLine,
  more: FiMoreHorizontal,
  usercircle: HiOutlineUserCircle,
  image: CgImage,
  tdots: TbDots,
  message: HiOutlineChatBubbleOvalLeftEllipsis,
  link: PiArrowCircleUpRight,
  rupee: FaRupeeSign,
  cake: HiOutlineCake,
  edit: TbEdit,
  downarrow: BiChevronDown,
  menu: GiHamburgerMenu,
  copylink: FiLink2,
  report: PiWarningOctagon,
  warning: AiOutlineInfoCircle,
  googleicon: FcGoogle,
  bookmark: HiOutlineBookmark,
  signout: PiSignOutBold,
  deleteAccount: AiOutlineUserDelete,
};
