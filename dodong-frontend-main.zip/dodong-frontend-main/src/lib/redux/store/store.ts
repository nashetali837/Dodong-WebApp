import { combineReducers, configureStore } from "@reduxjs/toolkit";
import {
  persistReducer,
  persistStore,
  FLUSH,
  REHYDRATE,
  PAUSE,
  PERSIST,
  PURGE,
  REGISTER,
} from "redux-persist";
import storage from "redux-persist/lib/storage";

import authSlice from "../slices/auth-slice";
import draftReducer from "../slices/draft-slice";
import userReducer from "../slices/user-slice";

const rootPersistConfig = {
  key: "root",
  storage,
};

const rootReducer = combineReducers({
  auth: persistReducer(
    {
      key: "auth",
      storage,
      whitelist: ["authToken", "tokenExpiresAt"],
    },
    authSlice
  ),

  user: persistReducer(
    {
      key: "user",
      storage,
      whitelist: ["user", "userProfile"],
    },
    userReducer
  ),

  draft: persistReducer(
    {
      key: "draft",
      storage,
      whitelist: ["draft"],
    },
    draftReducer
  ),
});

export const store = configureStore({
  reducer: persistReducer(rootPersistConfig, rootReducer),
  devTools: process.env.NODE_ENV !== "production",
  middleware: (getDefaultMiddleware) =>
    getDefaultMiddleware({
      serializableCheck: {
        ignoredActions: [FLUSH, REHYDRATE, PAUSE, PERSIST, PURGE, REGISTER],
      },
    }),
});

export const persistor = persistStore(store);

// Infer the `RootState` and `AppDispatch` types from the store itself
export type RootState = ReturnType<typeof store.getState>;
// Inferred type: {posts: PostsState, comments: CommentsState, users: UsersState}
export type AppDispatch = typeof store.dispatch;
