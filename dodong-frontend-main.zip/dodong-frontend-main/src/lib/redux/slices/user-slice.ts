import { createSlice } from "@reduxjs/toolkit";
import type { PayloadAction } from "@reduxjs/toolkit";
import { UserType } from "@/components/storefront/post/types";

export interface UserProfile {
  id: number;
  userId: number;
  name: string | null;
  displayName: string | null;
  occupation: string | null;
  bio: string | null;
  dateOfBirth: string | null;
  avatar: string | null;
  facebookURL: string | null;
  LinkedInURL: string | null;
  twitterHandle: string | null;
  locationId: number | null;
  createdAt: Date;
  draft: any;
  updatedAt: Date;
  followers: number;
  following: number;
  totalPosts: number;
  userProfileID: number;
  isUserOwner: boolean;
}

export interface UserProfessional {
  occupationType: string | null;
  companyName: string | null;
  jobLocation: string | null;
  officialMobileNumber: string | null;
  brandDetails: string | null;
  others: string | null;
}
export interface UserProfileProgress {
  percent: number;
  nextStep: string | null;
  profileSteps: {
    // signup: boolean;
    completeProfile: boolean;
    createFirstPost: boolean;
    profilePicUpdated: boolean;
    profileShared: boolean;
  };
}

export interface UserState {
  user: UserType | null;
  userProfile: UserProfile | null;
  userProfessional: UserProfessional | null;
  userProfileProgress: UserProfileProgress | null;
  openLoginModal: boolean;
  createPostModal: boolean;
  openForgotPasswordModal: boolean;
  openEditProfileModal: boolean;
  fetchPostData: boolean;
  draft: any;
}

const initialState: UserState = {
  user: null,
  userProfile: null,
  userProfessional: null,
  userProfileProgress: null,
  openLoginModal: false,
  createPostModal: false,
  openForgotPasswordModal: false,
  openEditProfileModal: false,
  draft: null,
  fetchPostData: false,
};

export const userReducer = createSlice({
  name: "user",

  initialState,

  reducers: {
    saveUser: (state: UserState, action: PayloadAction<UserType>) => {
      console.log("[User Reducer] Updating user =>", action.payload);
      state.user = action.payload;
    },

    saveProfile: (state: UserState, action: PayloadAction<UserProfile>) => {
      console.log("[User Reducer] Updating user profile =>", action.payload);
      state.userProfile = action.payload;
    },

    saveProfessional: (
      state: UserState,
      action: PayloadAction<UserProfessional>
    ) => {
      console.log(
        "[User Reducer] Updating user professional =>",
        action.payload
      );
      state.userProfessional = action.payload;
    },

    saveProfileProgress: (
      state: UserState,
      action: PayloadAction<UserProfileProgress>
    ) => {
      console.log(
        "[User Reducer] Updating user profile progress =>",
        action.payload
      );
      state.userProfileProgress = action.payload;
    },

    toggleLoginModal: (state: UserState, action: PayloadAction<any>) => {
      console.log("[Post Draft Reducer] toggleLoginModal");
      state.openLoginModal = action.payload;
    },

    toggleCreatePostModal: (state: UserState, action: PayloadAction<any>) => {
      console.log(
        "[Post Draft Reducer] opening Create post modal: ",
        action.payload
      );
      state.createPostModal = action.payload;
    },

    toggleForgotPasswordModal: (
      state: UserState,
      action: PayloadAction<any>
    ) => {
      console.log("[Post Draft Reducer] opening Forgot password modal");
      state.openForgotPasswordModal = action.payload;
      if (action.payload) state.openLoginModal = !action.payload;
    },

    toggleEditProfileModal: (state: UserState, action: PayloadAction<any>) => {
      console.log("[Post Draft Reducer] opening Edit Profile modal");
      state.openEditProfileModal = action.payload;
    },

    refetchPostData: (state: UserState, action: PayloadAction<any>) => {
      console.log("[Post Reducer] update on post submission");
      state.fetchPostData = action.payload;
    },
  },
});

// Action creators are generated for each case reducer function
export const {
  saveUser,
  saveProfile,
  saveProfessional,
  saveProfileProgress,
  toggleLoginModal,
  toggleCreatePostModal,
  toggleForgotPasswordModal,
  toggleEditProfileModal,
  refetchPostData,
} = userReducer.actions;

export default userReducer.reducer;
