import * as z from "zod";

const messages = {
  required: "required",
};

export const userSignInSchema = z.object({
  email: z.string().email(),
  password: z.string(),
});

export const userForgotPasswordSchema = z.object({
  email: z.string().email(),
});

export const otpSchema = z.object({
  OTP: z
    .string()
    .min(1, { message: messages.required })
    .max(4, { message: "Max 4 Digits Allowed" }),
  email: z.string().email(),
});

export const resetPasswordSchema = z.object({
  email: z.string().email(),
  newPassword: z.string().min(1, { message: messages.required }),
  confirmPassword: z.string().min(1, { message: messages.required }),
});

export const personalProfileSchema = z.object({
  // userId: z.number().min(1, { message: messages.required }),
  bio: z.string().optional(),
  name: z.string().min(1).optional(),
  // phoneNumber: z
  //   .string()
  //   .min(10)
  //   .max(10, { message: "Max digits should be 10" }),
  displayName: z.string().optional(),
  dateOfBirth: z.date().optional(),
  // email: z.string().email(),
  // idDetails: z.string().optional(),
  facebookURL: z.string().optional(),
  LinkedInURL: z.string().optional(),
  twitterHandle: z.string().optional(),
});

export const professionalProfileSchema = z.object({
  occupation: z.string().min(1, { message: messages.required }),
  company: z.string().optional(),
  jobLocation: z.string().optional(),
  officialMobileNumber: z.string().optional(),
  brandDetails: z.string().optional(),
  others: z.string().optional(),
  userId: z.number().optional(),
});

export const userSignUpSchema = z.object({
  name: z.string({ required_error: "Name is required" }),
  mobileNumber: z.string({ required_error: "Mobile Number is required" }),
  email: z.string({ required_error: "Email is required" }).email(),
  password: z.string(),
});
