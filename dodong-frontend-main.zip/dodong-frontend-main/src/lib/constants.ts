const TRENDING_CONTENT = [
  {
    name: "Manav Singla",
    designation: "Brand Ambassador",
    company: "Ustra",
    id: "23423",
    distance: "India",
    imageURL: "https://picsum.photos/200/100",
    liked: true,
  },
  {
    name: "Preeti Desai",
    designation:
      "Brand Ambassador Brand Ambassador Brand Ambassador Brand Ambassador",
    company: "Ustra",
    id: "23423",
    imageURL: "https://picsum.photos/200/100",
    distance: "India",
    liked: true,
  },
  {
    name: "Preeti Desai",
    designation:
      "Brand Ambassador Brand Ambassador Brand Ambassador Brand Ambassador",
    company: "Ustra",
    id: "23423",
    imageURL: "https://picsum.photos/200/100",
    distance: "India",
    liked: true,
  },
  {
    name: "Preeti Desai",
    designation:
      "Brand Ambassador Brand Ambassador Brand Ambassador Brand Ambassador",
    company: "Ustra",
    id: "23423",
    imageURL: "https://picsum.photos/200/100",
    distance: "India",
    liked: true,
  },
  {
    name: "Preeti Desai",
    designation:
      "Brand Ambassador Brand Ambassador Brand Ambassador Brand Ambassador",
    company: "Ustra",
    id: "23423",
    imageURL: "https://picsum.photos/200/100",
    distance: "India",
    liked: true,
  },
  {
    name: "Preeti Desai",
    designation:
      "Brand Ambassador Brand Ambassador Brand Ambassador Brand Ambassador",
    company: "Ustra",
    id: "23423",
    imageURL: "https://picsum.photos/200/100",
    distance: "India",
    liked: true,
  },
  {
    name: "Arup Dhodi",
    designation: "Brand Ambassador",
    company: "Ustra",
    id: "23423",
    imageURL: "https://picsum.photos/200/100",
    distance: "India",
    liked: true,
  },
  {
    name: "Manav Singla",
    designation: "Brand Ambassador",
    company: "Ustra",
    imageURL: "https://picsum.photos/200/100",
    id: "23423",
    distance: "India",
    liked: true,
  },
  {
    name: "Manav Singla",
    designation: "Brand Ambassador",
    company: "Ustra",
    id: "23423",
    imageURL: "https://picsum.photos/200/100",
    distance: "India",
    liked: true,
  },
  {
    name: "Manav Singla",
    designation: "Brand Ambassador",
    company: "Ustra",
    id: "23423",
    imageURL: "https://picsum.photos/200/100",
    distance: "India",
    liked: true,
  },
];

const POSTS_CONTENT = [
  {
    profile: {
      name: "Rudrakaal",
      followers: "1.2M",
      following: "1.2M",
      imageURL: "https://picsum.photos/100/100",
      distance: "India",
      id: "23423",
    },
    shopURL: "/23423",
    post: {
      imageURL: "https://picsum.photos/800/400",
      description:
        "A short travel package without any hassel. Spend weekens in a very reasonable price.A short travel package without any hassel. Spend weekens in a very reasonable price.A short travel package without any hassel. Spend weekens in a very reasonable price.",
      liked: true,
      likes: "72",
      comments: "10",
      shares: "2",
    },
    liked: true,
  },
  {
    profile: {
      name: "Rudrakaal",
      followers: "1.2M",
      following: "1.2M",
      imageURL: "https://picsum.photos/100/100",
      distance: "India",
      id: "23423",
    },
    shopURL: "/23423",
    post: {
      imageURL: "https://picsum.photos/800/400",
      description:
        "A short travel package without any hassel. Spend weekens in a very reasonable price.",
      liked: true,
      likes: "72",
      comments: "10",
      shares: "2",
      postID: "23423",
    },
    liked: true,
  },
  {
    profile: {
      name: "Rudrakaal",
      followers: "1.2M",
      following: "1.2M",
      imageURL: "https://picsum.photos/100/100",
      distance: "India",
      id: "23423",
    },
    shopURL: "/23423",
    post: {
      imageURL: "https://picsum.photos/800/400",
      description:
        "A short travel package without any hassel. Spend weekens in a very reasonable price.",
      liked: true,
      likes: "72",
      comments: "10",
      shares: "2",
    },
    liked: true,
  },
  {
    profile: {
      name: "Rudrakaal",
      followers: "1.2M",
      following: "1.2M",
      imageURL: "https://picsum.photos/100/100",
      distance: "India",
      id: "23423",
    },
    shopURL: "/23423",
    post: {
      imageURL: "https://picsum.photos/800/400",
      description:
        "A short travel package without any hassel. Spend weekens in a very reasonable price.",
      liked: true,
      likes: "72",
      comments: "10",
      shares: "2",
    },
    liked: true,
  },
  {
    profile: {
      name: "Rudrakaal",
      followers: "1.2M",
      following: "1.2M",
      imageURL: "https://picsum.photos/100/100",
      distance: "India",
      id: "23423",
    },
    shopURL: "/23423",
    post: {
      imageURL: "https://picsum.photos/800/400",
      description:
        "A short travel package without any hassel. Spend weekens in a very reasonable price.",
      liked: true,
      likes: "72",
      comments: "10",
      shares: "2",
    },
    liked: true,
  },
];

const LOCAL_MARKET_CONTENT = [
  {
    name: "Manav Singla",
    designation: "Brand Ambassador",
    company: "Ustra",
    id: "23423",
    distance: "India",
    location: "Delhi",
    imageURL: "https://picsum.photos/250/202",
    liked: true,
  },
  {
    name: "Preeti Desai",
    designation:
      "Brand Ambassador Brand Ambassador Brand Ambassador Brand Ambassador",
    company: "Ustra",
    id: "23423",
    imageURL: "https://picsum.photos/250/202",
    distance: "India",
    location: "Delhi",
    liked: true,
  },
  {
    name: "Preeti Desai",
    designation:
      "Brand Ambassador Brand Ambassador Brand Ambassador Brand Ambassador",
    company: "Ustra",
    id: "23423",
    imageURL: "https://picsum.photos/250/202",
    distance: "India",
    location: "Delhi",
    liked: true,
  },
  {
    name: "Preeti Desai",
    designation:
      "Brand Ambassador Brand Ambassador Brand Ambassador Brand Ambassador",
    company: "Ustra",
    id: "23423",
    location: "Delhi",
    imageURL: "https://picsum.photos/250/202",
    distance: "India",
    liked: true,
  },
  {
    name: "Preeti Desai",
    designation:
      "Brand Ambassador Brand Ambassador Brand Ambassador Brand Ambassador",
    company: "Ustra",
    id: "23423",
    imageURL: "https://picsum.photos/250/202",
    distance: "India",
    liked: true,
    location: "Delhi",
  },
  {
    name: "Preeti Desai",
    designation:
      "Brand Ambassador Brand Ambassador Brand Ambassador Brand Ambassador",
    company: "Ustra",
    id: "23423",
    imageURL: "https://picsum.photos/250/202",
    distance: "India",
    location: "Delhi",
    liked: true,
  },
  {
    name: "Arup Dhodi",
    designation: "Brand Ambassador",
    company: "Ustra",
    id: "23423",
    imageURL: "https://picsum.photos/200/100",
    distance: "India",
    liked: true,
    location: "Delhi",
  },
  {
    name: "Manav Singla",
    designation: "Brand Ambassador",
    company: "Ustra",
    imageURL: "https://picsum.photos/250/100",
    id: "23423",
    distance: "India",
    liked: true,
    location: "Delhi",
  },
  {
    name: "Manav Singla",
    designation: "Brand Ambassador",
    company: "Ustra",
    id: "23423",
    imageURL: "https://picsum.photos/250/200",
    distance: "India",
    liked: true,
    location: "Delhi",
  },
  {
    name: "Manav Singla",
    designation: "Brand Ambassador",
    company: "Ustra",
    id: "23423",
    imageURL: "https://picsum.photos/250/200",
    distance: "India",
    liked: true,
    location: "Delhi",
  },
];

const PROFILE = {
  name: "Manav Singla",
  designation: "Brand Ambassador",
  email: "manav.singh@gmail.com",
  dob: "29 July",
  bio: "I admire which is natural. Believe in simplicity.",
  company: "Ustra",
  id: "23423",
  imageURL: "https://picsum.photos/100/100",
  posts: "12",
  connects: "2123",
  connecting: "400",
};

const PROFILE_POSTS = {
  posts: [
    "https://picsum.photos/100/100",
    "https://picsum.photos/300",
    "https://picsum.photos/500",
    "https://picsum.photos/500",
    "https://picsum.photos/500",
    "https://picsum.photos/500",
    "https://picsum.photos/600",
    "https://picsum.photos/700",
    "https://picsum.photos/300",
    "https://picsum.photos/500",
    "https://picsum.photos/500",
    "https://picsum.photos/500",
    "https://picsum.photos/500",
    "https://picsum.photos/600",
    "https://picsum.photos/700",
  ],

  discoveries: [
    "https://picsum.photos/350",
    "https://picsum.photos/403",
    "https://picsum.photos/501",
  ],
};

export const DEFAULT_PROFILE_PIC =
  "https://st3.depositphotos.com/6672868/13701/v/600/depositphotos_137014128-stock-illustration-user-profile-icon.jpg";

export {
  TRENDING_CONTENT,
  POSTS_CONTENT,
  LOCAL_MARKET_CONTENT,
  PROFILE_POSTS,
  PROFILE,
};
