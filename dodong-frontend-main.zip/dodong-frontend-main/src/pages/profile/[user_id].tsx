import React, { Fragment, use, useEffect, useState } from "react";
import styled from "styled-components";
import { TRENDING_CONTENT, PROFILE_POSTS, PROFILE } from "@/lib/constants";
import Image from "next/image";
import { useDispatch, useSelector } from "react-redux";
import {
  toggleEditProfileModal,
  UserProfile,
} from "@/lib/redux/slices/user-slice";
import { useRouter } from "next/router";
import { getRequest, postRequest, deleteRequest } from "@/lib/networkHelper";
import { EndPoints } from "@/lib/apiConstants";
import Spinner from "@/shared/loading/spinner";
import { NextSeo } from "next-seo";
import { toast } from "react-toastify";
import useAuth from "@/components/auth/hooks/useAuth";
import { ButtonPrimary } from "@/shared/buttons/primary";
import { Heading } from "../product/[slug]";
import { Avatar } from "@/components/profile/ui/starter";
import { Flex } from "@/components/sections/Styled";
import { Icons } from "@/components/icons";
import Tabs from "@/shared/buttons/tabs";
import Slider from "react-slick";
import { TabSection, TabsWrapper } from "@/shared/buttons/tabs";
import CustomSelect from "@/shared/input-groups/custom-select";
import MediaQuery from "@/components/sections/MediaQuery";
import DiscoveryPosts from "@/components/sections/DiscoveryPosts";
import PostLikeDislike from "@/components/sections/PostLikeDislike";
import { PostCircleBox } from "@/components/storefront/post";
import VideoPlayer from "@/components/sections/VideoPlayer";
import { DEFAULT_PROFILE_PIC } from "@/lib/constants";

const ProfileSection = styled.div`
  width: 27%;

  ${MediaQuery.tablet} {
    width: 100%;
  }
  h3 {
    margin: 0px;
  }
`;

const ProfilePic = styled(Avatar)`
  img {
    height: 100%;
    width: 100%;
  }
  ${MediaQuery.phone} {
    height: 70px;
    width: 70px;
    border-width: 3px;
  }
`;

const ProfileAndPost = styled.div`
  display: flex;
  display: -webkit-flex;
  gap: 1.5rem;
  max-width: 1400px;
  padding: 0 1rem;
  margin: auto;
  min-height: calc(100vh - 128px);

  ${MediaQuery.tablet} {
    flex-wrap: wrap;
  }
`;

const PostTabs = styled.div`
  width: 75%;
  overflow-x: hidden;

  ${MediaQuery.tablet} {
    width: 100%;
  }

  ${TabsWrapper} {
    padding: 0px;
  }

  ${TabSection} {
    background: none;
    margin: 0 0 1.5rem;
    gap: 1.5rem;
    padding: 0 1.5rem;
    border-bottom: 1px solid ${(props) => props.theme.colors?.border};
    border-radius: 0px;
    max-width: 100%;

    button {
      text-align: left;
      flex: none;
      border-radius: 0px;
      border-bottom: 2px solid transparent;
      &.active {
        color: ${(props) => props.theme.colors?.primary};
        border-color: ${(props) => props.theme.colors?.primary};
      }
    }
  }
`;

const Like = styled.div`
  color: ${(props) => props.theme.colors?.white};
  border-radius: ${(props) => props.theme.borderRadius?.button};
  padding: 0.25rem;
  border: 1px solid ${(props) => props.theme.colors?.black};
  background: rgba(0, 0, 0, 0.75);
  display: grid;
`;

const Footer = styled.div`
  ${Flex("row", "center", "space-between")};
  position: absolute;
  bottom: 1rem;
  left: 0px;
  width: 100%;
  padding: 0px 1rem;
  svg {
    display: inline-block;
    color: ${(props) => props.theme.colors?.white};
  }
  button {
    background: transparent;
    padding: 0px;
  }
  .absolute {
    position: absolute;
    width: 100px;
    margin: 0px;
  }
  .block {
    color: ${(props) => props.theme.colors?.red};
  }

  ${PostCircleBox} {
    border-radius: ${(props) => props.theme.borderRadius?.button};
    padding: 0.25rem;
    border: 1px solid ${(props) => props.theme.colors?.black};
    background: rgba(0, 0, 0, 0.75);
    width: auto;
    min-height: auto;
  }
`;

const Header = styled.div`
  ${Flex("row", "center", "")};
  gap: 2rem;
  margin-bottom: 1.5rem;
  ${MediaQuery.tablet} {
    gap: 1rem;
  }
`;

const InfoBox = styled.div`
  ${Flex("column", "", "")};
  gap: 1rem;

  ${MediaQuery.phone} {
    flex-direction: row;
    text-align: center;
  }

  span {
    display: inline-block;
    font-weight: 500;
    margin-right: 4px;

    ${MediaQuery.phone} {
      display: block;
    }
  }
`;

const Dob = styled(Header)`
  gap: 0.5rem;
  margin-bottom: 1rem;
`;

const ButtonGroup = styled(Header)`
  gap: 8px;
  margin: 26px 0 1rem;

  button {
    width: 124px;
  }
  svg {
    display: inline-block;
    margin-right: 4px;
  }
`;

export const PostGallery = styled.div`
  display: grid;
  grid-template-columns: repeat(4, minmax(0, 1fr));
  column-gap: 1.5rem;
  margin-bottom: 2rem;

  .slick-dots {
    bottom: 0.25rem;
  }
  .slick-dots li {
    width: 0px;
  }
  .slick-dots li.slick-active button:before,
  .slick-dots li button:before {
    color: ${(props) => props.theme.colors?.white};
  }
  .slick-slide {
    margin-bottom: 1.5rem;
  }

  ${MediaQuery.laptop} {
    grid-template-columns: repeat(3, minmax(0, 1fr));
  }

  ${MediaQuery.tablet} {
    column-gap: 1rem;
    margin-bottom: 1.5rem;
  }

  ${MediaQuery.xs} {
    grid-template-columns: repeat(2, minmax(0, 1fr));
  }

  &.experiences {
    video,
    img {
      height: 300px;
    }
  }
`;

export const ImageWrapper = styled.div`
  position: relative;
  img,
  video {
    width: 100%;
    height: 200px;
    object-fit: cover;
    object-position: center;
    border-radius: ${(props) => props.theme.borderRadius?.lg};
  }
`;

type TrendingProps = {
  name: string;
  designation: string;
  company: string;
  id: string;
  distance: string;
  imageURL: string;
  liked: boolean;
};

type ProfileProps = {
  name: string;
  designation: string;
  email: string;
  bio: string;
  dob: string;
  company: string;
  id: string;
  imageURL: string;
  posts: string;
  connects: string;
  connecting: string;
};

type ProfilePost = {
  posts: string;
  discoveries: string;
};

type PostProps = {
  profile: {
    name: string;
    followers: string;
    following: string;
    imageURL: string;
    distance: string;
    id: string;
  };
  shopURL: string;
  post: {
    imageURL: string;
    description: string;
    liked: boolean;
    likes: string;
    comments: string;
    shares: string;
  };
  liked: boolean;
  resourceID: number;
};

function ProfilePage() {
  const { authToken, isLoggedIn } = useAuth();
  const {
    user,
    userProfile,
  }: {
    user: any;
    userProfile: UserProfile;
  } = useSelector((state: any) => state.user);

  const router = useRouter();
  const dispatch = useDispatch();
  const { user_id } = router.query;
  const [currentTab, setCurrentTab] = useState("post");

  const handleTabChange = (id: string) => {
    setCurrentTab(id);
    if (id === "post") {
      fetchPosts();
    } else {
      const selectedMode = modes.find((mode) => mode.id === id);
      if (selectedMode) {
        fetchPosts(selectedMode.resourceType);
      }
    }
  };

  const [data, setData] = useState<{
    posts: any[];
    loading: boolean;
    user?: any;
    isUserOwner?: boolean;
    userProfile?: UserProfile;
  }>({
    posts: [],
    loading: true,
  });

  const [posts, setPosts] = useState([]);

  const modes = [
    { label: "Post", id: "post", count: data?.userProfile?.totalPosts },
    { label: "Experiences", id: "experiences", resourceType: 4, count: 0 },
  ];

  const [postCounts, setPostCounts] = useState<{
    [key: string]: number;
  }>({
    post: 0,
    experiences: 0,
  });

  const updatedModes = modes.map((mode) => ({
    ...mode,
    count: postCounts[mode.id],
  }));

  // Function to fetch user profile
  const fetchUserProfile = async () => {
    try {
      if (isNaN(Number(user_id))) {
        return;
      }

      const profileResponse = await getRequest(
        EndPoints.profile + `/${user_id}`,
        authToken
      ).then((res) => res.data);

      setData({
        ...data,
        loading: false,
        user: profileResponse.user,
        userProfile: profileResponse.profile,
        isUserOwner: profileResponse.isUserOwner,
      });
    } catch (error) {
      console.error("Error fetching user profile:", error);
      setData({ ...data, loading: false });
    }
  };

  // Function to fetch posts based on resourceType
  const fetchPosts = async (resourceType?: number) => {
    try {
      if (isNaN(Number(user_id))) {
        return;
      }

      const response = await postRequest(
        EndPoints.filterPosts,
        {
          authorID: Number(user_id),
          ...(resourceType !== undefined && { resourceType: resourceType }),
        },
        authToken
      ).then((res) => res.data);

      // Sort the posts array in descending order by resourceID
      const posts = response.posts.sort(
        (a: { resourceID: number }, b: { resourceID: number }) =>
          b.resourceID - a.resourceID
      );

      setPosts(posts);
      // Store the counts in the postCounts state variable
    } catch (error) {
      console.error("Error fetching filtered posts:", error);
    }
  };

  const [discoveryPosts, setDiscoveryPosts] = useState([]);

  const fetchResourceTwoPosts = async () => {
    try {
      if (isNaN(Number(user_id))) {
        return;
      }

      const response = await postRequest(
        EndPoints.filterPosts,
        {
          authorID: Number(user_id),
          resourceType: 2, // Specify the resource ID here
        },
        authToken
      ).then((res) => res.data);

      // Sort the posts array in descending order by resourceID
      const posts = response.posts.sort(
        (a: { resourceID: number }, b: { resourceID: number }) =>
          b.resourceID - a.resourceID
      );
      setDiscoveryPosts(posts);
    } catch (error) {
      console.error("Error fetching posts with resourceId 2:", error);
    }
  };

  useEffect(() => {
    fetchUserProfile();
    fetchPosts();
    fetchResourceTwoPosts();

    // Post Count
    const fetchCounts = async () => {
      try {
        if (isNaN(Number(user_id))) {
          return;
        }

        const response = await postRequest(
          EndPoints.filterPosts,
          {
            authorID: Number(user_id),
          },
          authToken
        ).then((res) => res.data);

        const posts = response.posts;

        const counts: { [key: string]: number } = {};
        modes.forEach((mode) => {
          if (mode.resourceType !== undefined) {
            const count = posts.filter(
              (post: any) => post.resourceType === mode.resourceType
            ).length;
            counts[mode.id] = count;
          } else {
            counts[mode.id] = posts.length;
          }
        });

        setPostCounts(counts);
      } catch (error) {
        console.error("Error fetching counts:", error);
      }
    };

    fetchCounts();
  }, [user_id]);

  const deletePost = async (resourceID: number) => {
    try {
      const res = await deleteRequest(EndPoints.deletePost, authToken, {
        resourceID: resourceID, // Use resourceID in the URL
      });

      if (res.data.status === "success") {
        // Assuming you have a state variable named "posts" and "setPosts" function
        setPosts((prevPosts: any) =>
          prevPosts.filter((post: any) => post.resourceID !== resourceID)
        );

        // Show a success message to the user
        toast.success("Post deleted successfully");
      } else {
        // Show an error message if the delete request was not successful
        toast.error("Failed to delete post");
      }
    } catch (error) {
      // Handle errors, e.g., network issues or server errors
      console.error("Error deleting post:", error);
      toast.error("An error occurred while deleting the post");
    }
  };

  if (data.loading) {
    return <Spinner />;
  }

  const _renderProfile = () => {
    const stats = [
      { name: "Posts", value: data?.userProfile?.totalPosts },
      { name: "Followers", value: data?.userProfile?.followers },
      { name: "Following", value: data?.userProfile?.following },
    ];

    if (!data?.userProfile) {
      return <div>Loading...</div>;
    }

    const name = data?.userProfile.displayName || data?.userProfile.name;
    const dateOfBirth = data?.userProfile.dateOfBirth || "";
    const date = new Date(dateOfBirth);
    const year = date.getFullYear();
    const month = date.toLocaleString("default", { month: "long" });
    const day = date.getDate();
    const formattedDate = `${day} ${month}, ${year}`;

    return (
      <>
        <ProfileSection className="profilesection">
          <NextSeo title={name + " - DoDong"} />
          <Header>
            <ProfilePic>
              <Image
                src={
                  data?.isUserOwner
                    ? userProfile?.avatar || DEFAULT_PROFILE_PIC
                    : data?.userProfile?.avatar || DEFAULT_PROFILE_PIC
                }
                width={150}
                height={150}
                objectFit="cover"
                alt="profile image"
              />
            </ProfilePic>
            <InfoBox>
              {stats.map((stat, k) => (
                <div key={`stat_${k}`}>
                  <span className="black">{stat.value}</span>
                  {stat.name}
                </div>
              ))}
            </InfoBox>
          </Header>
          <Heading>{name}</Heading>
          {data?.userProfile.dateOfBirth && (
            <Dob>
              <Icons.cake size={22} className="black" />
              Born {formattedDate}
            </Dob>
          )}
          {data?.isUserOwner && (
            <ButtonGroup>
              {/* <ButtonPrimary className="borderButton">
                <Icons.email size={20} /> Message
              </ButtonPrimary> */}
              <ButtonPrimary
                className="borderButton"
                onClick={() => {
                  dispatch(toggleEditProfileModal(true));
                }}
              >
                <Icons.edit size={20} /> Edit Profile
              </ButtonPrimary>
            </ButtonGroup>
          )}

          {data?.userProfile.bio}
        </ProfileSection>
      </>
    );
  };

  const _renderPost = (post: any): JSX.Element => {
    const settings = {
      dots: true,
      infinite: true,
      arrows: false,
      speed: 500,
      slidesToShow: 1,
      slidesToScroll: 1,
    };
    const videoExtensions =
      /\.(mp4|webm|ogg|avi|mov|flv|mkv|wmv|mpg|mpeg|3gp|mp3)$/i;

    return (
      <Slider {...settings}>
        {post?.ResourceMedia?.map((mediaObject: any, key: number) => {
          const url = mediaObject.mediaURL;

          return (
            <ImageWrapper key={key}>
              {url.match(videoExtensions) ? (
                <VideoPlayer src={url} />
              ) : (
                <Image src={url} width={1200} height={1200} alt="post image" />
              )}
              <Footer>
                <>
                  <PostLikeDislike post={post}></PostLikeDislike>
                  {data.isUserOwner ? (
                    <CustomSelect
                      list={[
                        {
                          label: "Delete",
                          id: "delete",
                          onclick: () => deletePost(post.resourceID),
                        },
                      ]}
                    >
                      <Icons.tdots className="text-xl cursor-pointer" />
                    </CustomSelect>
                  ) : null}
                </>
              </Footer>
            </ImageWrapper>
          );
        })}
      </Slider>
    );
  };

  return (
    <>
      <ProfileAndPost className="ProfileAndPost">
        {_renderProfile()}

        <PostTabs id="posts">
          {discoveryPosts?.length > 0 && (
            <DiscoveryPosts posts={discoveryPosts} />
          )}

          <Tabs
            modes={updatedModes}
            currentTab={currentTab}
            onChange={handleTabChange}
          />

          <PostGallery className={`PostGallery ${currentTab}`}>
            {posts.length ? (
              posts.map((post: string) => _renderPost(post))
            ) : (
              <div className="text-center">No Posts</div>
            )}
          </PostGallery>
        </PostTabs>
      </ProfileAndPost>
    </>
  );
}
export default ProfilePage;
