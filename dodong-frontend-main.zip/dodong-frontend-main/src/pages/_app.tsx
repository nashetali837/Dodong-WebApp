"use client";
import "./globals.css";
import "react-toastify/dist/ReactToastify.css";
import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";
import { ThemeProvider } from "styled-components";
import ReactQueryWrapper from "@/components/ReactQueryWrapper";
import { GoogleOAuthProvider } from "@react-oauth/google";
import { ToastContainer } from "react-toastify";
import ReduxProvider from "@/lib/redux/reduxProvider";
import Header from "@/shared/header";
import Footer from "@/shared/footer";
import LoginModal from "../components/auth";
import ForgotPasswordModal from "../components/auth/ui/forgot-password";
import UpdateProfile from "@/components/profile";
import NoSSRWrapper from "@/components/NoSSRWrapper";
import themeConfig from "../../utils/themeConfig";
import Script from "next/script";

const GOOGLE_CLIENT_ID =
  "997465596213-ded239p2vc6g877phgmjbpdhm36qoi32.apps.googleusercontent.com";

const GOOGLE_API_KEY = "AIzaSyAjzJ24t6KAnbJ_H3buz96PHmnFeK9ZZ78";

export default function RootLayout({
  Component,
  pageProps,
}: {
  Component: any;
  pageProps: any;
}) {
  return (
    <ThemeProvider theme={themeConfig}>
      <GoogleOAuthProvider clientId={GOOGLE_CLIENT_ID}>
        <ReactQueryWrapper>
          <NoSSRWrapper>
            <ReduxProvider>
              <Header />
              <LoginModal />
              <ForgotPasswordModal />
              <UpdateProfile />
              <Component {...pageProps} />
              <Footer />
              <Script
                async
                type="text/javascript"
                src={`https://maps.googleapis.com/maps/api/js?key=${GOOGLE_API_KEY}&libraries=places`}
              />
            </ReduxProvider>
            <ToastContainer
              position="top-right"
              autoClose={5000}
              hideProgressBar={false}
              newestOnTop={false}
              closeOnClick
              rtl={false}
              pauseOnFocusLoss
              draggable
              pauseOnHover
              theme="light"
            />
          </NoSSRWrapper>
        </ReactQueryWrapper>
      </GoogleOAuthProvider>
    </ThemeProvider>
  );
}
