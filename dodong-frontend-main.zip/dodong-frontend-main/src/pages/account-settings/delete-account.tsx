import styled from "styled-components";
import { useRouter } from "next/router";
import { useDispatch, useSelector } from "react-redux";
import { toast } from "react-toastify";

import useAuth from "@/components/auth/hooks/useAuth";
import { InviteSection } from "@/components/profile/ui/invite";
import { Flex } from "@/components/sections/Styled";
import { EndPoints } from "@/lib/apiConstants";
import { postRequest } from "@/lib/networkHelper";
import { toggleLoginModal, UserProfile } from "@/lib/redux/slices/user-slice";
import { ButtonPrimary } from "@/shared/buttons/primary";
import { Title } from "@/shared/texts";

const Container = styled(InviteSection)`
  text-align: center;

  span {
    display: block;
  }
`;

const Heading = styled(Title)`
  font-size: 25px;
  margin-bottom: 0px;
`;

const ButtonWrapper = styled.div`
  ${Flex()};
  gap: 1rem;
  margin-top: 1.5rem;
  button {
    width: 9.5rem;
  }
`;

const ModalWrapper = styled.div`
  min-height: calc(100vh - 127px);

  .relative {
    top: 50%;
    transform: translateY(-50%);
  }
`;

const DeleteAccount = () => {
  const { authToken, isLoggedIn } = useAuth();
  const dispatch = useDispatch();
  const router = useRouter();
  const {
    userProfile,
  }: {
    userProfile: UserProfile;
  } = useSelector((state: any) => state.user);

  const deleteAccount = async () => {
    try {
      const res = await postRequest(
        EndPoints.deleteProfile,
        {
          userProfileID: userProfile?.userProfileID,
        },
        authToken
      );
      if (res.data.status === "success") {
        toast.success(res.data.message);
      } else {
        toast.error("Failed to delete your account");
      }
    } catch (error) {
      toast.error("An error occurred while processing your request");
    } finally {
      setTimeout(() => {
        router.push("/");
      }, 1500); // 1000 milliseconds = 1 second
    }
  };

  const handleSignInClick = () => {
    dispatch(toggleLoginModal(true));
  };

  const handleCancelClick = () => {
    router.push("/account-settings");
  };

  const subTitle = isLoggedIn
    ? " Are you sure you want to Delete your account now?"
    : "Please sign in to your account to continue";

  return (
    <ModalWrapper>
      <div className="fade-in-transition h-screen fade-in-transition w-full justify-center align-middle fixed top-0 z-2 overflow-hidden modalpopup">
        <div className="bg-black bg-opacity-50 fixed duration-150 h-full my-auto top-0 bottom-0 w-full left-0">
          <section className="align-middle self-center relative mx-auto overflow-hidden flex justify-center flex-col items-center max-w-7xl rounded-xl px-4">
            <Container>
              <Heading>Delete Your Account</Heading>
              <p>{subTitle}</p>
              <ButtonWrapper>
                <ButtonPrimary
                  onClick={isLoggedIn ? deleteAccount : handleSignInClick}
                  className="borderButton"
                >
                  {isLoggedIn ? "Yes" : "Sign in"}
                </ButtonPrimary>
                <ButtonPrimary onClick={handleCancelClick}>
                  Cancel
                </ButtonPrimary>
              </ButtonWrapper>
            </Container>
          </section>
        </div>
      </div>
    </ModalWrapper>
  );
};

export default DeleteAccount;
