import Link from "next/link";
import styled from "styled-components";

import { Icons } from "@/components/icons";
import MediaQuery from "@/components/sections/MediaQuery";
import { Icon, InviteBox } from "@/components/profile/ui/invite";
import { useRouter } from "next/router";

const WrapperContainer = styled.div`
  max-width: 1280px;
  margin: auto;
  padding: 0 1rem 2rem;
  min-height: calc(100vh - 127px);

  h1 {
    font-size: 2rem;
    text-align: center;
    margin-bottom: 2rem;
    font-weight: 600;

    ${MediaQuery.phone} {
      font-size: 1.5rem;
    }
  }
`;

const DeleteAccountLink = styled(InviteBox)`
  display: inline-flex;
  cursor: pointer;
`;

const AccountSettings = () => {
  const router = useRouter();
  return (
    <WrapperContainer>
      <h1>Account Settings</h1>

      <DeleteAccountLink
        onClick={() => router.push("/account-settings/delete-account")}
      >
        <Icon>
          <Icons.deleteAccount />
        </Icon>
        <p>Delete your account</p>
      </DeleteAccountLink>
    </WrapperContainer>
  );
};

export default AccountSettings;
