"use client";

import React, { useState, useEffect, useRef } from "react";
import styled from "styled-components";
import Image from "next/image";
import Link from "next/link";
import { useRouter } from "next/router";
import Slider from "react-slick";

import { TRENDING_CONTENT, PROFILE_POSTS, PROFILE } from "@/lib/constants";

import { FiLink2 } from "react-icons/fi";
import { RiPencilFill } from "react-icons/ri";
import { RxEnvelopeClosed } from "react-icons/rx";
import filter from "../../../public/images/filter.svg";

import { Icons } from "@/components/icons";

import { getRequest } from "@/lib/networkHelper";
import { EndPoints } from "@/lib/apiConstants";
import { ShopButton } from "@/shared/buttons/primary";
import FlexBox from "@/components/sections/FlexBox";
import { Flex } from "@/components/sections/Styled";
import { MapBox, WhiteMapBox } from "@/components/sections/Styled";
import { ImageWrapper } from "../profile/[user_id]";
import MediaQuery from "@/components/sections/MediaQuery";
import useAuth from "@/components/auth/hooks/useAuth";
import { StickyScrollBar } from "@/components/sections/CustomScrollbar";
import { StickyProducts } from "@/components/sections/Styled";
import VideoPlayer from "@/components/sections/VideoPlayer";
import AddRemoveWishlist from "@/components/sections/AddRemoveWishlist";
import Modal from "@/shared/modal";

const Price = styled.span`
  color: ${(props) => props.theme.colors.black};
  font-size: 1.125rem;
  font-weight: 500;
  position: relative;
  &:after {
    content: "";
    top: 50%;
    transform: translateY(-50%);
    transform: -webkit-translateY(-50%);
    right: -20px;
    border: 1px solid #f3f3f4;
    position: absolute;
    height: 1.5rem;
  }
  svg {
    display: inline-block;
    font-size: 90%;
    vertical-align: middle;
  }
`;

const ProductBox = styled.div`
  border-radius: ${(props) => props.theme.borderRadius.lg};
  border: 1px solid ${(props) => props.theme.colors.border};
  height: 100%;
  max-width: 20.625rem;
  min-width: 20.625rem;

  &.shopinfo {
    position: relative;
    max-width: 13.5rem;
    min-width: 13.5rem;
  }
`;

export const Product = styled(ProductBox)`
  margin-bottom: 1.5rem;
`;

const Rating = styled(MapBox)`
  align-items: center;
  color: ${(props) => props.theme.colors.black};
`;

export const ProductImage = styled(Image)`
  width: 100%;
  border-radius: ${(props) => props.theme.borderRadius.lg}
    ${(props) => props.theme.borderRadius.lg} 0px 0px;
`;

export const ProductInfo = styled.div`
  padding: 1rem;
`;

export const Nav = styled.div`
  border: 1px solid ${(props) => props.theme.colors.border};
  color: ${(props) => props.theme.colors.border};
  background: ${(props) => props.theme.colors.white};
  width: 32px;
  height: 32px;
  border-radius: ${(props) => props.theme.borderRadius.button};
  right: 4rem;
  left: auto;
  top: -30px;

  &:before {
    display: none;
  }
  &.slick-prev {
    right: 6.5rem;
  }

  &:hover {
    color: ${(props) => props.theme.colors.black};
    background: ${(props) => props.theme.colors.white};
  }
  svg {
    font-size: 16px;
    height: 100%;
    margin: auto;
  }
`;

export const CenterNav = styled(Nav)`
  position: absolute;
  top: 50%;
  right: 0;
  z-index: 2;
  color: ${(props) => props.theme.colors.black};

  &.slick-prev {
    left: 0;
    right: unset;
  }
`;

export const ProductTitle = styled.h4`
  font-size: 14px;
  font-weight: 600;
  margin-bottom: 0.25rem;
`;

const Title = styled.h2`
  font-size: 30px;

  ${MediaQuery.tablet} {
    font-size: 22px;
  }
`;

export const Heading = styled.h3`
  font-size: 18px;
  font-weight: 600;
  margin-bottom: 1rem;
`;

export const ProductSlider = styled.div`
  .slick-list {
    padding: 0px;

    .slick-slide {
      padding-right: 1.5rem;
      margin-bottom: 1.5rem;
    }
  }

  .slick-track {
    ${Flex("row", "", "")};
    margin-left: 0px;
  }
  .slick-list,
  .slick-track,
  .slick-slide {
    height: inherit;
  }

  .slick-slide > div {
    height: 100%;
  }
`;

const Tag = styled.span`
  border: 1px solid ${(props) => props.theme.colors?.border};
  color: ${(props) => props.theme.colors?.darkGray};
  border-radius: ${(props) => props.theme.borderRadius?.button};
  background: ${(props) => props.theme.colors?.white};
  font-size: 12px;
  color: #4f4b5c;
  padding: 0.25rem 0.5rem;
`;

const Button = styled.button`
  border-radius: ${(props) => props.theme.borderRadius?.button};
  color: ${(props) => props.theme.colors?.black};
  background: ${(props) => props.theme.colors?.white};
  border: 1px solid ${(props) => props.theme.colors?.border};
  padding: 8px 10px;
  font-weight: 500;
`;

const DetailSection = styled.div`
  margin-bottom: 3rem;
  gap: 1.5rem;
  ${Flex("row", "", "")};

  ${MediaQuery.phone} {
    flex-wrap: wrap;
  }

  ${Price} {
    font-size: 30px;
    &:after {
      right: -26px;
    }
  }

  .detail {
    position: absolute;
    top: 1rem;
    left: 1rem;
    z-index: 2;
  }

  .border-md {
    border-radius: ${(props) => props.theme.borderRadius?.md};
  }

  .galleryslider {
    height: 100%;
    img,
    video {
      border-radius: ${(props) => props.theme.borderRadius?.lg};
      width: 100%;
      height: 100%;
      object-fit: contain;
      background: #333;
      max-height: 450px;
      ${MediaQuery.phone} {
        height: 300px;
        max-height: 100%;
        object-fit: cover;
      }
    }
    .slick-list,
    .slick-track,
    .slick-slide > div {
      height: inherit;
    }
    .slick-arrow {
      position: absolute;
      top: 50%;
      right: 0.5rem;
      z-index: 2;
      color: ${(props) => props.theme.colors?.black};
      &.slick-prev {
        left: 0.5rem;
        right: unset;
      }
    }
  }
  .slidernav {
    position: absolute;
    bottom: 1rem;
    left: 50%;
    transform: translateX(-50%);
    transform: -webkit-translateY(-50%);
    img,
    video {
      border-radius: ${(props) => props.theme.borderRadius?.button};
      border: 1px solid ${(props) => props.theme.colors?.white};
      height: 50px;
      width: 50px;
      object-fit: cover;
      filter: brightness(40%);
    }
    .slick-slide {
      padding: 0 0.25rem;
      &.slick-current {
        img {
          filter: none;
        }
      }
    }
  }
`;

const Gallery = styled.div`
  width: 40%;
  position: relative;

  ${MediaQuery.phone} {
    width: 100%;
  }
`;

const Content = styled.div`
  font-weight: 300;
  line-height: 22px;
`;

export const Map = styled(Icons.map)`
  color: ${(props) => props.theme.colors?.primary};
  font-size: 1rem;
  min-width: 1.125rem;
`;

const GridSection = styled.div`
  ${Flex("", "", "right")};
  padding-left: 4rem;
  grid-template-columns: 1fr 5fr;
  gap: 1.5rem;
  min-height: calc(100vh - 127px);

  ${MediaQuery.laptop} {
    padding-left: 1rem;
  }

  ${MediaQuery.tablet} {
    padding: 0 0.75rem;
    // ${Heading}, ${ProductSlider} {
    //   display: none;
    // }
  }

  #trending-posts {
    width: 20%;

    ${MediaQuery.tablet} {
      display: none;
    }

    ${Price} {
      font-size: 1rem;
      margin-top: 0.5rem;
      display: inline-block;
      &:after {
        display: none;
      }
    }
  }
  #posts {
    width: 80%;

    ${MediaQuery.tablet} {
      width: 100%;
    }
  }
`;

const DetailInfo = styled.div`
  padding-right: 4rem;
  width: 60%;

  ${MediaQuery.tablet} {
    padding-right: 0;
    width: auto;
  }
`;

const MediaWrapper = styled(ImageWrapper)`
  height: inherit;
  > div {
    height: inherit;
  }
`;

type TrendingProps = {
  name: string;
  designation: string;
  company: string;
  id: string;
  distance: string;
  imageURL: string;
  liked: boolean;
};

type LocalMarketProps = {
  name: string;
  designation: string;
  company: string;
  id: string;
  distance: string;
  imageURL: string;
  location: string;
  liked: boolean;
};

type ProfileProps = {
  name: string;
  designation: string;
  email: string;
  bio: string;
  dob: string;
  company: string;
  id: string;
  imageURL: string;
  posts: string;
  connects: string;
  connecting: string;
};

const NextArrow = (props: any) => {
  const { className, onClick } = props;
  return (
    <Nav className={className} onClick={onClick}>
      <Icons.arrowright />
    </Nav>
  );
};

const PrevArrow = (props: any) => {
  const { className, onClick } = props;
  return (
    <Nav className={className} onClick={onClick}>
      <Icons.arrowleft />
    </Nav>
  );
};

const settings = {
  slidesToShow: 3,
  slidesToScroll: 1,
  infinite: false,
  dots: false,
  nextArrow: <NextArrow />,
  prevArrow: <PrevArrow />,
  variableWidth: true,
  swipeToSlide: true,
  responsive: [
    {
      breakpoint: 768,
      settings: {
        slidesToShow: 2,
      },
    },
    {
      breakpoint: 480,
      settings: {
        slidesToShow: 1,
      },
    },
  ],
};

const _renderProfile = () => {
  const data = PROFILE as ProfileProps;
  const stats = [
    { name: "Connects", value: data.connects },
    { name: "Connecting", value: data.connecting },
    { name: "Posts", value: data.posts },
  ];

  return (
    <div className="mb-4">
      <div className="grid md:flex justify-between">
        <div>
          <div className="grid md:flex items-center mb-3">
            <div className="relative mr-3 my-auto">
              <Image
                src={data.imageURL}
                width={70}
                height={70}
                objectFit="cover"
                alt="profile image"
                className="rounded-full my-auto"
              />
            </div>
            <div className="flex flex-col ml-2">
              <div className="text-xl font-bold">{data.name}</div>
              <div className="text-sm">{data.dob}</div>
            </div>
          </div>
          <div>
            <div className="flex items-center">
              <div className="flex flex-col ml-2">
                <div className="text-sm font-normal truncate">
                  {data.designation} @ {data.company}
                </div>

                <div className="text-sm font-normal">{data.email}</div>
                <div className="text-sm">{data.bio}</div>
              </div>
            </div>
          </div>
        </div>

        <div className="grid md:flex items-start">
          <div className="flex my-2 items-center">
            {stats?.map((stat, k) => (
              <div key={`stat_${k}`} className="flex flex-col mx-4">
                <div className="text-sm font-bold text-center truncate">
                  {stat.value}
                </div>
                <div className="text-xs truncate">{stat.name}</div>
              </div>
            ))}
          </div>

          <div className="flex my-2 justify-around items-center">
            <div className="flex flex-col ml-2">
              <button className="text-sm flex border text-orange-500 border-orange-500 rounded-full p-2 font-bold text-center">
                <RxEnvelopeClosed className="text-md my-auto cursor-pointer mx-2" />{" "}
                <span className="text-md px-2">Message</span>
              </button>
            </div>

            <div className="flex flex-col ml-2">
              <button className="text-sm font-bold border text-orange-500 border-orange-500 rounded-full p-2 text-center">
                {/* Share */}
                <FiLink2 className="text-md my-auto cursor-pointer mx-3" />
              </button>
            </div>

            <div className="flex flex-col ml-4">
              <button className="flex text-sm font-bold border text-orange-500 border-orange-500 rounded-full p-2 text-center">
                <RiPencilFill className="text-md my-auto cursor-pointer mx-2" />{" "}
                <span className="text-md px-2">Edit Profie</span>
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

const _renderViewdetails = () => {
  const [viewDetails, setViewDetails] = useState<null | any>(null);
  const router = useRouter();
  const slug: string = router.query.slug as string;
  const { authToken } = useAuth();

  useEffect(() => {
    if (slug) {
      const fetchCategoriesData = async () => {
        try {
          const config = `${EndPoints.products}?productID=${parseInt(slug)}`;
          const { data } = await getRequest(config, authToken);
          setViewDetails(data?.product);
        } catch (e) {
          console.log(e);
        }
      };

      fetchCategoriesData();
    }
  }, [slug]);

  const [nav1, setNav1] = useState<Slider | undefined>(undefined);
  const [nav2, setNav2] = useState<Slider | undefined>(undefined);
  const slider1Ref = useRef<Slider | null>(null);
  const slider2Ref = useRef<Slider | null>(null);

  useEffect(() => {
    setNav1(slider1Ref.current ?? undefined);
    setNav2(slider2Ref.current ?? undefined);
  }, []);
  const videoExtensions =
    /\.(mp4|webm|ogg|avi|mov|flv|mkv|wmv|mpg|mpeg|3gp|mp3)$/i;

  const renderSliderItems = (size: number) => {
    return viewDetails?.mediaURLs?.map((item: any) => {
      const url = item.mediaURL;
      return (
        <>
          <MediaWrapper key={item.id} className="MediaWrapper">
            {url.match(videoExtensions) ? (
              <VideoPlayer src={url} />
            ) : (
              <Image src={url} width={1200} height={1200} alt="image" />
            )}
          </MediaWrapper>
        </>
      );
    });
  };

  return (
    <DetailSection>
      <Gallery>
        <Tag className="detail">
          <a
            href={`${process.env.NEXT_PUBLIC_WEBSITE_URL}/?postID=${viewDetails?.mediaURLs?.[0]?.resourceID}`}
          >
            View Post
          </a>
        </Tag>
        <Slider
          asNavFor={nav2}
          slidesToShow={1}
          arrows={true}
          nextArrow={<NextArrow />}
          prevArrow={<PrevArrow />}
          ref={slider1Ref}
          className="galleryslider"
        >
          {renderSliderItems(560)}
        </Slider>
      </Gallery>

      <DetailInfo>
        <span className="black">{viewDetails?.brandName} </span>
        <Title style={{ marginBottom: "1rem" }}>
          {viewDetails?.productName || ""}
        </Title>
        <Content>{viewDetails?.description}</Content>
        <FlexBox align="center" gap="3rem" style={{ marginTop: "1rem" }}>
          {viewDetails?.price > 0 && (
            <Price>
              <Icons.rupee /> {viewDetails?.price}
            </Price>
          )}

          <FlexBox gap="2rem" className="ft-16">
            {viewDetails?.quantity > 0 && (
              <div>
                <span className="black" style={{ marginRight: "0.5rem" }}>
                  Quantity
                </span>
                {viewDetails?.quantity}
              </div>
            )}

            {false && (
              <div>
                <span className="black" style={{ marginRight: "0.5rem" }}>
                  Pc
                </span>
                2
              </div>
            )}
          </FlexBox>
        </FlexBox>
        <AddRemoveWishlist
          productID={parseInt(slug)}
          addedToWishlist={viewDetails?.addedToWishlist}
        />
        {false && (
          <>
            <FlexBox
              gap="1rem"
              style={{ marginTop: "1rem", marginBottom: "2rem" }}
            >
              <ShopButton>Buy Now</ShopButton>
              <Button>
                <Icons.cart
                  style={{
                    fontSize: "20px",
                    display: "inline-block",
                    marginRight: "5px",
                  }}
                />
                Add to Card
              </Button>
              <Button>
                <Icons.heart size={20} />
              </Button>
            </FlexBox>
            <FlexBox gap="1rem" align="center" style={{ marginTop: "2rem" }}>
              Categories <Tag>Category 1</Tag>
            </FlexBox>
            <FlexBox
              gap="1rem"
              align="center"
              style={{ marginTop: "0.5rem", marginBottom: "2rem" }}
            >
              Sub Categories <Tag>Category 1</Tag>
            </FlexBox>
          </>
        )}
        {false && (
          <>
            <div className="ft-16">Shop Name</div>
            <FlexBox gap="0.5rem" align="center" justify="space-between">
              <FlexBox gap="0.5rem" align="center">
                <Icons.map size={20} />
                <h3 className="ft-18">{viewDetails?.shop?.name}</h3>
              </FlexBox>

              <Button>
                <Image
                  src={filter}
                  width={20}
                  height={20}
                  objectFit={"contain"}
                  alt="filter"
                />
              </Button>
            </FlexBox>
            <FlexBox gap="0.15rem" style={{ marginTop: "1rem" }}>
              <Map style={{ marginTop: "3px" }} />
              <div className="ft-12">
                <p className="black">2.8 Km</p>
                <p>{viewDetails?.shop?.address}</p>
              </div>
            </FlexBox>
          </>
        )}
      </DetailInfo>
    </DetailSection>
  );
};

function HomePage() {
  const [loading, setLoading] = useState(true);
  const [shopData, setShopData] = useState([]);
  const [productData, setProductData] = useState([]);
  const router = useRouter();
  const slug: string = router.query.slug as string;
  const { authToken } = useAuth();
  const { query } = router;

  useEffect(() => {
    const fetchCategoriesData = async () => {
      try {
        if (slug) {
          const config = `${EndPoints.nearShop}?shopID=${query.shopID}`;
          const productConfig = `${EndPoints.productsShop}?shopID=${
            query.shopID
          }&productID=${parseInt(slug)}`;
          const { data } = await getRequest(config, authToken);
          const { data: productsData } = await getRequest(
            productConfig,
            authToken
          );
          setShopData(data?.shop);
          setProductData(productsData?.products);
        }
      } catch (e) {
        console.log(e);
      }
    };

    fetchCategoriesData();
  }, [slug]);

  const _renderTrendingPost = (post: TrendingProps): JSX.Element => {
    return (
      <Product>
        <div style={{ position: "relative" }}>
          <ProductImage
            src={post.imageURL}
            width={200}
            height={200}
            objectFit={"cover"}
            alt="image"
          />
          <WhiteMapBox>
            <Map />
            <p>2.8 Km</p>
          </WhiteMapBox>
        </div>
        <ProductInfo>
          <Rating>
            <Icons.solidstar size={14} />
            <p>4.5</p>
          </Rating>
          <ProductTitle>Wood Style Furniture</ProductTitle>
          <p className="ft-12">Category / Sub Category</p>
          <Price className="ft-16">$59.99</Price>
        </ProductInfo>
      </Product>
    );
  };

  const _renderShop = (shopData: any): JSX.Element => {
    return (
      <ProductBox className="shopinfo" key={shopData?.shopID}>
        <div style={{ position: "relative" }}>
          <ProductImage
            src={shopData?.image || "https://picsum.photos/200/100"}
            width={90}
            height={90}
            objectFit={"cover"}
            alt="image"
          />
          <WhiteMapBox>
            <Map />
            <p>2.8 Km</p>
          </WhiteMapBox>
        </div>
        <ProductInfo>
          <ProductTitle>{shopData?.name}</ProductTitle>
          {shopData?.address && (
            <MapBox>
              <Map />
              <p>{shopData.address}</p>
            </MapBox>
          )}
        </ProductInfo>
      </ProductBox>
    );
  };

  const _renderProducts = (productData: any): JSX.Element => {
    return (
      <>
        <ProductBox key={productData?.productID}>
          <ProductImage
            src={productData?.image || "https://picsum.photos/200/100"}
            width={90}
            height={90}
            objectFit={"cover"}
            alt="image"
          />

          <ProductInfo>
            <p>{productData?.brandName}</p>
            <ProductTitle>{productData?.productName}</ProductTitle>
            <FlexBox
              gap="2.5rem"
              align="center"
              style={{ marginTop: "0.5rem" }}
            >
              {productData?.price && parseInt(productData?.price) > 0 ? (
                <Price>${productData?.price}</Price>
              ) : null}

              <FlexBox gap="1rem">
                {productData?.quantity &&
                parseInt(productData?.quantity) > 0 ? (
                  <div>
                    <span className="black" style={{ marginRight: "0.5rem" }}>
                      Quantity
                    </span>
                    {productData.quantity}
                  </div>
                ) : null}
                <div>
                  <span className="black" style={{ marginRight: "0.5rem" }}>
                    Pc
                  </span>
                  2
                </div>
              </FlexBox>
              <div>
                <Image
                  src={filter}
                  width={15}
                  height={15}
                  objectFit={"contain"}
                  alt="filter icon"
                />
              </div>
            </FlexBox>
          </ProductInfo>
        </ProductBox>
      </>
    );
  };

  return (
    <GridSection>
      {false && (
        <StickyScrollBar id="trending-posts">
          <StickyProducts className="">
            {TRENDING_CONTENT.map((post: TrendingProps) =>
              _renderTrendingPost(post)
            )}
          </StickyProducts>
        </StickyScrollBar>
      )}

      <section id="posts">
        {/* {_renderProfile()} */}

        {_renderViewdetails()}

        {false && (
          <>
            <Heading>Price comparison from near by shops</Heading>
            <ProductSlider>
              <Slider {...settings}>
                {productData?.map((post: string) => _renderProducts(post))}
              </Slider>
            </ProductSlider>

            <Heading>Similar Shops nearby</Heading>

            <ProductSlider>
              <Slider {...settings}>
                {shopData?.map((post: any) => _renderShop(post))}
              </Slider>
            </ProductSlider>

            <Heading>Products used by the same user</Heading>

            <ProductSlider>
              <Slider {...settings}>
                {productData?.map((post: any) => _renderProducts(post))}
              </Slider>
            </ProductSlider>
          </>
        )}
      </section>
    </GridSection>
  );
}
export default HomePage;
