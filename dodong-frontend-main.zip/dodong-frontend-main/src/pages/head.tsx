export default function Head() {
  return (
    <>
      <title>DoDong - Go online Do Dong | Hyper-local market place</title>
      <link rel="icon" href="/favicon.ico" />
      <meta
        name="viewport"
        content="width=device-width, initial-scale=1, maximum-scale=1"
      />
      <meta
        name="description"
        content="Follow for local shop finds, product experiences, and collections on dodong. Let's explore together and make amazing discoveries!"
      />
      <meta
        name="title"
        key="title"
        content="DoDong - Go online Do Dong | Hyper-local market place"
      />
      <meta
        property="og:title"
        key="og:title"
        content="DoDong - Go online Do Dong | Hyper-local market place"
      />
      <meta
        property="og:description"
        key="og:description"
        content="Follow for local shop finds, product experiences, and collections on dodong. Let's explore together and make amazing discoveries!"
      />
    </>
  );
}
