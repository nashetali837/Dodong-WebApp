import React, { useCallback, useEffect, useState } from "react";
import { useRouter } from "next/router";
import Link from "next/link";
import { NextSeo } from "next-seo";
import styled from "styled-components";

import { EndPoints } from "@/lib/apiConstants";
import StoreFrontPost from "@/components/storefront/post";
import Spinner from "@/shared/loading/spinner";
import { TRENDING_CONTENT, LOCAL_MARKET_CONTENT } from "@/lib/constants";
import Modal from "@/shared/modal";
import { Heading } from "@/components/sections/Styled";
import {
  Product,
  ProductImage,
  ProductInfo,
  ProductTitle,
  Map,
} from "./product/[slug]";
import { MapBox, WhiteMapBox } from "@/components/sections/Styled";
import { StickyProducts } from "@/components/sections/Styled";
import { Icons } from "@/components/icons";
import ExpandedPost from "@/components/storefront/post/ui/ExpandedPost";
import { Flex } from "@/components/sections/Styled";
import MediaQuery from "@/components/sections/MediaQuery";
import DiscoveryPosts from "@/components/sections/DiscoveryPosts";
import { StickyScrollBar } from "@/components/sections/CustomScrollbar";
import { refetchPostData } from "@/lib/redux/slices/user-slice";
import { useDispatch, useSelector } from "react-redux";

const HomeSection = styled.div`
  display: flex;
  display: -webkit-flex;
  max-width: 1400px;
  justify-content: center;
  margin: auto;
  padding: 0 1rem;
  gap: 1.5rem;

  ${MediaQuery.laptop} {
    gap: 1rem;
  }

  ${MediaQuery.tablet} {
    display: block;
  }

  ${StickyScrollBar} {
    min-width: 130px;
    ${MediaQuery.tablet} {
      display: none;
      min-width: auto;
    }
  }

  #trending-posts {
    width: 17%;
  }

  #posts {
    width: 58%;
    ${MediaQuery.tablet} {
      width: 100%;
    }
    .StoreFrontPost {
      .slick-slide img,
      .slick-slide video {
        height: 440px;
        object-fit: contain;
        background: #333;
        ${MediaQuery.phone} {
          height: 300px;
          object-fit: cover;
        }
      }
    }
  }

  #local-market {
    width: 25%;
  }
`;

const CatList = styled.div`
  ${Flex("row", "", "")};
  gap: 8px;
  margin-bottom: 1.5rem;
`;

const CatTag = styled.span`
  padding: 8px;
  background: ${(props) => props.theme.colors.white};
  border: 1px solid ${(props) => props.theme.colors.border};
  border-radius: ${(props) => props.theme.borderRadius.button};
  display: inline-block;
  font-size: 12px;
  color: ${(props) => props.theme.colors.black};
  min-width: 45px;
  text-align: center;

  &.all {
    background: ${(props) => props.theme.colors.primary};
    border-color: ${(props) => props.theme.colors.primary};
    color: ${(props) => props.theme.colors.white};
  }
`;

const Like = styled(Link)`
  color: ${(props) => props.theme.colors?.white};
  border-radius: ${(props) => props.theme.borderRadius?.button};
  padding: 0.25rem;
  border: 1px solid ${(props) => props.theme.colors?.black};
  background: rgba(0, 0, 0, 0.75);
  display: inline-block;
  position: absolute;
  bottom: 1rem;
  right: 1rem;
`;

const IconsBox = styled.div`
  ${Flex("row", "", "")};
  gap: 0.25rem;
  margin-top: 0.5rem;
  font-size: 20px;
  color: ${(props) => props.theme.colors?.black};
`;

const ModalWrapper = styled.div`
  .flex.absolute.right-0 {
    padding: 1rem 0;
  }

  .bg-white:not(.closebtn, .rounded-tl-xl, .block) {
    background: #000;
  }

  .fullScreenOpened {
    > div {
      position: relative;
    }
  }
`;

type TrendingProps = {
  name: string;
  designation: string;
  company: string;
  id: string;
  distance: string;
  imageURL: string;
  liked: boolean;
};

type LocalMarketProps = {
  name: string;
  designation: string;
  company: string;
  id: string;
  distance: string;
  imageURL: string;
  // address: string;
  liked: boolean;
};

function HomePage() {
  const dispatch = useDispatch();
  const [page, setPage] = useState(1);
  const [isLoading, setLoading] = useState(true);
  const [trendingPosts, setTrendingPosts] = useState<any[]>([]);
  // const [localShops, setLocalShops] = useState<any[]>([]);
  const [currentPost, setCurrentPost] = useState<any>(undefined);
  const [discoveryPosts, setDiscoveryPosts] = useState<any[]>([]);
  const { fetchPostData } = useSelector((state: any) => state.user);
  const sortedTrendingPosts = trendingPosts
    ? trendingPosts
        .slice()
        .sort((postA, postB) => postB.resourceID - postA.resourceID)
    : [];
  const [viewPostModal, setViewPostModal] = useState<boolean>(false);
  const { query } = useRouter();
  const postID = query.postID;

  const _renderTrendingPost = (post: TrendingProps): JSX.Element => {
    return (
      <Product id={post.id}>
        <div className="relative">
          <div className="absolute right-0 text-trending-icon"></div>
          <ProductImage
            src={post.imageURL}
            width="1000"
            height={400}
            alt="data.post image"
          />
          <WhiteMapBox>
            <Map />
            <p>2.8 km</p>
          </WhiteMapBox>
          <Like href="/#">
            <Icons.heart />
          </Like>
        </div>
        <ProductInfo>
          <ProductTitle>{post.name}</ProductTitle>
          <div className="text-xs">
            {post.designation} @ <span>{post.company}</span>
          </div>
          <IconsBox>
            <Link href="/#m">
              <Icons.message />
            </Link>
            <Link href="/#">
              <Icons.link />
            </Link>
          </IconsBox>
          <div>{post.liked}</div>
        </ProductInfo>
      </Product>
    );
  };

  const _renderLocalMarketProduct = (post: LocalMarketProps): JSX.Element => {
    return (
      <Product id={post.id}>
        <ProductImage
          src={post.imageURL || "https://picsum.photos/200/100"}
          width={400}
          height={400}
          alt="data.post image"
          className="rounded-xl w-full"
          style={{ width: "100%" }}
        />
        <ProductInfo>
          <ProductTitle>{post.name}</ProductTitle>
          <MapBox>
            <Map />
            {post.distance}
          </MapBox>
        </ProductInfo>
      </Product>
    );
  };

  // Call the fetchData function

  // useEffect(() => {
  //   fetchStoreFront(page, "post").then((data) => {
  //     console.log("storefront", data);
  //     if (data) {
  //       // setTrendingPosts(data.resources);
  //       setLocalShops(data.localShops);
  //     }
  //     setLoading(false);
  //   });
  // }, [page]);

  // console.log(trendingPosts, "trendingPosts");

  const fetchStoreFront = useCallback(async (page: number, type: string) => {
    setLoading(true);
    const endpoint = `${EndPoints.storefront}?page=${page}&device=web&type=${type}`;

    try {
      const response = await fetch(endpoint);

      if (response.status === 200) {
        const data = await response.json();
        return data;
      } else {
        throw new Error(response.statusText);
      }
    } catch (error) {
      console.log(error);
      return null;
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    async function fetchData() {
      const pageNumber = 1;
      const postData = await fetchStoreFront(pageNumber, "post");
      const discoveryData = await fetchStoreFront(pageNumber, "discovery");
      const experiencesData = await fetchStoreFront(pageNumber, "experience");

      setDiscoveryPosts(discoveryData?.resources);

      if (postData || discoveryData) {
        const data = [...postData?.resources, ...experiencesData?.resources];

        setTrendingPosts(data);
      }
    }
    dispatch(refetchPostData(false));

    fetchData();
  }, [dispatch, fetchPostData, fetchStoreFront]);

  const selectedPost = trendingPosts?.find(
    (post) => post?.resourceID?.toString() === postID
  );

  useEffect(() => {
    if (selectedPost) {
      setCurrentPost(selectedPost);
      setViewPostModal(true);
    }
  }, [selectedPost]);

  const handleCloseModal = () => {
    setCurrentPost(null);
    setViewPostModal(false);
  };

  return (
    <div className="relative">
      <NextSeo
        title="Dodong | Go online Do dong"
        description="This is the home page of the website"
      />
      <div className="max-w-md container mx-auto"></div>
      {isLoading ? (
        <Spinner />
      ) : (
        <HomeSection className="HomeSection">
          {false && (
            <StickyScrollBar id="trending-posts">
              <StickyProducts>
                {TRENDING_CONTENT.map((post: TrendingProps) =>
                  _renderTrendingPost(post)
                )}
              </StickyProducts>
            </StickyScrollBar>
          )}

          <section id="posts">
            {/* <Statuses /> */}
            {discoveryPosts?.length > 0 && (
              <DiscoveryPosts posts={discoveryPosts} />
            )}

            {trendingPosts
              ?.sort((a, b) => b.resourceID - a.resourceID) // Sorted in descending order by resourceID
              .map((post: any, k: number) => (
                <StoreFrontPost
                  key={k}
                  post={post}
                  selectPost={() => {
                    setCurrentPost(post);
                  }}
                  openPost={() => {
                    setViewPostModal(true);
                  }}
                />
              ))}
          </section>

          {false && (
            <StickyScrollBar id="local-market">
              <StickyProducts>
                <Heading>Local Market</Heading>
                <CatList>
                  <CatTag className="all">All</CatTag>
                  <CatTag>Electronics</CatTag>
                </CatList>
                {LOCAL_MARKET_CONTENT.map((post: LocalMarketProps) =>
                  _renderLocalMarketProduct(post)
                )}
              </StickyProducts>
            </StickyScrollBar>
          )}
        </HomeSection>
      )}

      <ModalWrapper>
        <Modal
          fullScreen={true}
          key="post_modal"
          open={viewPostModal}
          onClose={handleCloseModal}
        >
          {currentPost && <ExpandedPost currentPost={currentPost} />}
        </Modal>
      </ModalWrapper>
    </div>
  );
}
export default HomePage;
