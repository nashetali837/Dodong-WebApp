/** @type {import('next').NextConfig} */
const nextConfig = {
  reactStrictMode: true,
  images: {
    remotePatterns: [
      {
        protocol: "https",
        hostname: "picsum.photos",
        port: "",
      },
      {
        protocol: "https",
        hostname: "i.imgur.com",
        port: "",
      },
      {
        protocol: "https",
        hostname: "post-uploads.s3.ap-northeast-1.amazonaws.com",
        port: "",
      },
      {
        protocol: "https",
        hostname: "lorempixel.com",
        port: "",
      },
      {
        protocol: "https",
        hostname: "st3.depositphotos.com",
        port: "",
      },
      {
        protocol: "https",
        hostname: "lh3.googleusercontent.com",
        port: "",
      },
      // lh3.googleusercontent.com
    ],
  },
};

module.exports = nextConfig;
