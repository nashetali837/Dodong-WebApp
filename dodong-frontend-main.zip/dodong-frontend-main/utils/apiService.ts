import axios from "axios";

interface APIConfig {
  endPoint?: string;
  method?: string;
  data?: any;
  token?: string;
}

export const sendAPIRequest = async ({
  config,
}: {
  config: APIConfig;
}): Promise<any> => {
  const { endPoint = "", method = "POST", data = {}, token = "" } = config;
  const url = endPoint;
  const body = { ...data };
  const headers = {
    authorization: `Bearer ${token}`,
    "Content-Type": "application/json",
  };

  try {
    return await axios({
      method,
      url,
      headers,
      data: body,
    });
  } catch (error: any) {
    return error.response?.data;
  }
};
