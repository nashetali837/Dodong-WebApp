const themeConfig = {
  font: {
    body: "'Kanit', sans-serif",
  },
  colors: {
    primary: "#FF9800", // Orange
    black: "#110C22", // Text
    white: "#FFFFFF",
    lightGray: "#F3F3F4",
    darkGray: "#8D8A95", // Secondary Text
    border: "#ECECED", // border
    red: "#F03D3D",
  },
  borderRadius: {
    button: "8px",
    md: "12px",
    lg: "16px", //map
    round: "50%",
  },
  maxWidth: "1146px",
};

export default themeConfig;
