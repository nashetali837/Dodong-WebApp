import mailgun from "mailgun-js";

console.log(';process.env.MAILGUN_API_KEY',process.env.MAILGUN_API_KEY);
const mg = mailgun({ apiKey:  process.env.MAILGUN_API_KEY, domain: process.env.MAILGUN_API_BASE_URL });

// Email Verification Code
export const sendCodeToEmail = (email: string, otp: string) => {
  let data = {
    from: "DoDong India <postmaster@mailgun.dodong.in>",
    to: email,
    subject: "DoDong - OTP to verify email",
    template: "email-verification",
    "h:X-Mailgun-Variables": { otp },
    "v:otp": otp,
  };
  console.log("Sending EMAIl to: ", email, otp);
  mg.messages().send(data, function (error, body) {
    console.log(body);
  });
};

export const sendEmail = async (to: string, subject: string, text: string) => {
  const data = {
    from: `Excited User <mailgun@${process.env.MAILGUN_API_BASE_URL}>`,
    to: to,
    subject: subject,
    text: text,
  };

  mg.messages()
    .send(data)
    .then((response) => console.log(response))
    .catch((error) => console.error(error));
};
