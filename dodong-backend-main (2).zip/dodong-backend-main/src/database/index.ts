import { PrismaClient } from "@prisma/client";

const db = new PrismaClient();

export default db;

/**
 * Connect to the database
 * @returns {Promise<void>} void
 * @constructor
 * @async
 * @function
 * @name connectDatabase
 * @description Connect to the database
 * @throws {Error} - If the connection fails
 * @see {@link https://www.prisma.io/docs/concepts/components/prisma-client/initialization|Prisma Client Initialization}
 * @see {@link https://www.prisma.io/docs/concepts/components/prisma-client/connection-management|Prisma Client Connection Management}
 * @see {@link https://www.prisma.io/docs/concepts/components/prisma-client/crud|Prisma Client CRUD}
 * @see {@link https://www.prisma.io/docs/concepts/components/prisma-client/working-with-fields|Prisma Client Working with Fields}
 * @see {@link https://www.prisma.io/docs/concepts/components/prisma-client/working-with-fields/working-with-json-fields|Prisma Client Working with JSON Fields}
 * @see {@link https://www.prisma.io/docs/concepts/components/prisma-client/working-with-fields/working-with-enum-fields|Prisma Client Working with Enum Fields}
 * @see {@link https://www.prisma.io/docs/concepts/components/prisma-client/working-with-fields/working-with-relation-fields|Prisma Client Working with Relation Fields}
 *
 */
export const connectDatabase = async (): Promise<void> => {
  try {
    console.log("Connecting to database...");
    await db.$connect();
    console.debug("====== Database connected ======");
  } catch (error) {
    console.log(error);
    await db.$disconnect();
  }
};

export const disconnectDatabase = async () => {
  try {
    console.log("Disconnecting from database...");
    await db.$disconnect();
    console.debug("====== Database disconnected ======");
  } catch (error) {
    console.log(error);
  }
};
