import { ResourceMedia } from "@prisma/client";

interface Resource {
  mediaURLs: ResourceMedia[];
  
}

interface Post {}

interface PostResource extends Resource {
  resourceDetails: Post;
}

// interface DiscoveryResource extends Resource {
//   resourceDetails: Post;
// }

// interface ExperienceResource extends Resource {
//   resourceDetails: Post;
// }

interface CollectionResource extends Resource {
  //   resourceDetails: Collection;
}
