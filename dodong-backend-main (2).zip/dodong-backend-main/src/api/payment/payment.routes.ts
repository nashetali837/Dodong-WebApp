import { Router } from "express";
import { isUserLoggedIn } from "../../middleware/authentication";
import { PaymentController } from "./payment.controller";

const router = Router()

router.post("/make-payment", isUserLoggedIn, PaymentController.makePayment)

export default router