import { Request, Response } from "express";
import { ResponseWithFailure, ResponseWithSuccess } from "../../utils/response";
import { createPayment } from "./payment.service";

export class PaymentController {
    static makePayment = async (req: Request, res: Response) => {
        let {amount}: any = req.body
        if(!amount) {
            return res.status(400).json(
                ResponseWithFailure({
                    error: "Amount is required"
                })
            )
        }
        const payment = await createPayment(Number(amount))
        if(payment === null) {
            res.json(ResponseWithFailure("Failed to make payment!"))
        }
        else {
            res.json(ResponseWithSuccess({payment}))
        }
    }
}