import Razorpay from "razorpay";
import crypto from 'crypto'

const razorPay = new Razorpay({
    key_id: process.env.RAZORPAY_KEY,
    key_secret: process.env.RAZORPAY_SECRET
})

export const createPayment = async (amount: number) => {
    try {
        const payment = await razorPay.orders.create({
            amount: amount * 100,
            currency: 'INR',
            receipt: `receipt_${crypto.randomUUID()}`,
            payment_capture: true,
    
        })
        return payment
    } catch (error) {
        console.log(error);
        return null
    }
    
}