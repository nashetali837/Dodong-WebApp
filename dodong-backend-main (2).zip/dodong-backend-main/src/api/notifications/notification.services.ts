import db from "../../database";

export enum NotificationType {
  DEFAULT = "DEFAULT",
  NEW_FOLLOWER = "NEW_FOLLOWER",
  NEW_COMMENT = "NEW_COMMENT",
  NEW_FOLLOW_REQUEST = "NEW_FOLLOW_REQUEST",
  NEW_MESSAGE = "NEW_MESSAGE",
  NEW_REGISTER = "NEW_REGISTER",
}

const NOTIFICATION_TEMPLATE = {
  [NotificationType.DEFAULT]: (body) => {
    return {
      title: body?.moreInformation?.title,
      content: body?.moreInformation?.content,
      moreInformation: {
        ...body.moreInformation,
      },
    };
  },

  [NotificationType.NEW_FOLLOWER]: (body) => {
    return {
      title: body.userName + " started following you",
      content: "",
      moreInformation: {
        followingUserProfileID: body.followerID,
        ...body.moreInformation,
      },
    };
  },

  [NotificationType.NEW_COMMENT]: (body) => {
    console.log("body", body);
    return {
      title:
        body?.moreInformation?.commenterName +
        " commented on your post: " +
        body?.moreInformation?.comment,
      content: "",
      moreInformation: {
        commenterProfileID: body?.moreInformation?.commenterProfileID,
        resourceID: body?.moreInformation?.resourceID,
        actionNeeded: true,
        commentID: body?.moreInformation?.commentID,
        comment: body?.moreInformation?.comment,
      },
    };
  },

  [NotificationType.NEW_FOLLOW_REQUEST]: (body) => {
    return {
      title: body.userName + " is requesting to connect",
      content: "",
      moreInformation: {
        followerId: body.profileId,
        actionNeeded: true,
      },
    };
  },

  [NotificationType.NEW_MESSAGE]: (body) => {
    return {
      title: body.userName + " is requesting to connect",
      content: "",
      moreInformation: {
        followerId: body.profileId,
        actionNeeded: true,
      },
    };
  },

  [NotificationType.NEW_REGISTER]: (body) => {
    return {
      title: "Welcome to DoDong!",
      content: "We are so excited to have you on-board.",
      moreInformation: {
        newUser: true,
      },
    };
  },
};

export const UnfollowNewProfile = async (followId, followerId) => {
  if (!followId || !followerId) {
    throw new Error("Both Follower ID and Follow ID are required");
  }
  const follow = await db.follows.deleteMany({
    where: {
      followerId: followerId,
      followingId: followId,
    },
  });
  console.log("unfollow", follow);
  return "Success";
};

export const createSilentNotification = async (
  notificationType: NotificationType,
  body: { userName: string; userProfileID: number },
  moreInformation?: any
) => {
  try {
    if (!moreInformation) {
      moreInformation = {};
    }
    const notification = await db.notification.create({
      data: {
        //
        ...NOTIFICATION_TEMPLATE[notificationType]({
          ...body,
          moreInformation,
        }),
        notificationType,
        userProfileID: body.userProfileID,
      },
    });
    console.log("notification created: ", notification);
  } catch (error) {
    console.log("Error while creating notification: ", error.message);
  }
};
