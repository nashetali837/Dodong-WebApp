import { Response } from "express";
import db from "../../database";
import { ResponseWithFailure, ResponseWithSuccess } from "../../utils/response";
import { AuthRequest } from "../location/location.controller";
import {
  NotificationType,
  createSilentNotification,
} from "./notification.services";

const NOTIFICATION_COUNT_PER_PAGE = 15;

export class NotificationController {
  static getUserNotifications = async (req: AuthRequest, res: Response) => {
    try {
      const profileID = req.locals.user.profileID;
      let page = Number(req.query.page);

      if (isNaN(page)) {
        page = 1;
      }

      const notifications = await db.notification.findMany({
        where: {
          userProfileID: profileID,
        },

        orderBy: [{ createdAt: "desc" }],

        skip: (page - 1) * NOTIFICATION_COUNT_PER_PAGE,
        take: NOTIFICATION_COUNT_PER_PAGE,
      });

      console.log("notifications", notifications.length);
      res.json(ResponseWithSuccess({ notifications: notifications }));
    } catch (error) {
      console.log(error);
      res.status(500).json(
        ResponseWithFailure({
          error: "Something went wrong",
        })
      );
    }
  };

  static createNotification = async (req: AuthRequest, res: Response) => {
    try {
      const profileID = req.locals.user.profileID;
      let page = Number(req.query.page);

      if (isNaN(page)) {
        page = 1;
      }

      await createSilentNotification(NotificationType.NEW_REGISTER, {
        userProfileID: profileID,
        userName: "",
      });

      await createSilentNotification(
        NotificationType.DEFAULT,
        {
          userProfileID: profileID,
          userName: "",
        },
        {
          title: "[Default] Some marketing title",
          content: "Here, there will be any content in future",
        }
      );

      res.json(ResponseWithSuccess({ notifications: "Created successfully" }));
    } catch (error) {
      console.log(error);
      res.status(500).json(
        ResponseWithFailure({
          error: "Something went wrong",
        })
      );
    }
  };
}
