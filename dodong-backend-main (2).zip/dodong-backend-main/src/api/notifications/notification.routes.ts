import { Router } from "express";
import { isUserLoggedIn } from "../../middleware/authentication";
import { NotificationController } from "./notification.controller";

const router = Router();

// Get all users
router.get("/get", isUserLoggedIn, NotificationController.getUserNotifications);

router.get(
  "/read",
  isUserLoggedIn,
  NotificationController.getUserNotifications
);

router.post(
  "/create",
  isUserLoggedIn,
  NotificationController.createNotification
);

export default router;
