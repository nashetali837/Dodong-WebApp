import { Router } from "express";
import { isUserLoggedIn } from "../../middleware/authentication";
import { PostController } from "./post.controller";
import { CategoryController } from "./category.controller";

const router = Router();

/**
 * Categories
 */

router.post("/categories/filter", CategoryController.getFilterCategories);

router.post(
  "/category/create",
  isUserLoggedIn,
  CategoryController.createNewCategory
);

router.post(
  "/sub-categories/filter",
  CategoryController.getFilterSubCategories
);
router.post(
  "/sub-category/create",
  isUserLoggedIn,
  CategoryController.createNewSubCategory
);

/**
 * Posts
 */

router.post("/filter", PostController.listAll);

router.get("/:id", PostController.getPostByID);

// Link a posts
router.post("/like", isUserLoggedIn, PostController.likePost);
router.post("/unlike", isUserLoggedIn, PostController.dislikePost);

router.post("/create", isUserLoggedIn, PostController.createNewPost);
router.delete("/delete", isUserLoggedIn, PostController.deletePost);

export default router;
