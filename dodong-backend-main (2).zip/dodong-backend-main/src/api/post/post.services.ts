import { Category, ResourceMedia } from "@prisma/client";
import db from "../../database";
import { RESOURCE_TYPES } from "./post.controller";
import { DEFAULT_USER_IMAGE } from "../../utils/constants";

// get all posts
export const getPostsByFilter = async (filters = {}) => {
  try {
    const posts = await db.resource.findMany({
      where: {
        ...filters,
        isActive: true,
      },
      include: {
        author: {
          select: {
            displayName: true,
            name: true,
            avatar: true,
            userProfileID: true,
          },
        },
        ResourceMedia: {
          select: {
            mediaURL: true,
          },
        },
        Locations: {
          select: {
            name: true,
            country: true,
            state: true,
          },
        },
        shop: {
          select: {
            shopID: true,
            name: true,
            bio: true,
          },
        },
      },
    });

    if (!posts) {
      return [];
    }
    return posts;
  } catch (error) {
    console.log(error);
    return [];
  }
};

export const AddImagesToPost = async (data: ResourceMedia) => {
  try {
    const post = await db.resourceMedia.create({
      data: {
        ...data,
        resourceID: data.resourceID,
        mediaURL: data.mediaURL,
        mediaType: data.mediaType,
      },
    });

    if (post) {
      return post;
    }
    return null;
  } catch (error) {
    console.log(error);
    return null;
  }
};

// create category
export const createCategory = async (data: Category) => {
  try {
    const categoryName = data.name.toLowerCase();

    // check if exists
    const categoryExists = await db.category.findFirst({
      where: {
        name: categoryName,
      },
    });
    if (categoryExists) {
      return { ...categoryExists, alreadyExists: true };
    }

    const category = await db.category.create({
      data: {
        name: categoryName,
        displayName: data.name,
      },
    });
    if (category) {
      return category;
    }
    return null;
  } catch (error) {
    console.log(error);
    return null;
  }
};

// get all categories
export const getCategories = async () => {
  try {
    const categories = await db.category.findMany({
      where: {},
    });

    if (categories) {
      return categories;
    }
    return null;
  } catch (error) {
    console.log(error);
    return null;
  }
};

// get all categories
export const getSubCategories = async (filters) => {
  try {
    const categories = await db.subCategory.findMany({
      where: filters,
    });

    if (categories) {
      return categories;
    }
    return null;
  } catch (error) {
    console.log(error);
    return null;
  }
};

// create subcategory
export const createSubCategory = async (body: any) => {
  try {
    let { name = "", categoryID, displayName } = body;

    const categoryName = name || displayName.toLowerCase();

    if (!categoryID) throw new Error("CategoryID is required");

    const subcategory = await db.subCategory.upsert({
      where: {
        name,
      },
      create: {
        categoryID: categoryID,
        displayName: displayName,
        name: categoryName,
      },
      update: {
        displayName: displayName,
      },
    });

    if (subcategory) {
      return subcategory;
    }
    return null;
  } catch (error) {
    console.log(error);
    return { error: error.message };
  }
};

// fetch trending posts

const STOREFRONT_PAGE_COUNT = 10;
export const fetchTrendingPosts = async (
  page: number,
  type?: string,
  userProfileID?: number
) => {
  try {
    if (!RESOURCE_TYPES[type.toUpperCase()]) {
      return [];
    }

    console.log("Resource Type:", RESOURCE_TYPES[type.toUpperCase()]);

    const resources = await db.resource.findMany({
      where: {
        isActive: true,
        resourceType: RESOURCE_TYPES[type.toUpperCase()],
      },
      include: {
        author: {
          select: {
            displayName: true,
            name: true,
            avatar: true,
            userProfileID: true,
          },
        },
        ResourceMedia: {
          select: {
            mediaURL: true,
            mediaType: true,
          },
        },
        product: {
          select: {
            price: true,
            productName: true,
            productID: true,
          },
        },
        Locations: {
          select: {
            name: true,
            country: true,
            geohash: true,
            state: true,
          },
        },
        shop: {
          select: {
            shopID: true,
            name: true,
            bio: true,
          },
        },
        ResourceCategories: {
          include: {
            category: {
              select: {
                id: true,
                name: true,
                displayName: true,
              },
            },
            subCategory: {
              select: {
                id: true,
                name: true,
                displayName: true,
                categoryID: true,
              },
            },
          },
        },
      },
      orderBy: [
        {
          createdAt: "desc",
        },
      ],
      skip: (page - 1) * STOREFRONT_PAGE_COUNT,
      take: STOREFRONT_PAGE_COUNT,
    });

    // NOT CACHED INFO

    // fetch post's images
    const postsWithImages = await Promise.all(
      resources.map(async (resource) => {
        const currentResourceLikes = await fetchResourceLikeCount(
          resource.resourceID
        );

        const currentResourceComments = await fetchResourceCommentCount(
          resource.resourceID
        );
        const userAlreadyLiked = await isResourceLikedByUser(
          resource.resourceID,
          userProfileID
        );

        return {
          profile: {
            name: resource.author.displayName || resource.author.name,
            // default image
            imageURL: resource.author.avatar || DEFAULT_USER_IMAGE,
            distance: resource?.Locations?.country || undefined,
            userID: resource.author.userProfileID,
            userProfileID: resource.author.userProfileID,
          },
          shopURL: "/shop/" + resource.shop.shopID,
          post: {
            imageURL: resource.ResourceMedia.map((img) => img.mediaURL),
            description: "",
            likes: currentResourceLikes,
            comments: currentResourceComments,
          },
          liked: userAlreadyLiked,
          ...resource,
        };
      })
    );

    if (resources) {
      return postsWithImages;
    }
    return null;
  } catch (error) {
    console.log(error);
    return null;
  }
};

export const fetchResourceLikeCount = async (resourceID: number) => {
  const count = await db.resourceLikes.count({
    where: {
      resourceID,
    },
  });
  return count;
};

export const fetchResourceCommentCount = async (resourceID: number) => {
  const count = await db.resourceComments.count({
    where: {
      resourceID,
    },
  });
  return count;
};

export const isResourceLikedByUser = async (
  resourceID: number,
  userProfileID?: number
) => {
  try {
    if (!userProfileID) {
      return false;
    }
    const resource = await db.resourceLikes.findFirstOrThrow({
      where: {
        resourceID,
        userProfileID,
      },
      select: {
        resourceID: true,
      },
    });

    console.log("resource", resource);

    if (!resource) {
      return false;
    } else {
      return true;
    }
  } catch (error) {
    return false;
  }
};
