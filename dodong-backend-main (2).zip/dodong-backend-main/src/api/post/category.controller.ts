import { Request, Response } from "express";
import { Category } from "@prisma/client";
import { ResponseWithFailure, ResponseWithSuccess } from "../../utils/response";
import {
  createCategory,
  createSubCategory,
  getCategories,
  getSubCategories,
} from "./post.services";

export class CategoryController {
  static createNewCategory = async (req: Request, res: Response) => {
    const body: Category = req.body;
    const category = await createCategory(body);
    res.json(ResponseWithSuccess({ category }));
  };

  static createNewSubCategory = async (req: Request, res: Response) => {
    const body = req.body;
    console.log("body", body);
    const subCategory = await createSubCategory(body);
    res.json(ResponseWithSuccess({ subCategory }));
  };

  static getFilterCategories = async (req: Request, res: Response) => {
    try {
      const categories: Category[] = await getCategories();
      res.json(ResponseWithSuccess({ categories }));
    } catch (error) {
      console.log(error);
      res.status(400).json(ResponseWithFailure({ message: error.message }));
    }
  };

  static getFilterSubCategories = async (req: Request, res: Response) => {
    try {
      const filters = req.body;
      const categories: Category[] = await getSubCategories(filters);
      res.json(ResponseWithSuccess({ categories }));
    } catch (error) {
      console.log(error);
      res.status(400).json(ResponseWithFailure({ message: error.message }));
    }
  };
}
