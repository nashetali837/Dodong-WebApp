import { Request, Response } from "express";
import db from "../../database";
import { ResponseWithFailure, ResponseWithSuccess } from "../../utils/response";
import { getPostsByFilter } from "./post.services";
import { AuthRequest } from "../location/location.controller";
import { addProductToShop, getShopById } from "../shop/shop.services";

export enum RESOURCE_TYPES {
  POST = 1,
  DISCOVERY = 2,
  COLLECTION = 3,
  EXPERIENCE = 4,
}

export const REVERSE_RESOURCE_TYPE_MAP = {
  1: "POST",
  2: "DISCOVERY",
  3: "COLLECTION",
  4: "EXPERIENCE",
};

export class PostController {
  static listAll = async (req: Request, res: Response) => {
    const filter = req.body || {};
    const posts = await getPostsByFilter(filter);
    res.json(ResponseWithSuccess({ posts }));
  };

  static getPostByID = async (req: Request, res: Response) => {
    try {
      const user = await db.post.findUnique({
        where: {
          postID: Number(req.params.id),
        },
      });
      if (user) {
        res.json(ResponseWithSuccess({ user }));
      } else {
        res.status(404).json(ResponseWithFailure({ message: "Not found" }));
      }
    } catch (error) {
      console.log(error);
      res.status(400).json(ResponseWithFailure({ message: error.message }));
    }
  };

  /**
   *
   * @param req {Request} - Express request object
   * @param res {Response} - Express response object
   * @returns {Promise<Response>} - Express response object
   * @description Create a new user
   * @example
   * POST /post
   * {
   *  "name": "John Doe",
   *  "email": "john@doe.com",
   * }
   *
   */
  static createNewPost = async (req: AuthRequest, res: Response) => {
    try {
      const body: any = req.body;
      const user = req.locals.user;
      const {
        newProduct,
        images = [],
        shopID,
        isNewProduct,
        isNewUserMeasurements,
        userMeasurements,
      } = body;

      let {
        resourceType,
        productID,
        userMeasurementId,
        postType = RESOURCE_TYPES.POST,
      } = body;

      const resourceTypeID = parseInt(RESOURCE_TYPES[resourceType]);

      if (!resourceTypeID) {
        return res.status(400).json(
          ResponseWithFailure({
            message: "Please select a valid resource type to create",
          })
        );
      }

      // if the product is new, then create a new product

      let shop = await getShopById(shopID);

      if (!shop) {
        return res.status(400).json(
          ResponseWithFailure({
            message: "Please create a shop before creating the product",
          })
        );
      }

      console.log("newProduct", newProduct);
      if (isNewProduct || !productID) {
        const product = await db.product.create({
          data: {
            brandName: newProduct.brandName,
            description: newProduct.description,
            productName: newProduct.name,
            price: Number(newProduct.price),
            quantity: Number(newProduct.quantity),
            weight: Number(newProduct.weight),
            authorID: user.profileID,
            // categoryId: Number(newProduct.categoryId),
            // subCategoryID: Number(newProduct.subCategory),
            published: true,
          },
        });
        productID = product.productID;
      }

      if (isNewUserMeasurements) {
        if (isNaN(userMeasurements.age)) {
          userMeasurementId = 0;
        } else {
          const userMeasurement = await db.userMeasurements.create({
            data: {
              authorID: user.profileID,
              age: Number(userMeasurements.age),
              name: userMeasurements.name,
              gender: userMeasurements.gender,
            },
          });
          userMeasurementId = userMeasurement.id;
        }
      }

      const resource = await db.resource.create({
        data: {
          authorID: user.profileID,
          shopID: shopID,
          productID: productID,
          resourceType: resourceTypeID,
          geohash: shop.geohash,
        },
      });

      addProductToShop({ shopID, productID });

      let response: any = {};

      // else, attach the post with product ID
      switch (postType) {
        case RESOURCE_TYPES.POST:
          response = await db.post.create({
            data: {
              body: newProduct.description,
              title: newProduct.title,
              rating: 0,
              userMeasurementId,
              published: true,
              resourceID: resource.resourceID,
            },
          });

          break;

        case RESOURCE_TYPES.DISCOVERY:
          response = await db.discovery.create({
            data: {
              description: newProduct.description,
              title: newProduct.title,
              rating: newProduct.rating,
              published: true,
              resourceID: resource.resourceID,
            },
          });

          break;

        case RESOURCE_TYPES.COLLECTION:
          response = await db.collection.create({
            data: {
              description: newProduct.description,
              title: newProduct.title,
              published: true,
              resourceID: resource.resourceID,
            },
          });

          break;

        case RESOURCE_TYPES.EXPERIENCE:
        // response = await db.post.create({
        //   data: {
        //     body: newProduct.description,
        //     title: newProduct.title,
        //     rating: 0,
        //     locationsId: shop.locationId,
        //     userMeasurementId,
        //     published: true,
        //   },
        // });

        // break;

        default:
          throw new Error("No valid postType");
      }

      // create images tags
      await db.resourceMedia.createMany({
        data: images.map((image: any) => {
          let isImage =
            String(image).endsWith("jpg") ||
            String(image).endsWith("jpeg") ||
            String(image).endsWith("png") ||
            String(image).endsWith("JPEG");
          return {
            mediaURL: image,
            mediaType: isImage ? "image" : "video",
            resourceID: resource.resourceID,
          };
        }),
      });

      res.json(ResponseWithSuccess(response));
    } catch (error) {
      console.log(error);
      res.status(400).json(ResponseWithFailure({ message: error.message }));
    }
  };

  static deletePost = async (req: AuthRequest, res: Response) => {
    const body: any = req.body;
    try {
      const userProfileID = req.locals.user.profileID;
      const { resourceID } = body;

      const resource = await db.resource.findFirstOrThrow({
        where: {
          resourceID,
        },
      });
      console.log("resource", resource);

      let post;
      switch (resource.resourceType) {
        case RESOURCE_TYPES.POST:
          post = await db.post.deleteMany({
            where: {
              resourceID: Number(resourceID),
            },
          });
          break;

        case RESOURCE_TYPES.EXPERIENCE:
          post = await db.post.deleteMany({
            where: {
              resourceID: Number(resourceID),
            },
          });
          break;

        case RESOURCE_TYPES.DISCOVERY:
          post = await db.post.deleteMany({
            where: {
              resourceID: Number(resourceID),
            },
          });
          break;

        case RESOURCE_TYPES.COLLECTION:
          post = await db.post.deleteMany({
            where: {
              resourceID: Number(resourceID),
            },
          });
          break;

        default:
          break;
      }

      // create images tags
      await db.resourceMedia.deleteMany({
        where: {
          resourceID: Number(resourceID),
        },
      });

      await db.resourceLikes.deleteMany({
        where: {
          resourceID: Number(resourceID),
        },
      });

      await db.resourcesTags.deleteMany({
        where: {
          resourceID: Number(resourceID),
        },
      });

      await db.resourceComments.deleteMany({
        where: {
          resourceID: Number(resourceID),
        },
      });

      await db.resourceCategories.deleteMany({
        where: {
          resourceID: Number(resourceID),
        },
      });

      await db.resource.deleteMany({
        where: {
          resourceID: Number(resourceID),
        },
      });

      console.log(post);

      res.json(ResponseWithSuccess(post));
    } catch (error) {
      console.log(error, body);
      res.status(400).json(ResponseWithFailure({ message: error.message }));
    }
  };

  static likePost = async (req: AuthRequest, res: Response) => {
    try {
      const profileID = req.locals.user.profileID;
      if (!req.body.postID) {
        return res
          .status(500)
          .json(ResponseWithFailure({ message: "Invalid Post ID" }));
      }

      const alreadyLiked = await db.resourceLikes.findMany({
        where: {
          resourceID: req.body.postID,
          userProfileID: profileID,
        },
      });

      if (alreadyLiked.length > 0) {
        return res.json(ResponseWithSuccess({ message: "You liked a post!" }));
      }

      const liked = await db.resourceLikes.create({
        data: {
          resourceID: req.body.postID,
          userProfileID: profileID,
        },
      });

      if (liked) {
        res.json(ResponseWithSuccess({ message: "You liked a post!" }));
      } else {
        res.status(404).json(ResponseWithFailure({ message: "Not found" }));
      }
    } catch (error) {
      console.log(error);
      res.status(400).json(ResponseWithFailure({ message: error.message }));
    }
  };

  static dislikePost = async (req: AuthRequest, res: Response) => {
    try {
      const userProfileID = req.locals.user.profileID;

      if (!req.body.postID) {
        return res
          .status(500)
          .json(ResponseWithFailure({ message: "Invalid Post ID" }));
      }

      const unliked = await db.resourceLikes.deleteMany({
        where: {
          resourceID: req.body.postID,
          userProfileID: userProfileID,
        },
      });

      console.log("unliked", req.body.postID, userProfileID);

      if (unliked) {
        res.json(ResponseWithSuccess({ message: "You disliked a post!" }));
      } else {
        res.status(404).json(ResponseWithFailure({ message: "Not found" }));
      }
    } catch (error) {
      console.log(error);
      res.status(400).json(ResponseWithFailure({ message: error.message }));
    }
  };
}
