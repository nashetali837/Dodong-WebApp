import { Router } from "express";
import {
  isUserLoggedIn,
  optionalLoggedIn,
} from "../../middleware/authentication";
import * as ProductController from "./product.controller";

const router = Router();

// Get posts
router.get("/search", ProductController.filterProducts);

router.post("/create", isUserLoggedIn, ProductController.createProduct);

router.get("/", optionalLoggedIn, ProductController.getProduct);

router.post("/update", isUserLoggedIn, ProductController.updateProduct);

router.post("/similar-products", isUserLoggedIn, ProductController.similarProducts);

router.post(
  "/price-compare",
  isUserLoggedIn,
  ProductController.similarProducts
);

router.post(
  "/user-products",
  isUserLoggedIn,
  ProductController.similarProducts
);

router.post(
  "/wishlist/add",
  isUserLoggedIn,
  ProductController.addProductToWishlist
);

router.post(
  "/wishlist/remove",
  isUserLoggedIn,
  ProductController.removeProductFromWishlist
);

router.get(
  "/wishlist/list",
  isUserLoggedIn,
  ProductController.listUserWishlist
);

export default router;
