import db from "../../database";

const PRODUCTS_PER_PAGE = 10;

// get filtered shops
export const filterProductsBy = async (query: string) => {
  try {
    const products = await db.product.findMany({
      where: {
        OR: [
          {
            productName: {
              contains: query || "",
              mode: "insensitive",
            },
          },

          {
            brandName: {
              contains: query || "",
              mode: "insensitive",
            },
          },

          {
            description: {
              contains: query || "",
              mode: "insensitive",
            },
          },
        ],
      },
      take: PRODUCTS_PER_PAGE,
    });

    if (products) {
      return products;
    }

    return null;
  } catch (error) {
    console.log(error);
    return null;
  }
};

export const searchForProduct = async (data: any) => {
  try {
    const shop = await db.product.findMany({
      where: {},
    });
    if (shop) {
      return shop;
    }
    return null;
  } catch (error) {
    console.log(error);
    return null;
  }
};

// create shop
export const createNewProduct = async (data: any) => {
  try {
    console.log("data", data);
    const shop = await db.product.create({
      data: { ...data },
    });
    if (shop) {
      return shop;
    }
    return null;
  } catch (error) {
    console.log(error);
    return null;
  }
};

export const getProductByID = async (id: string, userProfileID?: number) => {
  try {
    const product = await db.product.findFirst({
      where: {
        productID: Number(id),
      },
      include: {
        author: {
          select: {
            userProfileID: true,
            avatar: true,
            displayName: true,
            name: true,
          },
        },
        shop: true,
      },
    });

    let addedToWishlist = false;

    if (userProfileID) {
      addedToWishlist = await checkProductAddedInWishlist(
        product.productID,
        userProfileID
      );
    }

    let resourceByProductID = await db.resource.findFirst({
      where: {
        productID: product.productID,
      },
      include: {
        ResourceMedia: true,
      },
    });

    const mediaURLs = resourceByProductID.ResourceMedia;

    let completeProduct = { ...product, shop: {}, mediaURLs, addedToWishlist };
    if (!product.shop) {
      completeProduct.shop = {
        id: 7,
        name: "Poster Collection",
        address: "Gachibowli, Hyderabad, Telangana, India",
        contact: "9911223344",
        email: "amruthk99@gmail.com",
        website: "https://google.com",
        bio: "qwertt",
        createdAt: "2023-08-12T10:37:11.923Z",
        updatedAt: "2023-08-12T10:37:11.923Z",
        locationId: 30,
        categoryId: 4,
        subCategoryID: 4,
      };
    }
    return completeProduct;
  } catch (error) {
    console.log(error);
    return null;
  }
};

export const updateProductDetails = async (id: number, data: any) => {
  try {
    const user = await db.product.update({
      where: {
        productID: id,
      },
      data: { ...data },
    });
    return user;
  } catch (error) {
    console.log(error);
    return null;
  }
};

// get filtered shops
export const getSimilarProducts = async ({
  productID,
  productName,
}: {
  productID: number;
  productName?: string;
}) => {
  try {
    const products = await db.product.findMany({
      where: {
        productName: {
          contains: productName,
        },
      },
      take: PRODUCTS_PER_PAGE,
    });

    if (products) {
      return products;
    }

    return [];
  } catch (error) {
    console.log(error);
    return [];
  }
};

// create product wishlist
export const addProductToUserWishlist = async (data: {
  userProfileID: number;
  productID: number;
}) => {
  try {
    const shop = await db.productWishlist.create({
      data: {
        userProfileID: data.userProfileID,
        productID: data.productID,
      },
    });
    if (shop) {
      return shop;
    }
    return null;
  } catch (error) {
    console.log(error);
    return null;
  }
};

// create product wishlist
export const removeProductFromProductWishlist = async (data: {
  userProfileID: number;
  productID: number;
}) => {
  try {
    const shop = await db.productWishlist.deleteMany({
      where: {
        userProfileID: data.userProfileID,
        productID: data.productID,
      },
    });
    if (shop) {
      return shop;
    }
    return null;
  } catch (error) {
    console.log(error);
    return null;
  }
};

// create product wishlist
export const getUserProductWishlist = async (userProfileID: number) => {
  try {
    const shop = await db.productWishlist.findMany({
      where: {
        userProfileID: userProfileID,
      },
      include: {
        product: true,
      },
    });
    if (shop) {
      return shop;
    }
    return null;
  } catch (error) {
    console.log(error);
    return null;
  }
};

// check product is in wishlist
export const checkProductAddedInWishlist = async (
  productID: number,
  userProfileID: number
) => {
  try {
    const exits = await db.productWishlist.count({
      where: {
        userProfileID: userProfileID,
        productID: productID,
      },
    });
    console.log(
      "[checkProductAddedInWishlist] exits",
      userProfileID,
      productID,
      exits
    );
    if (exits === 0) {
      return false;
    }
    return true;
  } catch (error) {
    console.log(error);
    return false;
  }
};
