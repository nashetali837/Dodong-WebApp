import { Request, Response } from "express";
import { Product, Shop } from "@prisma/client";
import { ResponseWithFailure, ResponseWithSuccess } from "../../utils/response";
import {
  addProductToUserWishlist,
  createNewProduct,
  filterProductsBy,
  getProductByID,
  getSimilarProducts,
  getUserProductWishlist,
  removeProductFromProductWishlist,
  updateProductDetails,
} from "./product.services";
import { AuthRequest } from "../location/location.controller";

export const filterProducts = async (req: Request, res: Response) => {
  const { query }: any = req.query;
  // if (!query) {
  //   return res
  //     .status(400)
  //     .json(ResponseWithFailure({ message: "`query` parameter is missing" }));
  // }
  const products: Product[] = await filterProductsBy(query);

  res.json(ResponseWithSuccess({ products }));
};

export const createProduct = async (req: Request, res: Response) => {
  try {
    const body: any = req.body;

    const product = await createNewProduct(body);
    console.log("New product created: ", product);
    return res.json(ResponseWithSuccess({ product }));
  } catch (error) {
    console.log(error);
    res.status(400).json(ResponseWithFailure({ message: error.message }));
  }
};

export const getProduct = async (req: AuthRequest, res: Response) => {
  try {
    const id: any = req.query.productID;
    const userProfileID = req.locals?.user?.profileID;

    const product = await getProductByID(id, userProfileID);

    if (product) {
      return res.json(ResponseWithSuccess({ product }));
    }

    res.status(404).json(ResponseWithFailure({ message: "Not found" }));
  } catch (error) {
    res.status(400).json(ResponseWithFailure({ message: error.message }));
  }
};

export const updateProduct = async (req: Request, res: Response) => {
  try {
    const body: any = req.body;

    const updatedProduct = await updateProductDetails(body.id, body);

    return res.json(ResponseWithSuccess({ product: updatedProduct }));
  } catch (error) {
    res.status(400).json(ResponseWithFailure({ message: error.message }));
  }
};

export const similarProducts = async (req: Request, res: Response) => {
  try {
    const body: any = req.body;

    const products = await getSimilarProducts({
      productID: body.productID,
      productName: body.productName,
    });

    return res.json(ResponseWithSuccess({ similarProducts: products }));
  } catch (error) {
    res.status(400).json(ResponseWithFailure({ message: error.message }));
  }
};

export const addProductToWishlist = async (req: AuthRequest, res: Response) => {
  try {
    const body: any = req.body;
    const userProfileID = req.locals.user?.profileID;

    await addProductToUserWishlist({
      productID: body.productID,
      userProfileID,
    });

    return res.json(
      ResponseWithSuccess({ message: "Product added to Wishlist" })
    );
  } catch (error) {
    res.status(400).json(ResponseWithFailure({ message: error.message }));
  }
};

export const removeProductFromWishlist = async (
  req: AuthRequest,
  res: Response
) => {
  try {
    const body: any = req.body;
    const userProfileID = req.locals.user?.profileID;

    await removeProductFromProductWishlist({
      productID: body.productID,
      userProfileID,
    });

    return res.json(
      ResponseWithSuccess({ message: "Product removed to Wishlist" })
    );
  } catch (error) {
    res.status(400).json(ResponseWithFailure({ message: error.message }));
  }
};

export const listUserWishlist = async (req: AuthRequest, res: Response) => {
  try {
    const userProfileID = req.locals.user?.profileID;

    const products = await getUserProductWishlist(userProfileID);

    return res.json(ResponseWithSuccess({ wishlistProducts: products }));
  } catch (error) {
    res.status(400).json(ResponseWithFailure({ message: error.message }));
  }
};
