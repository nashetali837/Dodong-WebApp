import { Request, Response } from "express";
import { ResponseWithFailure, ResponseWithSuccess } from "../../utils/response";

import { fetchTrendingPosts } from "../post/post.services";
import { getShopsByFilter } from "../shop/shop.services";

export const fetchStorefront = async (req: Request, res: Response) => {
  try {
    const parameters: any = req.query;
    console.log(parameters);
    const page = isNaN(parameters.page) ? 1 : parseInt(parameters.page);
    const type = parameters.type ? parameters.type : "POST";

    const response = {
      resources: [],
      page,
      totalPosts: 0,
    };

    console.log("-- Page:", isNaN(parameters.page), parseInt(parameters.page));
    // fetch trending posts from a db
    const trendingPosts = await fetchTrendingPosts(page, type);

    response.resources = trendingPosts;
    response.totalPosts = trendingPosts.length;

    res.json(ResponseWithSuccess(response));
  } catch (error) {
    res.status(400).json(ResponseWithFailure({ message: error.message }));
  }
};
