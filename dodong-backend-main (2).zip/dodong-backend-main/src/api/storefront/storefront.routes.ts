import { Router } from "express";
import * as Storefront from "./storefront.controller";

const router = Router();

// Get posts
router.get("/", Storefront.fetchStorefront);

export default router;
