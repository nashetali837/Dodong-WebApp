import axios from "axios";
import { OAuth2Client } from "google-auth-library";
const client = new OAuth2Client(process.env.GOOGLE_CLIENT_ID as string);

export const validateGoogleToken = async (tokenId: string) => {
  try {
    const ticket = await client.verifyIdToken({
      idToken: tokenId,
      audience: process.env.GOOGLE_CLIENT_ID as string,
    });
    const payload = ticket.getPayload();
    const userid = payload?.sub;
    const response = userid ? true : false;

    if (response) {
      return payload;
    }
    return false;
  } catch (error) {
    console.log(error);
    return false;
  }
};

export const validateFacebookToken = async (userToken) => {
  // https://developers.facebook.com/docs/facebook-login/guides/advanced/manual-flow#checktoken

  // check if the user token is valid
  // if valid, check the user_id matched to our database
  // create the user if that user doesn't exist
  // else, create an auth_token and send it to the user
  const FB_SECRET = "1b47dbd0bcf71d4902e0cba265e09215";
  const FB_ACCESS_TOKEN = "724627192289395|z9s191vSubp8cVDArYM9qfusTXs";
  try {
    let response = { email: "", name: "", picture: "", email_verified: true };

    // const fbResponse = await axios.get(
    //   `https://graph.facebook.com/v10.0/me?fields=id,name,email&access_token=${userToken}`
    // );

    // from admin
    const fbResponse = await axios
      .get(
        `https://graph.facebook.com/debug_token?input_token=${userToken}&access_token=${FB_ACCESS_TOKEN}`
      )
      .catch((err) => {
        return { data: { data: { error: err.message } } };
      });

    console.log("fbResponse=> ", fbResponse?.data?.data);
    // error handling
    if (fbResponse?.data?.data?.error) {
      console.log(fbResponse?.data?.error);
      return false;
    }

    response.name = fbResponse.data.name;
    response.email = fbResponse.data.id;

    return response;
  } catch (error) {
    return false;
  }
};

export const loginWithFacebookController = async (userToken) => {
  // https://developers.facebook.com/docs/facebook-login/guides/advanced/manual-flow#checktoken

  // check if the user token is valid
  // if valid, check the user_id matched to our database
  // create the user if that user doesn't exist
  // else, create an auth_token and send it to the user
  const FB_SECRET = "1b47dbd0bcf71d4902e0cba265e09215";
  const FB_ACCESS_TOKEN = "724627192289395|z9s191vSubp8cVDArYM9qfusTXs";
  const FB_APP_ID = "724627192289395";

  try {
    let response = { email: "", name: "", picture: "", email_verified: true };

    console.log("userToken=> ", userToken);
    // get access token
    const fbResponse = await axios
      .get(
        `https://graph.facebook.com/v18.0/oauth/access_token?client_id=${FB_APP_ID}&client_secret=${FB_ACCESS_TOKEN}&grant_type=client_credentials&redirect_uri=https://localhost:3000/&code=1234`
      )
      .catch((err) => {
        return { data: { data: { error: err.message } } };
      });

    console.log("fbResponse login=> ", fbResponse.data.data);
    // error handling
    if (fbResponse?.data?.data?.error) {
      console.log(fbResponse.data.error);
      return false;
    }

    response.name = fbResponse.data.name;
    response.email = fbResponse.data.id;

    return response;
  } catch (error) {
    return false;
  }
};
