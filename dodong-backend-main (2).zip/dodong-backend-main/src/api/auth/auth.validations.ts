// validate registerUser and login functions with express-validator
import { Request, Response, NextFunction } from "express";
import { check, validationResult } from "express-validator";
import { ResponseWithFailure } from "../../utils/response";

export const loginValidator = [
  check("email", "Please enter a valid email").isEmail(),
  check("password", "Password is required").trim().exists(),
  (req: Request, res: Response, next: NextFunction) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ errors: errors.array() });
    }
    next();
  },
];

export const emailValidator = [
  check("email", "Please enter a valid email").isEmail().notEmpty(),
  (req: Request, res: Response, next: NextFunction) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ errors: errors.array() });
    }
    next();
  },
];

export const registerUserValidator = [
  check("name", "Name is required").trim().not().isEmpty(),
  check("email", "Please enter a valid email")
    .trim()
    .isEmail()
    .escape()
    .normalizeEmail(),
  check("mobileNumber", "Please enter a 10-digit mobile number")
    .trim()
    .isLength({
      min: 10,
      max: 10,
    }),
  check(
    "password",
    "Please enter a password with 6 or more characters"
  ).isLength({ min: 6 }),
  (req: Request, res: Response, next: NextFunction) => {
    const errors = validationResult(req);

    if (!errors.isEmpty()) {
      return res
        .status(400)
        .json(ResponseWithFailure({ errors: errors.array() }));
    }
    if (isNaN(req.body.mobileNumber)) {
      return res
        .status(400)
        .json(
          ResponseWithFailure({ errors: [{ msg: "Mobile number is invalid" }] })
        );
    }
    next();
  },
];
