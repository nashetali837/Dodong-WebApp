import { Request, Response } from "express";
import { ResponseWithFailure, ResponseWithSuccess } from "../../utils/response";
import * as UserService from "../user/user.services";
import ERRORS from "../../utils/errors";
import {
  loginWithFacebookController,
  validateFacebookToken,
  validateGoogleToken,
} from "./SocialAuthController";
import { Profile, User } from "@prisma/client";
import moment from "moment";
import { AuthRequest } from "../location/location.controller";
import { sendCodeToEmail } from "../../services/email";

/**
 * @param req {Request} - Express request object
 * @param res {Response} - Express response object
 * @returns {Promise<Response>} - Express response object
 * @description Register a new user
 * @example
 * POST /auth/register
 * {
 * "name": "John Doe",
 * "email": "john@gmail.com",
 * "password": "password",
 * "mobileNumber": "08012345678"
 * }
 *
 * */
export const registerUser = async (req: AuthRequest, res: Response) => {
  try {
    // inputs sanitized by express-validator
    let { email, profileID, id, mobileNumber } = req.locals.user;
    const { name, password } = req.body;

    console.log("req.locals.user", req.locals.user);
    // check if user exists
    const user = await UserService.getUserByEmailOrMobile({
      email,
      mobileNumber,
    });

    if (!user) {
      return res
        .status(400)

        .json(
          ResponseWithFailure({
            message: "Please verify your email",
            name,
          })
        );
    }

    // hash password
    const hashedPassword = await UserService.hashPassword(password);

    // create user
    let updatedUser: any = await UserService.updateUser(id, {
      password: hashedPassword,
      mobileNumber,
    });

    if (!updatedUser) {
      return res.status(400).json(
        ResponseWithFailure({
          message: ERRORS.SOMETHING_WENT_WRONG_PLEASE_TRY_AGAIN,
          name,
        })
      );
    }

    const profile = await UserService.updateProfileByUserId(id, {
      name: name,
      displayName: name,
    });

    // generate token
    const token = await UserService.generateToken({
      ...updatedUser,
      profileID: profile.userProfileID,
    });

    if (!token) {
      return res.status(400).json(
        ResponseWithFailure({
          message: ERRORS.SOMETHING_WENT_WRONG_PLEASE_TRY_AGAIN,
        })
      );
    }

    return res.json(
      ResponseWithSuccess({
        message: "Welcome! User registration was successful!",
        token,
        ...updatedUser,
        password: undefined,
        OTP: undefined,
        OTPExpiry: undefined,
      })
    );

    // send email verification link
  } catch (error) {
    console.log(error);
    res.status(400).json(ResponseWithFailure({ message: error.message }));
  }
};

export const loginUser = async (req: Request, res: Response) => {
  try {
    // sanitize inputs
    const { email, password } = req.body;

    // validate inputs

    // check if user exists
    const user = await UserService.getUserByEmailOrMobile({
      email,
    });

    console.log('user', user);
    if (!user) {
      return res.status(404).json(
        ResponseWithFailure({
          message: "Incorrect email or password",
        })
      );
    }

    const profile = await UserService.getProfileByUserId(user.id);

    // check if password is correct
    const isPasswordCorrect = await UserService.comparePassword(
      password,
      user.password
    );

    if (!isPasswordCorrect) {
      return res.status(400).json(
        ResponseWithFailure({
          message: "Incorrect password",
        })
      );
    }

    // generate token
    const token = await UserService.generateToken({
      ...user,
      profileID: profile.userProfileID,
    });

    if (!token) {
      return res.status(400).json(
        ResponseWithFailure({
          message: ERRORS.SOMETHING_WENT_WRONG_PLEASE_TRY_AGAIN,
        })
      );
    }

    // send response
    res.json(
      ResponseWithSuccess({
        message: "Login successful",
        token,
        ...user,
        password: undefined,
        OTP: undefined,
        OTPExpiry: undefined,
      })
    );
  } catch (error) {
    console.log(error);
    res.status(400).json(ResponseWithFailure({ message: error.message }));
  }
};

export const SendOTP_ToEmail = async (req: Request, res: Response) => {
  try {
    // sanitize inputs
    const { email, mobileNumber } = req.body;

    // validate inputs
    if (!email || !mobileNumber) {
      return res.status(400).json(
        ResponseWithFailure({
          message: "Please enter correct mobile number and email",
        })
      );
    }

    // check if user exists
    let user: any = await UserService.getUserByEmailOrMobile({
      email,
      mobileNumber: "",
    });

    if (!user) {
      // create user
      user = await UserService.createUser({
        name: "User",
        email,
        emailVerified: false,
        password: "DEFAULT_STRING",
        mobileNumber: mobileNumber,
      }).then((res) => res.user);
    }

    console.log("==> user", user);

    if (user.emailVerified) {
      // send response
      return res.status(200).json(
        ResponseWithFailure({
          message: "You are already a user, please try to login",
          data: {
            alreadyUser: true,
          },
        })
      );
    }

    // generate generate OTP
    let OTP = await generateOTP();

    let updates = {
      OTP: user.OTP
        ? moment().valueOf() > moment(user.OTPExpiry).valueOf()
          ? OTP
          : user.OTP
        : OTP,

      OTPExpiry: moment().add(5, "minutes").toDate(),
    };

    await UserService.updateUser(user.id, updates);

    // sends email
    await sendCodeToEmail(user.email, updates.OTP);

    await UserService.updateUser(user.id, updates);

    // send response
    res.json(
      ResponseWithSuccess({
        message: "Email verification link sent",
        data: {
          ...{ ...user, password: undefined, OTP: updates.OTP },
        },
      })
    );
  } catch (error) {
    console.log(error);
    res.status(400).json(ResponseWithFailure({ message: error.message }));
  }
};

export const forgotPassword = async (req: Request, res: Response) => {
  try {
    // sanitize inputs
    const { email } = req.body;

    // validate inputs

    // check if user exists
    const user = await UserService.getUserByEmailOrMobile({
      email,
      mobileNumber: "",
    });

    if (!user) {
      return res.status(404).json(
        ResponseWithFailure({
          message: "Uh oh! User not found",
        })
      );
    }

    // generate generate OTP
    let OTP = await generateOTP();

    let updates = {
      OTP: user.OTP
        ? moment().valueOf() > moment(user.OTPExpiry).valueOf()
          ? OTP
          : user.OTP
        : OTP,

      OTPExpiry: moment().add(5, "minutes").toDate(),
    };

    await UserService.updateUser(user.id, updates);

    // Send email via SES

    let email_content = {
      subject: `Email Verification from DoDong India`,
      user_email: email,
      from_address: "tech@dodong.in",
      to_address: email,
      message: `Hi ${user.email},
              <p>
            Your OTP for email verification TO <b>change password</b> is :  </p><p>
               <h2>${updates.OTP}</h2>
              </p>
              <p>
              Thank you,<br>
              Team DoDong</p>`,
    };

    // sends email
    await sendCodeToEmail(email_content.to_address, updates.OTP);

    // send response
    res.json(
      ResponseWithSuccess({
        message:
          "An OTP has been sent to your email. Please enter the OTP to reset your password. OTP expires in 5 minutes",
        data: {
          OTP: updates.OTP,
          email,
        },
      })
    );
  } catch (error) {
    console.log(error);
    res.status(400).json(ResponseWithFailure({ message: error.message }));
  }
};

export const VerifyEmailOTP = async (req: Request, res: Response) => {
  try {
    // sanitize inputs
    const { email, OTP, forgotPassword } = req.body;

    if (isNaN(OTP)) {
      return res.status(500).json(
        ResponseWithFailure({
          message: "Invalid OTP sent",
        })
      );
    }

    // validate inputs

    // check if user exists
    const user = await UserService.getUserByEmailOrMobile({
      email,
      mobileNumber: "",
    });
    console.log("user", user);

    if (!user) {
      return res.status(404).json(
        ResponseWithFailure({
          message: "Uh oh! User not found",
        })
      );
    }

    if (!forgotPassword) {
      if (user.emailVerified) {
        return res.json(
          ResponseWithSuccess({
            message:
              "Your email is already verified. Please complete your profile",
            data: {},
          })
        );
      }
    }

    const profile = await UserService.getProfileByUserId(user.id);

    console.log("profile", profile);

    if (!profile) {
      return res.status(404).json(
        ResponseWithFailure({
          message: "Uh oh! User not found. Please register to continue",
        })
      );
    }

    if (moment().valueOf() > moment(user.OTPExpiry).valueOf()) {
      return res.status(403).json(
        ResponseWithFailure({
          message: "OTP expired. Please resend verification request again.",
        })
      );
    }

    let isOTPMatched = user.OTP === OTP;

    if (!isOTPMatched) {
      return res.status(200).json(
        ResponseWithFailure({
          message: "Please enter the correct OTP.",
        })
      );
    }

    // generate token
    const expiresIn = "5m";
    const temporaryToken = await UserService.generateToken(
      { ...user, profileID: profile.userProfileID },
      expiresIn,
      true
    );

    await UserService.updateUser(user.id, {
      emailVerified: true,
      socialLogin: "email",
    });

    let message =
      "Successfully verified your email. Please enter the details to get started!";
    if (forgotPassword) {
      message =
        "Successfully verified your email. Please enter change your password in the next 5 minutes.";
    }

    // send response
    return res.json(
      ResponseWithSuccess({
        message: message,
        data: {
          temporaryToken,
          expiresIn,
        },
      })
    );
  } catch (error) {
    console.log(error);
    res.status(400).json(ResponseWithFailure({ message: error.message }));
  }
};

export const resetPassword = async (req: AuthRequest, res: Response) => {
  try {
    // sanitize inputs
    const { email, confirmPassword } = req.body;
    const loggedUser = req.locals.user;

    console.log("loggedUser", loggedUser);

    // validate inputs

    if (loggedUser && !loggedUser?.resetPassword) {
      return res.status(404).json(
        ResponseWithFailure({
          message: "Uh oh! User not found",
        })
      );
    }

    // check if user exists
    const user = await UserService.getUserByEmailOrMobile({
      email,
      mobileNumber: "",
    });

    if (!user) {
      return res.status(404).json(
        ResponseWithFailure({
          message: "Uh oh! User not found",
        })
      );
    }

    // hash password
    const hashedPassword = await UserService.hashPassword(confirmPassword);

    // update user
    const updatedUser = await UserService.updateUser(user.id, {
      password: hashedPassword,
    });

    if (!updatedUser) {
      return res.status(400).json(
        ResponseWithFailure({
          message: ERRORS.SOMETHING_WENT_WRONG_PLEASE_TRY_AGAIN,
        })
      );
    }

    // send response
    res.json(
      ResponseWithSuccess({
        message: "Password reset successful",
        data: {
          ...{ ...updatedUser, password: undefined },
        },
      })
    );
  } catch (error) {
    console.log(error);
    res.status(400).json(ResponseWithFailure({ message: error.message }));
  }
};

export const loginWithGoogle = async (req: Request, res: Response) => {
  try {
    // sanitize inputs
    const { tokenId } = req.body;

    // validate google token
    const response = await validateGoogleToken(tokenId);

    if (!response) {
      return res.status(400).json(
        ResponseWithFailure({
          message: "Invalid google token",
        })
      );
    }

    const { email, name, picture, email_verified } = response;
    // validate inputs

    // check if user exists
    let user: any = await UserService.getUserByEmailOrMobile({
      email,
      mobileNumber: "",
    });

    let profile: Profile;

    if (!user) {
      // create user
      // @ts-ignore TODO: fix this
      user = await UserService.createUser({
        name,
        email,
        avatar: picture,
        emailVerified: email_verified,
        password: "",
        mobileNumber: "",
        socialLogin: "google",
      });

      if (!user) {
        return res.status(400).json(
          ResponseWithFailure({
            message: ERRORS.SOMETHING_WENT_WRONG_PLEASE_TRY_AGAIN,
            name,
          })
        );
      }

      profile = user.profile;
    } else {
      profile = await UserService.getProfileByUserId(user.id);
    }

    let userHash = {
      ...user,
      profile: undefined,
      profileID: profile.userProfileID,
    };

    // generate token
    const token = await UserService.generateToken(userHash);

    if (!token) {
      return res.status(400).json(
        ResponseWithFailure({
          message: ERRORS.SOMETHING_WENT_WRONG_PLEASE_TRY_AGAIN,
        })
      );
    }

    // send response
    res.json(
      ResponseWithSuccess({
        message: "Login Successful",
        token,
        user: { ...user, password: undefined },
      })
    );
  } catch (error) {
    console.log(error);
    res.status(400).json(ResponseWithFailure({ message: error.message }));
  }
};

export const loginWithFacebook = async (req: Request, res: Response) => {
  try {
    // sanitize inputs
    const { tokenId } = req.body;

    // validate google token
    const response = await validateFacebookToken(tokenId);

    if (!response) {
      return res.status(400).json(
        ResponseWithFailure({
          message: "Invalid Facebook access token",
        })
      );
    }

    const { email, name, picture, email_verified } = response;
    // validate inputs

    // check if user exists
    let user: User | any = await UserService.getUserByEmailOrMobile({
      email,
    });

    let profile: Profile;

    if (!user) {
      // create user
      // @ts-ignore TODO: fix this
      user = await UserService.createUser({
        name,
        email,
        avatar: picture,
        emailVerified: email_verified,
        password: "",
        mobileNumber: "",
        socialLogin: "facebook",
      });

      if (!user) {
        return res.status(400).json(
          ResponseWithFailure({
            message: ERRORS.SOMETHING_WENT_WRONG_PLEASE_TRY_AGAIN,
            name,
          })
        );
      }
      profile = user.profile;
    } else {
      profile = await UserService.getProfileByUserId(user.id);
    }

    let userHash = {
      ...user,
      profile: undefined,
      profileID: profile.userProfileID,
    };
    // generate token
    const token = await UserService.generateToken(userHash);

    if (!token) {
      return res.status(400).json(
        ResponseWithFailure({
          message: ERRORS.SOMETHING_WENT_WRONG_PLEASE_TRY_AGAIN,
        })
      );
    }

    // send response
    res.json(
      ResponseWithSuccess({
        message: "Login Successful",
        token,
        user: { ...user, password: undefined },
      })
    );
  } catch (error) {
    console.log(error);
    res.status(400).json(ResponseWithFailure({ message: error.message }));
  }
};

export const loginWithFacebookTest = async (req: Request, res: Response) => {
  try {
    let fbToken = "";

    let fbResponse = await loginWithFacebookController(fbToken);

    if (!fbResponse) {
      return res.status(400).json(
        ResponseWithFailure({
          message: "Invalid Facebook access token",
        })
      );
    }

    return res.json(
      ResponseWithSuccess({
        message: "Login Successful",
        data: fbResponse,
      })
    );
  } catch (error) {
    res.status(400).json(ResponseWithFailure({ message: error.message }));
  }
};

const generateOTP = async (length = 4) => {
  let leastValue = Math.pow(10, length);

  let OTP = Math.floor(Math.random() * leastValue).toString();
  console.log("First OTP", leastValue, OTP, OTP.length);

  if (OTP.length === length) {
    return OTP;
  }
  while (OTP.length !== length) {
    OTP = "0" + OTP;
    console.log("OTP", OTP);
  }
  return OTP;
};
