# Usage

This is a basics of how authentication will work

## Before login

When user registers, the data should be validated and saved into the database. 


Check if the user's account is `verified`

Initially it will be `false`, therefore, he will be given a temporary token that expires in 5 minutes. In the 5 minutes, he must send a verify-otp API to verify his email.

Once the Email is verified, he will be given an access token that lasts 15 days


## Login Flow

When the user hits Login API
 - Check if the user exists, if not, throw error
 - Check if the password is correct, if not, throw error
 - Check if the user's email is verified, if not, send a prompt that email not verified, please verify your email
 - Return access token if everything is successful
