import { Router } from "express";
import { isUserLoggedIn } from "../../middleware/authentication";
import * as Controller from "./auth.controller";
import { loginValidator, emailValidator } from "./auth.validations";

const router = Router();

router.post("/login", loginValidator, Controller.loginUser);

router.post("/register", isUserLoggedIn, Controller.registerUser);

router.post("/google", Controller.loginWithGoogle);

router.post("/facebook", Controller.loginWithFacebook);

router.post("/facebook-login", Controller.loginWithFacebookTest);

router.post("/forgot-password", Controller.forgotPassword);

router.post("/verify-email", emailValidator, Controller.SendOTP_ToEmail);

router.post("/verify-otp", Controller.VerifyEmailOTP);

router.post("/reset-password", isUserLoggedIn, Controller.resetPassword);

export default router;
