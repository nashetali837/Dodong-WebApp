import { Router } from "express";
import { isUserLoggedIn } from "../../middleware/authentication";
import { CommentsController } from "./comments.controller";

const router = Router();

// Get all comments for a post
router.get("/get", CommentsController.fetchCommentsForPost);

router.post("/add", isUserLoggedIn, CommentsController.addCommentToPost);

router.post("/update", isUserLoggedIn, CommentsController.updateCommentToPost);

router.delete("/delete", isUserLoggedIn, CommentsController.deleteComment);

export default router;
