import { Request, Response } from "express";
import db from "../../database";
import { ResourceComments } from "@prisma/client";
import { ResponseWithFailure, ResponseWithSuccess } from "../../utils/response";
import { AuthRequest } from "../location/location.controller";
import {
  NotificationType,
  createSilentNotification,
} from "../notifications/notification.services";

const PER_PAGE = 10;

export class CommentsController {
  static fetchCommentsForPost = async (req: Request, res: Response) => {
    let { postID, page }: any = req.query;
    if (isNaN(page)) {
      page = 1;
    }
    if (!postID) {
      return res.status(400).json(
        ResponseWithFailure({
          error: "No PostID found",
        })
      );
    }

    const comments: ResourceComments[] = await db.resourceComments.findMany({
      where: {
        resourceID: Number(postID),
      },
      include: {
        profile: {
          select: {
            name: true,
            displayName: true,
            userProfileID: true,
          },
        },
        // select: {
        //   body: true,
        //   authorId: true,
        // },
      },
      skip: (page - 1) * PER_PAGE,
      take: PER_PAGE,
    });

    res.json(ResponseWithSuccess({ comments }));
  };

  static addCommentToPost = async (req: AuthRequest, res: Response) => {
    try {
      const profileID = req.locals.user.profileID;
      const { commentBody, resourceID } = req.body;
      console.log(`Adding comment: ${commentBody} to ${resourceID}`, profileID);

      if (!resourceID) {
        return res.status(400).json(
          ResponseWithFailure({
            error: "Please enter a resourceID",
          })
        );
      }

      const comment = await db.resourceComments.create({
        data: {
          body: commentBody,
          resourceID: parseInt(resourceID),
          userProfileID: profileID,
          commentID: Math.floor(Math.random() * 1000000000),
        },
        include: {
          profile: {
            select: {
              name: true,
              displayName: true,
              userProfileID: true,
            },
          },
          resource: {
            select: {
              authorID: true,
            },
          },
        },
      });

      // fetch user by ID

      console.log("comment", comment.resource.authorID);

      if (comment.resource.authorID !== profileID) {
        // send notification to user
        createSilentNotification(
          NotificationType.NEW_COMMENT,
          {
            // authorId: profileID,
            userProfileID: comment.resource.authorID,
            userName: "",
          },
          {
            resourceID,
            commenterProfileID: profileID,
            commenterName: comment.profile.displayName,
            commentID: comment.commentID,
            comment: comment.body,
          }
        );
      }

      res.json(
        ResponseWithSuccess({
          message: "Added the comment successfully",
        })
      );
    } catch (error) {
      console.log(error);
      res.status(500).json(
        ResponseWithFailure({
          error: "Something went wrong",
        })
      );
    }
  };

  static updateCommentToPost = async (req: AuthRequest, res: Response) => {
    try {
      const profileID = req.locals.user.profileID;
      const { commentBody, commentID } = req.body;
      console.log(`Updating comment: ${commentBody} to ${commentID}`);

      if (!commentID) {
        return res.status(400).json(
          ResponseWithFailure({
            error: "Please enter a comment ID",
          })
        );
      }

      const comment = await db.resourceComments.update({
        where: {
          commentID,
        },
        data: {
          body: commentBody,
        },
      });

      // fetch user by ID

      console.log("updated comment", comment);
      res.json(
        ResponseWithSuccess({
          message: "Comment updated successfully",
        })
      );
    } catch (error) {
      console.log(error);
      res.status(500).json(
        ResponseWithFailure({
          error: "Something went wrong",
        })
      );
    }
  };

  static deleteComment = async (req: AuthRequest, res: Response) => {
    try {
      const profileID = req.locals.user.profileID;
      const { commentID }: any = req.query;
      console.log(`Deleting comment: ${profileID} to ${commentID}`);

      if (!commentID) {
        return res.status(400).json(
          ResponseWithFailure({
            error: "Please enter a comment ID",
          })
        );
      }

      const comment = await db.resourceComments.deleteMany({
        where: {
          userProfileID: profileID,
          commentID: parseInt(commentID),
        },
      });

      // fetch user by ID

      if (comment.count === 0) {
        res.json(
          ResponseWithSuccess({
            message: "Only the author can delete their comment",
          })
        );
      }

      console.log("updated comment", comment);
      res.json(
        ResponseWithSuccess({
          message: "Comment deleted successfully",
        })
      );
    } catch (error) {
      console.log(error);
      res.status(500).json(
        ResponseWithFailure({
          error: "Something went wrong",
        })
      );
    }
  };
}
