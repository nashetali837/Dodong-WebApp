import { Router } from "express";
import { isUserLoggedIn } from "../../middleware/authentication";
import { FollowController } from "./follows.controller";

const router = Router();

// Get all users
router.get("/stats", isUserLoggedIn, FollowController.fetchStats);

router.get("/follower-list", isUserLoggedIn, FollowController.fetchFollowers);

router.get("/following-list", isUserLoggedIn, FollowController.fetchFollowing);

router.post("/follow-user", isUserLoggedIn, FollowController.followUser);

router.post("/unfollow-user", isUserLoggedIn, FollowController.unFollowUser);

export default router;
