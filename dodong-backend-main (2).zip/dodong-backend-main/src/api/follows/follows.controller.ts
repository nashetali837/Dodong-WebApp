import { Request, Response } from "express";
import db from "../../database";
import { Follows, Profile, User } from "@prisma/client";
import { ResponseWithFailure, ResponseWithSuccess } from "../../utils/response";
import { AuthRequest } from "../location/location.controller";
import { UnfollowNewProfile, fetchFollowerStats } from "./follows.services";
import {
  NotificationType,
  createSilentNotification,
} from "../notifications/notification.services";

const FOLLOWER_LIMIT = 10;

export class FollowController {
  static fetchStats = async (req: Request, res: Response) => {
    let { userProfileID }: any = req.query;

    userProfileID = parseInt(userProfileID);

    if (!userProfileID || isNaN(userProfileID)) {
      return res.status(400).json(
        ResponseWithFailure({
          error: "User Profile ID is required",
        })
      );
    }

    const response = await fetchFollowerStats(userProfileID);
    console.log(response);
    res.json(ResponseWithSuccess(response));
  };

  static followUser = async (req: AuthRequest, res: Response) => {
    try {
      const followerID = req.locals.user.profileID;
      const followingID: number = req.body.followingId;

      let followingIDUser: Profile = await db.profile.findFirst({
        where: {
          userProfileID: followingID,
        },
      });

      if (!followingIDUser) {
        return res.status(400).json(
          ResponseWithFailure({
            error: "Following User does not exist",
          })
        );
      }

      const alreadyFollows = await db.follows.findFirst({
        where: {
          followerId: followerID,
          followingId: followingIDUser.userProfileID,
        },
      });

      const name = followingIDUser.displayName || followingIDUser.name;

      if (alreadyFollows) {
        return res.status(400).json(
          ResponseWithFailure({
            error: "You are already a follower of " + name,
          })
        );
      }

      const follow = await db.follows.create({
        data: {
          followerId: followerID,
          followingId: followingIDUser.userProfileID,
        },
        select: {
          follower: {
            select: {
              avatar: true,
              displayName: true,
              name: true,
            },
          },
        },
      });

      const followerName = follow.follower.displayName || follow.follower.name;

      createSilentNotification(
        NotificationType.NEW_FOLLOWER,
        {
          userName: followerName,
          userProfileID: followingID,
        },
        {
          followingUserProfileID: followerID,
        }
      );
      // fetch user by ID

      console.log("followingIDUser", name);
      res.json(
        ResponseWithSuccess({
          message: "You are following " + name,
        })
      );
    } catch (error) {
      console.log(error);
      res.status(500).json(
        ResponseWithFailure({
          error: "Something went wrong",
        })
      );
    }
  };

  static unFollowUser = async (req: AuthRequest, res: Response) => {
    try {
      const followerID = req.locals.user.profileID;
      const unFollowId: number = req.body.unFollowId;

      const follow = await UnfollowNewProfile(unFollowId, followerID);

      console.log("unfollow", follow);
      res.json(
        ResponseWithSuccess({
          message: "Unfollow successful",
        })
      );
    } catch (error) {
      console.log(error);
      res.status(500).json(
        ResponseWithFailure({
          error: "Something went wrong",
        })
      );
    }
  };

  static fetchFollowers = async (req: AuthRequest, res: Response) => {
    try {
      // with pagination
      let { page, userProfileID }: any = req.query;

      userProfileID = parseInt(userProfileID);
      page = parseInt(page);

      if (!userProfileID || isNaN(userProfileID)) {
        return res.status(400).json(
          ResponseWithFailure({
            error: "User Profile ID is required",
          })
        );
      }

      if (isNaN(page)) page = 1;

      const followers: Follows[] = await db.follows.findMany({
        where: {
          followingId: userProfileID,
        },
        include: {
          follower: {
            select: {
              avatar: true,
              displayName: true,
              name: true,
              userProfileID: true,
            },
          },
        },
        skip: page ? (page - 1) * FOLLOWER_LIMIT : undefined,
        take: FOLLOWER_LIMIT,
      });

      const count = await db.follows.count({
        where: {
          followingId: userProfileID,
        },
      });

      const response = {
        followers,
        count,
        page: page ? +page : undefined,
      };

      res.json(ResponseWithSuccess(response));
    } catch (error) {
      console.log(error);
      res.status(500).json(
        ResponseWithFailure({
          error: "Something went wrong",
        })
      );
    }
  };

  static fetchFollowing = async (req: AuthRequest, res: Response) => {
    try {
      // with pagination
      let { page, userProfileID }: any = req.query;

      userProfileID = parseInt(userProfileID);
      page = parseInt(page);

      if (!userProfileID || isNaN(userProfileID)) {
        return res.status(400).json(
          ResponseWithFailure({
            error: "User Profile ID is required",
          })
        );
      }

      if (isNaN(page)) page = 1;

      const following: Follows[] = await db.follows.findMany({
        where: {
          followerId: userProfileID,
        },
        include: {
          following: {
            select: {
              avatar: true,
              displayName: true,
              name: true,
              userProfileID: true,
            },
          },
        },
        skip: page ? (page - 1) * FOLLOWER_LIMIT : undefined,
        take: FOLLOWER_LIMIT,
      });

      const count = await db.follows.count({
        where: {
          followerId: userProfileID,
        },
      });

      const response = {
        following,
        count,
        page: page ? +page : undefined,
      };

      res.json(ResponseWithSuccess(response));
    } catch (error) {
      console.log(error);
      res.status(500).json(
        ResponseWithFailure({
          error: "Something went wrong",
        })
      );
    }
  };
}
