import db from "../../database";

export const fetchFollowerStats = async (profileID: any) => {
  try {
    // fetch all followers
    const followersCount = await db.follows.count({
      where: {
        followingId: profileID,
      },
    });

    // fetch all following
    const followingCount = await db.follows.count({
      where: {
        followerId: profileID,
      },
    });

    // fetch total posts count
    const postsCount = await db.resource.count({
      where: {
        authorID: profileID,
        isActive: true,
      },
    });

    let result = {
      totalPosts: postsCount,
      followers: followersCount,
      following: followingCount,
    };

    return result;
  } catch (error) {
    console.log(error);
    return null;
  }
};

export const followNewProfile = async (followId, followerId) => {
  if (!followId || !followerId) {
    throw new Error("Both Follower ID and Follow ID are required");
  }
};

export const UnfollowNewProfile = async (followId, followerId) => {
  if (!followId || !followerId) {
    throw new Error("Both Follower ID and Follow ID are required");
  }
  const follow = await db.follows.deleteMany({
    where: {
      followerId: followerId,
      followingId: followId,
    },
  });
  console.log("unfollow", follow);
  return "Success";
};
