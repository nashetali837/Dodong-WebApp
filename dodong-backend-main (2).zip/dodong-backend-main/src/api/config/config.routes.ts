import { Router } from "express";
import { ConfigController } from "./config.controller";

const router = Router();

// Get all users
router.get("/", ConfigController.fetchConfig);


export default router;
