import { Request, Response } from "express";
import { ResponseWithFailure, ResponseWithSuccess } from "../../utils/response";
import {
  fetchPopularTags,
  fetchResourceTypes,
  fetchTopCategories,
} from "./config.services";

export class ConfigController {
  static fetchConfig = async (req: Request, res: Response) => {
    const params: any = req.query;

    if (!params.device) {
      return res.json(
        ResponseWithFailure({
          error: "Invalid Device Type",
        })
      );
    }

    const [resourceTypes, categories, tags] = await Promise.all([
      fetchResourceTypes(),
      fetchTopCategories(),
      fetchPopularTags(),
    ]);

    const configResponse = {
      device: params.device,
      config: {
        allowedRegion: ["IN"],
        resourceTypes: resourceTypes,

        topCategories: categories,

        popularTags: tags,
      },
    };
    res.json(ResponseWithSuccess(configResponse));
  };
}
