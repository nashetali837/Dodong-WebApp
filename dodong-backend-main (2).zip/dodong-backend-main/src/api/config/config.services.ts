import { SEED_CATEGORIES } from "../../../prisma/seed";
import db from "../../database";

export const fetchResourceTypes = async () => {
  try {
    const resourceTypes = await db.contentType.findMany({
      where: {
        isActive: true,
      },
      select: {
        contentType: true,
        description: true,
        image: true,
        order: true,
      },
    });
    return resourceTypes;
  } catch (error) {
    return [];
  }
};

export const fetchPopularTags = async () => {
  try {
    const resourceTypes = await db.tag.findMany({
      where: {},
      select: {
        name: true,
      },
    });
    return resourceTypes;
  } catch (error) {
    return [];
  }
};

export const fetchTopCategories = async () => {
  try {
    const resourceTypes = await db.category.findMany({
      where: {},
      take: 10,
    });
    return resourceTypes;
  } catch (error) {
    return [];
  }
};

export const seedCategories = async (req, res) => {

  try {

    let allCategories = SEED_CATEGORIES;

    for (let category of allCategories) {

      let newCategory = await db.category.findFirst({
        where: {
          displayName: category.category,
        },
      })
      if (!newCategory) {
        newCategory = await db.category.create({
          data: {
            name: category.category.toLocaleLowerCase(),
            displayName: category.category,
            id: Math.round(Math.random() * 100000)
          },
        })
      }



      console.log('newCategory: ', newCategory)

      for (let subCat of category.subcategories) {

        let newSubCategory = await db.subCategory.findFirst({
          where: {
            displayName: subCat,
          },
        })
        console.log('newSubCategory', newCategory.id, subCat, newSubCategory)
        if (!newSubCategory) {
          newSubCategory = await db.subCategory.create({
            data: {
              categoryID: newCategory.id,
              displayName: subCat,
              name: subCat.toLocaleLowerCase()
            },
          })
        }
        console.log('count', newSubCategory)

      }


    }

    res.json({
      allCategories,
    })

  } catch (error) {
    console.log('err', error)

  }

}