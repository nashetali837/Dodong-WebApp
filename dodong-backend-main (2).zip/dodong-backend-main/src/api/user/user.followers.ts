import db from "../../database";
import { getDistanceBetweenGeohash } from "../../utils/geohash";
import { fetchFollowerStats } from "../follows/follows.services";

export const USERS_PER_PAGE = 10;

export const getTotalConnectingCount = async (userProfileID: number) => {
  const count = await db.follows.count({
    where: {
      followingId: userProfileID,
    },
  });
  return count;
};

export const getConnectingProfileList = async ({
  userProfileID,
  requestedUserProfileID,
  page = 1,
}: {
  userProfileID: number;
  requestedUserProfileID: number;
  page: number;
}) => {
  const followers = await db.follows.findMany({
    where: {
      followingId: userProfileID,
    },
    select: {
      following: {
        select: {
          avatar: true,
          userProfileID: true,
          displayName: true,
          name: true,
        },
      },
    },
    take: USERS_PER_PAGE,
    skip: (page - 1) * USERS_PER_PAGE,
  });

  const sanitizedFollowers = await Promise.all(
    followers.map(async (follower) => {
      let isAlreadyFollowing = await isUserFollowing(
        requestedUserProfileID,
        follower.following.userProfileID
      );

      const stats = await fetchFollowerStats(follower.following.userProfileID);

      return {
        userProfileID: follower.following.userProfileID,
        displayName: follower.following.displayName || follower.following.name,
        avatar: follower.following.avatar,
        isAlreadyFollowing,
        ...stats,
      };
    })
  );
  return sanitizedFollowers;
};

export const getConnectedProfileList = async ({
  userProfileID,
  page = 1,
}: {
  userProfileID: number;
  page: number;
}) => {
  const followers = await db.follows.findMany({
    where: {
      followingId: userProfileID,
    },
    select: {
      following: {
        select: {
          avatar: true,
          userProfileID: true,
          displayName: true,
          name: true,
        },
      },
    },
    take: USERS_PER_PAGE,
    skip: (page - 1) * USERS_PER_PAGE,
  });

  const sanitizedFollowers = await Promise.all(
    followers.map(async (follower) => {
      let isAlreadyFollowing = true; // as it is connected already

      const stats = await fetchFollowerStats(follower.following.userProfileID);

      return {
        userProfileID: follower.following.userProfileID,
        displayName: follower.following.displayName || follower.following.name,
        avatar: follower.following.avatar,
        isAlreadyFollowing,
        ...stats,
      };
    })
  );
  return sanitizedFollowers;
};

export const isUserFollowing = async (
  followerID: number,
  followingID: number
) => {
  const count = await db.follows.count({
    where: {
      followerId: followerID,
      followingId: followingID,
    },
  });
  console.log(
    "count for follower",
    followerID,
    "and following",
    followingID,
    ": ",
    count
  );
  return count !== 0;
};

export const getNearbyUsers = async ({
  userProfileID,
  geohash,
  page = 1,
}: {
  userProfileID: number;
  geohash: string;
  page: number;
}) => {
  const users = await db.profile.findMany({
    where: {
      geohash: {
        startsWith: geohash,
      },
      userProfileID: {
        not: userProfileID,
      },
    },
    take: USERS_PER_PAGE,
    skip: (page - 1) * USERS_PER_PAGE,
  });

  console.log("users", users);

  const sanitizedUsers = await Promise.all(
    users.map(async (user) => {
      let isAlreadyFollowing = await isUserFollowing(
        userProfileID,
        user.userProfileID
      );

      const stats = await fetchFollowerStats(user.userProfileID);

      // get distance between two users
      const distance = await getDistanceBetweenGeohash(geohash, user.geohash);

      return {
        userProfileID: user.userProfileID,
        displayName: user.displayName || user.name,
        avatar: user.avatar,
        isAlreadyFollowing,
        ...stats,
      };
    })
  );
  return sanitizedUsers;
};
