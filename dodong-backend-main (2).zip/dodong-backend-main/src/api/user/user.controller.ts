import { Request, Response } from "express";
import db from "../../database";
import { Profile, User, UserMeasurements } from "@prisma/client";
import { ResponseWithFailure, ResponseWithSuccess } from "../../utils/response";
import * as UserService from "./user.services";
import { AuthRequest } from "../location/location.controller";
import { createLocation } from "../location/location.services";
import {
  getConnectedProfileList,
  getConnectingProfileList,
  getNearbyUsers,
  getTotalConnectingCount,
} from "./user.followers";
import { encodeLocation } from "../../utils/geohash";

export class UserController {
  static listAll = async (req: Request, res: Response) => {
    const users: User[] = await db.user.findMany();
    res.json(ResponseWithSuccess({ users }));
  };

  static getPublicProfile = async (req: AuthRequest, res: Response) => {
    try {
      const profileID = req?.locals?.user?.profileID;

      const profileId = Number(req.params.id);

      const profile = await UserService.getProfileByProfileId(profileId);
      console.log("isOwner: ", profile?.userProfileID, profileID);

      if (!profile) {
        return res
          .status(404)
          .json(ResponseWithFailure({ message: "Profile Not found" }));
      }

      const user = await UserService.getUserById(profile.userID);

      console.log("user,", user);
      if (!user) {
        return res
          .status(404)
          .json(ResponseWithFailure({ message: "Not found" }));
      }

      res.json(
        ResponseWithSuccess({
          user,
          profile,
          isUserOwner: profile?.userProfileID === profileID,
        })
      );
    } catch (error) {
      console.log(error);
      return res
        .status(400)
        .json(ResponseWithFailure({ message: error.message }));
    }
  };

  static fetchUserMeasurements = async (req: AuthRequest, res: Response) => {
    const profileID = req.locals.user.profileID;

    try {
      const measurements: UserMeasurements[] =
        await db.userMeasurements.findMany({
          where: {
            authorID: profileID,
          },
        });
      return res.json(ResponseWithSuccess({ measurements }));
    } catch (error) {
      console.log("Error while fetch measurements:", error.message);
      return res.json(ResponseWithFailure({ message: "Something went wrong" }));
    }
  };

  static fetchUsersFollowers = async (req: AuthRequest, res: Response) => {
    let { page, userProfileID }: any = req.query;
    const requestedUserProfileID = req.locals.user.profileID;

    if (isNaN(page)) {
      return res.json(ResponseWithFailure({ message: "Invalid Page Number" }));
    }

    if (isNaN(userProfileID)) {
      return res.json(
        ResponseWithFailure({ message: "Invalid userProfileID" })
      );
    } else {
      userProfileID = parseInt(userProfileID);
    }

    try {
      const followers = await getConnectingProfileList({
        userProfileID,
        requestedUserProfileID,
        page: 1,
      });

      const count = await getTotalConnectingCount(userProfileID);

      return res.json(
        ResponseWithSuccess({
          data: followers,
          count: count,
          totalPages: 10,
          page: 1,
        })
      );
    } catch (error) {
      console.log("Error while fetch measurements:", error.message);
      return res.json(ResponseWithFailure({ message: "Something went wrong" }));
    }
  };

  static fetchUsersConnected = async (req: AuthRequest, res: Response) => {
    let { page, userProfileID }: any = req.query;

    if (isNaN(page)) {
      return res.json(ResponseWithFailure({ message: "Invalid Page Number" }));
    }

    if (isNaN(userProfileID)) {
      return res.json(
        ResponseWithFailure({ message: "Invalid userProfileID" })
      );
    } else {
      userProfileID = parseInt(userProfileID);
    }

    try {
      const followers = await getConnectedProfileList({
        userProfileID,
        page: 1,
      });

      const count = await getTotalConnectingCount(userProfileID);

      return res.json(
        ResponseWithSuccess({
          data: followers,
          count: count,
          totalPages: 10,
          page: 1,
        })
      );
    } catch (error) {
      console.log("Error while fetch measurements:", error.message);
      return res.json(ResponseWithFailure({ message: "Something went wrong" }));
    }
  };

  static getUserProfile = async (req: AuthRequest, res: Response) => {
    try {
      const userID = req.locals.user.id;
      const profileID = req.locals.user.profileID;
      console.log("userID", userID);

      const user = await UserService.getUserById(userID);

      if (!user) {
        return res
          .status(400)
          .json(ResponseWithFailure({ message: "User Not found" }));
      }

      const profile = await UserService.getProfileByUserId(userID);

      if (!profile) {
        return res
          .status(404)
          .json(ResponseWithFailure({ message: "Profile Not found" }));
      }

      const professional = await UserService.getProfessionalProfileByUserId(
        profileID
      ).catch((error) => {
        console.log("err", error);
      });

      const percent = await UserService.profilePercentCompleted(profileID, {
        profile,
        professional,
      });

      res.json(
        ResponseWithSuccess({
          profile,
          user,
          professional,
          profileCompletion: percent,
        })
      );
    } catch (error) {
      console.log(error);
      return res
        .status(400)
        .json(ResponseWithFailure({ message: error.message }));
    }
  };

  static updateProfile = async (req: AuthRequest, res: Response) => {
    try {
      const userID = req.locals.user.id;
      let body: any = req.body;

      const user = await UserService.getUserById(userID);

      if (!user) {
        return res
          .status(404)
          .json(ResponseWithFailure({ message: "User Not found" }));
      }

      const profile = await UserService.getProfileByUserId(userID);

      if (!profile) {
        return res
          .status(404)
          .json(ResponseWithFailure({ message: "Profile Not found" }));
      }

      if (body.location) {
        let location = await createLocation(body.location);
        body.geohash = location.geohash || undefined;
        body.location = undefined;
      }

      const updatedProfile = await UserService.updateProfileByUserId(
        userID,
        body
      );

      res.json(ResponseWithSuccess(updatedProfile));
    } catch (error) {
      console.log(error);
      return res
        .status(400)
        .json(ResponseWithFailure({ message: error.message }));
    }
  };

  static updateProfessionalProfile = async (
    req: AuthRequest,
    res: Response
  ) => {
    try {
      const userID = req.locals.user.id;
      const profileID = req.locals.user.profileID;

      let body: any = req.body;
      body.profileId = profileID;

      const user = await UserService.getUserById(userID);

      if (!user) {
        return res
          .status(404)
          .json(ResponseWithFailure({ message: "User Not found" }));
      }

      // needs more robust mechanism to figure this out
      let location = await createLocation({
        name: body.jobLocation,
        latitude: 17.54,
        longitude: 54.33,
        country: body.country || "India",
        state: body.state || "India",
      });

      const updatedProfile = await UserService.updateProfessionalProfile(
        profileID,
        {
          brandDetails: body.brandDetails,
          jobLocation: body.jobLocation,
          companyName: body.company,
          occupationType: body.occupation,
          others: body.others,
          name: body.email,
          geohash: location.geohash,
          profileID: profileID,
          officialMobileNumber: body.officialMobileNumber,
        }
      );

      if (!updatedProfile) {
        return res
          .status(404)
          .json(ResponseWithFailure({ message: "Profile Not found" }));
      }

      res.json(
        ResponseWithSuccess({
          message: "Professional profile has been updated",
        })
      );
    } catch (error) {
      console.log(error);
      return res
        .status(400)
        .json(ResponseWithFailure({ message: error.message }));
    }
  };

  static getUserByEmailOrMobile = async (req: Request, res: Response) => {
    try {
      const { email, mobileNumber } = req.body;
      const user = await db.user.findFirst({
        where: {
          OR: [
            {
              email,
            },
            {
              mobileNumber,
            },
          ],
        },
      });
      if (user) {
        res.json(ResponseWithSuccess({ user }));
      } else {
        return res
          .status(404)
          .json(ResponseWithFailure({ message: "Not found" }));
      }
    } catch (error) {
      console.log(error);
      return res
        .status(400)
        .json(ResponseWithFailure({ message: error.message }));
    }
  };

  /**
   *
   * @param req {Request} - Express request object
   * @param res {Response} - Express response object
   * @returns {Promise<Response>} - Express response object
   * @description Create a new user
   * @example
   * POST /user
   * {
   *  "name": "John Doe",
   *  "email": "john@doe.com",
   * }
   *
   */
  static create = async (req: Request, res: Response) => {
    const body: User = req.body;
    const user = await db.user.create({
      data: body,
    });
    res.json({ user });
  };

  static update = async (req: Request, res: Response) => {
    const body: User = req.body;
    const user = await db.user.update({
      where: {
        id: Number(req.params.id),
      },
      data: body,
    });
    res.json({ user });
  };

  static getNearByUsers = async (req: AuthRequest, res: Response) => {
    const userProfileID = req.locals.user.profileID;
    let { location, page }: any = req.body;

    // number of geohash characters
    const GEOHASH_PRECISION = 6;

    if (!location?.latitude || !location?.longitude) {
      return res
        .status(400)
        .json(ResponseWithFailure({ message: "Location is required" }));
    }

    let geohash = encodeLocation(location);

    geohash = geohash.slice(0, GEOHASH_PRECISION);

    console.log("geohash", geohash, "page:", page);

    if (isNaN(page)) {
      page = 1;
    }

    const nearByUsers = await getNearbyUsers({
      geohash: geohash,
      page: page as number,
      userProfileID,
    });

    res.json(ResponseWithSuccess({ nearByUsers }));
  };

  static deleteUser = async (req: AuthRequest, res: Response) => {
    let userProfileID = req.locals.user.profileID;

    userProfileID = req.body.userProfileID;

    res.status(200).json(
      ResponseWithSuccess({
        message:
          "Your request has been processed. Your account will be deleted shortly",
      })
    );

    const deleteResponse = await UserService.deleteUserProfile(userProfileID);

    if (!deleteResponse) {
      console.log(
        "Something went wrong while deleting profile: ",
        userProfileID,
        deleteResponse
      );
    }
  };
}
