import { Router } from "express";
import {
  isUserLoggedIn,
  optionalLoggedIn,
} from "../../middleware/authentication";
import { UserController } from "./user.controller";

const router = Router();

// Get all users
router.get("/test-cxz", UserController.listAll);

router.get("/profile", isUserLoggedIn, UserController.getUserProfile);

router.get(
  "/profile/connecting",
  isUserLoggedIn,
  UserController.fetchUsersFollowers
);

router.get(
  "/profile/connected",
  isUserLoggedIn,
  UserController.fetchUsersConnected
);

router.get(
  "/measurements",
  isUserLoggedIn,
  UserController.fetchUserMeasurements
);

router.post("/update-profile", isUserLoggedIn, UserController.updateProfile);

router.post(
  "/update-professional-profile",
  isUserLoggedIn,
  UserController.updateProfessionalProfile
);

router.get("/profile/:id", optionalLoggedIn, UserController.getPublicProfile);

router.post("/nearby", isUserLoggedIn, UserController.getNearByUsers);

router.post("/delete", isUserLoggedIn, UserController.deleteUser);

export default router;
