import { ProfessionalProfile, Profile, User } from "@prisma/client";
import bcrypt from "bcryptjs";
import jsonwebtoken from "jsonwebtoken";
import db from "../../database";
import { fetchFollowerStats } from "../follows/follows.services";
import {
  NotificationType,
  createSilentNotification,
} from "../notifications/notification.services";

type EmailOrMobile = {
  email?: string;
  mobileNumber?: string;
};

export const getUserByEmailOrMobile = async ({
  email,
  mobileNumber,
}: EmailOrMobile) => {
  try {
    const user = await db.user
      .findFirst({
        where: {
          OR: [
            {
              mobileNumber: mobileNumber ? mobileNumber.toString() : undefined,
            },
            {
              email: email || undefined,
            },
          ],
        },
      })
      .catch((_) => null);
    if (user) {
      return user;
    }
    return null;
  } catch (error) {
    console.log(error);
    return null;
  }
};

export const getUserById = async (id: Number) => {
  try {
    const user = await db.user.findFirst({
      where: {
        id: Number(id),
      },
    });

    if (!user) {
      return null;
    }

    let result = {
      ...user,
      password: undefined,
      OTP: undefined,
      OTPExpiry: undefined,
    };

    return result;
  } catch (error) {
    console.log(error);
    return null;
  }
};

export const getProfileByUserId = async (id: Number) => {
  try {
    const profile = await db.profile.findFirst({
      where: {
        userID: Number(id),
      },
    });

    if (!profile) {
      return null;
    }

    // fetch follower stats
    const followerStats = await fetchFollowerStats(profile.userProfileID);

    const response = {
      ...profile,
      ...followerStats,
    };

    return response;
  } catch (error) {
    console.log(error);
    return null;
  }
};

export const getProfessionalProfileByUserId = async (id: Number) => {
  try {
    const profile = await db.professionalProfile.findFirst({
      where: {
        profileID: Number(id),
      },
    });

    if (!profile) {
      return null;
    }

    const response = {
      ...profile,
    };

    return response;
  } catch (error) {
    console.log(error);
    return null;
  }
};

export const getProfileByProfileId = async (id: Number) => {
  try {
    const profile = await db.profile.findFirst({
      where: {
        userProfileID: Number(id),
      },
    });

    console.log("profile", profile);
    if (!profile) {
      return null;
    }

    // fetch follower stats
    const followerStats = await fetchFollowerStats(profile.userProfileID);

    const response = {
      ...profile,
      ...followerStats,
    };

    return response;
  } catch (error) {
    console.log(error);
    return null;
  }
};

export const createUser = async ({
  name,
  email,
  password,
  mobileNumber,
  avatar = "",
  emailVerified = false,
  socialLogin = "",
}) => {
  try {
    const user = await db.user.create({
      data: {
        email,
        password,
        mobileNumber,
        emailVerified,
        lastLogin: new Date(),
        socialLogin: socialLogin || "email",
      },
    });
    console.log("New user created with details: ", user);

    const createProfile = await db.profile.create({
      data: {
        name,
        userID: user.id,
        avatar:
          avatar ||
          `https://st3.depositphotos.com/6672868/13701/v/600/depositphotos_137014128-stock-illustration-user-profile-icon.jpg`,
        bio: "",
      },
    });
    await createSilentNotification(NotificationType.NEW_REGISTER, {
      userProfileID: createProfile.userProfileID,
      userName: "",
    });
    console.log("New profile created with details: ", createProfile);

    return { user, profile: createProfile };
  } catch (error) {
    console.log(error);
    return null;
  }
};

export const updateUser = async (id: number, data: Partial<User>) => {
  try {
    const user = await db.user.update({
      where: {
        id,
      },
      data,
    });
    return user;
  } catch (error) {
    console.log("Error while updating user: ", error);
    return null;
  }
};

export const updateProfileByUserId = async (
  id: number,
  data: Partial<Profile>
) => {
  try {
    const profile = await db.profile.update({
      where: {
        userID: id,
      },
      data: { ...data },
    });
    return profile;
  } catch (error) {
    console.log(error);
    return null;
  }
};

export const updateProfessionalProfile = async (
  profileID: number,
  data: Partial<ProfessionalProfile>
) => {
  try {
    const professionalProfile = await db.professionalProfile.upsert({
      where: {
        profileID: profileID,
      },
      // @ts-ignore
      create: {
        ...data,
      },
      update: { ...data },
    });
    return professionalProfile;
  } catch (error) {
    console.log(error);
    return null;
  }
};

export const hashPassword = async (
  password: string
): Promise<string | null> => {
  try {
    const salt = await bcrypt.genSalt(10);
    const hash = await bcrypt.hash(password, salt);
    return hash;
  } catch (error) {
    console.log(error);
    return null;
  }
};

export const comparePassword = async (password: string, hash: string) => {
  try {
    const isMatch = await bcrypt.compare(password, hash);
    return isMatch;
  } catch (error) {
    console.log(error);
    return false;
  }
};

interface UserHash extends User {
  profileID: number;
}

export const generateToken = async (
  user: UserHash,
  expiresIn = process.env.JWT_EXPIRES_IN,

  // Need to check this when the user tries to reset the password
  resetPassword = false
) => {
  try {
    const payload = {
      user: {
        id: user.id,
        profileID: user.profileID,
        email: user.email,
        mobileNumber: user.mobileNumber,
        userTypeID: 1,
        resetPassword,
        emailVerified: user.emailVerified,
        mobileNumberVerified: user.mobileNumberVerified,
      },
    };
    const token = await jsonwebtoken.sign(payload, process.env.JWT_SECRET, {
      expiresIn: expiresIn,
    });
    return token;
  } catch (error) {
    console.log(error);
    return null;
  }
};

export const verifyToken = async (token: string) => {
  try {
    if (!token || token === "undefined" || token === "null") {
      console.log("No token provided");
      return null;
    }
    console.log("token", typeof token);
    const decoded = await jsonwebtoken.verify(token, process.env.JWT_SECRET);
    // check if token is expired
    if (decoded.exp < Date.now() / 1000) {
      return null;
    }

    return decoded;
  } catch (error) {
    console.log(error.message);
    return null;
  }
};

export const profilePercentCompleted = async (
  profileID: number,
  profile: any
) => {
  let percent = 0;
  let nextStep = "";
  const profileSteps = {
    profileShared: false,
    completeProfile: false,
    createFirstPost: false,
    profilePicUpdated: false,
  };

  const totalPosts = profile?.profile?.totalPosts;

  if (totalPosts > 0) {
    percent += 25;
    profileSteps.createFirstPost = true;
  } else {
    nextStep = "Create your first post to complete profile";
  }

  if (profile?.profile) {
    if (profile?.profile?.displayName) {
      percent += 25;
      profileSteps.completeProfile = true;
    } else {
      nextStep = "Update your business profile";
    }
  }

  if (profile?.profile) {
    if (profile?.profile?.avatar) {
      percent += 25;
      profileSteps.profilePicUpdated = true;
    } else {
      nextStep = "Update your personal profile";
    }
  }

  if (profile?.profile?.isProfileCompleted) {
    percent += 25;
    profileSteps.profileShared = true;
  } else {
    nextStep = "Update your personal profile";
  }

  return { percent, nextStep, profileSteps };
};

export const deleteUserProfile = async(userProfileID: number): Promise<any> => {
  try {

    const response = await db.profile.delete({
      
      where: {
        userProfileID
      }
    })

    console.log('response', response);
    return response;

  } catch (error) {
    console.log(error);
    return null;
  }
};
