import { Router } from "express";
import { ResourceController } from "./resources.controller";
import { optionalLoggedIn } from "../../middleware/authentication";

const router = Router();

router.get("/get", optionalLoggedIn, ResourceController.getResourceByID);

export default router;
