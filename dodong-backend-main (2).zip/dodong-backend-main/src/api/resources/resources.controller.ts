import { Response } from "express";
import { ResponseWithFailure, ResponseWithSuccess } from "../../utils/response";
import { fetchResource } from "./resources.services";
import { OptionalAuthRequest } from "../location/location.controller";

export class ResourceController {
  static getResourceByID = async (req: OptionalAuthRequest, res: Response) => {
    try {
      const { resourceID }: any = req.query;
      const userProfileID = req.locals?.user?.profileID;

      if (!resourceID || isNaN(resourceID)) {
        return res.status(400).json(
          ResponseWithFailure({
            error: "Resource ID is required",
          })
        );
      }

      console.log("resourceID", resourceID, userProfileID);
      const resource = await fetchResource(parseInt(resourceID), userProfileID);

      if (resource) {
        return res.json(ResponseWithSuccess({ resource }));
      }

      return res
        .status(404)
        .json(ResponseWithFailure({ message: "Something went wrong" }));
    } catch (error) {
      console.log(error);
      res.status(400).json(ResponseWithFailure({ message: error.message }));
    }
  };
}
