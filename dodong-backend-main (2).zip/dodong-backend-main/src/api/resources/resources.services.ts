import db from "../../database";
import { RESOURCE_TYPES } from "../post/post.controller";
import { resourceAdapter } from "../../adapters";
import {
  fetchResourceCommentCount,
  fetchResourceLikeCount,
  isResourceLikedByUser,
} from "../post/post.services";
import { checkProductAddedInWishlist } from "../product/product.services";

export const fetchResource = async (
  resourceID: number,
  userProfileID?: number
) => {
  // fetchResource
  try {
    if (isNaN(resourceID)) {
      return null;
    }

    // fetch static data in parallel
    let [resource, totalComments, totalLikes, alreadyLiked, alreadySaved] =
      await Promise.all([
        fetchMainResource(resourceID),
        fetchResourceCommentCount(resourceID),
        fetchResourceLikeCount(resourceID),
        isResourceLikedByUser(resourceID, userProfileID),
        false,
      ]);

    let resourceDetails = await getResourceDetails(
      resourceID,
      resource.resourceType
    );

    let addedToWishlist = false;

    if (userProfileID) {
      addedToWishlist = await checkProductAddedInWishlist(
        resource.productID,
        userProfileID
      );
      console.log("addedToWishlist", addedToWishlist);
    }

    return resourceAdapter({
      ...resource,
      alreadyLiked,
      alreadySaved,
      addedToWishlist,
      totalComments,
      totalLikes,
      resourceDetails,
    });
  } catch (error) {
    console.log(
      "[fetchResource] Error while fetching resourceID: ",
      resourceID,
      error.message
    );
    return null;
  }
};

const fetchMainResource = async (resourceID: number) => {
  return await db.resource.findFirst({
    where: {
      isActive: true,
      resourceID,
    },
    include: {
      author: {
        select: {
          displayName: true,
          name: true,
          avatar: true,
          userProfileID: true,
        },
      },
      ResourceMedia: {
        select: {
          mediaURL: true,
          mediaType: true,
          id: true,
        },
      },
      Locations: true,
      shop: {
        select: {
          shopID: true,
          name: true,
          bio: true,
        },
      },
      ResourceCategories: {
        include: {
          category: {
            select: {
              id: true,
              name: true,
              displayName: true,
            },
          },
          subCategory: {
            select: {
              id: true,
              name: true,
              displayName: true,
              categoryID: true,
            },
          },
        },
      },
    },
  });
};

export const getPostById = async (id: Number) => {
  try {
    const post = await db.post.findFirst({
      where: {
        postID: Number(id),
        published: true,
      },
    });
    if (post) {
      return post;
    }
    return null;
  } catch (error) {
    console.log(error);
    return null;
  }
};

// fetch trending posts

export const getResourceDetails = async (
  resourceID: number,
  resourceType: RESOURCE_TYPES
) => {
  try {
    let resourceDetails = null;
    switch (resourceType) {
      case RESOURCE_TYPES.POST:
        resourceDetails = await db.post.findFirst({
          where: {
            resourceID,
          },
        });

        break;
      case RESOURCE_TYPES.COLLECTION:
        resourceDetails = await db.collection.findFirst({
          where: {
            resourceID,
          },
        });
        break;
      case RESOURCE_TYPES.DISCOVERY:
        resourceDetails = await db.discovery.findFirst({
          where: {
            resourceID,
          },
        });
        break;
      case RESOURCE_TYPES.EXPERIENCE:
        resourceDetails = await db.post.findFirst({
          where: {
            resourceID,
          },
        });
        break;

      default:
        resourceDetails = null;
        break;
    }
    return resourceDetails;
  } catch (error) {
    return null;
  }
};
