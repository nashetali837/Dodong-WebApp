import { Request, Response } from "express";
import db from "../../database";
import { Category, SubCategory, Shop, Locations } from "@prisma/client";
import { ResponseWithFailure, ResponseWithSuccess } from "../../utils/response";
import {
  createShop,
  getProductsInShop,
  getShopById,
  getShopsByFilter,
  nearbyShops,
  updateShop,
} from "./shop.services";
import { encodeLocation } from "../../utils/geohash";
import { createLocation } from "../location/location.services";
import { AuthRequest } from "../location/location.controller";

export const filterShops = async (req: Request, res: Response) => {
  const filters = req.body;
  const shops: Shop[] = await getShopsByFilter(filters);

  res.json(ResponseWithSuccess({ shops }));
};

/**
 *
 * @param req {Request} - Express request object
 * @param res {Response} - Express response object
 * @returns {Promise<Response>} - Express response object
 * @description Create a new user
 * @example
 * POST /post
 * {
 *  "name": "John Doe",
 *  "email": "john@doe.com",
 * }
 *
 */
export const createNewShop = async (req: AuthRequest, res: Response) => {
  try {
    const profileID = req.locals.user.profileID;
    const body: any = req.body;

    const location = body.location;

    const geohash = encodeLocation(location);

    // create location
    const newLocation = await createLocation({ ...body.location, geohash });

    body.geohash = newLocation.geohash;

    const shop = await createShop({ ...body, creatorProfileID: profileID });
    console.log("New Shop created: ", shop);
    return res.json(ResponseWithSuccess(shop));
  } catch (error) {
    console.log(error);
    res.status(400).json(ResponseWithFailure({ message: error.message }));
  }
};

export const getShop = async (req: Request, res: Response) => {
  try {
    const id = req.params.id;

    const shop = await getShopById(id);

    if (shop) {
      return res.json(ResponseWithSuccess({ shop }));
    }

    res.status(404).json(ResponseWithFailure({ message: "Not found" }));
  } catch (error) {
    res.status(400).json(ResponseWithFailure({ message: error.message }));
  }
};

export const updateShopDetails = async (req: Request, res: Response) => {
  try {
    const body: any = req.body;
    const shop = await updateShop(body.id, body);

    return res.json(ResponseWithSuccess({ shop }));
  } catch (error) {
    res.status(400).json(ResponseWithFailure({ message: error.message }));
  }
};

export const fetchNearbyShops = async (req: Request, res: Response) => {
  try {
    const body: any = req.query;
    const shop = (await nearbyShops(body.shopID)) || [];

    return res.json(ResponseWithSuccess({ shop }));
  } catch (error) {
    res.status(400).json(ResponseWithFailure({ message: error.message }));
  }
};

export const similarProductsInShop = async (req: Request, res: Response) => {
  try {
    const body: any = req.query;
    let { shopID, productID } = body;

    if (!shopID) {
      return res
        .status(400)
        .json(ResponseWithFailure({ message: "Missing shopID" }));
    }

    shopID = Number(shopID);
    productID = Number(productID);

    const products = (await getProductsInShop(shopID, productID)) || [];

    return res.json(ResponseWithSuccess(products));
  } catch (error) {
    res.status(400).json(ResponseWithFailure({ message: error.message }));
  }
};
