import { Router } from "express";
import { isUserLoggedIn } from "../../middleware/authentication";
import * as ShopController from "./shop.controller";

const router = Router();

// Get posts
router.post("/", ShopController.filterShops);

router.post("/create", isUserLoggedIn, ShopController.createNewShop);

router.post("/update", isUserLoggedIn, ShopController.updateShopDetails);

router.get("/near-by", isUserLoggedIn, ShopController.fetchNearbyShops);

router.get("/similar-products", isUserLoggedIn, ShopController.similarProductsInShop);

router.get("/:id", ShopController.getShop);

export default router;
