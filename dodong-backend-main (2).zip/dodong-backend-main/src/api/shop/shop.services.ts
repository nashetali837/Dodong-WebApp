import db from "../../database";

const SHOP_COUNT = 10;
// get filtered shops
export const getShopsByFilter = async (filters) => {
  try {
    const shops = await db.shop.findMany({
      where: {
        ...filters,
      },
      take: SHOP_COUNT,
      orderBy: {
        createdAt: "desc",
      },
    });

    if (shops) {
      return shops;
    }

    return null;
  } catch (error) {
    console.log(error);
    return null;
  }
};

// create shop
/**
 * 
 * @param data 
 * @returns 
 * {
  id: number
  name: string
  address: string
  contact: string
  email: string
  website: string
  bio: string
  createdAt: Date
  updatedAt: Date
  locationId: number | null
  categoryId: number | null
  subCategoryID: number | null
}

 */
export const createShop = async (data: any) => {
  try {
    console.log("data", data);
    const shop = await db.shop.create({
      data: {
        geohash: data.geohash,
        name: data.name,
        address: data.address,
        contact: data.contact,
        email: data.email,
        website: data.website,
        bio: data.bio,
        isClaimed: false,
        createdBy: data.creatorProfileID,

        // categoryId: data.categoryId,
        // subCategoryID: data.subCategoryID,
      },
    });
    if (shop) {
      return shop;
    }
    return null;
  } catch (error) {
    console.log(error);
    return null;
  }
};

export const getShopById = async (id: string) => {
  try {
    const user = await db.shop.findFirst({
      where: {
        shopID: Number(id),
      },
    });
    if (user) {
      return user;
    }
    return null;
  } catch (error) {
    console.log(error);
    return null;
  }
};

export const updateShop = async (id: number, data: any) => {
  try {
    const user = await db.shop.update({
      where: {
        shopID: id,
      },
      data: { ...data },
    });
    return user;
  } catch (error) {
    console.log(error);
    return null;
  }
};

export const addProductToShop = async (data: {
  shopID: number;
  productID: number;
}) => {
  try {
    const productInShop = await db.productsInShop.create({
      data: {
        shopID: data.shopID,
        productID: data.productID,
      },
    });

    console.log("[addProductToShop] Added product to shop", productInShop);

    return productInShop;
  } catch (error) {
    console.log(error);
    return null;
  }
};

export const nearbyShops = async (geohash: string) => {
  try {
    const user = await db.shop.findMany({
      take: 10,
      include: {
        location: {
          select: {
            latitude: true,
            longitude: true,
            name: true,
            geohash: true,
          },
        },
      },
    });
    return user;
  } catch (error) {
    console.log(error);
    return null;
  }
};


export const getProductsInShop = async (shopID: number, productID?: number) => {
  try {
    const products = await db.productsInShop.findMany({
      where: {
        shopID: shopID,
      },
      include: {
        product: {
          include: {
            ProductCategories: {
              include: {
                category: true,
              },
            },

          },
        },

      },
    });

    let shop = products.length > 0 ? products[0] : null;
    // shop.product = undefined

    return {
      shop: { ...shop, product: undefined },
      products: products.map((p) => p.product),
    };
  } catch (error) {
    console.log(error);
    return null;
  }
}