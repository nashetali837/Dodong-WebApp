import { Request, Response } from "express";
import { ResponseWithFailure, ResponseWithSuccess } from "../../utils/response";
import { fetchTrendingPosts, getCategories } from "../post/post.services";

export const searchWholeStore = async (req: Request, res: Response) => {
  try {
    const parameters: any = req.query;
    console.log(parameters);

    const response = {
      page: parseInt(parameters.page) || 1,
      results: [],
      categories: [],
    };

    res.json(ResponseWithSuccess(response));
  } catch (error) {
    res.status(400).json(ResponseWithFailure({ message: error.message }));
  }
};
