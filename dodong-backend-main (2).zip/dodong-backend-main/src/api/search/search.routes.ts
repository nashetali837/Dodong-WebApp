import { Router } from "express";
import * as search from "./search.controller";

const router = Router();

// Get posts
router.get("/", search.searchWholeStore);

export default router;
