import { Request, Response } from "express";
import db from "../../database";
import { Category, SubCategory, Shop, Locations } from "@prisma/client";
import { ResponseWithFailure, ResponseWithSuccess } from "../../utils/response";
import {
  createLocation,
  getShopById,
  getShopsByFilter,
  updateShop,
} from "./location.services";

export interface Locals {
  locals: {
    user: {
      id: number;
      email: string;
      mobileNumber: string;
      profileID: number;
      resetPassword?: boolean;
    };
  };
}

export interface AuthRequest extends Request, Locals {}
export interface OptionalAuthRequest extends Request {
  locals?: {
    user: {
      id: number;
      email: string;
      mobileNumber: string;
      profileID: number;
      resetPassword?: boolean;
    };
  };
}

export const filterShops = async (req: Request, res: Response) => {
  const filters = req.body;
  const locations: Locations[] = await db.locations.findMany();

  res.json(ResponseWithSuccess({ locations }));
};

/**
 *
 * @param req {Request} - Express request object
 * @param res {Response} - Express response object
 * @returns {Promise<Response>} - Express response object
 * @description Create a new user
 * @example
 * POST /post
 * {
 *  "name": "John Doe",
 *  "email": "john@doe.com",
 * }
 *
 */
export const createNewLocation = async (req: Request, res: Response) => {
  try {
    const body: any = req.body;

    const location = await createLocation(body);

    return res.json(ResponseWithSuccess({ location }));
  } catch (error) {
    res.status(400).json(ResponseWithFailure({ message: error.message }));
  }
};

export const getShop = async (req: Request, res: Response) => {
  try {
    const id = req.params.id;

    const shop = await getShopById(id);

    if (shop) {
      return res.json(ResponseWithSuccess({ shop }));
    }

    res.status(404).json(ResponseWithFailure({ message: "Not found" }));
  } catch (error) {
    res.status(400).json(ResponseWithFailure({ message: error.message }));
  }
};

export const updateShopDetails = async (req: Request, res: Response) => {
  try {
    const body: any = req.body;
    const shop = await updateShop(body.id, body);

    return res.json(ResponseWithSuccess({ shop }));
  } catch (error) {
    res.status(400).json(ResponseWithFailure({ message: error.message }));
  }
};
