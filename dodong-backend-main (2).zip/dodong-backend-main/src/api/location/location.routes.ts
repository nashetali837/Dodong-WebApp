import { Router } from "express";
import { isUserLoggedIn } from "../../middleware/authentication";
import * as LocationController from "./location.controller";

const router = Router();

// Get posts
router.get("/", LocationController.filterShops);

router.post("/create", isUserLoggedIn, LocationController.createNewLocation);

router.get("/:id", LocationController.getShop);

router.post("/update", isUserLoggedIn, LocationController.createNewLocation);

export default router;
