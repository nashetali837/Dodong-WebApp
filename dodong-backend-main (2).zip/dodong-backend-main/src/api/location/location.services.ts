import { Category, ResourceMedia, Locations } from "@prisma/client";

import db from "../../database";
import { encodeLocation } from "../../utils/geohash";

// get filtered shops
export const getShopsByFilter = async (filters) => {
  try {
    const shops = await db.locations.findMany({
      where: {
        ...filters,
      },
      include: {},
    });

    if (shops) {
      return shops;
    }

    return null;
  } catch (error) {
    console.log(error);
    return null;
  }
};

// create shop
export const createLocation = async (data: any) => {
  try {
    const geohash = await encodeLocation(data);
    const exists = await db.locations.findFirst({
      where: {
        geohash: geohash,
      },
    });

    console.log("exists", exists);

    if (exists) {
      return exists;
    }

    const location = await db.locations.create({
      data: {
        name: data.name,
        latitude: data.latitude,
        longitude: data.longitude,
        country: data.country,
        state: data.state,
        geohash,
      },
    });

    if (location) {
      return location;
    }
    return null;
  } catch (error) {
    console.log(error);
    return null;
  }
};

export const getShopById = async (geohash: string) => {
  try {
    const user = await db.locations.findFirst({
      where: {
        geohash,
      },
    });
    if (user) {
      return user;
    }
    return null;
  } catch (error) {
    console.log(error);
    return null;
  }
};

export const AddImagesToPost = async (data: ResourceMedia) => {
  try {
    const post = await db.resourceMedia.create({
      data: {
        ...data,
        resourceID: data.resourceID,
        mediaURL: data.mediaURL,
        mediaType: data.mediaType,
      },
    });
    if (post) {
      return post;
    }
    return null;
  } catch (error) {
    console.log(error);
    return null;
  }
};

export const updateShop = async (geohash: string, data: any) => {
  try {
    const user = await db.locations.update({
      where: {
        geohash,
      },
      data,
    });
    return user;
  } catch (error) {
    console.log(error);
    return null;
  }
};
