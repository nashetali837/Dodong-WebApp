import { REVERSE_RESOURCE_TYPE_MAP } from "../api/post/post.controller";
import { DEFAULT_USER_IMAGE } from "../utils/constants";

const resourceAdapter = (data: any) => {
  const resourceType = isNaN(data?.resourceType)
    ? data?.resourceType?.toUpperCase()
    : REVERSE_RESOURCE_TYPE_MAP[data?.resourceType];

  let categories =
    data?.ResourceCategories?.reduce((prev, category) => {
      let alreadyIncludes = prev.filter((e) => category?.categoryID === e.cID);
      return alreadyIncludes?.length > 0
        ? prev
        : [
            ...prev,
            {
              name: category?.category?.displayName,
              cID: category?.categoryID,
            },
          ];
    }, []) || [];

  let subCategories =
    data?.ResourceCategories?.reduce((prev, category) => {
      return [
        ...prev,
        {
          name: category?.subCategory?.displayName,
          scID: category?.subCategory?.id,
        },
      ];
    }, []) || [];

  return {
    resourceID: data.resourceID,
    alreadyLiked: data?.alreadyLiked || false,
    alreadySaved: data?.alreadySaved || false,
    addedToWishlist: data?.addedToWishlist || false,
    resourceType: resourceType,
    createdAt: data?.createdAt,
    categories,
    subCategories: subCategories,
    productID: data?.productID,
    location: locationAdapter(data),
    author: {
      displayName: data.author?.displayName || data.author?.name,
      userProfilePicture: data.author?.avatar || DEFAULT_USER_IMAGE,
      authorID: data.authorID || data?.author?.id,
    },
    mediaURLs: data?.ResourceMedia || [],
    post: data?.post && {
      body: data?.post?.description,
    },
    stats: {
      likes: data.totalLikes,
      comments: data.totalComments,
    },
    shop: data?.shop ? shopAdapter(data) : undefined,
    resourceDetails: data?.resourceDetails,
  };
};

const productAdapter = (data: any) => {
  return {
    productID: data?.productID,
    productName: data?.name,
    price: data?.price || 0,
    description: data?.description,
    mediaURLs: data?.ResourceMedia || [],
    shop: data?.shop ? shopAdapter(data) : undefined,
    stock: {
      available: data?.quantity || 0,
      totalQuantity: data?.quantity || 0,
    },
  };
};

const shopAdapter = (data: any) => {
  console.log("data", data?.shop);
  return {
    shopID: data?.shop?.shopID,
    name: data?.shop?.name,
    description: data?.shop?.bio,
    location: locationAdapter(data),
  };
};

const locationAdapter = (data: any) => {
  return {
    name: data?.Locations?.name,
    geohash: data?.Locations?.geohash,
    state: data?.Locations?.state,
    country: data?.Locations?.country,
  };
};

export { resourceAdapter, productAdapter, shopAdapter, locationAdapter };
