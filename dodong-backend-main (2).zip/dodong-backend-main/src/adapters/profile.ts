import { locationAdapter } from ".";
import { DEFAULT_USER_IMAGE } from "../utils/constants";

const profileAdapter = (data) => {
  return {
    profileID: data?.profileID,
    name: data?.name,
    designation: data?.designation,
    userProfilePicture: data.author?.avatar || DEFAULT_USER_IMAGE,
    dob: data?.dob,
    bio: data?.description,
    profileCompleted: data?.profileCompletedPercentage === 100,
    profileCompletedPercentage: data?.profileCompletedPercentage,
    location: locationAdapter(data),
    stats: {
      connects: data?.connects || 0,
      connecting: data?.connecting || 0,
      totalPosts: data?.totalPosts || 0,
    },
    professional: data?.professional
      ? professionalProfileAdapter(data)
      : undefined,
  };
};

const professionalProfileAdapter = (data: any) => {
  return {};
};

export { profileAdapter, professionalProfileAdapter };
