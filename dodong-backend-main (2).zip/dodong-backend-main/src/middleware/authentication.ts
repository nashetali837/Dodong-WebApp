import { Request, Response, NextFunction } from "express";
import { verifyToken } from "../api/user/user.services";

export const isUserLoggedIn = async (
  req: Request,
  res: Response,
  next: NextFunction
) => {
  // Bearers are used to authenticate users and clients.
  let bearerToken = <string>req.headers["authorization"];
  let jwtPayload;

  //Try to validate the token and get data
  try {
    const token = bearerToken.split(" ")[1];
    jwtPayload = await verifyToken(token);
    if (!jwtPayload) {
      res.status(401).json({
        message: "Unauthorized",
      });
      return;
    }

    req["locals"] = jwtPayload;

    next();
  } catch (error) {
    console.log("---", error.message);
    //If token is not valid, respond with 401 (unauthorized)
    res.status(401).json({
      message: "Unauthorized",
    });
    return;
  }
};
export const optionalLoggedIn = async (
  req: Request,
  res: Response,
  next: NextFunction
) => {
  // Bearers are used to authenticate users and clients.
  let bearerToken = req.headers?.authorization;

  let jwtPayload;

  //Try to validate the token and get data
  try {
    if (!bearerToken) {
      req["locals"] = jwtPayload;
    } else {
      const token = bearerToken.split(" ")[1];
      jwtPayload = await verifyToken(token);
      req["locals"] = jwtPayload ?? undefined;
    }
    next();
  } catch (error) {
    console.log("---", error.message);
    //If token is not valid, respond with 401 (unauthorized)
    res.status(401).json({
      message: "Unauthorized",
    });
    return;
  }
};
