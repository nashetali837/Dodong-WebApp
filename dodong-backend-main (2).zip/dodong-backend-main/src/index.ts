import express from "express";
import dotenv from "dotenv";

console.log("Selected Environment: ", process.env.NODE_ENV);

dotenv.config({
  path: process.env.NODE_ENV === "production" ? ".env.production" : ".env",
});

import expressLoader from "./loaders/express";
import { connectDatabase } from "./database";
import swaggerUi from "swagger-ui-express";
import swaggerDocument from "./swagger.json";



async function StartServer() {
  try {
    const app = express();

    // load all the Express routes
    await connectDatabase();
    await expressLoader(app);

    app.use(
      "/api",
      swaggerUi.serve,
      swaggerUi.setup(swaggerDocument, {
        explorer: true,
      })
    );

    app.listen(process.env.PORT, () => {
      console.log("Selected environment: ", process.env.NODE_ENV);
      return console.log(
        `Express Server is listening on port ${process.env.BACKEND_URL}:${process.env.PORT}`
      );
    });
  } catch (error) {
    console.log(error);
  }
}

StartServer();
