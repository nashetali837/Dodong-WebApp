import cors from "cors";
import helmet from "helmet";
import express, { Application as ExpressApplication } from "express";
import dotenv from "dotenv";
import morgan from "morgan";

// Routes
import userRoutes from "../api/user/user.routes";
import notificationRoutes from "../api/notifications/notification.routes";
import configRoutes from "../api/config/config.routes";
import authRoutes from "../api/auth/auth.routes";
import postRoutes from "../api/post/post.routes";
import resourceRoutes from "../api/resources/resources.routes";
import shopRoutes from "../api/shop/shop.routes";
import productRoutes from "../api/product/product.routes";
import userFollowRoutes from "../api/follows/follows.routes";
import commentsRoutes from "../api/comments/comments.routes";
import locationRoutes from "../api/location/location.routes";
import storefrontRoutes from "../api/storefront/storefront.routes";
import searchRoutes from "../api/search/search.routes";

export default async function ExpressLoader(app: ExpressApplication) {
  dotenv.config({
    path: process.env.NODE_ENV === "production" ? ".env.production" : ".env",
  });

  app.use(helmet());
  app.use(cors());
  app.use(express.json());
  app.use(express.urlencoded({ extended: true }));
  app.use(morgan("dev"));

  app.use("/config", configRoutes);

  app.use("/auth", authRoutes);

  app.use("/users", userRoutes);

  app.use("/notifications", notificationRoutes);

  app.use("/follow", userFollowRoutes);

  app.use("/posts", postRoutes);

  app.use("/resources", resourceRoutes);

  app.use("/comments", commentsRoutes);

  app.use("/locations", locationRoutes);

  app.use("/shops", shopRoutes);

  app.use("/products", productRoutes);

  app.use("/storefront", storefrontRoutes);

  app.use("/search", searchRoutes);

  app.get("/health", (_, res) => {
    res.json({
      status: "ok",
    });
  });

  return app;
}
