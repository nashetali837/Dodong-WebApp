import geohash from "ngeohash";

export const GEOHASH_PRECISION = 9;

export const encodeLocation = (location: {
  latitude: number;
  longitude: number;
}): string => {
  const latlong: string = geohash.encode(location.latitude, location.longitude);
  return latlong;
};

export const getDistanceBetweenGeohash = async (
  geohash1: string,
  geohash2: string
): Promise<number> => {
  const location1 = geohash.decode(geohash1);
  const location2 = geohash.decode(geohash2);

  return 2;
};
