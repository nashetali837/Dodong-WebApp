export const ResponseWithSuccess = (body: any): IResponse => {
  return {
    status: "success",
    ...body,
  };
};

export const ResponseWithFailure = (body: any): IResponse => {
  return {
    status: "error",
    ...body,
  };
};

interface IResponse {
  status: "error" | "success";
  body: any;
}
