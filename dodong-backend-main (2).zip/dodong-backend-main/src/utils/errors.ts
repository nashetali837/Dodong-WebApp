const ERRORS = {
  SOMETHING_WENT_WRONG: "SOMETHING_WENT_WRONG",
  SOMETHING_WENT_WRONG_PLEASE_TRY_AGAIN:
    "Something went wrong, please try again",
};
export default ERRORS;
