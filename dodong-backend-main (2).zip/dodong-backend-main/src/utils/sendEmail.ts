///Helpers
import AWS from "aws-sdk";

AWS.config.update({ region: "ap-south-1" });

const sendEmail = ({
  to_address,
  from_address,
  message,
  body = "",
  subject,
}) => {
  return new Promise((resolve, reject) => {
    // Create sendTemplatedEmail params
    console.log("in email");
    let params = {
      Destination: {
        /* required */
        // CcAddresses: [
        //   "EMAIL_ADDRESS",
        //   /* more CC email addresses */
        // ],
        ToAddresses: [
          to_address,
          /* more To email addresses */
        ],
      },
      Source: from_address /* required */,
      Message: {
        /* required */
        Body: {
          /* required */
          Html: {
            Charset: "UTF-8",
            Data: message,
          },
          Text: {
            Charset: "UTF-8",
            Data: body,
          },
        },
        Subject: {
          Charset: "UTF-8",
          Data: subject,
        },
      },
    };

    // Create the promise and SES service object
    let sendPromise = new AWS.SES({
      apiVersion: "2010-12-01",
      accessKeyId: process.env.aws_access_key_id,
      secretAccessKey: process.env.aws_secret_access_key,
    })
      .sendEmail(params)
      .promise();

    // Handle promise's fulfilled/rejected states
    sendPromise
      .then(function (data) {
        resolve({ data, error: null });
      })
      .catch(function (err) {
        console.error(err, err.stack);
        reject({ err });
      });
  });
};

export { sendEmail };
