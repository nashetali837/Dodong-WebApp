sudo npm install pm2@latest -g
echo "PM2 installed..."
pm2 startup
