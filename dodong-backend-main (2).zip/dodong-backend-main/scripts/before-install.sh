npm i
echo "Packages updated"