git pull origin main
npm i
echo "Preparing Build files..."
npx prisma migrate dev
npm run pre-start
pm2 start dist/src/index.js --name server
pm2 restart dist/src/index.js --name server --update-env
echo "Deployment successful"