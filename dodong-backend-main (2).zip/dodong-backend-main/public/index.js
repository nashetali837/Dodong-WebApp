const pincodes = require("./pincodes.json");

const fs = require("fs");

let cities = {};
// cities by state
for (const pincode of pincodes) {
  console.log(pincode.Pincode);
  let pin = {
    pincode: pincode.Pincode,
    taluk: pincode.District,
  };

  if (cities[pincode.StateName]) {
    cities[pincode.StateName].push(pin);
  } else {
    cities[pincode.StateName] = [pin];
  }
}
//
const final = [];
for (let state in cities) {
  final.push({
    [state]: cities[state],
  });
}
console.log(final);
