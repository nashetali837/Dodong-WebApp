-- AlterTable
ALTER TABLE "resource_comments" ADD COLUMN     "profileId" INTEGER NOT NULL DEFAULT 2;

-- AddForeignKey
ALTER TABLE "resource_comments" ADD CONSTRAINT "resource_comments_profileId_fkey" FOREIGN KEY ("profileId") REFERENCES "user_profiles"("id") ON DELETE RESTRICT ON UPDATE CASCADE;
