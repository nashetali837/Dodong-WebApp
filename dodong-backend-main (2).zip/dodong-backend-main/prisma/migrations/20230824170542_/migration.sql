/*
  Warnings:

  - You are about to drop the column `categoryID` on the `shops` table. All the data in the column will be lost.
  - You are about to drop the column `subCategoryID` on the `shops` table. All the data in the column will be lost.

*/
-- DropForeignKey
ALTER TABLE "shops" DROP CONSTRAINT "shops_categoryID_fkey";

-- DropForeignKey
ALTER TABLE "shops" DROP CONSTRAINT "shops_subCategoryID_fkey";

-- AlterTable
ALTER TABLE "shops" DROP COLUMN "categoryID",
DROP COLUMN "subCategoryID";
