-- AlterTable
ALTER TABLE "products" ALTER COLUMN "authorID" DROP DEFAULT;
