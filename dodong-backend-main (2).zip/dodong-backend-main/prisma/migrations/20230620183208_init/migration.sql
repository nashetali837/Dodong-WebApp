/*
  Warnings:

  - You are about to drop the column `authorId` on the `resource_collections` table. All the data in the column will be lost.
  - You are about to drop the column `collectionDescription` on the `resource_collections` table. All the data in the column will be lost.
  - You are about to drop the column `collectionTitle` on the `resource_collections` table. All the data in the column will be lost.
  - The primary key for the `resource_comments` table will be changed. If it partially fails, the table could be left without primary key constraint.
  - You are about to drop the column `postId` on the `resource_comments` table. All the data in the column will be lost.
  - You are about to drop the column `authorId` on the `resource_discoveries` table. All the data in the column will be lost.
  - You are about to drop the column `tags` on the `resource_discoveries` table. All the data in the column will be lost.
  - You are about to drop the column `postId` on the `resource_likes` table. All the data in the column will be lost.
  - You are about to drop the column `image` on the `resource_media` table. All the data in the column will be lost.
  - You are about to drop the column `postId` on the `resource_media` table. All the data in the column will be lost.
  - You are about to drop the column `userId` on the `resource_media` table. All the data in the column will be lost.
  - You are about to drop the column `authorId` on the `resource_posts` table. All the data in the column will be lost.
  - You are about to drop the column `categoryId` on the `resource_posts` table. All the data in the column will be lost.
  - You are about to drop the column `createdAt` on the `resource_posts` table. All the data in the column will be lost.
  - You are about to drop the column `locationsId` on the `resource_posts` table. All the data in the column will be lost.
  - You are about to drop the column `productId` on the `resource_posts` table. All the data in the column will be lost.
  - You are about to drop the column `shopId` on the `resource_posts` table. All the data in the column will be lost.
  - You are about to drop the column `subCategoryId` on the `resource_posts` table. All the data in the column will be lost.
  - You are about to drop the column `type` on the `resource_posts` table. All the data in the column will be lost.
  - You are about to drop the column `updatedAt` on the `resource_posts` table. All the data in the column will be lost.
  - The primary key for the `resource_tags` table will be changed. If it partially fails, the table could be left without primary key constraint.
  - You are about to drop the column `assignedById` on the `resource_tags` table. All the data in the column will be lost.
  - You are about to drop the column `postId` on the `resource_tags` table. All the data in the column will be lost.
  - You are about to drop the column `locationID` on the `resources` table. All the data in the column will be lost.
  - You are about to drop the column `professionalProfileId` on the `users` table. All the data in the column will be lost.
  - You are about to drop the column `userType` on the `users` table. All the data in the column will be lost.
  - You are about to drop the `Follows` table. If the table is not empty, all the data it contains will be lost.
  - You are about to drop the `Profile` table. If the table is not empty, all the data it contains will be lost.
  - You are about to drop the `comments` table. If the table is not empty, all the data it contains will be lost.
  - You are about to drop the `notifications` table. If the table is not empty, all the data it contains will be lost.
  - You are about to drop the `users_professional` table. If the table is not empty, all the data it contains will be lost.
  - Added the required column `resourceID` to the `resource_collections` table without a default value. This is not possible if the table is not empty.
  - Added the required column `resourceID` to the `resource_comments` table without a default value. This is not possible if the table is not empty.
  - Added the required column `resourceID` to the `resource_discoveries` table without a default value. This is not possible if the table is not empty.
  - Added the required column `resourceID` to the `resource_likes` table without a default value. This is not possible if the table is not empty.
  - Added the required column `mediaURL` to the `resource_media` table without a default value. This is not possible if the table is not empty.
  - Added the required column `resourceID` to the `resource_posts` table without a default value. This is not possible if the table is not empty.
  - Added the required column `resourceID` to the `resource_tags` table without a default value. This is not possible if the table is not empty.
  - Added the required column `userTypeID` to the `users` table without a default value. This is not possible if the table is not empty.

*/
-- DropForeignKey
ALTER TABLE "Follows" DROP CONSTRAINT "Follows_followerId_fkey";

-- DropForeignKey
ALTER TABLE "Follows" DROP CONSTRAINT "Follows_followingId_fkey";

-- DropForeignKey
ALTER TABLE "Profile" DROP CONSTRAINT "Profile_locationId_fkey";

-- DropForeignKey
ALTER TABLE "Profile" DROP CONSTRAINT "Profile_userId_fkey";

-- DropForeignKey
ALTER TABLE "comments" DROP CONSTRAINT "comments_authorId_fkey";

-- DropForeignKey
ALTER TABLE "comments" DROP CONSTRAINT "comments_postId_fkey";

-- DropForeignKey
ALTER TABLE "notifications" DROP CONSTRAINT "notifications_profileId_fkey";

-- DropForeignKey
ALTER TABLE "products" DROP CONSTRAINT "products_authorId_fkey";

-- DropForeignKey
ALTER TABLE "resource_collections" DROP CONSTRAINT "resource_collections_authorId_fkey";

-- DropForeignKey
ALTER TABLE "resource_comments" DROP CONSTRAINT "resource_comments_commentId_fkey";

-- DropForeignKey
ALTER TABLE "resource_comments" DROP CONSTRAINT "resource_comments_postId_fkey";

-- DropForeignKey
ALTER TABLE "resource_discoveries" DROP CONSTRAINT "resource_discoveries_authorId_fkey";

-- DropForeignKey
ALTER TABLE "resource_likes" DROP CONSTRAINT "resource_likes_postId_fkey";

-- DropForeignKey
ALTER TABLE "resource_likes" DROP CONSTRAINT "resource_likes_userId_fkey";

-- DropForeignKey
ALTER TABLE "resource_media" DROP CONSTRAINT "resource_media_postId_fkey";

-- DropForeignKey
ALTER TABLE "resource_media" DROP CONSTRAINT "resource_media_userId_fkey";

-- DropForeignKey
ALTER TABLE "resource_posts" DROP CONSTRAINT "resource_posts_authorId_fkey";

-- DropForeignKey
ALTER TABLE "resource_posts" DROP CONSTRAINT "resource_posts_categoryId_fkey";

-- DropForeignKey
ALTER TABLE "resource_posts" DROP CONSTRAINT "resource_posts_locationsId_fkey";

-- DropForeignKey
ALTER TABLE "resource_posts" DROP CONSTRAINT "resource_posts_productId_fkey";

-- DropForeignKey
ALTER TABLE "resource_posts" DROP CONSTRAINT "resource_posts_shopId_fkey";

-- DropForeignKey
ALTER TABLE "resource_posts" DROP CONSTRAINT "resource_posts_subCategoryId_fkey";

-- DropForeignKey
ALTER TABLE "resource_tags" DROP CONSTRAINT "resource_tags_assignedById_fkey";

-- DropForeignKey
ALTER TABLE "resource_tags" DROP CONSTRAINT "resource_tags_postId_fkey";

-- DropForeignKey
ALTER TABLE "user_measurements" DROP CONSTRAINT "user_measurements_authorId_fkey";

-- DropForeignKey
ALTER TABLE "users" DROP CONSTRAINT "users_professionalProfileId_fkey";

-- DropForeignKey
ALTER TABLE "users_professional" DROP CONSTRAINT "users_professional_locationId_fkey";

-- DropForeignKey
ALTER TABLE "users_professional" DROP CONSTRAINT "users_professional_profileId_fkey";

-- AlterTable
ALTER TABLE "products" ADD COLUMN     "shopId" INTEGER;

-- AlterTable
ALTER TABLE "resource_collections" DROP COLUMN "authorId",
DROP COLUMN "collectionDescription",
DROP COLUMN "collectionTitle",
ADD COLUMN     "description" TEXT DEFAULT '',
ADD COLUMN     "resourceID" INTEGER NOT NULL,
ADD COLUMN     "title" TEXT;

-- AlterTable
ALTER TABLE "resource_comments" DROP CONSTRAINT "resource_comments_pkey",
DROP COLUMN "postId",
ADD COLUMN     "postCommentId" SERIAL NOT NULL,
ADD COLUMN     "resourceID" INTEGER NOT NULL,
ADD CONSTRAINT "resource_comments_pkey" PRIMARY KEY ("postCommentId");

-- AlterTable
ALTER TABLE "resource_discoveries" DROP COLUMN "authorId",
DROP COLUMN "tags",
ADD COLUMN     "resourceID" INTEGER NOT NULL;

-- AlterTable
ALTER TABLE "resource_likes" DROP COLUMN "postId",
ADD COLUMN     "resourceID" INTEGER NOT NULL;

-- AlterTable
ALTER TABLE "resource_media" DROP COLUMN "image",
DROP COLUMN "postId",
DROP COLUMN "userId",
ADD COLUMN     "mediaURL" TEXT NOT NULL,
ADD COLUMN     "resourceID" INTEGER;

-- AlterTable
ALTER TABLE "resource_posts" DROP COLUMN "authorId",
DROP COLUMN "categoryId",
DROP COLUMN "createdAt",
DROP COLUMN "locationsId",
DROP COLUMN "productId",
DROP COLUMN "shopId",
DROP COLUMN "subCategoryId",
DROP COLUMN "type",
DROP COLUMN "updatedAt",
ADD COLUMN     "resourceID" INTEGER NOT NULL;

-- AlterTable
ALTER TABLE "resource_tags" DROP CONSTRAINT "resource_tags_pkey",
DROP COLUMN "assignedById",
DROP COLUMN "postId",
ADD COLUMN     "resourceID" INTEGER NOT NULL,
ADD COLUMN     "uID" SERIAL NOT NULL,
ADD CONSTRAINT "resource_tags_pkey" PRIMARY KEY ("uID");

-- AlterTable
ALTER TABLE "resources" DROP COLUMN "locationID",
ADD COLUMN     "categoryId" INTEGER,
ADD COLUMN     "locationsId" INTEGER,
ADD COLUMN     "productId" INTEGER,
ADD COLUMN     "shopId" INTEGER,
ADD COLUMN     "subCategoryId" INTEGER,
ADD COLUMN     "updatedAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP;

-- AlterTable
ALTER TABLE "users" DROP COLUMN "professionalProfileId",
DROP COLUMN "userType",
ADD COLUMN     "userTypeID" INTEGER NOT NULL;

-- DropTable
DROP TABLE "Follows";

-- DropTable
DROP TABLE "Profile";

-- DropTable
DROP TABLE "comments";

-- DropTable
DROP TABLE "notifications";

-- DropTable
DROP TABLE "users_professional";

-- DropEnum
DROP TYPE "Role";

-- CreateTable
CREATE TABLE "m_user_types" (
    "userTypeID" SERIAL NOT NULL,
    "userType" TEXT NOT NULL,
    "description" TEXT,
    "isActive" BOOLEAN NOT NULL DEFAULT true,
    "image" TEXT,
    "order" INTEGER NOT NULL DEFAULT 0,

    CONSTRAINT "m_user_types_pkey" PRIMARY KEY ("userTypeID")
);

-- CreateTable
CREATE TABLE "user_profiles" (
    "id" SERIAL NOT NULL,
    "userId" INTEGER NOT NULL,
    "name" TEXT,
    "displayName" TEXT,
    "occupation" TEXT,
    "bio" TEXT,
    "dateOfBirth" TEXT,
    "avatar" TEXT,
    "facebookURL" TEXT,
    "LinkedInURL" TEXT,
    "twitterHandle" TEXT,
    "locationId" INTEGER,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "user_profiles_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "user_professional_profiles" (
    "id" SERIAL NOT NULL,
    "name" TEXT,
    "officialMobileNumber" TEXT,
    "occupationType" TEXT,
    "companyName" TEXT,
    "jobLocation" TEXT,
    "brandDetails" TEXT,
    "others" TEXT,
    "locationId" INTEGER,
    "profileId" INTEGER NOT NULL,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "user_professional_profiles_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "profile_settings" (
    "profileId" INTEGER NOT NULL,
    "publicProfile" BOOLEAN NOT NULL DEFAULT false,
    "publicProfessionalProfile" BOOLEAN NOT NULL DEFAULT false,
    "privateFields" JSONB DEFAULT '{}'
);

-- CreateTable
CREATE TABLE "user_follows" (
    "followerId" INTEGER NOT NULL,
    "followingId" INTEGER NOT NULL,

    CONSTRAINT "user_follows_pkey" PRIMARY KEY ("followerId","followingId")
);

-- CreateTable
CREATE TABLE "user_notifications" (
    "notificationId" SERIAL NOT NULL,
    "title" TEXT NOT NULL,
    "content" TEXT NOT NULL,
    "isNotificationRead" BOOLEAN NOT NULL DEFAULT false,
    "profileId" INTEGER NOT NULL,
    "notificationType" TEXT NOT NULL,
    "notificationURL" TEXT,
    "moreInformation" JSONB,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "user_notifications_pkey" PRIMARY KEY ("notificationId")
);

-- CreateIndex
CREATE UNIQUE INDEX "m_user_types_userType_key" ON "m_user_types"("userType");

-- CreateIndex
CREATE UNIQUE INDEX "user_profiles_userId_key" ON "user_profiles"("userId");

-- CreateIndex
CREATE UNIQUE INDEX "user_professional_profiles_profileId_key" ON "user_professional_profiles"("profileId");

-- CreateIndex
CREATE UNIQUE INDEX "profile_settings_profileId_key" ON "profile_settings"("profileId");

-- AddForeignKey
ALTER TABLE "users" ADD CONSTRAINT "users_userTypeID_fkey" FOREIGN KEY ("userTypeID") REFERENCES "m_user_types"("userTypeID") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "user_profiles" ADD CONSTRAINT "user_profiles_userId_fkey" FOREIGN KEY ("userId") REFERENCES "users"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "user_profiles" ADD CONSTRAINT "user_profiles_locationId_fkey" FOREIGN KEY ("locationId") REFERENCES "locations"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "user_professional_profiles" ADD CONSTRAINT "user_professional_profiles_profileId_fkey" FOREIGN KEY ("profileId") REFERENCES "user_profiles"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "user_professional_profiles" ADD CONSTRAINT "user_professional_profiles_locationId_fkey" FOREIGN KEY ("locationId") REFERENCES "locations"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "profile_settings" ADD CONSTRAINT "profile_settings_profileId_fkey" FOREIGN KEY ("profileId") REFERENCES "user_profiles"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "user_follows" ADD CONSTRAINT "user_follows_followingId_fkey" FOREIGN KEY ("followingId") REFERENCES "user_profiles"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "user_follows" ADD CONSTRAINT "user_follows_followerId_fkey" FOREIGN KEY ("followerId") REFERENCES "user_profiles"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "products" ADD CONSTRAINT "products_shopId_fkey" FOREIGN KEY ("shopId") REFERENCES "shops"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "products" ADD CONSTRAINT "products_authorId_fkey" FOREIGN KEY ("authorId") REFERENCES "user_profiles"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "resources" ADD CONSTRAINT "resources_categoryId_fkey" FOREIGN KEY ("categoryId") REFERENCES "categories"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "resources" ADD CONSTRAINT "resources_productId_fkey" FOREIGN KEY ("productId") REFERENCES "products"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "resources" ADD CONSTRAINT "resources_subCategoryId_fkey" FOREIGN KEY ("subCategoryId") REFERENCES "sub_categories"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "resources" ADD CONSTRAINT "resources_shopId_fkey" FOREIGN KEY ("shopId") REFERENCES "shops"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "resources" ADD CONSTRAINT "resources_authorID_fkey" FOREIGN KEY ("authorID") REFERENCES "user_profiles"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "resources" ADD CONSTRAINT "resources_locationsId_fkey" FOREIGN KEY ("locationsId") REFERENCES "locations"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "resource_posts" ADD CONSTRAINT "resource_posts_resourceID_fkey" FOREIGN KEY ("resourceID") REFERENCES "resources"("resourceID") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "resource_discoveries" ADD CONSTRAINT "resource_discoveries_resourceID_fkey" FOREIGN KEY ("resourceID") REFERENCES "resources"("resourceID") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "resource_collections" ADD CONSTRAINT "resource_collections_resourceID_fkey" FOREIGN KEY ("resourceID") REFERENCES "resources"("resourceID") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "user_measurements" ADD CONSTRAINT "user_measurements_authorId_fkey" FOREIGN KEY ("authorId") REFERENCES "user_profiles"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "resource_media" ADD CONSTRAINT "resource_media_resourceID_fkey" FOREIGN KEY ("resourceID") REFERENCES "resources"("resourceID") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "resource_tags" ADD CONSTRAINT "resource_tags_resourceID_fkey" FOREIGN KEY ("resourceID") REFERENCES "resources"("resourceID") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "resource_likes" ADD CONSTRAINT "resource_likes_resourceID_fkey" FOREIGN KEY ("resourceID") REFERENCES "resources"("resourceID") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "resource_likes" ADD CONSTRAINT "resource_likes_userId_fkey" FOREIGN KEY ("userId") REFERENCES "user_profiles"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "resource_comments" ADD CONSTRAINT "resource_comments_resourceID_fkey" FOREIGN KEY ("resourceID") REFERENCES "resources"("resourceID") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "user_notifications" ADD CONSTRAINT "user_notifications_profileId_fkey" FOREIGN KEY ("profileId") REFERENCES "user_profiles"("id") ON DELETE RESTRICT ON UPDATE CASCADE;
