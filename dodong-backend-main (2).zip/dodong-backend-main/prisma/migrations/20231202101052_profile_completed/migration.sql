-- AlterTable
ALTER TABLE "user_profiles" ADD COLUMN     "isProfileCompleted" BOOLEAN DEFAULT false;
