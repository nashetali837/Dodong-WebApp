-- AlterTable
ALTER TABLE "users" ALTER COLUMN "userTypeID" SET DEFAULT 2;
