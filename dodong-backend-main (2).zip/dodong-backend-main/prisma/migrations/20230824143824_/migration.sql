/*
  Warnings:

  - You are about to drop the column `profileId` on the `profile_settings` table. All the data in the column will be lost.
  - You are about to drop the column `profileId` on the `resource_comments` table. All the data in the column will be lost.
  - You are about to drop the column `authorId` on the `user_measurements` table. All the data in the column will be lost.
  - You are about to drop the column `profileId` on the `user_notifications` table. All the data in the column will be lost.
  - You are about to drop the column `profileId` on the `user_professional_profiles` table. All the data in the column will be lost.
  - The primary key for the `user_profiles` table will be changed. If it partially fails, the table could be left without primary key constraint.
  - You are about to drop the column `id` on the `user_profiles` table. All the data in the column will be lost.
  - You are about to drop the column `userId` on the `user_profiles` table. All the data in the column will be lost.
  - A unique constraint covering the columns `[profileID]` on the table `profile_settings` will be added. If there are existing duplicate values, this will fail.
  - A unique constraint covering the columns `[profileID]` on the table `user_professional_profiles` will be added. If there are existing duplicate values, this will fail.
  - A unique constraint covering the columns `[userID]` on the table `user_profiles` will be added. If there are existing duplicate values, this will fail.
  - Added the required column `profileID` to the `profile_settings` table without a default value. This is not possible if the table is not empty.
  - Added the required column `authorID` to the `user_measurements` table without a default value. This is not possible if the table is not empty.
  - Added the required column `profileID` to the `user_notifications` table without a default value. This is not possible if the table is not empty.
  - Added the required column `profileID` to the `user_professional_profiles` table without a default value. This is not possible if the table is not empty.
  - Added the required column `userID` to the `user_profiles` table without a default value. This is not possible if the table is not empty.

*/
-- DropForeignKey
ALTER TABLE "products" DROP CONSTRAINT "products_authorId_fkey";

-- DropForeignKey
ALTER TABLE "profile_settings" DROP CONSTRAINT "profile_settings_profileId_fkey";

-- DropForeignKey
ALTER TABLE "resource_comments" DROP CONSTRAINT "resource_comments_profileId_fkey";

-- DropForeignKey
ALTER TABLE "resource_likes" DROP CONSTRAINT "resource_likes_userId_fkey";

-- DropForeignKey
ALTER TABLE "resources" DROP CONSTRAINT "resources_authorID_fkey";

-- DropForeignKey
ALTER TABLE "user_follows" DROP CONSTRAINT "user_follows_followerId_fkey";

-- DropForeignKey
ALTER TABLE "user_follows" DROP CONSTRAINT "user_follows_followingId_fkey";

-- DropForeignKey
ALTER TABLE "user_measurements" DROP CONSTRAINT "user_measurements_authorId_fkey";

-- DropForeignKey
ALTER TABLE "user_notifications" DROP CONSTRAINT "user_notifications_profileId_fkey";

-- DropForeignKey
ALTER TABLE "user_professional_profiles" DROP CONSTRAINT "user_professional_profiles_profileId_fkey";

-- DropForeignKey
ALTER TABLE "user_profiles" DROP CONSTRAINT "user_profiles_userId_fkey";

-- DropIndex
DROP INDEX "profile_settings_profileId_key";

-- DropIndex
DROP INDEX "user_professional_profiles_profileId_key";

-- DropIndex
DROP INDEX "user_profiles_userId_key";

-- AlterTable
ALTER TABLE "profile_settings" DROP COLUMN "profileId",
ADD COLUMN     "profileID" INTEGER NOT NULL;

-- AlterTable
ALTER TABLE "resource_comments" DROP COLUMN "profileId",
ADD COLUMN     "profileID" INTEGER NOT NULL DEFAULT 2;

-- AlterTable
ALTER TABLE "user_measurements" DROP COLUMN "authorId",
ADD COLUMN     "authorID" INTEGER NOT NULL;

-- AlterTable
ALTER TABLE "user_notifications" DROP COLUMN "profileId",
ADD COLUMN     "profileID" INTEGER NOT NULL;

-- AlterTable
ALTER TABLE "user_professional_profiles" DROP COLUMN "profileId",
ADD COLUMN     "profileID" INTEGER NOT NULL;

-- AlterTable
ALTER TABLE "user_profiles" DROP CONSTRAINT "user_profiles_pkey",
DROP COLUMN "id",
DROP COLUMN "userId",
ADD COLUMN     "userID" INTEGER NOT NULL,
ADD COLUMN     "userProfileID" SERIAL NOT NULL,
ADD CONSTRAINT "user_profiles_pkey" PRIMARY KEY ("userProfileID");

-- AlterTable
ALTER TABLE "users" ADD COLUMN     "socialLogin" TEXT DEFAULT 'CUSTOM',
ALTER COLUMN "password" DROP NOT NULL;

-- CreateIndex
CREATE UNIQUE INDEX "profile_settings_profileID_key" ON "profile_settings"("profileID");

-- CreateIndex
CREATE UNIQUE INDEX "user_professional_profiles_profileID_key" ON "user_professional_profiles"("profileID");

-- CreateIndex
CREATE UNIQUE INDEX "user_profiles_userID_key" ON "user_profiles"("userID");

-- AddForeignKey
ALTER TABLE "user_profiles" ADD CONSTRAINT "user_profiles_userID_fkey" FOREIGN KEY ("userID") REFERENCES "users"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "user_professional_profiles" ADD CONSTRAINT "user_professional_profiles_profileID_fkey" FOREIGN KEY ("profileID") REFERENCES "user_profiles"("userProfileID") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "profile_settings" ADD CONSTRAINT "profile_settings_profileID_fkey" FOREIGN KEY ("profileID") REFERENCES "user_profiles"("userProfileID") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "user_follows" ADD CONSTRAINT "user_follows_followingId_fkey" FOREIGN KEY ("followingId") REFERENCES "user_profiles"("userProfileID") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "user_follows" ADD CONSTRAINT "user_follows_followerId_fkey" FOREIGN KEY ("followerId") REFERENCES "user_profiles"("userProfileID") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "products" ADD CONSTRAINT "products_authorId_fkey" FOREIGN KEY ("authorId") REFERENCES "user_profiles"("userProfileID") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "resources" ADD CONSTRAINT "resources_authorID_fkey" FOREIGN KEY ("authorID") REFERENCES "user_profiles"("userProfileID") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "user_measurements" ADD CONSTRAINT "user_measurements_authorID_fkey" FOREIGN KEY ("authorID") REFERENCES "user_profiles"("userProfileID") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "resource_likes" ADD CONSTRAINT "resource_likes_userId_fkey" FOREIGN KEY ("userId") REFERENCES "user_profiles"("userProfileID") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "resource_comments" ADD CONSTRAINT "resource_comments_profileID_fkey" FOREIGN KEY ("profileID") REFERENCES "user_profiles"("userProfileID") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "user_notifications" ADD CONSTRAINT "user_notifications_profileID_fkey" FOREIGN KEY ("profileID") REFERENCES "user_profiles"("userProfileID") ON DELETE RESTRICT ON UPDATE CASCADE;
