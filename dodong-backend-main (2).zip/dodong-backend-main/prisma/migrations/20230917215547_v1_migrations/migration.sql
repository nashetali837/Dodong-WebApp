-- AlterTable
ALTER TABLE "products" ALTER COLUMN "authorID" SET DEFAULT 1;
