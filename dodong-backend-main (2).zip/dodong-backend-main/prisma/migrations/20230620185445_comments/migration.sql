/*
  Warnings:

  - The primary key for the `resource_comments` table will be changed. If it partially fails, the table could be left without primary key constraint.
  - You are about to drop the column `commentId` on the `resource_comments` table. All the data in the column will be lost.
  - You are about to drop the column `postCommentId` on the `resource_comments` table. All the data in the column will be lost.
  - Added the required column `body` to the `resource_comments` table without a default value. This is not possible if the table is not empty.

*/
-- AlterTable
ALTER TABLE "resource_comments" DROP CONSTRAINT "resource_comments_pkey",
DROP COLUMN "commentId",
DROP COLUMN "postCommentId",
ADD COLUMN     "body" TEXT NOT NULL,
ADD COLUMN     "commentID" SERIAL NOT NULL,
ADD CONSTRAINT "resource_comments_pkey" PRIMARY KEY ("commentID");
