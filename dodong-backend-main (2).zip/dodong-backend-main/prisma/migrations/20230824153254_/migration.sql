/*
  Warnings:

  - The primary key for the `locations` table will be changed. If it partially fails, the table could be left without primary key constraint.
  - You are about to drop the column `id` on the `locations` table. All the data in the column will be lost.
  - The primary key for the `products` table will be changed. If it partially fails, the table could be left without primary key constraint.
  - You are about to drop the column `authorId` on the `products` table. All the data in the column will be lost.
  - You are about to drop the column `categoryId` on the `products` table. All the data in the column will be lost.
  - You are about to drop the column `id` on the `products` table. All the data in the column will be lost.
  - You are about to drop the column `name` on the `products` table. All the data in the column will be lost.
  - You are about to drop the column `shopId` on the `products` table. All the data in the column will be lost.
  - You are about to drop the column `subCategoryId` on the `products` table. All the data in the column will be lost.
  - The primary key for the `resource_collections` table will be changed. If it partially fails, the table could be left without primary key constraint.
  - You are about to drop the column `collectionId` on the `resource_collections` table. All the data in the column will be lost.
  - You are about to drop the column `profileID` on the `resource_comments` table. All the data in the column will be lost.
  - The primary key for the `resource_discoveries` table will be changed. If it partially fails, the table could be left without primary key constraint.
  - You are about to drop the column `discoveryId` on the `resource_discoveries` table. All the data in the column will be lost.
  - You are about to drop the column `updatedAt` on the `resource_likes` table. All the data in the column will be lost.
  - You are about to drop the column `userId` on the `resource_likes` table. All the data in the column will be lost.
  - You are about to drop the column `type` on the `resource_media` table. All the data in the column will be lost.
  - You are about to drop the column `updatedAt` on the `resource_media` table. All the data in the column will be lost.
  - The primary key for the `resource_posts` table will be changed. If it partially fails, the table could be left without primary key constraint.
  - You are about to drop the column `id` on the `resource_posts` table. All the data in the column will be lost.
  - You are about to drop the column `tagId` on the `resource_tags` table. All the data in the column will be lost.
  - You are about to drop the column `categoryId` on the `resources` table. All the data in the column will be lost.
  - You are about to drop the column `locationsId` on the `resources` table. All the data in the column will be lost.
  - You are about to drop the column `productId` on the `resources` table. All the data in the column will be lost.
  - You are about to drop the column `shopId` on the `resources` table. All the data in the column will be lost.
  - You are about to drop the column `subCategoryId` on the `resources` table. All the data in the column will be lost.
  - The primary key for the `shops` table will be changed. If it partially fails, the table could be left without primary key constraint.
  - You are about to drop the column `categoryId` on the `shops` table. All the data in the column will be lost.
  - You are about to drop the column `id` on the `shops` table. All the data in the column will be lost.
  - You are about to drop the column `locationId` on the `shops` table. All the data in the column will be lost.
  - You are about to drop the column `subCategoryId` on the `shops` table. All the data in the column will be lost.
  - You are about to drop the column `categoryId` on the `sub_categories` table. All the data in the column will be lost.
  - The primary key for the `tags` table will be changed. If it partially fails, the table could be left without primary key constraint.
  - You are about to drop the column `id` on the `tags` table. All the data in the column will be lost.
  - You are about to drop the column `size` on the `user_measurements` table. All the data in the column will be lost.
  - The primary key for the `user_notifications` table will be changed. If it partially fails, the table could be left without primary key constraint.
  - You are about to drop the column `notificationId` on the `user_notifications` table. All the data in the column will be lost.
  - You are about to drop the column `profileID` on the `user_notifications` table. All the data in the column will be lost.
  - You are about to drop the column `locationId` on the `user_professional_profiles` table. All the data in the column will be lost.
  - You are about to drop the column `locationId` on the `user_profiles` table. All the data in the column will be lost.
  - A unique constraint covering the columns `[userProfileID,resourceID]` on the table `resource_likes` will be added. If there are existing duplicate values, this will fail.
  - Added the required column `productName` to the `products` table without a default value. This is not possible if the table is not empty.
  - Added the required column `userProfileID` to the `resource_likes` table without a default value. This is not possible if the table is not empty.
  - Added the required column `tagID` to the `resource_tags` table without a default value. This is not possible if the table is not empty.
  - Added the required column `createdBy` to the `shops` table without a default value. This is not possible if the table is not empty.
  - Added the required column `categoryID` to the `sub_categories` table without a default value. This is not possible if the table is not empty.
  - Added the required column `userProfileID` to the `user_notifications` table without a default value. This is not possible if the table is not empty.

*/
-- DropForeignKey
ALTER TABLE "products" DROP CONSTRAINT "products_authorId_fkey";

-- DropForeignKey
ALTER TABLE "products" DROP CONSTRAINT "products_categoryId_fkey";

-- DropForeignKey
ALTER TABLE "products" DROP CONSTRAINT "products_shopId_fkey";

-- DropForeignKey
ALTER TABLE "products" DROP CONSTRAINT "products_subCategoryId_fkey";

-- DropForeignKey
ALTER TABLE "resource_comments" DROP CONSTRAINT "resource_comments_profileID_fkey";

-- DropForeignKey
ALTER TABLE "resource_likes" DROP CONSTRAINT "resource_likes_userId_fkey";

-- DropForeignKey
ALTER TABLE "resource_tags" DROP CONSTRAINT "resource_tags_tagId_fkey";

-- DropForeignKey
ALTER TABLE "resources" DROP CONSTRAINT "resources_categoryId_fkey";

-- DropForeignKey
ALTER TABLE "resources" DROP CONSTRAINT "resources_locationsId_fkey";

-- DropForeignKey
ALTER TABLE "resources" DROP CONSTRAINT "resources_productId_fkey";

-- DropForeignKey
ALTER TABLE "resources" DROP CONSTRAINT "resources_shopId_fkey";

-- DropForeignKey
ALTER TABLE "resources" DROP CONSTRAINT "resources_subCategoryId_fkey";

-- DropForeignKey
ALTER TABLE "shops" DROP CONSTRAINT "shops_categoryId_fkey";

-- DropForeignKey
ALTER TABLE "shops" DROP CONSTRAINT "shops_locationId_fkey";

-- DropForeignKey
ALTER TABLE "shops" DROP CONSTRAINT "shops_subCategoryId_fkey";

-- DropForeignKey
ALTER TABLE "sub_categories" DROP CONSTRAINT "sub_categories_categoryId_fkey";

-- DropForeignKey
ALTER TABLE "user_notifications" DROP CONSTRAINT "user_notifications_profileID_fkey";

-- DropForeignKey
ALTER TABLE "user_professional_profiles" DROP CONSTRAINT "user_professional_profiles_locationId_fkey";

-- DropForeignKey
ALTER TABLE "user_profiles" DROP CONSTRAINT "user_profiles_locationId_fkey";

-- DropIndex
DROP INDEX "resource_likes_userId_resourceID_key";

-- AlterTable
ALTER TABLE "locations" DROP CONSTRAINT "locations_pkey",
DROP COLUMN "id",
ADD CONSTRAINT "locations_pkey" PRIMARY KEY ("geohash");

-- AlterTable
ALTER TABLE "products" DROP CONSTRAINT "products_pkey",
DROP COLUMN "authorId",
DROP COLUMN "categoryId",
DROP COLUMN "id",
DROP COLUMN "name",
DROP COLUMN "shopId",
DROP COLUMN "subCategoryId",
ADD COLUMN     "authorID" INTEGER NOT NULL DEFAULT 1,
ADD COLUMN     "productID" SERIAL NOT NULL,
ADD COLUMN     "productName" TEXT NOT NULL,
ADD COLUMN     "shopID" INTEGER,
ADD COLUMN     "size" TEXT DEFAULT 'NA',
ALTER COLUMN "weight" SET DEFAULT 0.0,
ADD CONSTRAINT "products_pkey" PRIMARY KEY ("productID");

-- AlterTable
ALTER TABLE "resource_collections" DROP CONSTRAINT "resource_collections_pkey",
DROP COLUMN "collectionId",
ADD COLUMN     "collectionID" SERIAL NOT NULL,
ADD CONSTRAINT "resource_collections_pkey" PRIMARY KEY ("collectionID");

-- AlterTable
ALTER TABLE "resource_comments" DROP COLUMN "profileID",
ADD COLUMN     "userProfileID" INTEGER NOT NULL DEFAULT 2;

-- AlterTable
ALTER TABLE "resource_discoveries" DROP CONSTRAINT "resource_discoveries_pkey",
DROP COLUMN "discoveryId",
ADD COLUMN     "discoveryID" SERIAL NOT NULL,
ADD CONSTRAINT "resource_discoveries_pkey" PRIMARY KEY ("discoveryID");

-- AlterTable
ALTER TABLE "resource_likes" DROP COLUMN "updatedAt",
DROP COLUMN "userId",
ADD COLUMN     "userProfileID" INTEGER NOT NULL;

-- AlterTable
ALTER TABLE "resource_media" DROP COLUMN "type",
DROP COLUMN "updatedAt",
ADD COLUMN     "mediaType" TEXT;

-- AlterTable
ALTER TABLE "resource_posts" DROP CONSTRAINT "resource_posts_pkey",
DROP COLUMN "id",
ADD COLUMN     "postID" SERIAL NOT NULL,
ADD CONSTRAINT "resource_posts_pkey" PRIMARY KEY ("postID");

-- AlterTable
ALTER TABLE "resource_tags" DROP COLUMN "tagId",
ADD COLUMN     "tagID" INTEGER NOT NULL;

-- AlterTable
ALTER TABLE "resources" DROP COLUMN "categoryId",
DROP COLUMN "locationsId",
DROP COLUMN "productId",
DROP COLUMN "shopId",
DROP COLUMN "subCategoryId",
ADD COLUMN     "geohash" TEXT,
ADD COLUMN     "productID" INTEGER,
ADD COLUMN     "shopID" INTEGER;

-- AlterTable
ALTER TABLE "shops" DROP CONSTRAINT "shops_pkey",
DROP COLUMN "categoryId",
DROP COLUMN "id",
DROP COLUMN "locationId",
DROP COLUMN "subCategoryId",
ADD COLUMN     "categoryID" INTEGER,
ADD COLUMN     "createdBy" INTEGER NOT NULL,
ADD COLUMN     "geohash" TEXT,
ADD COLUMN     "isClaimed" BOOLEAN NOT NULL DEFAULT false,
ADD COLUMN     "shopID" SERIAL NOT NULL,
ADD COLUMN     "subCategoryID" INTEGER,
ADD CONSTRAINT "shops_pkey" PRIMARY KEY ("shopID");

-- AlterTable
ALTER TABLE "sub_categories" DROP COLUMN "categoryId",
ADD COLUMN     "categoryID" INTEGER NOT NULL;

-- AlterTable
ALTER TABLE "tags" DROP CONSTRAINT "tags_pkey",
DROP COLUMN "id",
ADD COLUMN     "tagID" SERIAL NOT NULL,
ADD CONSTRAINT "tags_pkey" PRIMARY KEY ("tagID");

-- AlterTable
ALTER TABLE "user_measurements" DROP COLUMN "size",
ADD COLUMN     "forSelf" BOOLEAN NOT NULL DEFAULT false;

-- AlterTable
ALTER TABLE "user_notifications" DROP CONSTRAINT "user_notifications_pkey",
DROP COLUMN "notificationId",
DROP COLUMN "profileID",
ADD COLUMN     "notificationID" SERIAL NOT NULL,
ADD COLUMN     "userProfileID" INTEGER NOT NULL,
ADD CONSTRAINT "user_notifications_pkey" PRIMARY KEY ("notificationID");

-- AlterTable
ALTER TABLE "user_professional_profiles" DROP COLUMN "locationId",
ADD COLUMN     "businessEmail" TEXT,
ADD COLUMN     "businessLogo" TEXT,
ADD COLUMN     "businessWebsite" TEXT,
ADD COLUMN     "geohash" TEXT;

-- AlterTable
ALTER TABLE "user_profiles" DROP COLUMN "locationId",
ADD COLUMN     "geohash" TEXT;

-- CreateTable
CREATE TABLE "shop_categories" (
    "id" SERIAL NOT NULL,
    "shopID" INTEGER NOT NULL,
    "categoryID" INTEGER NOT NULL,
    "subCategoryID" INTEGER NOT NULL,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "shop_categories_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "product_categories" (
    "id" SERIAL NOT NULL,
    "productID" INTEGER NOT NULL,
    "categoryID" INTEGER NOT NULL,
    "subCategoryID" INTEGER NOT NULL,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "product_categories_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE UNIQUE INDEX "shop_categories_categoryID_shopID_subCategoryID_key" ON "shop_categories"("categoryID", "shopID", "subCategoryID");

-- CreateIndex
CREATE UNIQUE INDEX "product_categories_categoryID_productID_subCategoryID_key" ON "product_categories"("categoryID", "productID", "subCategoryID");

-- CreateIndex
CREATE UNIQUE INDEX "resource_likes_userProfileID_resourceID_key" ON "resource_likes"("userProfileID", "resourceID");

-- AddForeignKey
ALTER TABLE "sub_categories" ADD CONSTRAINT "sub_categories_categoryID_fkey" FOREIGN KEY ("categoryID") REFERENCES "categories"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "user_profiles" ADD CONSTRAINT "user_profiles_geohash_fkey" FOREIGN KEY ("geohash") REFERENCES "locations"("geohash") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "user_professional_profiles" ADD CONSTRAINT "user_professional_profiles_geohash_fkey" FOREIGN KEY ("geohash") REFERENCES "locations"("geohash") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "shops" ADD CONSTRAINT "shops_createdBy_fkey" FOREIGN KEY ("createdBy") REFERENCES "user_profiles"("userProfileID") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "shops" ADD CONSTRAINT "shops_categoryID_fkey" FOREIGN KEY ("categoryID") REFERENCES "categories"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "shops" ADD CONSTRAINT "shops_subCategoryID_fkey" FOREIGN KEY ("subCategoryID") REFERENCES "sub_categories"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "shops" ADD CONSTRAINT "shops_geohash_fkey" FOREIGN KEY ("geohash") REFERENCES "locations"("geohash") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "shop_categories" ADD CONSTRAINT "shop_categories_shopID_fkey" FOREIGN KEY ("shopID") REFERENCES "shops"("shopID") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "shop_categories" ADD CONSTRAINT "shop_categories_categoryID_fkey" FOREIGN KEY ("categoryID") REFERENCES "categories"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "shop_categories" ADD CONSTRAINT "shop_categories_subCategoryID_fkey" FOREIGN KEY ("subCategoryID") REFERENCES "sub_categories"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "products" ADD CONSTRAINT "products_shopID_fkey" FOREIGN KEY ("shopID") REFERENCES "shops"("shopID") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "products" ADD CONSTRAINT "products_authorID_fkey" FOREIGN KEY ("authorID") REFERENCES "user_profiles"("userProfileID") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "product_categories" ADD CONSTRAINT "product_categories_productID_fkey" FOREIGN KEY ("productID") REFERENCES "products"("productID") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "product_categories" ADD CONSTRAINT "product_categories_categoryID_fkey" FOREIGN KEY ("categoryID") REFERENCES "categories"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "product_categories" ADD CONSTRAINT "product_categories_subCategoryID_fkey" FOREIGN KEY ("subCategoryID") REFERENCES "sub_categories"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "resources" ADD CONSTRAINT "resources_productID_fkey" FOREIGN KEY ("productID") REFERENCES "products"("productID") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "resources" ADD CONSTRAINT "resources_shopID_fkey" FOREIGN KEY ("shopID") REFERENCES "shops"("shopID") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "resources" ADD CONSTRAINT "resources_geohash_fkey" FOREIGN KEY ("geohash") REFERENCES "locations"("geohash") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "resource_tags" ADD CONSTRAINT "resource_tags_tagID_fkey" FOREIGN KEY ("tagID") REFERENCES "tags"("tagID") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "resource_likes" ADD CONSTRAINT "resource_likes_userProfileID_fkey" FOREIGN KEY ("userProfileID") REFERENCES "user_profiles"("userProfileID") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "resource_comments" ADD CONSTRAINT "resource_comments_userProfileID_fkey" FOREIGN KEY ("userProfileID") REFERENCES "user_profiles"("userProfileID") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "user_notifications" ADD CONSTRAINT "user_notifications_userProfileID_fkey" FOREIGN KEY ("userProfileID") REFERENCES "user_profiles"("userProfileID") ON DELETE RESTRICT ON UPDATE CASCADE;
