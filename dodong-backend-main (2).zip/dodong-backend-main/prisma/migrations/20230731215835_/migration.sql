/*
  Warnings:

  - A unique constraint covering the columns `[userId,resourceID]` on the table `resource_likes` will be added. If there are existing duplicate values, this will fail.

*/
-- CreateIndex
CREATE UNIQUE INDEX "resource_likes_userId_resourceID_key" ON "resource_likes"("userId", "resourceID");
