-- CreateTable
CREATE TABLE "resource_categories" (
    "id" SERIAL NOT NULL,
    "resourceID" INTEGER NOT NULL,
    "categoryID" INTEGER NOT NULL,
    "subCategoryID" INTEGER NOT NULL,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "resource_categories_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE UNIQUE INDEX "resource_categories_categoryID_resourceID_subCategoryID_key" ON "resource_categories"("categoryID", "resourceID", "subCategoryID");

-- AddForeignKey
ALTER TABLE "resource_categories" ADD CONSTRAINT "resource_categories_resourceID_fkey" FOREIGN KEY ("resourceID") REFERENCES "resources"("resourceID") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "resource_categories" ADD CONSTRAINT "resource_categories_categoryID_fkey" FOREIGN KEY ("categoryID") REFERENCES "categories"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "resource_categories" ADD CONSTRAINT "resource_categories_subCategoryID_fkey" FOREIGN KEY ("subCategoryID") REFERENCES "sub_categories"("id") ON DELETE RESTRICT ON UPDATE CASCADE;
