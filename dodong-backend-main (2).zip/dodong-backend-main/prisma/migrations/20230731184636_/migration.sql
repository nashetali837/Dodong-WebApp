/*
  Warnings:

  - A unique constraint covering the columns `[geohash]` on the table `locations` will be added. If there are existing duplicate values, this will fail.

*/
-- AlterTable
ALTER TABLE "locations" ADD COLUMN     "geohash" TEXT NOT NULL DEFAULT '';

-- CreateIndex
CREATE UNIQUE INDEX "locations_geohash_key" ON "locations"("geohash");
