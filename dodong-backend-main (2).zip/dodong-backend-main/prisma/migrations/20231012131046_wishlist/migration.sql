-- AlterTable
ALTER TABLE "products" ADD COLUMN     "productVerified" BOOLEAN NOT NULL DEFAULT false;

-- CreateTable
CREATE TABLE "products_in_shop" (
    "id" SERIAL NOT NULL,
    "shopID" INTEGER NOT NULL,
    "productID" INTEGER NOT NULL,
    "priceInShop" DOUBLE PRECISION,
    "quantity" INTEGER,
    "verified" BOOLEAN NOT NULL DEFAULT false,
    "published" BOOLEAN NOT NULL DEFAULT true,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "products_in_shop_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "product_wishlist" (
    "id" SERIAL NOT NULL,
    "productID" INTEGER NOT NULL,
    "userProfileID" INTEGER NOT NULL,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "product_wishlist_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE UNIQUE INDEX "product_wishlist_productID_userProfileID_key" ON "product_wishlist"("productID", "userProfileID");

-- AddForeignKey
ALTER TABLE "products_in_shop" ADD CONSTRAINT "products_in_shop_shopID_fkey" FOREIGN KEY ("shopID") REFERENCES "shops"("shopID") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "products_in_shop" ADD CONSTRAINT "products_in_shop_productID_fkey" FOREIGN KEY ("productID") REFERENCES "products"("productID") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "product_wishlist" ADD CONSTRAINT "product_wishlist_productID_fkey" FOREIGN KEY ("productID") REFERENCES "products"("productID") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "product_wishlist" ADD CONSTRAINT "product_wishlist_userProfileID_fkey" FOREIGN KEY ("userProfileID") REFERENCES "user_profiles"("userProfileID") ON DELETE RESTRICT ON UPDATE CASCADE;
