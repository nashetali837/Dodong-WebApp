// seed.ts is a script that runs when you run prisma db seed
import { PrismaClient } from "@prisma/client";

// It is used to seed your database with data
const User = {
  email: "amruthk99@gmail.com",
  password: "password",
  mobileNumber: "9121561335",
};

const Profile = {
  name: "Amruth Kuntamalla",
  avatar: "",
  userId: 1,
  displayName: "amruthk99",
  occupation: "Software Engineer",
  bio: "I am a software engineer",
  dateOfBirth: "1999-09-20",
  website: "https://amruthk99.github.io",
  twitterHandle: "https://twitter.com/amruthk99",
  facebookURL: "https://facebook.com/amruthk99",
  linkedInURL: "https://linkedin.com/in/amruthk99",
};

const ProfessionalProfile = {
  userId: 1,
  githubURL: "",
};

const categories = [
  {
    "category": "Apparel and Accessories",
    "subcategories": [
      "Clothing",
      "Shoes",
      "Jewelry",
      "Handbags and Wallets",
      "Hats and Caps",
      "Sunglasses"
    ]
  },
  {
    "category": "Home and Decor",
    "subcategories": [
      "Furniture",
      "Home Appliances",
      "Home Textiles",
      "Kitchenware",
      "Lighting",
      "Wall Art"
    ]
  },
  {
    "category": "Electronics",
    "subcategories": [
      "Computers and Laptops",
      "Mobile Phones and Accessories",
      "Televisions",
      "Audio and Video Equipment",
      "Cameras",
      "Gaming Consoles and Accessories"
    ]
  },
  {
    "category": "Beauty and Personal Care",
    "subcategories": [
      "Skincare",
      "Makeup",
      "Haircare",
      "Perfumes and Fragrances",
      "Bath and Body Products",
      "Personal Grooming Tools"
    ]
  },
  {
    "category": "Books and Stationery",
    "subcategories": [
      "Fiction and Non-Fiction Books",
      "Stationery Supplies",
      "Art and Craft Materials",
      "Calendars and Planners",
      "Office Supplies",
      "Journals and Notebooks"
    ]
  },
  {
    "category": "Sports and Fitness",
    "subcategories": [
      "Sports Equipment",
      "Fitness Gear and Apparel",
      "Outdoor Gear",
      "Cycling Accessories",
      "Team Sports Gear",
      "Exercise Machines"
    ]
  },
  {
    "category": "Health and Wellness",
    "subcategories": [
      "Vitamins and Supplements",
      "Herbal Remedies",
      "Fitness Trackers",
      "Yoga and Meditation Accessories",
      "Health Monitors",
      "Personal Care Products"
    ]
  },
  {
    "category": "Food and Beverages",
    "subcategories": [
      "Fresh Produce",
      "Bakery Items",
      "Dairy Products",
      "Meat and Seafood",
      "Snacks and Confectionery",
      "Beverages"
    ]
  },
  {
    "category": "Toys and Games",
    "subcategories": [
      "Board Games",
      "Puzzles",
      "Action Figures",
      "Dolls and Accessories",
      "Educational Toys",
      "Outdoor Play Equipment"
    ]
  },
  {
    "category": "Pet Supplies",
    "subcategories": [
      "Pet Food",
      "Pet Toys",
      "Pet Accessories",
      "Grooming Products",
      "Pet Beds and Furniture",
      "Collars and Leashes"
    ]
  },
  {
    "category": "Automotive and Tools",
    "subcategories": [
      "Car Parts and Accessories",
      "Tools and Equipment",
      "Car Care Products",
      "Tires and Wheels",
      "Automotive Electronics",
      "Power Tools"
    ]
  },
  {
    "category": "Specialty Stores",
    "subcategories": [
      "Art Supplies",
      "Musical Instruments",
      "Vintage and Antique Items",
      "Party Supplies",
      "Comic Books and Collectibles",
      "Ethnic and Cultural Products"
    ]
  }
]



export {
  categories as SEED_CATEGORIES
}