
# update and install nginx
sudo apt update

# install nodejs

# install pm2

# install nginx

sudo apt install nginx
sudo ufw allow 'Nginx HTTP'
sudo systemctl status nginx

sudo systemctl reload nginx