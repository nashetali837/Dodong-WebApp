# Database initialization

https://www.prisma.io/docs/getting-started/quickstart


<!-- Deployment docs -->
https://www.digitalocean.com/community/tutorials/how-to-set-up-a-node-js-application-for-production-on-ubuntu-20-04#step-4-setting-up-nginx-as-a-reverse-proxy-server

https://www.digitalocean.com/community/tutorials/how-to-secure-nginx-with-let-s-encrypt-on-ubuntu-20-04


## From Postman to Swagger conversion

https://metamug.com/util/postman-to-swagger/


<!--  TODO  -->
1. Google API not working
2. Abhinash about location distance
5. Swaraj about Shop Detail, quantity and pcs
6. Price Comparison API, Similar Shops API, Similar Products API, products used by same user
7. Introduce an 'Add to Wishlist' option to improve user interaction.
