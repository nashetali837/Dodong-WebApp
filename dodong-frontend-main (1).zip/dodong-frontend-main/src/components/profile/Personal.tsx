import React from "react";
import TextInput from "@/shared/input-groups/TextInput";

type ProfessionalProfileProps = {
  forms?: any;
  handleSubmit: (event: React.FormEvent<HTMLFormElement>) => void;
};

export default function PersonalProfile({
  handleSubmit,
}: ProfessionalProfileProps) {
  const forms = [
    {
      label: "About me (Short Intro)",
      placeholder: "",
      type: "text",
      id: "bio",
      required: true,
      half: false,
    },
    {
      label: "Name",
      placeholder: "",
      type: "text",
      id: "names",
      required: true,
      half: false,
    },
    {
      label: "Display Name",
      placeholder: "",
      type: "text",
      id: "displayName",
      required: true,
      half: true,
    },
    {
      label: "Phone number",
      placeholder: "",
      type: "number",
      id: "phoneNumber",
      required: false,
      half: true,
    },
    {
      label: "Email Address",
      placeholder: "",
      type: "email",
      id: "email",
      required: false,
      half: true,
    },
    {
      label: "Date of Birth",
      placeholder: "",
      type: "date",
      id: "dob",
      required: true,
      half: true,
    },
    {
      label: "Facebook URL",
      placeholder: "",
      type: "text",
      id: "facebookURL",
      half: false,
    },
    {
      label: "LinkedIn URL",
      placeholder: "",
      type: "text",
      id: "LinkedInURL",
      half: false,
    },
    {
      label: "Twitter Handle",
      placeholder: "",
      type: "text",
      id: "twitterHandle",
      half: false,
    },
  ];

  return (
    <form id="personal-form" onSubmit={handleSubmit} className="w-full">
      <div className="w-full gap-8 flex flex-col justify-between text-orange-593500 font-semibold">
        <div className="grid grid-cols-2 gap-3">
          {forms.map((form: any, k: number) => (
            <div
              key={"field_" + form.id}
              className={form.half ? "col-span-1" : "col-span-2"}
            >
              <TextInput
                inputStyle=""
                id={form.id}
                autoFocus={k === 0}
                label={form.label}
                required={form.required}
                type={form.type}
                placeholder={form.placeholder}
              />
            </div>
          ))}
        </div>
      </div>
    </form>
  );
}
