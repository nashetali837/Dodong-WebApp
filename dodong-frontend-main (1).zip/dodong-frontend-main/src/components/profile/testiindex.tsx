import React, { useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import Starter from "./ui/starter";
import Info from "./ui/info";
import Invite from "./ui/invite";
import Share from "./ui/share";
import { toggleEditProfileModal } from "@/lib/redux/slices/user-slice";
import Modal from "@/shared/modal";

const Profile = () => {
  const [openEditProfileModal, setOpenEditProfileModal] = useState(false);
  const [step, setStep] = useState(1);

  const handleOpen = () => {
    setOpenEditProfileModal(true);
  };

  const handleClose = () => {
    setOpenEditProfileModal(false);
  };

  const handleNext = () => {
    setStep((prevStep) => prevStep + 1);
  };

  const handlePrev = () => {
    setStep((prevStep) => prevStep - 1);
  };

  return (
    <div>
      <button onClick={handleOpen}>Edit Profile</button>

      {step === 1 && (
        <Modal
          hideCloseButton
          open={openEditProfileModal}
          onClose={handleClose}
        >
          <Starter
            step={step}
            onNext={handleNext}
            setStep={setStep}
            handleClose={handleClose}
          />
        </Modal>
      )}

      {step === 2 && (
        <Modal fullScreen open={openEditProfileModal} onClose={handleClose}>
          <Info
            step={step}
            onNext={handleNext}
            onPrev={handlePrev}
            handleClose={handleClose}
          />
        </Modal>
      )}

      {step === 3 && (
        <Modal
          hideCloseButton
          open={openEditProfileModal}
          onClose={handleClose}
        >
          <Invite handleClose={handleClose} />
        </Modal>
      )}
    </div>
  );
};

export default Profile;
