import { useDispatch, useSelector } from "react-redux";
import { logoutUser } from "@/lib/redux/slices/auth-slice";

const useProfile = () => {
  const dispatch = useDispatch();
  const { user } = useSelector((state: any) => state.user);

  const refreshUserData = () => {};

  return { user, refreshUserData };
};

export default useProfile;
