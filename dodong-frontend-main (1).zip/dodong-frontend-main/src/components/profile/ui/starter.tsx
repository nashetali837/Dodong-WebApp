import React, { useEffect, useRef, useState } from "react";
import Image from "next/image";
import UploadNewImage from "../../../../public/images/upload.svg";

import { useSelector } from "react-redux";
import { setServers } from "dns";
import {
  InviteSection as Profile,
  InviteBox as InviteBoxes,
  Icon,
  SubTitle,
  ModalHead,
} from "./invite";
import FlexBox from "@/components/sections/FlexBox";
import { styled } from "styled-components";
import { Icons } from "@/components/icons";
import PrimaryButton from "@/shared/buttons/primary";
import { uploadImage } from "@/components/storefront/post/create/UploadImage";
import { ImageDiscard } from "@/components/storefront/post/create/UploadImage";
import Invite from "../ui/invite";
import { useDispatch } from "react-redux";
// import { updateDraft } from "@/lib/redux/slices/draft-slice";
import {
  saveProfile,
  toggleCreatePostModal,
} from "@/lib/redux/slices/user-slice";
import { EndPoints } from "@/lib/apiConstants";
import { postRequest } from "@/lib/networkHelper";
import { toast } from "react-toastify";
import useAuth from "@/components/auth/hooks/useAuth";

const InviteBox = styled(InviteBoxes)`
  cursor: pointer;
`;

const Avatar = styled.div`
  height: 155px;
  width: 155px;
  border: 5px solid ${(props) => props.theme.colors.white};
  border-radius: ${(props) => props.theme.borderRadius.lg};
  background: ${(props) => props.theme.colors.lightGray};
  -moz-box-shadow: 0px 4px 9px -4px rgba(0, 0, 0, 0.25);
  -webkit-box-shadow: 0px 4px 9px -4px rgba(0, 0, 0, 0.25);
  box-shadow: 0px 4px 9px -4px rgba(0, 0, 0, 0.25);
  display: flex;
  display: -webkit-flex;
  align-items: center;
  justify-content: center;

  &.isUserImage {
    img {
      width: 100%;
      height: 100%;
      object-fit: cover;
      object-position: center;
    }
  }
`;

const Button = styled.button`
  color: ${(props) => props.theme.colors.black};
  border: 1px solid ${(props) => props.theme.colors.border};
  border-radius: ${(props) => props.theme.borderRadius.button};
  padding: 9px;
  max-width: 200px;
  width: 100%;

  &.isUserImage {
    background: ${(props) => props.theme.colors?.primary};
    color: ${(props) => props.theme.colors?.white};
  }
`;

const ImageUpload = styled.div`
  position: relative;
`;

export default function Step1({
  step,
  onNext,
  setStep,
  handleInvite,
  handleClose,
}: {
  step?: any;
  onNext?: () => void;
  setStep?: any;
  handleInvite?: () => void;
  handleClose: () => void;
}) {
  const { userProfile } = useSelector((state: any) => state.user);
  const inputRef = useRef<HTMLInputElement | null>(null);
  const [image, setImage] = useState<string>("");
  const [isInviteOpen, setIsInviteOpen] = useState(true);
  const dispatch = useDispatch();
  const { authToken } = useAuth();

  const handleOpenInvite = () => {
    setIsInviteOpen(true);
  };

  const onPhotoUpload = async (e: any) => {
    let uploadedURL = await uploadImage(e);
    // Update userProfile avatar data
    const updatedProfile = { ...userProfile, avatar: uploadedURL };
    // Dispatch an action to update the userProfile
    dispatch(saveProfile(updatedProfile));

    setImage(uploadedURL);
  };

  const resetImage = () => {
    // Remove the updated avatar from userProfile
    const updatedProfile = { ...userProfile, avatar: null };
    // Dispatch an action to update the userProfile
    dispatch(saveProfile(updatedProfile));
    setImage("");
  };

  const onClickHandler = () => {
    if (image) {
      // Handle the case when the image is available
      updateProfilePicture();
    } else {
      // Trigger the file input click event
      inputRef.current?.click();
    }
  };

  const updateProfilePicture = () => {
    const data = {
      avatar: image,
    };

    postRequest(EndPoints.updateProfile, data, authToken)
      .then((res) => {
        console.log(res);
        toast.success("Profile Picture successfully updated", {
          type: "success",
        });
      })

      .catch((err) => {
        console.log(err);
        toast("Something went wrong", {
          type: "error",
        });
      });
  };

  return (
    <>
      {isInviteOpen && (
        <Profile>
          <ModalHead>
            <span className="black">Complete Profile</span>
            <button onClick={handleClose} className="cursor-pointer">
              &#10005;
            </button>
          </ModalHead>
          <FlexBox justify="space-between" align="center">
            <ImageUpload>
              <Avatar className={image ? "isUserImage" : undefined}>
                <Image
                  src={image || UploadNewImage}
                  alt="Picture of the author"
                  width={58}
                  height={58}
                />
              </Avatar>

              <ImageDiscard onClick={resetImage}>
                <Icons.close className="text-white text-2xl" />
              </ImageDiscard>
            </ImageUpload>

            <input
              id="imageUpload"
              ref={inputRef}
              className="hidden"
              placeholder="Upload"
              onChange={onPhotoUpload}
              type="file"
              accept="image/*"
            />

            <Button
              className={image ? "isUserImage" : undefined}
              onClick={onClickHandler}
            >
              {image ? "save" : "Upload Image"}
            </Button>
          </FlexBox>
          <SubTitle>
            You now have only 3 steps to complete to connect with your viewers
            on Dodong. Let’s get started.
          </SubTitle>
          <p>
            <span className="black">0 to 3</span> Step to follow
          </p>
          <InviteBox onClick={onNext}>
            <Icon>
              <Icons.usercircle />
            </Icon>
            Update Your Profile
          </InviteBox>
          <InviteBox
            onClick={() => {
              dispatch(toggleCreatePostModal(true));
              handleClose();
            }}
          >
            <Icon>
              <Icons.image />
            </Icon>
            Share Photos and Videos
          </InviteBox>
          <InviteBox onClick={handleInvite}>
            <Icon>
              <Icons.user />
            </Icon>
            Invite Friends
          </InviteBox>
        </Profile>
      )}
    </>
  );
}
