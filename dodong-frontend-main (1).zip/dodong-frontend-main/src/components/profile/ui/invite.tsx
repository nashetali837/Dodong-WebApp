import React from "react";
// import Image from "next/image";
// import sharePhotos from "../../../../public/images/profile/sharePhotos.svg";
// import inviteFriends from "../../../../public/images/profile/inviteFriends.svg";
// import completeYourProfile from "../../../../public/images/profile/completeYourProfile.svg";
// import squareProfile from "../../../../public/images/profile/square-profile.svg";
// import fiftypercentage from "../../../../public/images/profile/50percentage.svg";
import { Icons } from "@/components/icons";
import FlexBox, { FlexBoxStyle } from "@/components/sections/FlexBox";
import styled from "styled-components";
import {
  LinkedinShareButton,
  EmailShareButton,
  WhatsappShareButton,
} from "react-share";

export const InviteSection = styled.div`
  padding: 2rem;
  max-width: 445px;
  width: 100%;
  margin: auto;
  background: ${(props) => props.theme.colors.white};
  border-radius: ${(props) => props.theme.borderRadius.md};
`;

export const ModalHead = styled(FlexBox)`
  justify-content: space-between;
  align-items: center;
  margin-bottom: 1.25rem;
`;

export const SubTitle = styled.p`
  margin: 1.5rem 0 1rem;
`;

export const InviteBox = styled(FlexBoxStyle)`
  align-items: center;
  gap: 1rem;
  font-size: 22px;
  color: ${(props) => props.theme.colors.black};
  margin-top: 1.25rem;
`;

export const Icon = styled.div`
  width: 40px;
  height: 40px;
  border: 1px solid ${(props) => props.theme.colors.border};
  border-radius: ${(props) => props.theme.borderRadius.md};
  display: flex;
  display: -webkit-flex;
  align-items: center;
  justify-content: center;
`;

export default function Step1({
  onNext,
  onPrev,
  handleClose,
}: {
  onNext?: () => void;
  onPrev?: () => void;
  handleClose: () => void;
}) {
  const url = process.env.NEXT_PUBLIC_WEBSITE_URL || "https://dodong.in";

  return (
    <InviteSection>
      <ModalHead>
        <span className="black">Invite friends</span>
        <button onClick={handleClose} className="cursor-pointer">
          &#10005;
        </button>
      </ModalHead>
      <SubTitle>
        Invite your friends to grow your network to follow your account. You can
        also connect with them to let them add you to their network.
      </SubTitle>
      <InviteBox>
        <Icon>
          <Icons.user />
        </Icon>
        Follow Connects
      </InviteBox>

      <InviteBox>
        <Icon>
          <Icons.Whatsapp />
        </Icon>
        <WhatsappShareButton url={url}>
          Invite friends by whatsapp
        </WhatsappShareButton>
      </InviteBox>

      <InviteBox>
        <Icon>
          <Icons.email />
        </Icon>
        <EmailShareButton url={url}> Invite friends by email</EmailShareButton>
      </InviteBox>

      <InviteBox>
        <Icon>
          <Icons.chat />
        </Icon>
        <a href={`sms:?body=${url}`} target="_blank" rel="noreferrer">
          Invite friends by sms
        </a>
      </InviteBox>
      <InviteBox>
        <Icon>
          <Icons.more />
        </Icon>
        Invite friends by...
      </InviteBox>
    </InviteSection>
  );
}
