"use client";
import React, { useState } from "react";
import { toast } from "react-toastify";
import axios from "axios";
import {
  personalProfileSchema,
  professionalProfileSchema,
} from "@/lib/validations/auth";
import { useMutation } from "@tanstack/react-query";
import z, { ZodError } from "zod";
import { postRequest } from "@/lib/networkHelper";
import { EndPoints } from "@/lib/apiConstants";
import { fromZodError } from "zod-validation-error";
import { useSelector } from "react-redux";
import { RootState } from "@/lib/redux/store/store";
import PersonalProfile from "@/components/profile/Personal";
import ProfessionalProfile from "@/components/profile/Professional";
import Tabs from "@/shared/buttons/tabs";
import PrimaryButton from "@/shared/buttons/primary";
import { styled } from "styled-components";
import FooterNav from "@/components/sections/FooterButtons";
import useAuth from "@/components/auth/hooks/useAuth";

export const PopupHeader = styled.div`
  position: sticky;
  left: 0px;
  top: 0px;
  padding: 1rem;
  background: ${(props) => props.theme.colors.white};
  color: ${(props) => props.theme.colors.black};
  border-bottom: 1px solid ${(props) => props.theme.colors.border};
  width: 100%;
`;

const Content = styled.div`
  max-width: 44.75rem;
  padding: 1rem;
  width: 100%;
`;

type personalProfileSchema = z.infer<typeof personalProfileSchema>;
type professionalProfileSchema = z.infer<typeof professionalProfileSchema>;

type MutationType = {
  data: personalProfileSchema | professionalProfileSchema;
  type: string;
};

export default function Step1({
  step,
  onNext,
  onPrev,
  handleClose,
}: {
  step?: any;
  onNext?: () => void;
  onPrev?: () => void;
  handleClose: () => void;
}) {
  const { user, userProfile } = useSelector((state: RootState) => state);

  const { authToken } = useAuth();

  const [tab, setTab] = useState<boolean>(false);

  const mutation = useMutation({
    mutationFn: async ({ data, type }: MutationType) => {
      try {
        if (type === "personal") {
          await postRequest(EndPoints.updateProfile, data, authToken).then(
            (res) => {
              setTab(true);
            }
          );
        } else {
          await postRequest(EndPoints.businessProfile, data, authToken);
        }
      } catch (error: any) {
        console.error("Error updating profile:", error.message);
      }
    },

    onSuccess: (data: any, variables: { type: string }) => {
      const { type } = variables;
      if (type === "personal") {
        toast.success("Personal profile updated successfully");
      } else {
        toast.success("Professional profile updated successfully");
        handleClose();
      }
    },

    onError: (error: any) => {
      if (axios.isAxiosError(error)) {
        console.log(error);
        return toast.error(error.response?.data.message);
      }
      if (error instanceof ZodError) {
        console.log(fromZodError(error));
        return toast.error("Please enter valid data");
      }
    },
  });

  const handleSubmitProfessional = (
    event: React.FormEvent<HTMLFormElement>
  ): void => {
    // onNext();
    event.preventDefault();
    try {
      const data = {
        occupation: (event.target as HTMLFormElement).occupation.value,
        company: (event.target as HTMLFormElement).company.value,
        jobLocation: (event.target as HTMLFormElement).jobLocation.value,
        officialMobileNumber: (event.target as HTMLFormElement).phoneNumber
          .value,
        brandDetails: (event.target as HTMLFormElement).brandDetails.value,
        others: (event.target as HTMLFormElement).other.value,
        userId: user?.user?.id,
      };
      const isValidData = professionalProfileSchema.parse(data);
      mutation.mutate({ data: isValidData, type: "professional" });
    } catch (error: any) {
      if (error instanceof ZodError) {
        const validationError = fromZodError(error);
        console.log(validationError);
        toast.error(validationError.message);
      }
      console.log(error);
    }
  };

  const handleSubmit = (event: React.FormEvent<HTMLFormElement>): void => {
    event.preventDefault();
    try {
      const data = {
        userId: user?.user?.id,
        bio: (event.target as HTMLFormElement).bio.value,
        name: (event.target as HTMLFormElement).names.value,
        displayName: (event.target as HTMLFormElement).displayName.value,
        phoneNumber: (event.target as HTMLFormElement).phoneNumber.value,
        dateOfBirth: new Date((event.target as HTMLFormElement).dob.value),
        email: (event.target as HTMLFormElement).email.value,
        facebookURL: (event.target as HTMLFormElement).facebookURL.value,
        LinkedInURL: (event.target as HTMLFormElement).LinkedInURL.value,
        twitterHandle: (event.target as HTMLFormElement).twitterHandle.value,
      };
      const isValidData = personalProfileSchema.parse(data);
      mutation.mutate({ data: isValidData, type: "personal" });
    } catch (error: any) {
      if (error instanceof ZodError) {
        console.log(error);
        const validationError = fromZodError(error);
        toast.error(validationError.message);
      }
      console.log(error);
    }
  };

  const handleTab = (val: boolean): void => {
    setTab(val);
  };

  const _renderModes = () => {
    const modes = [
      { label: "Personal", id: "Personal" },
      { label: "Professional", id: "Professional" },
    ];

    return (
      <Tabs
        modes={modes}
        currentTab={tab === false ? "Personal" : "Professional"}
        onChange={(id) => {
          handleTab(id === "Professional" ? true : false);
        }}
      />
    );
  };

  return (
    <section
      className={`w-full h-full overflow-y-scroll relative flex flex-col items-center`}
    >
      <PopupHeader className="black">
        When you add details about you, your connects will be engaged more with
        your profile
      </PopupHeader>

      <Content>
        {_renderModes()}
        {tab ? (
          <ProfessionalProfile
            handleSubmitProfessional={handleSubmitProfessional}
          />
        ) : (
          <PersonalProfile handleSubmit={handleSubmit} />
        )}
      </Content>

      <FooterNav>
        <PrimaryButton
          type="submit"
          label="Save"
          form={tab ? "professional-form" : "personal-form"}
        />
      </FooterNav>
    </section>
  );
}
