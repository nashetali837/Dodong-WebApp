import { DEFAULT_PROFILE_PIC } from "@/lib/constants";
import Image from "next/image";
import Link from "next/link";
import React from "react";
import { MdLocationOn } from "react-icons/md";
import { PostProps } from "../types";
import { styled } from "styled-components";
import { ProductTitle as UserTitle } from "@/pages/product/[slug]";

export default function UserDisplay({
  post,
  user,
  hideLocation,
  onClick,
}: {
  post?: PostProps;
  user?: any;
  hideLocation?: boolean;
  onClick?: () => void;
}) {
  return (
    <div className="flex items-center">
      <div className="relative cursor-pointer" onClick={onClick}>
        <Image
          src={post?.profile?.imageURL || DEFAULT_PROFILE_PIC}
          width={30}
          height={30}
          alt="profile image"
          className="rounded-lg w-full object-cover"
          style={{
            maxHeight: "300px",
          }}
        />
      </div>
      <div className="flex flex-col ml-2">
        <Link href={"/profile/" + post?.profile?.userID}>
          <UserTitle>
            {user
              ? post?.profile?.name || user?.name
              : post?.profile?.displayName || post?.profile?.name}
          </UserTitle>
        </Link>
        {!hideLocation && (
          <div className="text-xs flex">
            <MdLocationOn className="text-md my-auto cursor-pointer mr-1" />
            {post?.profile?.distance}
          </div>
        )}
      </div>
    </div>
  );
}
