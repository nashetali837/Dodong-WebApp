import React from "react";
import UserDisplay from "./UserDisplay";
import { AiOutlinePlus } from "react-icons/ai";
import { PostProps } from "../types";

export default function UserInfo({
  post,
  stats,
}: {
  post: PostProps;
  stats: any;
}) {
  return (
    <div>
      <div className="absolute bg-white left-8 drop-shadow-2xl top-20 w-[365px] rounded-xl py-4 px-3 border border-slate-300">
        <div className="flex items-center">
          <UserDisplay post={post} />
          <button className="shadow-md bg-zinc-100 flex gap-2 font-bold text-sm items-center border border-slate-300 p-2 rounded-xl ml-auto">
            <AiOutlinePlus className="text-xl" /> Connect
          </button>
        </div>
        <div className="flex items-center mt-5 gap-4">
          {stats.map((stat: any, k: number) => (
            <div key={`stat_${k}`} className="flex flex-col">
              <div className="text-sm font-bold">{stat.value}</div>
              <div className="text-xs">{stat.label}</div>
            </div>
          ))}
        </div>
      </div>
      <div className="absolute left-11 top-[3.5rem] w-0 h-0 border-l-[10px] border-l-transparent border-b-[15px] border-b-white border-r-[10px] border-r-transparent" />
    </div>
  );
}
