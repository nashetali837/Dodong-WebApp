import React from "react";
import { toast } from "react-toastify";
import { PostProps } from "../types";
import UserDisplay from "./UserDisplay";
import { HiOutlineBookmark } from "react-icons/hi2";
import { TbDots } from "react-icons/tb";
import { Icons } from "@/components/icons";
import CustomSelect from "@/shared/input-groups/custom-select";

export default function UserBlock({
  post,
  toggle,
  children,
  removeBorder,
  hideLocation,
  hideSave,
  hideDescription,
}: {
  post: PostProps;
  toggle: any;
  children?: React.ReactNode;
  removeBorder?: boolean;
  hideLocation?: boolean;
  hideSave?: boolean;
  hideDescription?: boolean;
}) {
  const link = `${process.env.NEXT_PUBLIC_WEBSITE_URL}/?postID=${post?.resourceID}`;

  const copylink = (e: any) => {
    navigator.clipboard.writeText(link);
    toast.success("Link Copied");
  };

  return (
    <div
      className={`bg-white ${
        !removeBorder && "post-border"
      } py-2 pl-4 pr-6 rounded-tl-xl rounded-tr-xl`}
    >
      <div className={`flex justify-between ${!hideDescription && "mb-4"}`}>
        <UserDisplay
          post={post}
          hideLocation
          onClick={() => toggle((state: any) => !state)}
        />

        <div className="flex items-center">
          {!hideSave && (
            <div className="flex flex-col ml-2">
              <div className="text-sm font-bold text-center">
                <HiOutlineBookmark className="text-xl cursor-pointer" />
              </div>
            </div>
          )}
          <CustomSelect
            list={[
              // { label: "Edit", id: "edit" },
              // { label: "Report", id: "Report" },
              // { label: "Disconnect", id: "Disconnect" },
              // { label: "Add to favorites", id: "AddToFavorites" },
              // { label: "Go to post", id: "GoToPost" },
              {
                label: "Share to",
                id: "ShareTo",
                link: link,
              },
              {
                label: "Copy link",
                id: "CopyLink",
                onclick: copylink,
              },
              // { label: "Embed", id: "Embed" },
              // { label: "About this account", id: "AboutThisAccount" },
            ]}
          >
            <div className="flex flex-col">
              <div className="text-sm font-bold text-center cursor-pointer">
                <Icons.tdots className="text-xl cursor-pointer" />
              </div>
            </div>
          </CustomSelect>
        </div>
      </div>
      {!hideDescription && (
        <div className="text-sm text-left">{post.post.description}</div>
      )}
      {children}
    </div>
  );
}
