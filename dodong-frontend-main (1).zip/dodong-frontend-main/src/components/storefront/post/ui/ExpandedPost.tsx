import ImageCarousal from "@/shared/carousal";
import EmojiPicker from "emoji-picker-react";
import React, { useEffect, useState } from "react";
import UserBlock from "./UserBlock";
import UserInfo from "./UserInfo";
import { AiOutlineHeart, AiOutlineSend } from "react-icons/ai";
import { PostProps } from "../types";
import { BsEmojiSmile } from "react-icons/bs";
import UserDisplay from "./UserDisplay";
import { getRequest, postRequest, deleteRequest } from "@/lib/networkHelper";
import { EndPoints } from "@/lib/apiConstants";
import moment from "moment";
import InfiniteScroll from "react-infinite-scroll-component";
import Spinner from "@/shared/loading/spinner";
import useAuth from "@/components/auth/hooks/useAuth";
import { ShopLink } from "@/shared/buttons/primary";
import styled from "styled-components";
import { Icons } from "@/components/icons";
import { useRouter } from "next/router";
import { FlexBoxCenter } from "@/components/sections/FlexBox";
import { useSelector } from "react-redux";
import CustomSelect from "@/shared/input-groups/custom-select";
import { UserProfile } from "@/lib/redux/slices/user-slice";

export const ShopButton = styled(ShopLink)`
  position: absolute;
  z-index: 4;
  bottom: 1rem;
  left: 1rem;
`;

export default function ExpandedPost({
  currentPost,
}: {
  currentPost: PostProps;
}) {
  const [openPopup, setOpenPopup] = useState<boolean>(false);
  const [openEmojiSelect, setOpenEmojiSelect] = useState<boolean>(false);
  const [openEditEmojiSelect, setEditOpenEmojiSelect] =
    useState<boolean>(false);
  const [newComment, setNewComment] = useState<string>("");
  const [comments, setComments] = useState<any>([]);
  const [page, setPage] = useState<number>(1);
  const [hasMore, setHasMore] = useState<boolean>(false);
  const [loading, setLoading] = useState<boolean>(false);
  const { authToken } = useAuth();
  const [editCommentId, setEditCommentId] = useState(null);
  const [editedComment, setEditedComment] = useState("");
  const { userProfile } = useSelector((state: any) => state.user);

  const fetchComments = async () => {
    setLoading(true);
    const url = `${EndPoints.getComments}?postID=${currentPost?.resourceID}`;
    const res = await getRequest(url, authToken);
    setComments([...res.data.comments]);
    setHasMore(res.data.hasMore ?? false);
    setLoading(false);
  };

  const addComment = async () => {
    if (comments === "") {
      return;
    }
    const res = await postRequest(
      EndPoints.addComment,
      {
        postID: currentPost?.resourceID,
        commentBody: newComment,
      },
      authToken
    );
    if (res.data.status === "success") {
      setNewComment("");
      fetchComments();
    }
  };

  const deleteComment = async (commentID: number) => {
    const res = await deleteRequest(
      `${EndPoints.deleteComment}?postID=${currentPost?.resourceID}&commentID=${commentID}`,
      authToken
    );

    if (res.data.status === "success") {
      setComments((prevComments: any) =>
        prevComments.filter((comment: any) => comment.commentID !== commentID)
      );
    }
  };

  const saveEditedComment = async (commentID: number) => {
    try {
      // Call the API to update the comment
      const updatePromise = postRequest(
        EndPoints.updateComment,
        {
          commentID: commentID,
          commentBody: editedComment,
        },
        authToken
      );

      // Update the comments in the state simultaneously with the API request
      const updatedComments = comments.map((comment: any) => {
        if (comment.commentID === commentID) {
          return {
            ...comment,
            body: editedComment,
          };
        }
        return comment;
      });

      // Wait for both the API request and state update to complete
      await Promise.all([updatePromise, setComments(updatedComments)]);

      // Clear the editing state after successful update
      setEditCommentId(null);
      setEditedComment("");
    } catch (error) {
      // Handle any error that may occur during the update process
      console.error("Error updating comment:", error);
      // You might want to show an error message to the user
    }
  };

  const cancelEdit = () => {
    // Clear the editing state
    setEditCommentId(null);
    setEditedComment("");
  };

  // ... existing code ...

  useEffect(() => {
    fetchComments();
  }, []);

  const sortedComments = comments
    .slice()
    .sort(
      (a: { commentID: number }, b: { commentID: number }) =>
        b.commentID - a.commentID
    );

  return (
    <div className="z-40 w-full my-auto ">
      <div className="bg-white p-2 lg:p-4 text-center sm:items-center my-auto sm:p-0">
        <div
          className="flex flex-1 flex-col md:flex-row my-auto"
          style={{ maxHeight: "90vh" }}
        >
          <div className="relative flex-1 items-center self-center h-[85vh]">
            <ImageCarousal
              style="object-contain h-full w-full xl:max-w-3xl items-center h-[85vh]"
              width={400}
              height={800}
              images={currentPost?.post?.imageURL}
            />

            <ShopButton href={`product/${currentPost?.productId}`}>
              <Icons.shop className="text-xl" /> <span>Shop</span>
            </ShopButton>
          </div>
          <div className="w-full md:p-4 my-3 justify-start max-w-lg mx-auto overflow-y-scroll">
            <UserBlock post={currentPost} toggle={setOpenPopup} removeBorder />
            <div className="flex mt-5 relative">
              <BsEmojiSmile
                onClick={() => setOpenEmojiSelect(!openEmojiSelect)}
                className="absolute text-2xl top-3.5 left-3 cursor-pointer"
              />
              <input
                value={newComment}
                onChange={(e) => setNewComment(e.target.value)}
                onFocus={() => setOpenEmojiSelect(false)}
                placeholder="Write a comment..."
                className="border rounded-md py-3 w-full pr-3 pl-12"
              />
              <button
                onClick={addComment}
                disabled={newComment.length === 0}
                className="absolute right-2 shadow-md top-1.5 rounded-xl text-xl bg-amber-500 p-2"
              >
                <AiOutlineSend className="text-white" />
              </button>
            </div>
            {openPopup && <UserInfo post={currentPost} stats={[]} />}
            {openEmojiSelect && (
              <EmojiPicker
                width="100%"
                onEmojiClick={(e) => {
                  setOpenEmojiSelect(false);
                  setNewComment(newComment + " " + e.emoji + " ");
                }}
              />
            )}
            {loading ? (
              <div className="mt-10">
                <Spinner />
              </div>
            ) : (
              <InfiniteScroll
                dataLength={comments.length}
                next={() => {
                  setPage(page + 1);
                  fetchComments();
                }}
                hasMore={hasMore}
                loader={<h4>Loading...</h4>}
                endMessage={
                  <p className="text-center text-gray-500 py-6">
                    No more comments!
                  </p>
                }
              >
                {sortedComments.map((comment: any, key: number) => {
                  const test = moment(comment?.createdAt);
                  const today = moment();

                  // Calculate the difference between test date and today in days
                  const daysDiff = today.diff(test, "days");

                  // Determine the output format based on the difference in days
                  let days;
                  if (daysDiff === 0) {
                    days = "Today";
                  } else if (daysDiff === 1) {
                    days = "Yesterday";
                  } else if (daysDiff <= 7) {
                    days = `${daysDiff} days ago`;
                  } else if (daysDiff > 7 && daysDiff <= 30) {
                    const weeksDiff = Math.floor(daysDiff / 7);
                    days = `${weeksDiff} ${
                      weeksDiff === 1 ? "week" : "weeks"
                    } ago`;
                  } else {
                    const monthsDiff = Math.floor(daysDiff / 30);
                    days = `${monthsDiff} ${
                      monthsDiff === 1 ? "month" : "months"
                    } ago`;
                  }

                  const isEditing = comment.commentID === editCommentId;

                  return (
                    <div className="py-4" key={`comment-${key}`}>
                      <FlexBoxCenter>
                        <UserDisplay
                          post={currentPost}
                          user={{
                            name: comment?.author?.name,
                            displayName: comment?.author?.displayName,
                            id: comment?.authorId,
                          }}
                          hideLocation
                        />
                        <CustomSelect
                          list={[
                            {
                              label: "Edit",
                              id: "edit",
                              onclick: () =>
                                setEditCommentId(comment.commentID),
                            },
                            {
                              label: "Delete",
                              id: "delete",
                              onclick: () => deleteComment(comment.commentID),
                            },
                          ]}
                        >
                          <div className="flex flex-col">
                            <div className="text-sm font-bold text-center cursor-pointer">
                              <Icons.tdots className="text-xl cursor-pointer" />
                            </div>
                          </div>
                        </CustomSelect>
                      </FlexBoxCenter>
                      {isEditing ? (
                        <>
                          <div className="flex mt-5 relative">
                            <BsEmojiSmile
                              onClick={() =>
                                setEditOpenEmojiSelect(!openEditEmojiSelect)
                              }
                              className="absolute text-2xl top-3.5 left-3 cursor-pointer"
                            />
                            <input
                              value={editedComment}
                              placeholder="Write a comment..."
                              onChange={(e) => setEditedComment(e.target.value)}
                              onFocus={() => setEditOpenEmojiSelect(false)}
                              className="border rounded-md py-3 w-full pr-3 pl-12"
                            />

                            <button
                              onClick={() => cancelEdit()}
                              className="absolute right-10 top-1.5 text-xl p-2"
                            >
                              <Icons.close />
                            </button>
                            <button
                              onClick={() =>
                                saveEditedComment(comment?.commentID)
                              }
                              disabled={editedComment.length === 0}
                              className="absolute right-2 shadow-md top-1.5 rounded-xl text-xl bg-amber-500 p-2"
                            >
                              <AiOutlineSend className="text-white" />
                            </button>
                          </div>

                          {openEditEmojiSelect && (
                            <EmojiPicker
                              width="100%"
                              onEmojiClick={(e) => {
                                setEditOpenEmojiSelect(false);
                                setEditedComment(
                                  editedComment + " " + e.emoji + " "
                                );
                              }}
                            />
                          )}
                        </>
                      ) : (
                        // <div>
                        //   <input
                        //     type="text"
                        //     onFocus={() => setOpenEmojiSelect(false)}
                        //     className="my-2"
                        //     value={editedComment}
                        //     onChange={(e) => setEditedComment(e.target.value)}
                        //   />
                        // </div>
                        <div className="text-left text-slate-500 text-sm ml-10">
                          {comment?.body}
                        </div>
                      )}
                      <div className="flex items-center gap-3 ml-10 mt-2 text-sm text-slate-500">
                        <p>{days}</p>

                        <div className="flex items-center gap-1 cursor-pointer">
                          <AiOutlineHeart /> Like
                        </div>
                        {/* <div className="flex items-center gap-1 cursor-pointer">
                            <HiArrowUturnRight /> Reply
                          </div> */}
                      </div>
                    </div>
                  );
                })}
              </InfiniteScroll>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
