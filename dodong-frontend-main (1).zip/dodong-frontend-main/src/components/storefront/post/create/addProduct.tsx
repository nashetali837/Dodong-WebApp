import React, { useEffect, useState } from "react";
import { EndPoints } from "@/lib/apiConstants";
import { postRequest } from "@/lib/networkHelper";
import { useDispatch, useSelector } from "react-redux";
import { toast } from "react-toastify";
import { Input } from "./index";
import Select from "react-select";
import debounce from "lodash.debounce";
import UserDisplay from "../ui/UserDisplay";
import PrimaryButton from "@/shared/buttons/primary";
import { updateDraft } from "@/lib/redux/slices/draft-slice";
import { ShopInfo } from "./ShopInformation";
import { styled } from "styled-components";
import FooterNav from "@/components/sections/FooterButtons";
import CategorySubcategory from "@/components/sections/CategorySubcategory";

const ReactSelect = styled(Select)`
  width: 50%;
`;

const ProductInfo = (props: any) => {
  const { userProfile }: any = useSelector((state: any) => state.user);
  const { draft = {} }: any = useSelector((state: any) => state.draft);
  const dispatch = useDispatch();
  const [categories, setCategories] = useState([]);
  const [subCategories, setSubCategories] = useState([]);
  const [shopName, setShopName] = useState("");
  const [addShopButton, setAddShopButton] = useState(false);
  const [addShop, setAddShop] = useState(false);
  const [hasInput, setHasInput] = useState(false);
  const [fetchedNames, setFetchedNames] = useState([]);
  const activeState = draft?.resourceType === 1 ? "user" : "product";
  const [active, setActive] = useState(activeState);
  const [radio, setRadio] = useState("me");
  const [otherUser, setOtherUser] = useState({
    username: "",
    size: "",
    gender: "",
    age: "",
  });

  const [ages, setAges] = useState([]);

  const [product, setProduct] = useState({
    name: draft?.product?.name || "",
    brandName: draft?.product?.brandName || "",
    price: draft?.product?.price || "",
    quantity: draft?.product?.quantity || "",
    categoryId: draft?.product?.categoryId || "",
    subCategory: draft?.product?.subCategory || "",
    description: draft?.product?.description || "",
    location: draft?.product?.location || "",
    weight: draft?.product?.weight || "",
    images: props.images,
  });

  const handleSelectChange = (selected: any) => {
    setRadio(selected.value);
  };

  useEffect(() => {
    let values = Array.from({ length: 83 }, (_, i) => i + 18);
    let tempAges: any = [];
    values.map((value) => {
      tempAges.push({ value: value, label: value });
    });
    setAges(tempAges);
  }, []);

  const fetchCategories = () => {
    postRequest(EndPoints.categories, {}).then((res) => {
      // console.log(res);
      setCategories(res.data.categories);
      setProduct({ ...product, categoryId: res.data.categories[0].id });
    });
  };

  const fetchShopNames = (userInput: string) => {
    postRequest(EndPoints.shops, {
      name: { contains: userInput, mode: "insensitive" },
    }).then((res) => {
      if (res.data?.status === "success") {
        let shops = res.data.shops;
        let shopsOption: any = [];
        shops.forEach((shop: any) => {
          shopsOption.push({ value: shop.id, label: shop.name });
        });
        setFetchedNames(shopsOption);
        setAddShopButton(!shopsOption.length);
      }
    });
  };

  const debouncedFetch = debounce((userInput: string) => {
    fetchShopNames(userInput);
  }, 500);

  useEffect(() => {
    console.log("draft?.product", draft?.product);
    fetchCategories();
    setProduct({ ...product, ...draft?.product });
    if (!draft?.product?.price) {
      setHasInput(true);
    }
    // eslint-disable-next-line
  }, []);

  useEffect(() => {
    // fetch subcategories
    if (product?.categoryId) {
      postRequest(EndPoints.sub_categories, {
        categoryId: parseInt(product.categoryId),
      }).then((res) => {
        console.log(res.data);
        setSubCategories(res.data.categories);
      });
    }
  }, [product.categoryId]);

  useEffect(() => {
    if (radio === "me") {
      dispatch(
        updateDraft({
          ...draft,
          otherUser: {},
        })
      );
    }
  }, [radio]);

  console.log(draft, "draftproduct");

  const onChange = (e: any) => {
    dispatch(
      updateDraft({
        product: { ...product, [e.target.id]: e.target.value },
      })
    );
    setProduct({ ...product, [e.target.id]: e.target.value });
    if (e.target.id === "price") {
      setHasInput(true);
    }
  };

  const onUserChange = (e: any) => {
    dispatch(
      updateDraft({
        otherUser: { ...otherUser, [e.target.id]: e.target.value },
      })
    );
    setOtherUser({ ...otherUser, [e.target.id]: e.target.value });
  };

  const onSelectChange = (text: any) => {
    if (text.length > 1) {
      debouncedFetch(text);
    }
  };

  const handleShopNameChange = (selected: any) => {
    if (selected?.value) {
      setShopName(selected.value);
      dispatch(
        updateDraft({
          shopId: selected.value,
        })
      ); // Dispatch an action with the selected value
    } else {
      setShopName("");
      dispatch(
        updateDraft({
          shopId: "",
        })
      ); // Dispatch an action with null when selection is cleared
    }
  };

  const finishCreatePost = () => {
    if (!product.price) {
      toast.error("Please provide price!");
      return;
    }
    let user = userProfile;

    if (radio === "other") {
      if (
        !otherUser.username ||
        !otherUser.size ||
        !otherUser.gender ||
        !otherUser.age
      ) {
        toast.error("Please provide all user fields");
        return;
      }
      user = otherUser;
    }

    props.moveForward();
  };

  const handleShopBack = () => {
    setAddShop(false);
    setAddShopButton(false);
  };

  return (
    <div className="lg:px-20 pt-10 pb-20 h-full overflow-y-scroll relative">
      {draft?.resourceType === "POST" && (
        <div className="flex gap-10 pl-2 pb-5">
          <h3
            onClick={() => setActive("user")}
            className={`cursor-pointer ${
              active === "user" && "text-[#FF9800] underline underline-offset-8"
            }`}
          >
            User Details
          </h3>
          <h3
            onClick={() => setActive("product")}
            className={`cursor-pointer ${
              active === "product" &&
              "text-[#FF9800] underline underline-offset-8"
            }`}
          >
            Product Details
          </h3>
        </div>
      )}

      {active === "user" && (
        <div className="p-2">
          <h6 className="font-light mb-2">For</h6>
          <ReactSelect
            options={[
              { value: "me", label: "For Me" },
              { value: "other", label: "For Other" },
            ]}
            onChange={handleSelectChange}
            placeholder="Select"
          />

          {radio === "me" && (
            <>
              <div className="mt-5">
                <UserDisplay user={userProfile} hideLocation />
              </div>
            </>
          )}

          {radio === "other" && (
            <div>
              <div className="flex lg:flex-row flex-col">
                <div className="lg:w-3/5 w-full">
                  <Input
                    label="Name *"
                    id="username"
                    defaultValue={otherUser?.username}
                    onChange={onUserChange}
                  />
                </div>
                <div className="lg:w-1/5 w-full">
                  <Input
                    label="Size *"
                    id="size"
                    type="select"
                    options={[
                      { label: "Free Size", value: "FS" },
                      { label: "Small", value: "SM" },
                      { label: "Medium", value: "MD" },
                      { label: "Large", value: "LG" },
                      { label: "X Large", value: "XL" },
                      { label: "XX Large", value: "XXL" },
                      { label: "XXX Large", value: "XXXL" },
                    ]}
                    defaultValue={otherUser?.size}
                    onChange={onUserChange}
                  />
                </div>
                <div className="lg:w-1/6 w-full">
                  <Input
                    label="Gender *"
                    id="gender"
                    type="select"
                    options={[
                      { label: "Male", value: "male" },
                      { label: "Female", value: "female" },
                      { label: "Other", value: "other" },
                    ]}
                    defaultValue="male"
                    onChange={onUserChange}
                  />
                </div>
                <div className="lg:w-1/6 w-full">
                  <Input
                    label="Age *"
                    id="age"
                    type="select"
                    options={ages}
                    defaultValue={otherUser?.size}
                    onChange={onUserChange}
                  />
                </div>
              </div>
            </div>
          )}
        </div>
      )}

      {active === "product" && (
        <div style={{ paddingBottom: "90px" }}>
          {!addShop && (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
              <div>
                <div className="flex flex-col">
                  <Input
                    label="Product Name"
                    id="name"
                    defaultValue={product?.name}
                    onChange={onChange}
                    placeholder=""
                  />

                  <Input
                    label="Brand Name"
                    id="brandName"
                    defaultValue={product?.brandName}
                    onChange={onChange}
                    placeholder=""
                  />

                  <Input
                    label="Description"
                    id="description"
                    defaultValue={product?.description}
                    onChange={onChange}
                    placeholder=""
                  />
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-2">
                    <Input
                      label="Price (Rs) *"
                      id="price"
                      type="number"
                      defaultValue={product?.price}
                      onChange={onChange}
                      placeholder=""
                    />

                    <Input
                      label="Qty"
                      id="quantity"
                      type="number"
                      defaultValue={product?.quantity}
                      onChange={onChange}
                      placeholder="00"
                    />

                    <Input
                      label="Weight (KG)"
                      id="weight"
                      type="number"
                      defaultValue={product?.weight}
                      onChange={onChange}
                      placeholder="00"
                    />
                  </div>

                  {/* <Input
                    label="Category"
                    id="categoryId"
                    type="select"
                    // defaultValue={product?.categoryId}
                    options={
                      categories?.map((category: any) => {
                        return {
                          label: category.name,
                          value: parseInt(category.id),
                        };
                      }) || []
                    }
                    onChange={onChange}
                    placeholder=""
                  />

                  <Input
                    label="Sub-Category"
                    id="subCategory"
                    type="select"
                    options={
                      subCategories?.map((category: any) => {
                        return {
                          label: category.name,
                          value: parseInt(category.id),
                        };
                      }) || []
                    }
                    onChange={onChange}
                    placeholder=""
                  /> */}

                  <CategorySubcategory label />
                </div>
              </div>
              <div className="pt-4 flex flex-col gap-1">
                <label className="font-medium text-sm">Tag the Shop</label>
                <Select
                  onChange={handleShopNameChange}
                  isDisabled={!hasInput}
                  onInputChange={onSelectChange}
                  isClearable
                  options={fetchedNames}
                  placeholder="Enter at least 2 letters to show ths shops"
                />
                {addShopButton && (
                  <PrimaryButton
                    style="borderButton mt-6 w-12 addshop"
                    label="Add Shop Details"
                    onClick={() => setAddShop(true)}
                    type="button"
                  />
                )}
              </div>
            </div>
          )}
          {addShop && (
            <ShopInfo
              categories={categories}
              subCategories={subCategories}
              handleShopBack={handleShopBack}
              finishCreatePost={finishCreatePost}
              moveForward={props.moveForward}
            />
          )}
        </div>
      )}
      {!addShop && (
        <FooterNav>
          <PrimaryButton
            style="borderButton"
            label="Back"
            onClick={() => props.moveBackward()}
            type="button"
          />
          <PrimaryButton
            label="Next"
            onClick={finishCreatePost}
            type="button"
          />
        </FooterNav>
      )}
    </div>
  );
};

export { ProductInfo };
