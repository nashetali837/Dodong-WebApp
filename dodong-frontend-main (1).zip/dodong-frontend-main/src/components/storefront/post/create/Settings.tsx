import { styled } from "styled-components";
import { EndPoints } from "@/lib/apiConstants";
import { postRequest } from "@/lib/networkHelper";
import useAuth from "@/components/auth/hooks/useAuth";
import FooterNav from "@/components/sections/FooterButtons";
import PrimaryButton from "@/shared/buttons/primary";
import { useDispatch, useSelector } from "react-redux";
import { toast } from "react-toastify";
import { Icons } from "@/components/icons";
import debounce from "lodash.debounce";

const Container = styled.div`
  max-width: 684px;
  margin: auto;

  h5 {
    font-weight: 500;
    margin-bottom: 0.5rem;
    color: #4f4b5c;
  }
`;

const Heading = styled.h3`
  font-size: 18px;
`;

const TitleBar = styled.div`
  display: flex;
  display: -webkit-flex;
  justify-content: space-between;
  margin: 1.5rem 0;
  gap: 1rem;

  svg {
    font-size: 20px;
    color: #4f4b5c;
  }
`;

const TwoColumns = styled.div`
  display: grid;
  gap: 1.5rem;
  grid-template-columns: auto auto;
`;

const Settings = (props: any) => {
  const { userProfile }: any = useSelector((state: any) => state.user);
  const { draft = {} }: any = useSelector((state: any) => state.draft);
  const { authToken } = useAuth();

  const reloadPage = debounce(() => {
    window.location.reload();
  }, 1000);

  const finishCreatePost = () => {
    const data = {
      title: "",
      images: draft.product.images,
      isNewProduct: true,
      productId: null,
      newProduct: {
        ...draft.product,
        categoryId: draft.categoryId,
        subCategory: draft.subCategoryId,
        rating: draft.rating,
      },
      resourceType: draft.resourceType,
      shopId: draft.shopId,

      isNewUserMeasurements: true,
      userMeasurementId: null,
      userMeasurements: draft.otherUser || userProfile,
    };
    console.log("Info data", data);
    postRequest(EndPoints.createPost, data, authToken)
      .then((res) => {
        console.log(res);
        console.log("Info user", JSON.stringify(data));
        toast.success("New Post created", {
          type: "success",
        });
        reloadPage();
      })

      .catch((err) => {
        console.log(err);
        toast("Something went wrong", {
          type: "error",
        });
      });
  };

  return (
    <>
      <Container>
        <TitleBar>
          <Heading>Location</Heading>
          <Icons.map />
        </TitleBar>
        <TitleBar>
          <Heading>Settings</Heading>
          <Icons.arrowright />
        </TitleBar>
        <>
          <h5>Hide like and view counts on this post</h5>
          <p>
            Only you will see the total number of likes and views on this post.
            You can change this later.To hide like counts on other people&apos;s
            posts, go to your account settings.
          </p>
        </>

        <TitleBar>
          <Heading>Accessibility</Heading>
          <TwoColumns>
            <div className="my-auto">
              <label className="inline-flex relative items-center cursor-pointer">
                <input type="checkbox" className="sr-only peer" />
                <div className="w-11 h-6 bg-gray-200 rounded-full peer dark:bg-gray-700 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-0.5 after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all dark:border-gray-600 peer-checked:bg-blue-600"></div>
              </label>
            </div>
            <Icons.arrowright />
          </TwoColumns>
        </TitleBar>
      </Container>
      <FooterNav>
        <PrimaryButton
          style="borderButton"
          onClick={() => props.moveBackward()}
          label="Back"
          type="button"
        />
        <PrimaryButton label="Save" onClick={finishCreatePost} type="button" />
      </FooterNav>
    </>
  );
};

export { Settings };
