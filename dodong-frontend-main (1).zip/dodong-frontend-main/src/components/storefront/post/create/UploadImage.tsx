import React, { useEffect, useRef, useState } from "react";
import axios from "axios";
import Image from "next/image";
import { AiOutlineMinusCircle } from "react-icons/ai";
import { useDispatch, useSelector } from "react-redux";
import PrimaryButton from "@/shared/buttons/primary";
import { updateDraft, deleteDraft } from "@/lib/redux/slices/draft-slice";
import UploadSVG from "../../../../../public/images/upload-image.svg";
import FooterNav from "@/components/sections/FooterButtons";
import { styled } from "styled-components";
import { Icons } from "@/components/icons";
import { toast } from "react-toastify";
import CategorySubcategory from "@/components/sections/CategorySubcategory";
import debounce from "lodash.debounce";
import { Input } from ".";

const BrowseImage = styled.div`
  width: 488px;
  margin: auto;
  border: 1px dashed #e2e2e4;
  border-radius: ${(props) => props.theme.borderRadius.lg};
  flex-direction: column;
  height: 55%;
  padding: 2rem;

  button {
    width: 219px;
    margin: 0px auto;
  }
`;

const PlusIcon = styled.div`
  width: 100px;
  height: 100px;
  background: linear-gradient(
      180deg,
      rgba(255, 255, 255, 0.2) 0%,
      rgba(255, 255, 255, 0) 100%
    ),
    #ff9800;
  box-shadow: 0px 1px 2px -1px rgba(17, 12, 34, 0.08);
  border-radius: ${(props) => props.theme.borderRadius.round};
  color: ${(props) => props.theme.colors.white};
  margin: auto;
  position: relative;
  transform: translateY(-50%);
  top: 50%;
  svg {
    font-size: 40px;
    margin: auto;
    position: relative;
    transform: translateY(-50%);
    top: 50%;
  }
`;

const VideoPlayer = styled.div`
  width: 100%;
  height: 100%;
  > video {
    width: 100%;
    height: 100%;
    object-fit: cover;
  }
`;

const ImgWrapper = styled.div`
  border: 1px solid #e2e2e4;
  border-radius: ${(props) => props.theme.borderRadius.lg};
  position: relative;
  img {
    object-fit: cover;
    object-position: center;
    height: 100%;
    width: 100%;
    border-radius: ${(props) => props.theme.borderRadius.lg};
  }
`;

const ContentColumn = styled.div`
  > .p-2 {
    padding: 0px;
  }
  label {
    font-weight: 400;
  }
  textarea {
    border: 1px solid ${(props) => props.theme.colors.border};
    border-radius: ${(props) => props.theme.borderRadius.button};
    padding: 0.5rem 1rem;
    width: 100%;
    outline: none;
    height: 88px;
    margin-bottom: 2rem;
  }
`;

export const ImageDiscard = styled.div`
  background: rgba(0, 0, 0, 0.75);
  border: 1px solid ${(props) => props.theme.colors.black};
  border-radius: ${(props) => props.theme.borderRadius.button};
  box-shadow: 0px 1px 2px -1px rgba(17, 12, 34, 0.08);
  position: absolute;
  top: 10px;
  right: 10px;
  cursor: pointer;
`;

const Section = styled.div`
  padding: 2rem;
  ${BrowseImage} {
    width: 100%;
    height: 100%;
  }
`;

const FlexBox = styled.div`
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 1.5rem;
  margin: 1.5rem 0 0;
`;

const TextArea = styled.textarea`
  border: 1px solid ${(props) => props.theme.colors.border};
  border-radius: ${(props) => props.theme.borderRadius.button};
  padding: 0.5rem 1rem;
  width: 100%;
  outline: none;
  height: 88px;
  margin-bottom: 2rem;
`;

const Star = styled(Icons.star)`
  color: ${(props) => props.theme.colors.black};
`;

const SolidStar = styled(Icons.solidstar)`
  color: ${(props) => props.theme.colors.primary};
`;

const StarSection = styled.div`
  display: flex;
  display: -webkit-flex;
  gap: 8px;
  margin-top: 0.35rem;
`;

const Tags = styled.div`
  display: flex;
  display: -webkit-flex;
  gap: 8px;
  margin-top: 2rem;
  span {
    display: inline-block;
    border: 1px solid ${(props) => props.theme.colors.border};
    padding: 0.25rem 0.5rem;
    border-radius: ${(props) => props.theme.borderRadius.button};
    &:nth-of-type(2n + 1) {
      background: linear-gradient(
          180deg,
          rgba(255, 255, 255, 0.2) 0%,
          rgba(255, 255, 255, 0) 100%
        ),
        #ececed;
    }
  }
`;

// check login
const uploadImage = async (e: any) => {
  // upload file
  let file = e.target.files[0];
  console.log(file);

  const res = await fetch("/api/upload-s3", {
    headers: {
      "Content-Type": "multipart/form-data",
    },
    method: "POST",
    body: JSON.stringify({
      file: {
        name: "images/" + file.name,
        type: file.type,
      },
    }),
  })
    .then((res) => res.json())
    .catch((err) => {
      console.log(err);
    });

  const url = res.url;

  const uploadRes = await axios
    .put(url, file, {
      headers: {
        "Content-Type": file.type,
        "Access-Control-Allow-Origin": "*",
      },
    })
    .catch((err) => {
      console.log(err);
    });

  let uploadedURL =
    "https://post-uploads.s3.ap-northeast-1.amazonaws.com/images/" +
    encodeURI(file.name);
  console.log(uploadedURL);
  return uploadedURL;
};

const UploadPage = (props: any) => {
  const { draft }: any = useSelector((state: any) => state.draft);
  const inputRef = useRef<HTMLInputElement | null>(null);

  useEffect(() => {
    console.log("draft?.images", draft);
    if (draft?.images) {
      props.moveForward(draft?.images);
    }
  }, []);

  const onPhotoUpload = async (e: any) => {
    let uploadedURL = await uploadImage(e);
    props.moveForward([uploadedURL]);
  };

  return (
    <div className=" w-full h-full my-auto flex items-center justify-center align-middle">
      <BrowseImage className="flex items-center justify-center align-middle">
        <Image
          alt="image-upload"
          className="self-center align-middle mx-auto"
          src={UploadSVG}
          width={150}
          height={150}
        />

        <input
          id="imageUpload"
          ref={inputRef}
          className="hidden"
          placeholder="Upload"
          onChange={onPhotoUpload}
          type="file"
          accept="image/*, video/*"
          multiple
        />
        <p className="mx-auto text-center mb-3 text-sm">
          Drag your images / videos here or
        </p>
        <PrimaryButton
          style="block m-auto"
          label="Browse"
          onClick={() => {
            inputRef.current?.click();
          }}
          type="button"
        />
      </BrowseImage>
    </div>
  );
};

const SelectCategory = (props: any) => {
  const inputRef = useRef<HTMLInputElement | null>(null);
  const dispatch = useDispatch();
  const [images, setImages] = useState(props.images || []);

  const videoRef = useRef<(HTMLVideoElement | null)[]>([]);
  const [isPlaying, setIsPlaying] = useState<boolean[]>([]);
  const [isPauseButtonDisabled, setIsPauseButtonDisabled] = useState(false);

  useEffect(() => {
    const enablePauseButton = debounce(() => {
      setIsPauseButtonDisabled(false);
    }, 3000);

    return () => {
      enablePauseButton.cancel();
    };
  }, []);

  // const handlePlayPause = (key: number) => {
  //   const video = videoRef.current[key];
  //   if (video && video.paused) {
  //     video.play();
  //     setIsPlaying(true);
  //     setIsPauseButtonDisabled(true);
  //   } else if (video) {
  //     video.pause();
  //     setIsPlaying(false);
  //     setIsPauseButtonDisabled(false);
  //   }
  // };

  const handlePlayPause = (key: number) => {
    const video = videoRef.current[key];
    if (video && video.paused) {
      video.play();
      setIsPlaying((prevIsPlaying) => {
        const updatedIsPlaying = [...prevIsPlaying];
        updatedIsPlaying[key] = true;
        return updatedIsPlaying;
      });
      setIsPauseButtonDisabled(true);
      // setTimeout(() => {
      //   setIsPlaying((prevIsPlaying) => {
      //     const updatedIsPlaying = [...prevIsPlaying];
      //     updatedIsPlaying[key] = false;
      //     return updatedIsPlaying;
      //   });
      //   setIsPauseButtonDisabled(false);
      // }, 1000);
    } else if (video) {
      video.pause();
      setIsPlaying((prevIsPlaying) => {
        const updatedIsPlaying = [...prevIsPlaying];
        updatedIsPlaying[key] = false;
        return updatedIsPlaying;
      });
      setIsPauseButtonDisabled(false);
    }
  };

  const onPhotoUpload = async (e: any) => {
    let uploadedURL = await uploadImage(e);
    setImages([...images, uploadedURL]);
  };

  const onPhotoDelete = (index: any) => {
    images.splice(index, 1);
    dispatch(updateDraft({ ...images }));
  };

  return (
    <div className="p-2">
      <div className="flex justify-between py-3">
        <CategorySubcategory row={true} />
      </div>

      <div className="h-96 overflow-scroll grid grid-cols-4 justify-between gap-6 p-3">
        <ImageContainer key="upload-image">
          <PlusIcon
            onClick={() => {
              inputRef.current?.click();
            }}
          >
            <Icons.plus />
          </PlusIcon>
        </ImageContainer>

        {images.map((image: string, key: number) => {
          const imageType = image
            .substring(image.lastIndexOf(".") + 1)
            .toLowerCase();

          return (
            <ImageContainer key={key}>
              {imageType === "mp4" ||
              imageType === "webm" ||
              imageType === "mov" ||
              imageType === "ogg" ? (
                <VideoPlayer
                  onClick={() => handlePlayPause(key)}
                  className={isPauseButtonDisabled ? "pause" : "play"}
                >
                  <video
                    ref={(ref) => (videoRef.current[key] = ref)}
                    controls={false}
                  >
                    <source src={image} />
                  </video>

                  {isPlaying[key] ? <Icons.pause /> : <Icons.play />}
                </VideoPlayer>
              ) : (
                <Image src={image} width={1200} height={1200} alt="" />
              )}

              <ImageDiscard
                onClick={() => {
                  if (images.length === 1) {
                    dispatch(deleteDraft());
                    props.moveBackward();
                  } else {
                    onPhotoDelete(key);
                  }
                }}
              >
                <Icons.close className="text-white text-2xl" />
              </ImageDiscard>
            </ImageContainer>
          );
        })}
      </div>
      {/* add more */}

      <div className="flex justify-between py-3">
        <button
          className="flex text-red-600 hover:bg-gray-50 p-2 duration-100"
          onClick={() => {
            dispatch(deleteDraft());
            props.moveBackward();
          }}
        >
          <div className="mx-3 font-semibold" onClick={props.moveBackward}>
            <AiOutlineMinusCircle className="text-2xl" />
          </div>
          <label htmlFor="select-category" className="font-semibold flex">
            Discard
          </label>
          {/* add dropdown */}
        </button>

        <button className="flex hover:bg-gray-50 p-2 duration-100">
          {/* <div className="mx-3 font-semibold">
            <AiOutlinePlusCircle className="text-2xl text-gray-700" />
          </div> */}
          <input
            className="hidden"
            ref={inputRef}
            id="uploadAnotherPic"
            onChange={onPhotoUpload}
            type="file"
            accept="image/*, video/*"
          />
          {/* <label htmlFor="uploadAnotherPic" className="font-semibold flex">
            Add images
          </label> */}
        </button>
      </div>

      <FooterNav>
        <PrimaryButton
          label="Next"
          onClick={() => props.moveForward(images)}
          type="button"
        />
      </FooterNav>
    </div>
  );
};

const UploadDiscovery = (props: any) => {
  const { draft }: any = useSelector((state) => state);
  const inputRef = useRef<HTMLInputElement | null>(null);
  const dispatch = useDispatch();
  const [rating, setRating] = useState(0);
  const [image, setImage] = useState("");

  const handleRating = (value: any) => {
    setRating(value);
    dispatch(
      updateDraft({
        rating: rating,
      })
    );
  };

  const onChange = (e: any) => {
    dispatch(
      updateDraft({
        description: e.target.value,
      })
    );
  };

  const onPhotoUpload = async (e: any) => {
    let uploadedURL = await uploadImage(e);
    dispatch(
      updateDraft({
        images: [uploadedURL],
      })
    );
    setImage(uploadedURL);
  };

  return (
    <>
      <Section>
        <CategorySubcategory row={true} />
        <FlexBox>
          {image ? (
            <ImageContainer>
              <Image src={image} width={1200} height={1200} alt="" />
            </ImageContainer>
          ) : (
            <BrowseImage className="flex items-center justify-center align-middle">
              <Image
                alt="image-upload"
                className="self-center align-middle mx-auto"
                src={UploadSVG}
                width={150}
                height={150}
              />

              <input
                id="imageUpload"
                ref={inputRef}
                className="hidden"
                placeholder="Upload"
                onChange={onPhotoUpload}
                type="file"
                accept="image/*"
              />
              <p className="mx-auto text-center mb-3 text-sm">
                Drag your images here or
              </p>
              <PrimaryButton
                style="block m-auto"
                label="Browse"
                onClick={() => {
                  inputRef.current?.click();
                }}
                type="button"
              />
            </BrowseImage>
          )}

          <ContentColumn>
            <Input
              label="I discovered"
              id="name"
              textarea
              onChange={onChange}
              placeholder="Enter description"
            />

            <p>I want to rate it</p>

            <StarSection>
              {[...Array(5)].map((_, index) => {
                const ratingValue = index + 1;
                const Icon = ratingValue <= rating ? SolidStar : Star;

                return (
                  <Icon
                    size="32"
                    key={`star-${index}`}
                    onClick={() => handleRating(ratingValue)}
                  />
                );
              })}
            </StarSection>
            <Tags>
              <span>Easy</span>
              <span>Value for money</span>
              <span>Meets expectations</span>
              <span>Always recommended</span>
            </Tags>
          </ContentColumn>
        </FlexBox>
      </Section>
      <FooterNav>
        <PrimaryButton
          label="Next"
          onClick={() => props.moveForward()}
          type="button"
        />
      </FooterNav>
    </>
  );
};

const UploadExperience = (props: any) => {
  const { draft }: any = useSelector((state) => state);
  const inputRef = useRef<HTMLInputElement | null>(null);
  const dispatch = useDispatch();
  const [rating, setRating] = useState(0);
  const [image, setImage] = useState("");

  const handleRating = (value: any) => {
    setRating(value);
    dispatch(
      updateDraft({
        rating: rating,
      })
    );
  };

  const onChange = (e: any) => {
    dispatch(
      updateDraft({
        description: e.target.value,
      })
    );
  };

  const onPhotoUpload = async (e: any) => {
    let uploadedURL = await uploadImage(e);
    dispatch(
      updateDraft({
        images: [uploadedURL],
      })
    );
    setImage(uploadedURL);
  };

  return (
    <>
      <Section>
        <CategorySubcategory row={true} />
        <FlexBox>
          {image ? (
            <ImageContainer>
              {/* <Iframe src={image} width={500} height={500} title="" /> */}
            </ImageContainer>
          ) : (
            <BrowseImage className="flex items-center justify-center align-middle">
              <Image
                alt="image-upload"
                className="self-center align-middle mx-auto"
                src={UploadSVG}
                width={150}
                height={150}
              />

              <input
                id="imageUpload"
                ref={inputRef}
                className="hidden"
                placeholder="Upload"
                onChange={onPhotoUpload}
                type="file"
                accept="video/*"
              />
              <p className="mx-auto text-center mb-3 text-sm">
                Drag your video here
              </p>
              <PrimaryButton
                style="block m-auto"
                label="Browse"
                onClick={() => {
                  inputRef.current?.click();
                }}
                type="button"
              />
            </BrowseImage>
          )}

          <ContentColumn>
            <Input
              label="I discovered"
              id="name"
              textarea
              onChange={onChange}
              placeholder="Enter description"
            />

            <p>I want to rate it</p>

            <StarSection>
              {[...Array(5)].map((_, index) => {
                const ratingValue = index + 1;
                const Icon = ratingValue <= rating ? SolidStar : Star;

                return (
                  <Icon
                    size="32"
                    key={`star-${index}`}
                    onClick={() => handleRating(ratingValue)}
                  />
                );
              })}
            </StarSection>
            <Tags>
              <span>Easy</span> <span>Value for money</span>
              <span>Meets expectations</span> <span>Always recommended</span>
            </Tags>
          </ContentColumn>
        </FlexBox>
      </Section>
      <FooterNav>
        <PrimaryButton
          label="Next"
          onClick={() => props.moveForward()}
          type="button"
        />
      </FooterNav>
    </>
  );
};

const ImageContainer = (props: any) => {
  return <ImgWrapper>{props.children}</ImgWrapper>;
};

export {
  UploadPage,
  SelectCategory,
  uploadImage,
  UploadDiscovery,
  UploadExperience,
};
function enablePauseButton() {
  throw new Error("Function not implemented.");
}
