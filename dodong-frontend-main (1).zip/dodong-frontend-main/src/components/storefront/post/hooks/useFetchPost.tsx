import { useEffect, useState } from "react";

type FetchPostInterface = {
  postId: number;
};

const useFetchPost = (props: FetchPostInterface) => {
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<any>(null);
  const [post, setPost] = useState<any>();

  useEffect(() => {
    // fetch call for this post
    if (props.postId) {
      fetchPost(props.postId);
    } else {
      setLoading(false);
      setError("Please provide postID");
    }
  }, [props.postId]);

  const fetchPost = (postId: number) => {
    // fetch data about the post, post statistics
    
    // fetch top 10 comments
  };

  return { post, fetchPost, error };
};

export default useFetchPost;
