"use client";
import React from "react";
import { AiFillHeart, AiOutlineHeart } from "react-icons/ai";
import { BiRightTopArrowCircle } from "react-icons/bi";
import { TbMessageCircle } from "react-icons/tb";
import { PostProps } from "./types";
import ImageCarousal from "../../../shared/carousal";
import { postRequest } from "@/lib/networkHelper";
import { EndPoints } from "@/lib/apiConstants";
import { useSelector } from "react-redux";
import { toast } from "react-toastify";
import UserBlock from "./ui/UserBlock";
import UserInfo from "./ui/UserInfo";
import useAuth from "@/components/auth/hooks/useAuth";
import { ShopButton } from "./ui/ExpandedPost";
import { Icons } from "@/components/icons";
import { useEffect } from "react";
import { useRouter } from "next/router";

const Post = ({
  post,
  selectPost,
  openPost,
}: {
  post: PostProps;
  selectPost: () => void;
  openPost: () => void;
}): JSX.Element => {
  const { user }: any = useSelector((state) => state);
  const { authToken, isLoggedIn } = useAuth();
  const [liked, setLiked] = React.useState<boolean>(post.post.liked);
  const [likes, setLikes] = React.useState<number>(1);
  const [viewPopup, setViewPopup] = React.useState<boolean>(false);

  const handlePostClick = () => {
    selectPost();
    openPost();
  };

  const stats = [
    {
      label: "Posts",
      value: post.profile.totalPosts || 0,
    },
    {
      label: "Connects",
      value: post.profile.followers,
    },
    {
      label: "Connecting",
      value: post.profile.followers,
    },
  ];

  const _renderPostActions = () => {
    return (
      <div
        style={{ top: "45%", zIndex: 30 }}
        className="absolute right-7 flex flex-col gap-1.5 border border-white rounded-[10rem] p-1 bg-transparent"
      >
        <button
          onClick={postLikeInteraction}
          className="rounded-full bg-white p-3 cursor-pointer"
        >
          {liked ? (
            <AiFillHeart className="text-2xl text-slate-500" />
          ) : (
            <AiOutlineHeart className="text-2xl" />
          )}
          <p>{post?.post?.likes}</p>
        </button>

        <button
          onClick={handlePostClick}
          className="rounded-full bg-white p-3 cursor-pointer"
        >
          <TbMessageCircle className="text-2xl" />
        </button>
        <button
          onClick={handlePostClick}
          className="rounded-full bg-white p-3 cursor-pointer"
        >
          <BiRightTopArrowCircle className="text-2xl" />
        </button>
      </div>
    );
  };

  const postLikeInteraction = () => {
    if (!isLoggedIn) {
      toast.error("Please login to continue");
      return;
    }

    postRequest(
      liked ? EndPoints.unlikePost : EndPoints.likePost,
      {
        postID: post.resourceID,
        userId: user.id,
      },
      authToken
    );
    setLiked(!liked);
    setLikes(liked ? likes - 1 : likes + 1);
  };

  // {
  //   label: "Comment",
  //   value: comments,
  //   icon: (
  //     <TbMessage
  //       className="text-2xl text-black cursor-pointer mr-1"
  //       onClick={() => {
  //         setComments(comments + 1);
  //       }}
  //     />
  //   ),
  // },
  // {
  //   label: "Share",
  //   value: post.post.shares,
  //   icon: (
  //     <BsArrowUpRightCircle className="text-2xl text-black cursor-pointer mr-1" />
  //   ),
  // },

  return (
    <div
      className="relative md:rounded-xl"
      id={post.post.shares}
      style={{ marginBottom: "1.5rem" }}
    >
      {/* Profile section */}
      <UserBlock post={post} toggle={setViewPopup} />
      {/* Post */}
      <div
        onClick={handlePostClick}
        className="relative bg-gray-100 cursor-pointer rounded-bl-xl rounded-br-xl"
      >
        <ImageCarousal height={200} images={post.post.imageURL} />
        {/* Shop Button */}
        <div className="absolute bottom-5 left-5">
          <ShopButton href={`product/${post.productId}`}>
            <Icons.shop className="text-xl" /> <span>Shop</span>
          </ShopButton>
        </div>
      </div>
      {_renderPostActions()}
      {viewPopup && <UserInfo post={post} stats={stats} />}
    </div>
  );
};

export default Post;
