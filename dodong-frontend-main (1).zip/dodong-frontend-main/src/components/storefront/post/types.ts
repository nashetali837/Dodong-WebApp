type PostProps = {
  productId: any;
  profile: {
    name: string;
    avatar?: string;
    displayName: string;
    followers: string;
    following: string;
    totalPosts: string;
    imageURL: string;
    distance: string;
    userID: string;
  };
  shopURL: string;
  post: {
    imageURL: string[];
    description: string;
    liked: boolean;
    likes: string;
    comments: string;
    shares: string;
  };
  id: number;
  liked: boolean;
  authorId: string;
  resourceID: number;
};

type UserType = {
  id: number;
  email: string;
  mobileNumber: string;
  password?: string;
  emailVerified: boolean;
  userType: Role;
  createdAt?: Date;
  lastLogin?: Date;
  OTP: string | null;
  OTPExpiry?: Date | null;
};

type Role = {
  ADMIN: "ADMIN";
  USER: "USER";
};

export type { PostProps, UserType, Role };
