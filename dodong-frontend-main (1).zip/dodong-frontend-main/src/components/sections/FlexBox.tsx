import React, { CSSProperties } from "react";
import styled from "styled-components";

export const FlexBoxStyle = styled.div`
  display: flex;
  display: -webkit-flex;
  align-items: normal;
  flex-direction: row;
`;

export const FlexBoxCenter = styled(FlexBoxStyle)`
  align-items: center;
  justify-content: space-between;
`;

interface BoxProps {
  align?: CSSProperties["alignItems"];
  padding?: CSSProperties["padding"];
  flex?: CSSProperties["flex"];
  direction?: CSSProperties["flexDirection"];
  wrap?: boolean;
  height?: CSSProperties["height"];
  justify?: CSSProperties["justifyContent"];
  gap?: CSSProperties["gap"];
}

const Box = styled.div<BoxProps>`
  display: flex;
  align-items: ${(props) => props.align || "normal"};
  padding: ${(props) => props.padding || null};
  flex: ${(props) => props.flex || "0 1 auto"};
  flex-direction: ${(props) => props.direction || "row"};
  flex-wrap: ${(props) => (props.wrap ? "wrap" : "nowrap")};
  height: ${(props) => props.height || "auto"};
  justify-content: ${(props) => props.justify || "normal"};
  gap: ${(props) => (props.gap ? props.gap : null)};
`;

interface FlexBoxProps extends BoxProps {
  className?: string;
  onClick?: () => void; // Make onClick prop optional
  children: React.ReactNode;
  style?: React.CSSProperties; // Added style prop
}

const FlexBox = ({ className, children, wrap, ...rest }: FlexBoxProps) => {
  return (
    <Box className={className} wrap={wrap} {...rest}>
      {children}
    </Box>
  );
};

export default FlexBox;
