import styled, { css } from "styled-components";

const Section = styled.div`
  border-top: 1px solid ${(props) => props.theme.colors.border};
  padding: 1.5rem 3rem;
  width: 100%;
  position: fixed;
  bottom: 0;
  background: ${(props) => props.theme.colors.white};
  left: 0;
`;

const Container = styled.div`
  display: grid;
  grid-template-columns: auto auto;
  gap: 1rem;
  justify-content: right;
`;

const FooterNav = (props: any) => {
  return (
    <Section {...props}>
      <Container>{props.children}</Container>
    </Section>
  );
};

export default FooterNav;
