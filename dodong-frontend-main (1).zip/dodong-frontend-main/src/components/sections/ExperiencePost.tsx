import React from "react";
import Slider from "react-slick";
import { Icons } from "@/components/icons";
import styled from "styled-components";
import { CenterNav } from "../../pages/product/[slug]";
import Image from "next/image";

interface Post {
  post: any;
  id: number;
  title: string;
  imageURL: string;
}

interface PostProps {
  posts: Post[];
}

const Wrapper = styled.div`
  position: relative;
  margin-bottom: 1rem;
  .slick-slide {
    padding-right: 0.75rem;
  }
`;

const PostWrapper = styled.iframe`
  border-radius: ${(props) => props.theme.borderRadius.lg};
  border: none;
`;

const ExperiencePost = ({ posts }: PostProps) => {
  const NextArrow = (props: any) => {
    const { className, onClick } = props;
    return (
      <CenterNav className={className} onClick={onClick}>
        <Icons.arrowright />
      </CenterNav>
    );
  };

  const PrevArrow = (props: any) => {
    const { className, onClick } = props;
    return (
      <CenterNav className={className} onClick={onClick}>
        <Icons.arrowleft />
      </CenterNav>
    );
  };

  const settings = {
    slidesToShow: 4,
    slidesToScroll: 4,
    infinite: true,
    dots: false,
    nextArrow: <NextArrow />,
    prevArrow: <PrevArrow />,
    variableWidth: true,
    swipeToSlide: true,
    responsive: [
      {
        breakpoint: 768,
        settings: {
          slidesToShow: 3,
          slidesToScroll: 3,
        },
      },
      {
        breakpoint: 480,
        settings: {
          slidesToShow: 2,
          slidesToScroll: 2,
        },
      },
    ],
  };

  return (
    <Wrapper>
      <Slider {...settings}>
        {posts.map((post) => (
          <div key={post.id}>
            <PostWrapper
              src={post?.post?.imageURL[0]}
              width={120}
              height={140}
            />
          </div>
        ))}
      </Slider>
    </Wrapper>
  );
};

export default ExperiencePost;
