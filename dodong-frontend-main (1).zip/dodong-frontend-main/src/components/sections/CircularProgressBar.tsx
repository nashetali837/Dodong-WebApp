import { useEffect, useRef, useState } from "react";
import styled from "styled-components";
import { sendAPIRequest } from "../../../utils/apiService";
import { EndPoints } from "@/lib/apiConstants";
import useAuth from "@/components/auth/hooks/useAuth";

const ProgressSection = styled.div`
  position: relative;

  &:after {
    position: absolute;
    top: 50%;
    left: 50%;
    font-size: 12px;
    transform: translate(-50%, -50%);
    content: attr(data-percent) "%";
  }
`;

const CircleBar = styled.svg`
  display: block;
  margin: 0 auto;
  overflow: hidden;
  transform: rotate(-90deg) rotateX(180deg);
`;

const Circle = styled.circle`
  stroke-dashoffset: 0;
  transition: stroke-dashoffset 1s ease;
  stroke: #4f4b5c;
  stroke-width: 1rem;
`;

const FilledCircle = styled(Circle)`
  stroke: #ececed;
`;

const CircularProgressBar = ({ onLogout }: { onLogout: () => void }) => {
  const barRef = useRef<SVGCircleElement>(null);
  const [profilePercentage, setProfilePercentage] = useState(20);
  const percentage = profilePercentage;
  const { authToken } = useAuth();

  useEffect(() => {
    const fetchProfileCompletion = async () => {
      try {
        const config = {
          endPoint: EndPoints.profile,
          method: "GET",
          token: authToken,
        };
        const { data } = await sendAPIRequest({ config });
        if (data && data.profileCompletion?.percent) {
          // Assuming the API response is an object with "percent" property
          setProfilePercentage(data?.profileCompletion?.percent);
        } else {
          onLogout();
        }
      } catch (e) {
        console.log(e);
      }
    };

    fetchProfileCompletion();
  }, []);

  useEffect(() => {
    const totalProgress = barRef.current?.getAttribute("stroke-dasharray");
    barRef.current!.style.strokeDashoffset = `${
      (Number(totalProgress) * percentage) / 100
    }`;
  }, [percentage]);

  return (
    <ProgressSection data-percent={percentage}>
      <CircleBar
        width="40" /* Updated width */
        height="40" /* Updated height */
        viewBox="0 0 178 178" /* Updated viewBox */
        version="1.1"
        xmlns="http://www.w3.org/2000/svg"
      >
        <Circle
          r="80"
          cx="89"
          cy="89"
          fill="transparent"
          strokeDasharray="502.4"
          strokeDashoffset="0"
        ></Circle>
        <FilledCircle
          ref={barRef}
          r="80"
          cx="89"
          cy="89"
          fill="transparent"
          strokeDasharray="502.4"
          strokeDashoffset="0"
        ></FilledCircle>
      </CircleBar>
    </ProgressSection>
  );
};

export default CircularProgressBar;
