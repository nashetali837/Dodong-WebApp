import { useState, useEffect } from "react";
import Select from "react-select";
import { sendAPIRequest } from "../../../utils/apiService";
import { EndPoints } from "@/lib/apiConstants";
import styled, { css } from "styled-components";
import { useDispatch, useSelector } from "react-redux";
import { updateDraft } from "@/lib/redux/slices/draft-slice";

const RowSection = styled.div`
  display: flex;
  display: -webkit-flex;
  gap: 1rem;
  flex-direction: row;

  .inputSelect {
    width: 30%;
    min-width: 180px;

    &.inputSubCat {
      width: 40%;
      min-width: 220px;
    }
  }
`;

const Section = styled.div`
  .inputSelect {
    text-transform: capitalize;
    > div {
      border-radius: ${(props) => props.theme.borderRadius.button};
    }
  }

  .default-select__control {
    &:hover,
    &:focus,
    &--is-focused {
      border-color: ${(props) => props.theme.colors.border};
    }
  }

  & .default-select__option {
    background-color: transparent;
    cursor: pointer;
    padding: 0.45rem;

    &:not(:last-child) {
      border-bottom: 1px solid ${(props) => props.theme.colors.border};
    }

    &:hover,
    &--is-selected {
      color: ${(props) => props.theme.colors.black};
      background-color: transparent;
    }
  }

  .default-select__indicator-separator {
    display: none;
  }

  ${(props: any) =>
    props.row &&
    css`
      flex-direction: row;
    `}
`;

type CategorySubcategoryProps = {
  label?: boolean;
  row?: boolean;
};

const CategorySubcategory = (props: CategorySubcategoryProps) => {
  const [categoriesData, setCategoriesData] = useState<null | any>(null);
  const [subcategoriesData, setSubcategoriesData] = useState<null | any>(null);
  const [selectedCategoryId, setSelectedCategoryId] = useState<number | null>(
    null
  );
  const { draft: updatedValue }: any = useSelector((state) => state);

  const dispatch = useDispatch();

  useEffect(() => {
    const fetchCategoriesData = async () => {
      try {
        const config = { endPoint: EndPoints.categories };
        const { data } = await sendAPIRequest({ config });
        setCategoriesData(data);
      } catch (e) {
        console.log(e);
      }
    };

    fetchCategoriesData();
  }, []);

  useEffect(() => {
    const fetchSubcategoriesData = async () => {
      try {
        const config = {
          endPoint: EndPoints.sub_categories,
          data: { categoryId: selectedCategoryId }, // Replace 1 with the selected category ID
        };
        const { data } = await sendAPIRequest({ config });
        setSubcategoriesData(data);
      } catch (e) {
        console.log(e);
      }
    };

    if (selectedCategoryId) {
      fetchSubcategoriesData();
    } else {
      setSubcategoriesData(null); // Reset subcategories data when no category is selected
    }
  }, [selectedCategoryId]);

  const handleCategoryChange = (e: any) => {
    setSelectedCategoryId(e.value);

    dispatch(
      updateDraft({
        categoryId: e.value,
      })
    );
  };

  const handleSubCategoryChange = (e: any) => {
    setSelectedCategoryId(e.value);

    dispatch(
      updateDraft({
        subCategoryId: e.value,
      })
    );
  };

  // Function to find the category name based on ID
  const findCategoryName = (categoryId: number) => {
    const category = categoriesData?.categories?.find(
      (category: { id: string }) => parseInt(category.id) === categoryId
    );
    return category ? category.name : "";
  };

  // Function to find the subcategory name based on ID
  const findSubCategoryName = (subCategoryId: number) => {
    const subcategory = subcategoriesData?.categories?.find(
      (subcategory: { id: string }) =>
        parseInt(subcategory.id) === subCategoryId
    );
    return subcategory ? subcategory.name : "";
  };

  return (
    <Section {...props}>
      {props.label ? (
        <>
          <div className="p-2">
            <div className="py-1">
              <label htmlFor="categoryId" className="font-medium text-sm">
                Category
              </label>
            </div>
            <Select
              id="category"
              className="inputSelect"
              classNamePrefix="default-select"
              placeholder="Select Category"
              options={
                categoriesData?.categories?.map((category: any) => {
                  return {
                    label: category.name.toString(),
                    value: parseInt(category.id),
                  };
                }) || []
              }
              onChange={handleCategoryChange}
              // defaultValue={{
              //   label: findCategoryName(draft?.categoryId),
              //   value: draft?.categoryId,
              // }}
            />
          </div>

          <div className="p-2">
            <div className="py-1">
              <label htmlFor="categoryId" className="font-medium text-sm">
                Sub-Category
              </label>
            </div>

            <Select
              id="subcategory"
              className="inputSelect inputSubCat"
              classNamePrefix="default-select"
              placeholder="Select Sub Category"
              options={
                subcategoriesData?.categories?.map((subcategory: any) => {
                  return {
                    label: subcategory.name.toString(),
                    value: parseInt(subcategory.id),
                  };
                }) || []
              }
              onChange={handleSubCategoryChange}
              // defaultValue={{
              //   label: findSubCategoryName(draft?.subCategoryId),
              //   value: draft?.subCategoryId,
              // }}
            />
          </div>
        </>
      ) : (
        <RowSection>
          <Select
            id="category"
            className="inputSelect"
            classNamePrefix="default-select"
            placeholder="Select Category"
            options={
              categoriesData?.categories?.map((category: any) => {
                return {
                  label: category.name.toString(),
                  value: parseInt(category.id),
                };
              }) || []
            }
            onChange={handleCategoryChange}
            // defaultValue={{
            //   label: findCategoryName(draft?.categoryId),
            //   value: draft?.categoryId,
            // }}
          />
          <Select
            id="subcategory"
            className="inputSelect inputSubCat"
            classNamePrefix="default-select"
            placeholder="Select Sub Category"
            options={
              subcategoriesData?.categories?.map((subcategory: any) => {
                return {
                  label: subcategory.name.toString(),
                  value: parseInt(subcategory.id),
                };
              }) || []
            }
            onChange={handleSubCategoryChange}
            // defaultValue={{
            //   label: findSubCategoryName(draft?.subCategoryId),
            //   value: draft?.subCategoryId,
            // }}
          />
        </RowSection>
      )}
    </Section>
  );
};

export default CategorySubcategory;
