import {
  AiFillGithub,
  AiOutlineGoogle,
  AiOutlinePlus,
  AiOutlinePause,
  AiOutlineHeart,
  AiOutlineUserAdd,
} from "react-icons/ai";
import { FaSpinner } from "react-icons/fa";
import {
  BsFacebook,
  BsTwitter,
  BsStar,
  BsStarFill,
  BsWhatsapp,
} from "react-icons/bs";
import { RiMapPinLine, RiStore3Line } from "react-icons/ri";
import {
  HiOutlineArrowRight,
  HiOutlineArrowLeft,
  HiOutlineShoppingCart,
  HiOutlineUserCircle,
} from "react-icons/hi";
import { RiCloseLine, RiWechatLine } from "react-icons/ri";
import { CiPlay1, CiCircleList } from "react-icons/ci";
import {
  MdOutlineArrowBackIos,
  MdOutlineArrowForwardIos,
} from "react-icons/md";
import { HiOutlineEnvelope } from "react-icons/hi2";
import { FiMoreHorizontal } from "react-icons/fi";
import { CgImage } from "react-icons/cg";
import { TbDots } from "react-icons/tb";

export const Icons = {
  gitHub: AiFillGithub,
  spinner: FaSpinner,
  google: AiOutlineGoogle,
  fb: BsFacebook,
  twitter: BsTwitter,
  map: RiMapPinLine,
  next: HiOutlineArrowRight,
  prev: HiOutlineArrowLeft,
  plus: AiOutlinePlus,
  close: RiCloseLine,
  star: BsStar,
  solidstar: BsStarFill,
  play: CiPlay1,
  pause: AiOutlinePause,
  shop: RiStore3Line,
  circlelist: CiCircleList,
  arrowleft: MdOutlineArrowBackIos,
  arrowright: MdOutlineArrowForwardIos,
  cart: HiOutlineShoppingCart,
  wishlist: AiOutlineHeart,
  user: AiOutlineUserAdd,
  Whatsapp: BsWhatsapp,
  email: HiOutlineEnvelope,
  chat: RiWechatLine,
  more: FiMoreHorizontal,
  usercircle: HiOutlineUserCircle,
  image: CgImage,
  tdots: TbDots,
};
