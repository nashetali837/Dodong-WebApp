"use client";
import { EndPoints } from "@/lib/apiConstants";
import { updateAuthState } from "@/lib/redux/slices/auth-slice";
import { saveUser, toggleLoginModal } from "@/lib/redux/slices/user-slice";
import { useEffect } from "react";
import { useLogin } from "react-facebook";
import { BsFacebook } from "react-icons/bs";
import { useDispatch } from "react-redux";

export const facebookAppId = "724627192289395";

function initFacebookSdk() {
  return new Promise((resolve) => {
    // wait for facebook sdk to initialize before starting the react app
    window.fbAsyncInit = function () {
      window.FB.init({
        appId: facebookAppId,
        autoLogAppEvents: true,
        xfbml: true,
        version: "v15.0",
      });

      // auto authenticate with the api if already logged in with facebook
      window.FB.getLoginStatus(({ authResponse }) => {
        if (authResponse) {
          accountService
            .apiAuthenticate(authResponse.accessToken)
            .then((res) => {
              console.log("res", res);
              resolve();
            });
        } else {
          resolve();
        }
      });
    };

    // load facebook sdk script
    (function (d, s, id) {
      var js,
        fjs = d.getElementsByTagName(s)[0];
      if (d.getElementById(id)) {
        return;
      }
      js = d.createElement(s);
      js.id = id;
      js.src = "https://connect.facebook.net/en_US/sdk.js";
      fjs.parentNode.insertBefore(js, fjs);
    })(document, "script", "facebook-jssdk");
  });
}

export default function FacebookButton() {
  const dispatch = useDispatch();
  const { status, error } = useLogin();

  useEffect(() => {
    initFacebookSdk();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  async function handleLogin() {
    try {
      FB.login(function (response) {
        if (response.authResponse) {
          console.log("Welcome!  Fetching your information.... ");

          FB.getLoginStatus(function (response) {
            if (response.status === "connected") {
              let accessToken = response.authResponse.accessToken;
              console.log(accessToken);
              // send this access token to the backend
              fetch(EndPoints.facebookAuth, {
                method: "POST",
                headers: {
                  "Content-Type": "application/json",
                },
                body: JSON.stringify({ tokenId: accessToken }),
              })
                .then((res) => res.json())
                .then((resJson) => {
                  console.log("Facebook auth response", resJson);
                  if (resJson) {
                    dispatch(updateAuthState({ authToken: resJson.token }));
                    dispatch(saveUser(resJson.user));
                    dispatch(toggleLoginModal(false));
                  }
                })
                .catch((error) => {
                  console.log("Facebook auth error", error);
                });
            }
          });
        } else {
          console.log("User cancelled login or did not fully authorize.");
        }
      });
    } catch (error) {
      console.log(error.message);
    }
  }

  return (
    <div
      scope="email"
      className="flex justify-between text-sm font-normal whitespace-nowrap gap-2 my-auto"
      onClick={handleLogin}
    >
      <BsFacebook className="text-blue-600" size={22} /> Continue with Facebook
    </div>
  );
}
