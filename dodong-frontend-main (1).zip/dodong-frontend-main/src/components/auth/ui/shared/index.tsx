import React from "react";

export default function SeparatorLine({ label = "OR" }: { label?: string }) {
  return (
    <div className="flex my-8 gap-4 w-full max-w-2xl">
      <div className="flex-1 items-center mt-2">
        <div className="w-full border-t border-slate-300"></div>
      </div>
      <div className="relative flex justify-center text-xs uppercase">
        <span className="px-2 text-slate-500">{label}</span>
      </div>
      <div className="flex-1 items-center mt-2">
        <div className="w-full border-t border-slate-300"></div>
      </div>
    </div>
  );
}
