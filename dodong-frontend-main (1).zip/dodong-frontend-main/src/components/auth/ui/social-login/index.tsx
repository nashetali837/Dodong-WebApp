"use client";
import React from "react";
import { FacebookProvider } from "react-facebook";
import dynamic from "next/dynamic";
import { useDispatch } from "react-redux";
import { GoogleLogin } from "@react-oauth/google";

import { EndPoints } from "@/lib/apiConstants";
import { saveUser, toggleLoginModal } from "@/lib/redux/slices/user-slice";
import { updateAuthState } from "@/lib/redux/slices/auth-slice";
import { toast } from "react-toastify";
import { facebookAppId } from "@/components/auth/facebook";
import { AuthModalType } from "../..";

const FacebookButton = dynamic(() => import("@/components/auth/facebook"), {
  ssr: false,
});

const SocialLoginComponent = (props: any) => {
  const dispatch = useDispatch();

  const responseSuccessGoogle = (response: any) => {
    console.log("Google auth response", response);

    fetch(EndPoints.googleAuth, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ tokenId: response.credential }),
    })
      .then((res) => {
        if (res.status === 200) {
          return res.json();
        }
        throw new Error("Google authentication failed");
      })
      .then((resJson) => {
        console.log("Google auth response", resJson);
        if (resJson) {
          dispatch(
            updateAuthState({ authToken: resJson.token, isLoggedIn: true })
          );
          dispatch(saveUser(resJson.user));
          dispatch(toggleLoginModal(false));
          toast.success("Google login successful!");
        }
      })
      .catch((error) => {
        console.log("Google auth error", error);
        toast.error("Google login failed. Please try again!");
      });
  };

  const responseFailGoogle = () => {
    toast.error("Google login failed. Please try again!");
  };

  return (
    <React.Fragment>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-5 justify-center">
        <GoogleLogin
          onSuccess={responseSuccessGoogle}
          onError={responseFailGoogle}
        />
        <button
          type="button"
          className="inline-flex items-center justify-center border bg-white rounded-sm px-5 py-2 h-full text-center text-sm font-medium text-black hover:bg-slate-100 focus:outline-none focus:ring-4 focus:ring-[#24292F]/50 disabled:opacity-50 dark:hover:bg-[#050708]/30 dark:focus:ring-slate-500"
          //onClick={() => signIn("github")}
          //disabled={isLoading}
        >
          <FacebookProvider appId={facebookAppId}>
            <FacebookButton />
          </FacebookProvider>
        </button>
      </div>
      <div className="my-7 text-center">
        <div className="text-sm text-gray-600 justify-self-end font-medium">
          {props.authType === AuthModalType.LOGIN
            ? "Don't have an account?"
            : "Already have an account?"}

          <span
            onClick={() => {
              props.switch(
                props.authType === AuthModalType.SIGNUP
                  ? AuthModalType.LOGIN
                  : AuthModalType.SIGNUP
              );
            }}
            className="ml-2 cursor-pointer text-orange-600 underline-offset-1"
          >
            {props.authType === AuthModalType.LOGIN ? "Sign up" : "Login"}
          </span>
        </div>
      </div>
      {props.authType === AuthModalType.SIGNUP && (
        <div className="flex justify-center text-center mb-4">
          <input
            id="agreed"
            type="checkbox"
            value=""
            className="w-4 h-4 my-auto align-middle text-green-600 bg-gray-100 border-gray-300 rounded focus:ring-green-700 dark:focus:ring-green-600 dark:ring-offset-gray-800 focus:ring-2 dark:bg-gray-700 focus:outline-none dark:border-gray-600"
          />
          <label
            htmlFor="agreed"
            className="ml-4 text-md align-middle font-medium text-gray-900 dark:text-gray-700"
          >
            I have read and understood the Terms and Privacy Policy
          </label>
        </div>
      )}
    </React.Fragment>
  );
};

export default SocialLoginComponent;
