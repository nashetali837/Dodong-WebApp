"use client";

import React, { useState } from "react";
import z, { ZodError } from "zod";
import { toast } from "react-toastify";
import { useRouter } from "next/navigation";
import { useMutation } from "@tanstack/react-query";
import { userSignInSchema } from "@/lib/validations/auth";
import { postRequest } from "@/lib/networkHelper";
import { EndPoints } from "@/lib/apiConstants";
import axios from "axios";
import { useDispatch } from "react-redux";
import {
  saveUser,
  toggleForgotPasswordModal,
  toggleLoginModal,
} from "@/lib/redux/slices/user-slice";
import { updateAuthState } from "@/lib/redux/slices/auth-slice";
import { Icons } from "../../../icons";
import { fromZodError } from "zod-validation-error";
import TextInput from "@/shared/input-groups/TextInput";
import PrimaryButton from "@/shared/buttons/primary";

interface UserAuthFormProps extends React.HTMLAttributes<HTMLDivElement> {}

type userSignInSchema = z.infer<typeof userSignInSchema>;

export function UserLoginForm({ className, ...props }: UserAuthFormProps) {
  const dispatch = useDispatch();
  const [loading, setLoading] = useState(false);

  const mutation = useMutation({
    mutationFn: (data: userSignInSchema) => {
      return postRequest(EndPoints.login, data);
    },
    onSuccess: (response) => {
      console.log(response.data, "returned data");
      dispatch(updateAuthState({ authToken: response.data.token }));
      dispatch(
        saveUser({
          ...response.data,
        })
      );
      dispatch(toggleLoginModal(false));
      toast.success("Login Successful");
      setLoading(false);
    },

    onError: (error: any) => {
      console.log(error.response?.data);
      if (axios.isAxiosError(error)) {
        toast.error(error.response?.data.message);
      }
      if (error instanceof ZodError) {
        console.log(fromZodError(error));
        return toast.error("Please enter valid data");
      }
      setLoading(false);
    },
  });

  const handleSubmit = (event: React.FormEvent<HTMLFormElement>): any => {
    event.preventDefault();
    setLoading(true);

    try {
      const data = {
        email: (event.target as HTMLFormElement).email.value,
        password: (event.target as HTMLFormElement).password.value,
      };

      if (!data.email || !data.password) {
        toast.error("Please enter all the fields");
        setLoading(false);
        return;
      }

      const isValidData = userSignInSchema.parse(data);
      mutation.mutate(isValidData);
    } catch (error: any) {
      if (error instanceof ZodError) {
        const validationError = fromZodError(error);
        setLoading(false);
        toast.error(validationError.message);
      }
    }
  };

  return (
    <div className="w-full">
      <div className="grid gap-2 mx-2 lg:mx-10">
        <form onSubmit={handleSubmit}>
          <div className="grid gap-2">
            <div className="">
              <TextInput
                id="email"
                label="Email Address"
                type="email"
                placeholder="Enter Email/Phone Number"
              />
            </div>
            <div className="">
              <TextInput
                id="password"
                label="Password"
                type="password"
                placeholder="**********"
              />
            </div>
            <PrimaryButton
              type="submit"
              disabled={loading}
              label="Sign In"
              loading={loading}
            />
          </div>
        </form>

        <div className="flex my-2 justify-between">
          <div className="flex items-center">
            <input
              id="link-checkbox"
              type="checkbox"
              value=""
              className="w-4 h-4 text-red-600 bg-gray-100 border-gray-300 rounded focus:ring-red-500 dark:focus:ring-red-600 dark:ring-offset-gray-800 focus:ring-2 dark:bg-gray-700 focus:outline-none dark:border-gray-600"
            />
            <label
              htmlFor="link-checkbox"
              className="ml-2 text-md font-medium text-gray-900 dark:text-gray-700"
            >
              Keep me logged in
            </label>
          </div>
          <div className="">
            <div
              onClick={() => {
                dispatch(toggleForgotPasswordModal(true));
              }}
              className="text-md cursor-pointer text-black font-medium"
            >
              Forgot password?
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
