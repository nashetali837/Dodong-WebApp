"use client";

import React, { useState } from "react";
import z, { ZodError } from "zod";
import { toast } from "react-toastify";
import { useMutation } from "@tanstack/react-query";
import { resetPasswordSchema } from "@/lib/validations/auth";
import { postRequest } from "@/lib/networkHelper";
import { EndPoints } from "@/lib/apiConstants";
import axios from "axios";
import { useDispatch } from "react-redux";
import { Icons } from "../../../icons";
import { fromZodError } from "zod-validation-error";
import {
  toggleForgotPasswordModal,
  toggleLoginModal,
} from "@/lib/redux/slices/user-slice";

type resetPasswordSchema = z.infer<typeof resetPasswordSchema>;

export function ResetPasswordForm(props: {
  switch: any;
  email: string;
  temporaryToken: string;
}) {
  const dispatch = useDispatch();
  const [loading, setLoading] = useState(false);

  const mutation = useMutation({
    mutationFn: (data: resetPasswordSchema) => {
      return postRequest(EndPoints.resetPassword, data, props.temporaryToken);
    },
    onSuccess: (response) => {
      console.log("returned data", response.data);

      toast.success("Password reset successful. Please login to continue");
      dispatch(toggleForgotPasswordModal(false));
      dispatch(toggleLoginModal(true));
    },

    onError: (error: any) => {
      console.log(error.response?.data);
      if (axios.isAxiosError(error)) {
        toast.error(error.response?.data.message);
      }
      setLoading(false);
      if (error instanceof ZodError) {
        console.log(fromZodError(error));
        return toast.error("Please enter valid data");
      }
    },
  });

  const handleSubmit = (event: React.FormEvent<HTMLFormElement>): any => {
    event.preventDefault();

    try {
      const data = {
        email: props.email,
        newPassword: (event.target as HTMLFormElement).newPassword.value,
        confirmPassword: (event.target as HTMLFormElement).confirmPassword
          .value,
      };

      if (!data.newPassword || !data.confirmPassword) {
        toast.error("Please enter all the fields");
        return;
      }

      if (data.newPassword !== data.confirmPassword) {
        toast.error("Passwords do not match! Please enter matching Passwords");
        return;
      }

      const isValidData = resetPasswordSchema.parse(data);
      console.log(isValidData);
      mutation.mutate(isValidData);
    } catch (error: any) {
      if (error instanceof ZodError) {
        const validationError = fromZodError(error);
        setLoading(false);
        toast.error(validationError.message);
      }
    }
  };

  return (
    <div className="grid gap-6">
      <form onSubmit={handleSubmit}>
        <h5 className="text-orange-593500 text-2xl mb-3 text-center font-medium">
          Reset your Password
        </h5>
        <div>Please reset your password in 5 minutes for {props.email}</div>
        <div className="grid gap-2">
          <div className="grid gap-1">
            <input
              id="newPassword"
              placeholder="New Password"
              className="bg-transparent text-734400 my-1 mb-2 block h-9 w-full rounded-md border border-734400 py-2 px-3 text-sm placeholder:text-734400 hover:border-734400 focus:border-734400 focus:outline-none"
              type="password"
              name="newPassword"
            />
          </div>
          <div className="grid gap-2">
            <input
              id="confirmPassword"
              placeholder="Confirm New Password"
              className="bg-transparent text-734400 my-1 mb-2 block h-9 w-full rounded-md border border-734400 py-2 px-3 text-sm placeholder:text-734400 hover:border-734400 focus:border-734400 focus:outline-none"
              type="password"
              name="confirmPassword"
            />
          </div>
          <button
            disabled={loading}
            className="my-0 mb-8 mx-auto inline-flex w-full items-center justify-center rounded-full bg-orange-500 px-5 py-2.5 text-center text-sm font-medium text-white focus:outline-none disabled:opacity-50"
          >
            {loading && <Icons.spinner className="mr-2 h-4 w-4 animate-spin" />}
            Reset Password
          </button>
        </div>
      </form>
    </div>
  );
}
