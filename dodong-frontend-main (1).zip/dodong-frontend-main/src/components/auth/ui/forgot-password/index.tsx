"use client";
import React, { useState } from "react";
import Image from "next/image";
import dodongLogo from "../../../../../public/images/common/dodong-logo.svg";
import { useDispatch, useSelector } from "react-redux";
import { toggleForgotPasswordModal } from "@/lib/redux/slices/user-slice";
import { useRouter } from "next/router";
import { AiOutlineCloseCircle } from "react-icons/ai";
import { ForgotPasswordAuthForm } from "./forgot-password-form";
import { OtpAuthForm } from "./otp-form";
import { ResetPasswordForm } from "./reset-password-form";

export default function ForgotPasswordModal() {
  const { openForgotPasswordModal } = useSelector((state: any) => state.user);
  const [state, setState] = useState({
    type: "forgot-password",
    email: "",
    temporaryToken: "",
  });
  const dispatch = useDispatch();
  const router = useRouter();


  if (!openForgotPasswordModal) {
    return <div />;
  }

  return (
    <div className="h-screen w-screen justify-center align-middle sticky top-0 z-50 overflow-hidden">
      <div
        className="bg-black bg-opacity-50 py-10 px-2 fixed duration-150 h-full my-auto top-0 w-screen"
        style={{ zIndex: 20 }}
      >
        <section
          style={{ zIndex: 120 }}
          className="bg-neutral-100 max-w-5xl py-3 align-middle self-center mx-auto overflow-hidden flex justify-center flex-col items-center"
        >
          <div
            className="ml-auto mx-4 cursor-pointer"
            onClick={() => {
              dispatch(toggleForgotPasswordModal(false));
            }}
          >
            <AiOutlineCloseCircle className="text-black text-2xl" />
          </div>
          <div className="mb-10">
            <Image
              src={dodongLogo}
              alt="Picture of the author"
              width={307}
              height={307}
            />
          </div>
          <div className="flex flex-col items-center mb-10">
            <div className="text-734400 font-bold">Welcome to DODONG</div>
            <div className="font-normal italic text-orange-CC7A00">
              Go online Do dong
            </div>
          </div>
          {state.type === "forgot-password" && (
            <ForgotPasswordAuthForm switch={setState} />
          )}
          {state.type === "verify-otp" && (
            <OtpAuthForm
              switch={(data: { temporaryToken: string }) =>
                setState({
                  ...state,
                  temporaryToken: data.temporaryToken,
                  type: "reset-password",
                })
              }
              email={state.email}
            />
          )}
          {state.type === "reset-password" && (
            <ResetPasswordForm
              switch={() =>
                setState({ ...state, type: "forgot-password", email: "" })
              }
              email={state.email}
              temporaryToken={state.temporaryToken}
            />
          )}
        </section>
      </div>
    </div>
  );
}
