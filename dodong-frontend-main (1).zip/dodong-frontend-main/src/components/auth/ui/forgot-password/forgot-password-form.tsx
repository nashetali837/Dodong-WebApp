"use client";

import React, { useState } from "react";
import z, { ZodError } from "zod";
import { toast } from "react-toastify";
import { useMutation } from "@tanstack/react-query";
import { userForgotPasswordSchema } from "@/lib/validations/auth";
import { postRequest } from "@/lib/networkHelper";
import { EndPoints } from "@/lib/apiConstants";
import axios from "axios";
import { useDispatch } from "react-redux";
import { Icons } from "../../../icons";
import { fromZodError } from "zod-validation-error";

type userForgotPasswordSchema = z.infer<typeof userForgotPasswordSchema>;

export function ForgotPasswordAuthForm(props: { switch: any }) {
  const [loading, setLoading] = useState(false);

  const mutation = useMutation({
    mutationFn: (data: userForgotPasswordSchema) => {
      return postRequest(EndPoints.forgotPassword, data);
    },
    onSuccess: (response) => {
      console.log(response.data, "returned data");

      setLoading(false);
      props.switch((prev: any) => {
        return {
          ...prev,
          email: response.data.data.email,
          type: "verify-otp",
        };
      });
    },

    onError: (error: any) => {
      console.log(error.response?.data);
      if (axios.isAxiosError(error)) {
        toast.error(error.response?.data.message);
      }
      setLoading(false);
      if (error instanceof ZodError) {
        console.log(fromZodError(error));
        toast.error("Please enter valid data");
      }
    },
  });

  const handleSubmit = (event: React.FormEvent<HTMLFormElement>): any => {
    event.preventDefault();

    try {
      const data = {
        email: (event.target as HTMLFormElement).email.value,
      };

      if (!data.email) {
        toast.error("Please enter all the fields");
        return;
      }
      setLoading(true);

      mutation.mutate(data);
    } catch (error: any) {
      if (error instanceof ZodError) {
        const validationError = fromZodError(error);
        setLoading(false);
        toast.error(validationError.message);
      }
    }
  };

  return (
    <div className="grid gap-6">
      <form onSubmit={handleSubmit}>
        <h5 className="text-orange-593500 text-2xl mb-3 text-center font-medium">
          Recover your Account
        </h5>
        <div className="grid gap-2">
          <div className="grid gap-1">
            <input
              id="email"
              placeholder="name@example.com"
              className="bg-transparent text-734400 my-1 mb-2 block h-9 w-full rounded-md border border-734400 py-2 px-3 text-sm placeholder:text-734400 hover:border-734400 focus:border-734400 focus:outline-none"
              type="email"
              autoCapitalize="none"
              autoComplete="email"
              autoCorrect="off"
              name="email"
            />
          </div>
          <button
            disabled={loading}
            className="my-0 mb-8 mx-auto inline-flex w-full items-center justify-center rounded-full bg-orange-500 px-5 py-2.5 text-center text-sm font-medium text-white focus:outline-none disabled:opacity-50"
          >
            {loading && <Icons.spinner className="mr-2 h-4 w-4 animate-spin" />}
            Send OTP
          </button>
        </div>
      </form>
    </div>
  );
}
