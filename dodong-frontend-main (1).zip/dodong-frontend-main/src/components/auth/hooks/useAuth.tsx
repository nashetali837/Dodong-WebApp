import { useDispatch, useSelector } from "react-redux";
import { logoutUser } from "@/lib/redux/slices/auth-slice";

const useAuth = () => {
  const dispatch = useDispatch();
  const { authToken, isLoggedIn } = useSelector((state: any) => state.auth);

  const refreshToken = () => {};

  const login = () => {};

  const logout = () => {
    dispatch(logoutUser());
  };

  const registerUser = () => {};

  return { isLoggedIn, authToken, refreshToken, registerUser, login, logout };
};

export default useAuth;
