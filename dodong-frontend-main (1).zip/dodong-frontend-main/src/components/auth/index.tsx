"use client";
import React, { useState } from "react";
import Image from "next/image";
import dodongLogo from "../../../public/images/common/dodong-logo.svg";
import { useDispatch, useSelector } from "react-redux";
import { toggleLoginModal } from "@/lib/redux/slices/user-slice";

import { AiOutlineCloseCircle } from "react-icons/ai";
import SocialLoginComponent from "./ui/social-login";
import SeparatorLine from "./ui/shared";
import { UserSignupForm } from "./ui/signup";
import { UserLoginForm } from "./ui/login";

export enum AuthModalType {
  LOGIN = "LOGIN",
  SIGNUP = "SIGNUP",
  FORGOT_PASSWORD = "FORGOT_PASSWORD",
}

const LoginModal = () => {
  const { openLoginModal } = useSelector((state: any) => state.user);
  const [state, setState] = useState({
    type: AuthModalType.LOGIN,
  });

  const dispatch = useDispatch();
  const userMessage =
    state.type === AuthModalType.LOGIN
      ? "Good to see you today!"
      : "We are so excited to onboard you";

  return (
    <div
      className={`${
        openLoginModal ? "fade-in-transition" : "fade-out-transition"
      } h-screen fade-in-transition w-screen justify-center align-middle absolute top-0 z-50 overflow-hidden`}
    >
      <div
        className="bg-black bg-opacity-50 py-5 px-2 fixed duration-150 top-0 h-screen w-screen"
        style={{ zIndex: 20 }}
      >
        <section
          style={{ zIndex: 120 }}
          className="bg-white max-w-3xl flex rounded-xl py-3 overflow-hidden md:mt-20 justify-center flex-col m-auto align-middle items-center"
        >
          <div
            className="ml-auto mx-4 cursor-pointer"
            onClick={() => {
              dispatch(toggleLoginModal(false));
            }}
          >
            <AiOutlineCloseCircle className="text-black text-2xl" />
          </div>
          <div className="mb-4">
            <Image
              src={dodongLogo}
              alt="Picture of the author"
              width={207}
              height={207}
            />
          </div>
          <div className="items-center mb-2">
            <div className="text-black text-2xl font-extrabold spacing-2 tracking-wide">
              Welcome to DoDong
            </div>
            <div className="font-normal text-center text-gray-500">
              {userMessage}
            </div>
          </div>
          {state.type === AuthModalType.SIGNUP ? (
            <UserSignupForm
              switch={() => {
                setState({ ...state, type: AuthModalType.LOGIN });
              }}
            />
          ) : (
            <UserLoginForm />
          )}

          <SeparatorLine />

          <SocialLoginComponent
            authType={state.type}
            switch={(changedType: AuthModalType) => {
              setState({ ...state, type: changedType });
            }}
          />
        </section>
      </div>
    </div>
  );
};
export default LoginModal;
