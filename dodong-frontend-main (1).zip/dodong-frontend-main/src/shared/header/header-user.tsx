import { UserType } from "@/lib/types";
import React from "react";
import { useDispatch, useSelector } from "react-redux";
import {
  UserProfile,
  toggleCreatePostModal,
  toggleEditProfileModal,
} from "@/lib/redux/slices/user-slice";
import { AiOutlineHeart } from "react-icons/ai";
import Link from "next/link";
import PrimaryButton from "@/shared/buttons/primary";
import Image from "next/image";
import { DEFAULT_PROFILE_PIC } from "@/lib/constants";
import { toast } from "react-toastify";
import Dropdown from "@/shared/input-groups/dropdown";
import useAuth from "@/components/auth/hooks/useAuth";
import CircularProgressBar from "@/components/sections/CircularProgressBar";

const HeaderUserComponent = ({ setOpenMenu, openMenu }: any) => {
  const { logout } = useAuth();
  const {
    user,
    userProfile,
  }: {
    user: UserType;
    userProfile: UserProfile;
    authToken: string;
  } = useSelector((state: any) => state.user);

  const isProfileComplete = false;

  const dispatch = useDispatch();
  const stats = [
    {
      label: "Posts",
      value: userProfile?.totalPosts || 0,
    },
    {
      label: "Connects",
      value: userProfile?.followers || 0,
    },
    {
      label: "Connecting",
      value: userProfile?.following || 0,
    },
  ];

  const handleLogout = () => {
    logout();
    setOpenMenu(false);
  };

  return (
    <div className="hidden md:flex justify-between">
      <div
        onClick={() => {
          toast.info("New feature coming soon!");
        }}
        className="flex flex-col cursor-pointer my-auto"
      >
        <div className="align-middle justify-center font-bold my-auto text-center">
          <AiOutlineHeart className="text-3xl m-auto text-orange-500" />
        </div>
      </div>
      <div className="flex flex-col ml-4 mr-4 cursor-pointer my-auto">
        <PrimaryButton
          label="Post / Share"
          onClick={() => {
            console.log("====");
            dispatch(toggleCreatePostModal(true));
          }}
          type="button"
          style="px-8"
        />
      </div>

      <div
        onClick={() => {
          dispatch(toggleEditProfileModal(true));
        }}
        style={{ cursor: "pointer" }}
      >
        <CircularProgressBar onLogout={handleLogout} />
      </div>

      <Link
        href={`/profile/${user.id}`}
        className="flex flex-col ml-4 cursor-pointer my-auto rounded-lg"
      >
        <Image
          width={40}
          height={40}
          alt="Picture of the author"
          src={userProfile?.avatar || DEFAULT_PROFILE_PIC}
          className="rounded-lg"
        />
      </Link>
      <div className="flex flex-col ml-4 my-auto">
        <Dropdown
          user={user}
          userProfile={userProfile}
          handleLogout={handleLogout}
        />
      </div>
    </div>
  );
};

export default HeaderUserComponent;
