"use client";
import React, { useEffect, useState } from "react";
import { AiOutlineShoppingCart } from "react-icons/ai";
import { BiChevronDown } from "react-icons/bi";
import { useDispatch, useSelector } from "react-redux";
import { getRequest } from "@/lib/networkHelper";
import { EndPoints } from "@/lib/apiConstants";
import {
  saveUser,
  saveProfile,
  toggleCreatePostModal,
} from "@/lib/redux/slices/user-slice";
import HeaderSearch from "./header-search";
import HeaderUserComponent from "./header-user";
import HeaderActions from "./header-actions";
import HeaderLogo from "./header-logo";
import { toast } from "react-toastify";
import Modal from "@/shared/modal";
import CreatePost from "@/components/storefront/post/create";
import { checkAuth } from "@/lib/redux/slices/auth-slice";
import useAuth from "@/components/auth/hooks/useAuth";

const Header = () => {
  const dispatch = useDispatch();
  const { createPostModal } = useSelector((state: any) => state.user);
  const { authToken, isLoggedIn } = useAuth();
  const [openMenu, setOpenMenu] = useState(false);

  useEffect(() => {
    dispatch(checkAuth());
  }, [dispatch]);

  useEffect(() => {
    const fetchProfile = async () => {
      if (!authToken) {
        return null;
      }

      let res = await getRequest(EndPoints.profile, authToken);

      dispatch(saveUser(res.data.user) as any);
      dispatch(saveProfile(res.data.profile) as any);
      return res.data;
    };
    if (isLoggedIn) {
      fetchProfile();
    }
  }, [authToken, dispatch, isLoggedIn]);

  return (
    <React.Fragment>
      <div className="justify-center w-full align-middle mx-auto sticky bg-white z-50 top-0 my-2 px-3 py-2">
        <div className="flex justify-between">
          <HeaderLogo />

          <div className="flex-1 my-auto align-middle">
            <div className="flex justify-between my-auto">
              <button
                onClick={() => {
                  toast.info("New feature coming soon!");
                }}
                className="flex items-center border border-gray200 rounded-md ml-4"
              >
                <div className="hidden md:block mx-2">
                  <AiOutlineShoppingCart className="text-2xl text-gray-900" />
                </div>

                <div className="flex flex-col mx-2">
                  <button type="button" className="text-xs flex truncate">
                    New Delhi <BiChevronDown className="text-lg my-auto" />
                  </button>
                </div>
              </button>

              <div className="flex w-full items-center px-2 mx-auto">
                <HeaderSearch />
                {/* add state for login  */}
                {isLoggedIn ? (
                  <HeaderUserComponent
                    openMenu={openMenu}
                    setOpenMenu={setOpenMenu}
                  />
                ) : (
                  <HeaderActions />
                )}
              </div>
            </div>
          </div>
        </div>
      </div>
      <Modal
        fullScreen={true}
        key={"create-post-modal"}
        open={createPostModal}
        onClose={() => {
          dispatch(toggleCreatePostModal(false));
        }}
      >
        <CreatePost />
      </Modal>
    </React.Fragment>
  );
};

export default Header;
