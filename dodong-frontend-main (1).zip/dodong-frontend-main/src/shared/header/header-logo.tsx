import Link from "next/link";
import React from "react";
import { styled } from "styled-components";

const SubTitle = styled.em`
  color: ${(props) => props.theme.colors?.primary};
  font-size: 10px;
  display: block;
  text-align: center;
`;

import AppLogo from "@/shared/logo";

const HeaderLogo = () => {
  return (
    <Link href="/">
      <div>
        <div className="flex pr-1">
          <AppLogo />
        </div>
        <div className="text-center m-auto italic text-xs md:text-sm">
          <SubTitle>Go online Do dong</SubTitle>
        </div>
      </div>
    </Link>
  );
};

export default HeaderLogo;
