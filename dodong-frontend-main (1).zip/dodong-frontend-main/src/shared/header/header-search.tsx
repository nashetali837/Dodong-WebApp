import React, { useState } from "react";
import { AiOutlineClose } from "react-icons/ai";
import { BsSearch } from "react-icons/bs";
import { styled } from "styled-components";

const InputSearch = styled.div`
  position: relative;
  svg {
    position: absolute;
    left: 0.75rem;
    top: 50%;
    transform: translateY(-50%);
  }
  input {
    padding-left: 2.5rem;
  }
`;

const HeaderSearch = () => {
  const [selected, setSelected] = useState(false);

  return (
    <React.Fragment>
      <div
        onClick={() => setSelected(true)}
        className={`hidden md:flex cursor-pointer md:flex-1 w-full justify-between mx-4 my-auto rounded-lg h-full border-gray-200`}
      >
        <InputSearch className="flex my-auto justify-between text-sm w-full text-center truncate">
          <BsSearch className="text-lg black" />
          <input
            className="pr-5 px-4 text-gray-800 w-full bg-transparent focus:outline-none outline-none"
            placeholder="Search products,people, shops..."
          />
        </InputSearch>
      </div>

      {false && (
        <div
          style={{
            position: "absolute",
            top: 0,
            left: 0,
            width: "100vw",
            zIndex: selected ? 1000 : 0,
            visibility: selected ? "visible" : "hidden",
          }}
          className={`bg-white transition-width transition-opacity ${
            selected
              ? "h-screen opacity-100 py-10 px-5"
              : "h-0 opacity-0 transition-width-out"
          }`}
        >
          <div
            className={`${
              selected ? "block" : "hidden"
            } flex justify-between gap-10`}
          >
            <input
              className="w-full border-b border-b-gray-500 h-28 font-semibold py-4 text-2xl outline-none"
              placeholder="Search here for products, places..."
            />

            <div
              onClick={() => {
                setSelected(false);
              }}
              className="m-auto"
            >
              <AiOutlineClose className="text-4xl text-gray-500 my-auto" />
            </div>
          </div>
        </div>
      )}
    </React.Fragment>
  );
};

export default HeaderSearch;
