import React from "react";
import { styled } from "styled-components";

export interface TextInputProps {
  label?: string;
  type?: "text" | "email" | "number" | "password";
  id: string;
  placeholder: string;
  inputStyle?: string;
  autoFocus?: boolean;
  onChange?: (e: any) => void;
  required?: boolean;
}
const TextInput = ({
  label,
  type = "text",
  id = "email",
  placeholder = "",
  inputStyle = "",
  autoFocus = false,
  onChange = () => {},
  required = true,
}: TextInputProps) => {
  return (
    <div>
      {label && (
        <label htmlFor={id}>
          {label} {required && "*"}
        </label>
      )}
      <input
        id={id}
        onChange={onChange}
        autoFocus={autoFocus}
        placeholder={placeholder}
        className={` ${inputStyle}`}
        type={type}
        required={required}
        autoCapitalize="none"
        autoComplete={type}
        autoCorrect="off"
        name={id}
      />
    </div>
  );
};

export default TextInput;
