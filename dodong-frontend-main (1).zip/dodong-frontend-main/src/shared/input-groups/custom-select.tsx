import React, { useState } from "react";

interface Props {
  options: {
    label: String;
    value: String;
  }[];
  selectedOption?: String;
}

const colorOptions = [
  { value: "ocean", label: "Ocean", color: "#00B8D9", isFixed: true },
  { value: "blue", label: "Blue", color: "#0052CC", isDisabled: true },
  { value: "purple", label: "Purple", color: "#5243AA" },
  { value: "red", label: "Red", color: "#FF5630", isFixed: true },
  { value: "orange", label: "Orange", color: "#FF8B00" },
  { value: "yellow", label: "Yellow", color: "#FFC400" },
  { value: "green", label: "Green", color: "#36B37E" },
  { value: "forest", label: "Forest", color: "#00875A" },
  { value: "slate", label: "Slate", color: "#253858" },
  { value: "silver", label: "Silver", color: "#666666" },
];

const list = [
  { label: "Edit", id: "edit" },
  { label: "Report", id: "edit" },
  { label: "Disconnect", id: "edit" },
  { label: "Add to favorites", id: "edit" },
  { label: "Go to post", id: "edit" },
  { label: "Share to", id: "edit" },
  { label: "Copy link", id: "edit" },
  { label: "Embed", id: "edit" },
  { label: "About this account", id: "edit" },
];

const CustomSelect = (props: any) => {
  const [open, setOpen] = useState(false);

  return (
    <div className="relative inline-block text-left">
      <div>
        <button
          onClick={() => setOpen(!open)}
          type="button"
          className="w-full justify-center rounded-md bg-white px-3 mx-2 py-2 text-sm font-semibold text-gray-900"
          id="menu-button"
          aria-expanded="true"
          aria-haspopup="true"
        >
          {props.children}
        </button>
      </div>

      {/* <!--
    Dropdown menu, show/hide based on menu state.

    Entering: "transition ease-out duration-100"
      From: "transform opacity-0 scale-95"
      To: "transform opacity-100 scale-100"
    Leaving: "transition ease-in duration-75"
      From: "transform opacity-100 scale-100"
      To: "transform opacity-0 scale-95"
  --> */}
      <div
        style={{ zIndex: open ? 1000 : -1 }}
        className={`${
          open
            ? "transition ease-in duration-75 transform opacity-100 scale-100"
            : "transition ease-out duration-100 transform opacity-0 scale-95"
        } absolute right-0 z-10 mt-2 w-56 origin-top-right divide-y divide-gray-100 rounded-md bg-white shadow-lg ring-1 ring-black ring-opacity-5 focus:outline-none`}
        role="menu"
        aria-orientation="vertical"
        aria-labelledby="menu-button"
        tabIndex={-1}
      >
        {/* <!-- Active: "bg-gray-100 text-gray-900", Not Active: "text-gray-700" --> */}
        {props.list.map((listItem: any, k: number) => (
          <div key={k} className="py-1" role="none">
            {listItem.link && (
              <a
                href={listItem.link}
                className="text-gray-700 block px-4 py-2 text-sm"
                role="menuitem"
                tabIndex={-1}
                id="menu-item-0"
              >
                {listItem.label}
              </a>
            )}
            {listItem.onclick && (
              <div
                className="text-gray-700 block px-4 py-2 text-sm cursor-pointer"
                onClick={listItem.onclick}
              >
                {" "}
                {listItem.label}
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
};
export default CustomSelect;
