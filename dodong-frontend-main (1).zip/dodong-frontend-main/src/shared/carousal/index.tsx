import Image from "next/image";
import React from "react";
import { Carousel } from "react-responsive-carousel";

export default function ImageCarousal({
  images,
  height = 300,
  width = 400,
  style,
}: {
  images?: string[];
  style?: string;
  height?: number;
  width?: number;
}) {
  return (
    <Carousel
      showStatus={false}
      infiniteLoop
      showThumbs={false}
      swipeable={true}
    >
      {images?.map((image, k) => (
        <div key={`post_${k}`}>
          <Image
            src={image}
            height={height}
            width={width}
            alt="post.post image"
            className={
              style ?? "rounded-bl-xl object-cover rounded-br-xl w-fit"
            }
          />
        </div>
      ))}
    </Carousel>
  );
}
