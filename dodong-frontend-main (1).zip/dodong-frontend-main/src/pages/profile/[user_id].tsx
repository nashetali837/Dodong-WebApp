import React, { Fragment, useEffect, useState } from "react";
import Header from "@/shared/header";

import { MdLocationOn } from "react-icons/md";
import { FiHeart, FiLink2 } from "react-icons/fi";
import { BsGrid3X3 } from "react-icons/bs";
import { TbMessage, TbLink } from "react-icons/tb";
import { RiPencilFill } from "react-icons/ri";
import { RxEnvelopeClosed } from "react-icons/rx";
import { styled } from "styled-components";

import { TRENDING_CONTENT, PROFILE_POSTS, PROFILE } from "@/lib/constants";
import Image from "next/image";
import Link from "next/link";
// import { Heading } from "@/shared/texts";
import { useDispatch, useSelector } from "react-redux";
import {
  toggleEditProfileModal,
  UserProfile,
} from "@/lib/redux/slices/user-slice";
import { useRouter } from "next/router";
import { getRequest, postRequest } from "@/lib/networkHelper";
import { EndPoints } from "@/lib/apiConstants";
import Spinner from "@/shared/loading/spinner";
import { NextSeo } from "next-seo";
import { toast } from "react-toastify";
import useAuth from "@/components/auth/hooks/useAuth";
import { HiCake } from "react-icons/hi2";
import PrimaryButton from "@/shared/buttons/primary";
import { Heading } from "../product/[slug]";

const PostGallery = styled.div`
  display: grid;
  grid-template-columns: repeat(4, minmax(0, 1fr));
  gap: 1.5rem;
  margin-bottom: 2rem;
`;

const ImageWrapper = styled.div`
  img {
    width: 100%;
    height: 100%;
    border-radius: ${(props) => props.theme.borderRadius?.lg};
  }
`;

type TrendingProps = {
  name: string;
  designation: string;
  company: string;
  id: string;
  distance: string;
  imageURL: string;
  liked: boolean;
};

type ProfileProps = {
  name: string;
  designation: string;
  email: string;
  bio: string;
  dob: string;
  company: string;
  id: string;
  imageURL: string;
  posts: string;
  connects: string;
  connecting: string;
};

type ProfilePost = {
  posts: string;
  discoveries: string;
};

type PostProps = {
  profile: {
    name: string;
    followers: string;
    following: string;
    imageURL: string;
    distance: string;
    id: string;
  };
  shopURL: string;
  post: {
    imageURL: string;
    description: string;
    liked: boolean;
    likes: string;
    comments: string;
    shares: string;
  };
  liked: boolean;
};

function ProfilePage() {
  const { authToken } = useAuth();
  const {
    user,
  }: {
    user: any;
  } = useSelector((state: any) => state.user);

  const router = useRouter();
  const dispatch = useDispatch();
  const { user_id } = router.query;
  const isPageOwner = user_id === user?.id?.toString();

  const [data, setData] = useState<{
    posts: any[];
    loading: boolean;
    user?: any;
    userProfile?: UserProfile;
  }>({
    posts: [],
    loading: true,
  });

  useEffect(() => {
    console.log("---> isUserEditor", user, user?.id?.toString(), user_id);
    fetchPosts();
  }, [user_id]);

  const fetchPosts = async () => {
    try {
      console.log("user_id", user_id);
      if (isNaN(Number(user_id))) {
        return;
      }

      let profileResponse = await getRequest(
        EndPoints.profile + `/${user_id}`,
        authToken
      ).then((res) => res.data);

      let response = await postRequest(
        EndPoints.filterPosts,
        {
          authorID: Number(user_id),
        },
        authToken
      ).then((res) => res.data);
      const posts = response.posts.reduce((images: any[], post: any) => {
        let newURLs = post?.ResourceMedia?.map((media: any) => media.mediaURL);
        console.log("--mage :", newURLs);
        return [...images, ...newURLs];
      }, []);

      setData({
        ...data,
        loading: false,
        user: profileResponse.user,
        userProfile: profileResponse.profile,
        posts: posts,
      });
    } catch (e) {
      console.log(e);
      setData({ ...data, loading: false });
    }
  };

  if (data.loading) {
    return <Spinner />;
  }

  const _renderTrendingPost = (post: TrendingProps): JSX.Element => {
    return (
      <div className="my-5 rounded-md" id={post.id} key={post.id}>
        <div className="relative">
          <div className="absolute right-0 text-trending-icon">
            <Link href="/#">
              <FiHeart className="text-xl m-2" />
            </Link>
          </div>
          <Image
            src={post.imageURL}
            width="250"
            height={100}
            alt="post image"
            className="rounded-md border-b-4 border-trending-icon"
          />
        </div>
        <div className="text-gray-800 p-2">
          <div className="text-sm font-bold truncate">{post.name}</div>

          <div className="text-xs truncate">
            {post.designation} @ <span>{post.company}</span>
          </div>

          <div className="flex my-1">
            <Link href="/#m">
              <TbMessage className="text-xl text-trending-icon my-auto mr-2 cursor-pointer" />
            </Link>
            <Link href="/#">
              <TbLink className="text-xl text-trending-icon my-auto mr-2 cursor-pointer" />
            </Link>
          </div>

          <div className="flex my-1">
            <MdLocationOn className="text-lg my-auto cursor-pointer" />
            <div className="text-xs">{post.distance}</div>
          </div>

          <div>{post.liked}</div>
        </div>
      </div>
    );
  };

  const _onCopyProfileLink = () => {
    navigator.clipboard.writeText(window.location.href);
    toast.success("Copied the profile URL");
  };

  const _renderProfile = () => {
    console.log("data", data);
    const stats = [
      { name: "Posts", value: data?.userProfile?.totalPosts },
      { name: "Connects", value: data?.userProfile?.followers },
      { name: "Connecting", value: data?.userProfile?.following },
    ];

    if (!data?.userProfile) {
      return <div>Loading...</div>;
    }

    console.log(data?.userProfile);

    const name = data?.userProfile.displayName || data?.userProfile.name;

    return (
      <div className="mb-4 md:fixed gap-y-2">
        <NextSeo title={name + " - DoDong"} />
        <div className="flex mt-3">
          <div>
            <div className="grid md:flex items-center mb-3">
              <Image
                src={
                  data?.userProfile?.avatar || "https://picsum.photos/120/120"
                }
                width={150}
                height={150}
                objectFit="cover"
                alt="profile image"
                className="rounded-xl my-auto p-1 border shadow-md"
              />
            </div>
          </div>

          <div className="grid md:flex items-center my-auto">
            <div className="my-2 items-center">
              {stats.map((stat, k) => (
                <div key={`stat_${k}`} className="flex gap-1 mx-4 my-3">
                  <div className="black text-center my-auto">{stat.value}</div>
                  <div className="my-auto text-center">{stat.name}</div>
                </div>
              ))}
            </div>
          </div>
        </div>

        <div className="flex flex-col">
          <Heading>{name}</Heading>

          {data?.userProfile?.dateOfBirth && (
            <div className="text-sm flex gap-2">
              <HiCake className="text-xl black" /> Born{" "}
              {data?.userProfile.dateOfBirth}
            </div>
          )}
        </div>

        <div className="flex gap-3 mt-4 justify-start">
          {!isPageOwner && (
            <div className="h-10">
              <PrimaryButton label="Connect" type="button" />
            </div>
          )}

          {isPageOwner ? (
            <button
              onClick={() => {
                dispatch(toggleEditProfileModal(true));
              }}
              className="flex text-sm font-bold border duration-150 text-gray-700 border-gray-300 rounded-lg p-2 text-center"
            >
              <RiPencilFill className="text-md my-auto cursor-pointer mx-2" />{" "}
              <span className="text-md px-2">Edit Profile</span>
            </button>
          ) : (
            <button className="flex text-sm font-bold border duration-150 text-gray-700 border-gray-700 rounded-lg p-2 text-center">
              <RxEnvelopeClosed className="text-md my-auto cursor-pointer mx-2" />{" "}
              <span className="text-md px-2">Message</span>
            </button>
          )}
        </div>

        <div>
          <div className="flex flex-col gap-y-1 mt-4">
            <div className="text-sm">
              {data?.userProfile.bio ? (
                data?.userProfile.bio
              ) : (
                <i>-- No Bio --</i>
              )}
            </div>

            {data?.userProfile.occupation && (
              <div className="text-sm font-normal truncate">
                Occupation: {data?.userProfile.occupation || "N/A"}
              </div>
            )}

            <div className="text-sm font-normal">{data?.user?.email}</div>
          </div>
        </div>
      </div>
    );
  };

  const _renderPost = (post: any): JSX.Element => {
    return (
      <ImageWrapper className="ImageWrapper" id={post}>
        <Image src={post} width={240} height={200} alt={"image" + post} />
      </ImageWrapper>
    );
  };
  return (
    <div className="mx-2 md:mx-4 lg:mx-6 xl:mx-12 align-middle">
      <div className="grid grid-cols-2 md:grid-cols-11 justify-center mx-auto">
        <section className="px-2 col-span-3 flex-1 container" id="profile">
          {_renderProfile()}
        </section>
        <section className="px-2 col-span-8 flex-1 container" id="posts">
          <div className="flex-1">
            <Heading title="Posts" />

            <PostGallery className="PostGallery">
              {data.posts.length ? (
                data.posts.map((post: string) => _renderPost(post))
              ) : (
                <div className="text-md mx-auto text-gray-500 font-semibold text-center">
                  No Posts
                </div>
              )}
            </PostGallery>

            {/* {false && (
              <Fragment>
                <Heading
                  title="Discoveries"
                  icon={<BsGrid3X3 className="text-lg" />}
                />

                <div className="flex overflow-x-scroll gap-5 mb-5">
                  {PROFILE_POSTS.discoveries.map((post: string) =>
                    _renderPost(post)
                  )}
                </div>
              </Fragment>
            )} */}
            {/* 
            {false && (
              <Fragment>
                <Heading
                  title="Collections"
                  icon={<BsGrid3X3 className="text-lg" />}
                />

                <div className="flex overflow-x-scroll gap-5 mb-5">
                  {PROFILE_POSTS.discoveries.map((post: string) =>
                    _renderPost(post)
                  )}
                </div>
              </Fragment>
            )} */}
          </div>
        </section>
      </div>
    </div>
  );
}
export default ProfilePage;
