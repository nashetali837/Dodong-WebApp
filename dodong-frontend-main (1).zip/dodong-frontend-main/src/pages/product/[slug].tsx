"use client";

import React, { useState, useEffect, useRef } from "react";
import styled from "styled-components";

import { TRENDING_CONTENT, PROFILE_POSTS, PROFILE } from "@/lib/constants";
import Image from "next/image";
import Link from "next/link";
import { useRouter } from "next/router";

import { FiLink2 } from "react-icons/fi";
import { RiPencilFill } from "react-icons/ri";
import { RxEnvelopeClosed } from "react-icons/rx";
import filter from "../../../public/images/filter.svg";

import { Icons } from "@/components/icons";
import Slider from "react-slick";
import { sendAPIRequest } from "../../../utils/apiService";
import { EndPoints } from "@/lib/apiConstants";
import { ShopButton } from "@/shared/buttons/primary";
import FlexBox from "@/components/sections/FlexBox";

import Modal from "@/shared/modal";

const Price = styled.span`
  color: ${(props) => props.theme.colors.black};
  font-size: 1.125rem;
  font-weight: 500;
  position: relative;
  &:after {
    content: "";
    top: 50%;
    transform: translateY(-50%);
    transform: -webkit-translateY(-50%);
    right: -20px;
    border: 1px solid #f3f3f4;
    position: absolute;
    height: 1.5rem;
  }
`;

const Product = styled.div`
  border-radius: ${(props) => props.theme.borderRadius.lg};
  border: 1px solid ${(props) => props.theme.colors.border};
  margin-bottom: 1.5rem;

  &.shopinfo {
    position: relative;
    max-width: 13.5rem;
  }
`;

const Star = styled(Icons.solidstar)`
  color: ${(props) => props.theme.colors.primary};
`;

const ProductImage = styled(Image)`
  width: 100%;
  border-radius: ${(props) => props.theme.borderRadius.lg}
    ${(props) => props.theme.borderRadius.lg} 0px 0px;
`;

const ProductInfo = styled.div`
  padding: 1rem;
`;

export const Nav = styled.div`
  border: 1px solid ${(props) => props.theme.colors.border};
  color: ${(props) => props.theme.colors.border};
  background: ${(props) => props.theme.colors.white};
  width: 32px;
  height: 32px;
  border-radius: ${(props) => props.theme.borderRadius.button};
  right: 4rem;
  left: auto;
  top: -30px;

  &:before {
    display: none;
  }
  &.slick-prev {
    right: 6.5rem;
  }

  &:hover {
    color: ${(props) => props.theme.colors.black};
    background: ${(props) => props.theme.colors.white};
  }
  svg {
    font-size: 16px;
    height: 100%;
    margin: auto;
  }
`;

export const CenterNav = styled(Nav)`
  position: absolute;
  top: 50%;
  right: 0;
  z-index: 2;
  color: ${(props) => props.theme.colors.black};

  &.slick-prev {
    left: 0;
    right: unset;
  }
`;

export const ProductTitle = styled.h4`
  font-size: 14px;
  font-weight: 600;
`;

const Title = styled.h2`
  font-size: 30px;
`;

export const Heading = styled.h3`
  font-size: 18px;
  font-weight: 600;
  margin-bottom: 1rem;
`;

const ProductSlider = styled.div`
  .slick-list {
    padding: 0px;

    .slick-slide {
      padding-right: 1.5rem;
    }
  }
`;

const Tag = styled.span`
  border: 1px solid ${(props) => props.theme.colors?.border};
  color: ${(props) => props.theme.colors?.darkGray};
  border-radius: ${(props) => props.theme.borderRadius?.button};
  background: ${(props) => props.theme.colors?.white};
  font-size: 12px;
  color: #4f4b5c;
  padding: 0.25rem 0.5rem;
`;

const Button = styled.button`
  border-radius: ${(props) => props.theme.borderRadius?.button};
  color: ${(props) => props.theme.colors?.black};
  background: ${(props) => props.theme.colors?.white};
  border: 1px solid ${(props) => props.theme.colors?.border};
  padding: 8px 10px;
  font-weight: 500;
`;

const DetailSection = styled.div`
  margin-bottom: 1.5rem;

  ${Price} {
    font-size: 30px;
    &:after {
      right: -26px;
    }
  }

  .detail {
    position: absolute;
    top: 1rem;
    left: 1rem;
    z-index: 2;
  }

  .border-md {
    border-radius: ${(props) => props.theme.borderRadius?.md};
  }

  .galleryslider {
    height: 100%;
    img {
      border-radius: ${(props) => props.theme.borderRadius?.lg};
      width: 100%;
      height: 100%;
      object-fit: cover;
    }
    .slick-list,
    .slick-track,
    .slick-slide > div {
      height: inherit;
    }
    .slick-arrow {
      position: absolute;
      top: 50%;
      right: 0.5rem;
      z-index: 2;
      color: ${(props) => props.theme.colors?.black};
      &.slick-prev {
        left: 0.5rem;
        right: unset;
      }
    }
  }
  .slidernav {
    position: absolute;
    bottom: 1rem;
    left: 50%;
    transform: translateX(-50%);
    transform: -webkit-translateY(-50%);
    img {
      border-radius: ${(props) => props.theme.borderRadius?.button};
      border: 1px solid ${(props) => props.theme.colors?.white};
      height: 50px;
      object-fit: cover;
      filter: brightness(40%);
    }
    .slick-slide {
      padding: 0 0.25rem;
      &.slick-current {
        img {
          filter: none;
        }
      }
    }
  }
`;

const Gallery = styled.div`
  width: 40%;
  position: relative;
`;

const Content = styled.div`
  font-weight: 300;
  line-height: 22px;
`;

const Map = styled(Icons.map)`
  color: ${(props) => props.theme.colors?.primary};
  margin-top: 0.2rem;
  font-size: 1rem;
  min-width: 1.125rem;
`;

const Distance = styled(FlexBox)`
  color: ${(props) => props.theme.colors?.white};
  border-radius: ${(props) => props.theme.borderRadius?.button};
  font-size: 12px;
  padding: 0.25rem 0.5rem;
  border: 1px solid ${(props) => props.theme.colors?.black};
  background: rgba(0, 0, 0, 0.75);
  font-weight: 500;
  width: fit-content;
  position: absolute;
  bottom: 1rem;
  left: 1rem;

  ${Map} {
    margin-top: 0px;
    color: ${(props) => props.theme.colors?.white};
  }
`;

const GridSection = styled.div`
  display: flex;
  display: -webkit-flex;
  padding-left: 4rem;
  grid-template-columns: 1fr 5fr;
  gap: 1.5rem;

  #trending-posts {
    width: 20%;
    overflow-y: scroll;
    height: 100vh;
    position: sticky;
    top: 0px;

    ${Price} {
      font-size: 1rem;
      margin-top: 0.5rem;
      display: inline-block;
      &:after {
        display: none;
      }
    }
  }
  #posts {
    width: 80%;
  }
`;

const DetailInfo = styled.div`
  padding-right: 4rem;
`;

type TrendingProps = {
  name: string;
  designation: string;
  company: string;
  id: string;
  distance: string;
  imageURL: string;
  liked: boolean;
};

type LocalMarketProps = {
  name: string;
  designation: string;
  company: string;
  id: string;
  distance: string;
  imageURL: string;
  location: string;
  liked: boolean;
};

type ProfileProps = {
  name: string;
  designation: string;
  email: string;
  bio: string;
  dob: string;
  company: string;
  id: string;
  imageURL: string;
  posts: string;
  connects: string;
  connecting: string;
};

const NextArrow = (props: any) => {
  const { className, onClick } = props;
  return (
    <Nav className={className} onClick={onClick}>
      <Icons.arrowright />
    </Nav>
  );
};

const PrevArrow = (props: any) => {
  const { className, onClick } = props;
  return (
    <Nav className={className} onClick={onClick}>
      <Icons.arrowleft />
    </Nav>
  );
};

const settings = {
  slidesToShow: 3,
  slidesToScroll: 1,
  infinite: false,
  dots: false,
  nextArrow: <NextArrow />,
  prevArrow: <PrevArrow />,
  variableWidth: true,
  swipeToSlide: true,
  responsive: [
    {
      breakpoint: 768,
      settings: {
        slidesToShow: 2,
      },
    },
    {
      breakpoint: 480,
      settings: {
        slidesToShow: 1,
      },
    },
  ],
};

const _renderProfile = () => {
  const data = PROFILE as ProfileProps;
  const stats = [
    { name: "Connects", value: data.connects },
    { name: "Connecting", value: data.connecting },
    { name: "Posts", value: data.posts },
  ];

  return (
    <div className="mb-4">
      <div className="grid md:flex justify-between">
        <div>
          <div className="grid md:flex items-center mb-3">
            <div className="relative mr-3 my-auto">
              <Image
                src={data.imageURL}
                width={70}
                height={70}
                objectFit="cover"
                alt="profile image"
                className="rounded-full my-auto"
              />
            </div>
            <div className="flex flex-col ml-2">
              <div className="text-xl font-bold">{data.name}</div>
              <div className="text-sm">{data.dob}</div>
            </div>
          </div>
          <div>
            <div className="flex items-center">
              <div className="flex flex-col ml-2">
                <div className="text-sm font-normal truncate">
                  {data.designation} @ {data.company}
                </div>

                <div className="text-sm font-normal">{data.email}</div>
                <div className="text-sm">{data.bio}</div>
              </div>
            </div>
          </div>
        </div>

        <div className="grid md:flex items-start">
          <div className="flex my-2 items-center">
            {stats?.map((stat, k) => (
              <div key={`stat_${k}`} className="flex flex-col mx-4">
                <div className="text-sm font-bold text-center truncate">
                  {stat.value}
                </div>
                <div className="text-xs truncate">{stat.name}</div>
              </div>
            ))}
          </div>

          <div className="flex my-2 justify-around items-center">
            <div className="flex flex-col ml-2">
              <button className="text-sm flex border text-orange-500 border-orange-500 rounded-full p-2 font-bold text-center">
                <RxEnvelopeClosed className="text-md my-auto cursor-pointer mx-2" />{" "}
                <span className="text-md px-2">Message</span>
              </button>
            </div>

            <div className="flex flex-col ml-2">
              <button className="text-sm font-bold border text-orange-500 border-orange-500 rounded-full p-2 text-center">
                {/* Share */}
                <FiLink2 className="text-md my-auto cursor-pointer mx-3" />
              </button>
            </div>

            <div className="flex flex-col ml-4">
              <button className="flex text-sm font-bold border text-orange-500 border-orange-500 rounded-full p-2 text-center">
                <RiPencilFill className="text-md my-auto cursor-pointer mx-2" />{" "}
                <span className="text-md px-2">Edit Profie</span>
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

const _renderViewdetails = () => {
  const [viewDetails, setViewDetails] = useState<null | any>(null);
  const router = useRouter();
  const slug: string = router.query.slug as string;

  console.log(router, "router");

  console.log(typeof slug, "slug");
  console.log(viewDetails, "viewDetails");

  useEffect(() => {
    if (slug) {
      const fetchCategoriesData = async () => {
        try {
          const config = {
            endPoint: EndPoints.filterPosts,
            data: { productId: parseInt(slug) },
          };
          const { data } = await sendAPIRequest({ config });
          console.log(data, "data");
          setViewDetails(data?.posts[0]);
        } catch (e) {
          console.log(e);
        }
      };

      fetchCategoriesData();
    }
  }, [slug]);

  const [nav1, setNav1] = useState<Slider | undefined>(undefined);
  const [nav2, setNav2] = useState<Slider | undefined>(undefined);
  const slider1Ref = useRef<Slider | null>(null);
  const slider2Ref = useRef<Slider | null>(null);

  useEffect(() => {
    setNav1(slider1Ref.current ?? undefined);
    setNav2(slider2Ref.current ?? undefined);
  }, []);

  const renderSliderItems = (size: number) => {
    return viewDetails?.ResourceMedia?.map((item: any) => (
      <>
        <Image
          key={item.id}
          src={item?.mediaURL}
          width={size}
          height={size}
          objectFit={"cover"}
          objectPosition={"center"}
          alt="image"
          // style={{ width: "100%" }}
        />
      </>
    ));
  };

  return (
    <DetailSection>
      <FlexBox gap=" 1.5rem">
        <Gallery>
          <Tag className="detail">
            <a href={`${process.env.NEXT_PUBLIC_WEBSITE_URL}/?postID=${slug}`}>View Details</a>
          </Tag>
          <Slider
            asNavFor={nav2}
            slidesToShow={1}
            arrows={true}
            nextArrow={<NextArrow />}
            prevArrow={<PrevArrow />}
            ref={slider1Ref}
            className="galleryslider"
          >
            {renderSliderItems(560)}
          </Slider>

          <Slider
            asNavFor={nav1}
            ref={slider2Ref}
            slidesToShow={3}
            infinite={false}
            arrows={false}
            variableWidth={true}
            swipeToSlide={true}
            focusOnSelect={true}
            className="slidernav"
          >
            {renderSliderItems(50)}
          </Slider>
        </Gallery>

        <DetailInfo style={{ width: "60%" }}>
          <span className="black">Ikea</span>
          <Title style={{ marginBottom: "1rem" }}>
            {viewDetails?.title || "Doris Swivel Accent Chair - Black"}
          </Title>
          <Content>{viewDetails?.body}</Content>
          <FlexBox align="center" gap="3rem" style={{ marginTop: "1rem" }}>
            <Price>$59.99</Price>
            <FlexBox gap="2rem" className="ft-16">
              <div>
                <span className="black" style={{ marginRight: "0.5rem" }}>
                  Quantity
                </span>
                20
              </div>
              <div>
                <span className="black" style={{ marginRight: "0.5rem" }}>
                  Pc
                </span>
                2
              </div>
            </FlexBox>
          </FlexBox>
          <FlexBox
            gap="1rem"
            style={{ marginTop: "1rem", marginBottom: "2rem" }}
          >
            {/* <ShopButton>Buy Now</ShopButton>
            <Button>
              <Icons.cart
                style={{
                  fontSize: "20px",
                  display: "inline-block",
                  marginRight: "5px",
                }}
              />
              Add to Card
            </Button> */}
            <Button>
              <Icons.wishlist
                style={{
                  fontSize: "20px",
                  display: "inline-block",
                }}
              />
            </Button>
          </FlexBox>
          <FlexBox gap="1rem" align="center" style={{ marginTop: "2rem" }}>
            Categories <Tag>Category 1</Tag>
          </FlexBox>
          <FlexBox
            gap="1rem"
            align="center"
            style={{ marginTop: "0.5rem", marginBottom: "2rem" }}
          >
            Sub Categories <Tag>Category 1</Tag>
          </FlexBox>
          <div className="ft-16">Shop Name</div>
          <FlexBox gap="0.5rem" align="center" justify="space-between">
            <FlexBox gap="0.5rem" align="center">
              {/* <Image
                src={filter}
                width={40}
                height={40}
                objectFit={"contain"}
                alt="image"
                className="border-md"
              /> */}
              <Icons.map />
              <h3 className="ft-18">Wooden Street - Furniture Store</h3>
            </FlexBox>
            <Button>
              <Image
                src={filter}
                width={20}
                height={20}
                objectFit={"contain"}
                alt="filter"
              />
            </Button>
          </FlexBox>
          <FlexBox gap="0.15rem" style={{ marginTop: "1rem" }}>
            <Map />
            <div className="ft-12">
              <p className="black">2.8 Km</p>
              <p>
                No.163/1, Second Floor, BLOCK-Z1, No.201, BRT Road, above Sakti
                Sports Office, Roseland Residency, Pimple Saudagar
              </p>
            </div>
          </FlexBox>
        </DetailInfo>
      </FlexBox>
    </DetailSection>
  );
};

const _renderPost = (image: string): JSX.Element => {
  return (
    <>
      {/* <div
        className="my-2  w-auto flex-shrink-0 rounded-lg border border-gray-300"
        id={image}
      >
        <div className="gap-2">
          <Image
            src={image}
            width={90}
            height={90}
            objectFit={"cover"}
            alt="image"
            className="rounded-md m-auto"
          />

          <div
            style={{
              maxWidth: "11rem",
            }}
          >
            <p
              aria-rowindex={2}
              className="text-sm text-gray-800 font-semibold mb-1"
            >
              Product Name Product Name Product Name Product Name Product Name
            </p>
            <div className="text-xs font-bold mb-1">₹ 300.00</div>

            <div className="text-xs flex justify-between">
              <div className="flex gap-3">
                <div>Qty.</div>
                <div>Weight.</div>
              </div>
              <div className="text-xl text-orange-500">
                <AiOutlineAppstore />
              </div>
            </div>
          </div>
        </div>
      </div> */}

      <Product>
        <ProductImage
          src={image}
          width={90}
          height={90}
          objectFit={"cover"}
          alt="image"
        />

        <ProductInfo>
          <p>Ikea</p>
          <ProductTitle>Sofa Cabby- Wooden Sofa Couch</ProductTitle>
          <FlexBox gap="2.5rem" align="center" style={{ marginTop: "0.5rem" }}>
            <Price>$59.99</Price>
            <FlexBox gap="1rem">
              <div>
                <span className="black" style={{ marginRight: "0.5rem" }}>
                  Quantity
                </span>
                20
              </div>
              <div>
                <span className="black" style={{ marginRight: "0.5rem" }}>
                  Pc
                </span>
                2
              </div>
            </FlexBox>
            <div>
              <Image
                src={filter}
                width={15}
                height={15}
                objectFit={"contain"}
                alt="filter icon"
              />
            </div>
          </FlexBox>
        </ProductInfo>
      </Product>
    </>
  );
};

const _renderShop = (image: string): JSX.Element => {
  return (
    <>
      <Product className="shopinfo">
        <div style={{ position: "relative" }}>
          <ProductImage
            src={image}
            width={90}
            height={90}
            objectFit={"cover"}
            alt="image"
          />
          <Distance gap="0.15rem" align="center">
            <Map />
            <p>2.8 Km</p>
          </Distance>
        </div>
        <ProductInfo>
          <ProductTitle>Wood Style Furniture</ProductTitle>
          <FlexBox gap="0.15rem" style={{ marginTop: "0.25rem" }}>
            <Map />
            <div className="ft-12">
              No.163/1, Second Floor, BLOCK-Z1, No.201, BRT Road, above Sakti
              Sports Office, Roseland Residency, Pimple Saudagar
            </div>
          </FlexBox>
        </ProductInfo>
      </Product>
    </>
  );
};

function HomePage() {
  const [loading, setLoading] = useState(true);

  const _renderTrendingPost = (post: TrendingProps): JSX.Element => {
    return (
      <Product>
        <div style={{ position: "relative" }}>
          <ProductImage
            src={post.imageURL}
            width={200}
            height={200}
            objectFit={"cover"}
            alt="image"
          />
          <Distance gap="0.15rem" align="center">
            <Map />
            <p>2.8 Km</p>
          </Distance>
        </div>
        <ProductInfo>
          <FlexBox align="center" gap="0.25rem">
            <Star />
            <p className="black ft-12">4.5</p>
          </FlexBox>

          <ProductTitle>Wood Style Furniture</ProductTitle>
          <p className="ft-12">Category / Sub Category</p>
          <Price className="ft-16">$59.99</Price>
          {/* <FlexBox gap="0.15rem" style={{ marginTop: "0.25rem" }}>
            <Map />
            <div className="ft-12">
              No.163/1, Second Floor, BLOCK-Z1, No.201, BRT Road, above Sakti
              Sports Office, Roseland Residency, Pimple Saudagar
            </div>
          </FlexBox> */}
        </ProductInfo>
      </Product>
      // <div className="my-5 rounded-md" id={post.id}>
      //   <div className="relative">
      //     <div className="absolute right-0 text-trending-icon">
      //       <Link href="/#">
      //         <FiHeart className="text-xl m-2" />
      //       </Link>
      //     </div>
      //     <Image
      //       src={post.imageURL}
      //       width="1000"
      //       height={400}
      //       alt="data.post image"
      //       className="rounded-xl"
      //     />
      //   </div>
      //   <div className="text-gray-800 p-2">
      //     <div className="text-sm font-bold truncate">{post.name}</div>

      //     <div className="text-xs truncate">
      //       {post.designation} @ <span>{post.company}</span>
      //     </div>

      //     <div className="flex my-1">
      //       <Link href="/#m">
      //         <TbMessage className="text-xl text-trending-icon my-auto mr-2 cursor-pointer" />
      //       </Link>
      //       <Link href="/#">
      //         <TbLink className="text-xl text-trending-icon my-auto mr-2 cursor-pointer" />
      //       </Link>
      //     </div>

      //     <div className="flex my-1">
      //       <MdLocationOn className="text-lg my-auto cursor-pointer" />
      //       <div className="text-xs">{post.distance}</div>
      //     </div>

      //     <div>{post.liked}</div>
      //   </div>
      // </div>
    );
  };

  return (
    <div>
      <GridSection>
        <section id="trending-posts" className="">
          {TRENDING_CONTENT.map((post: TrendingProps) =>
            _renderTrendingPost(post)
          )}
        </section>

        <section id="posts">
          {/* {_renderProfile()} */}

          {_renderViewdetails()}

          <Heading>Price comparison from near by shops</Heading>
          <ProductSlider>
            <Slider {...settings}>
              {PROFILE_POSTS.posts.map((post: string) => _renderPost(post))}
            </Slider>
          </ProductSlider>

          <Heading>Similar Shops nearby</Heading>
          <ProductSlider>
            <Slider {...settings}>
              {PROFILE_POSTS.posts.map((post: string) => _renderShop(post))}
            </Slider>
          </ProductSlider>

          {/* <div className="flex overflow-x-scroll gap-5 ">
              {PROFILE_POSTS.discoveries.map((post: string) =>
                _renderPost(post)
              )}
            </div> */}

          <Heading>Products used by the same user</Heading>
          <ProductSlider>
            {/* {PROFILE_POSTS.discoveries.map((post: string) =>
                _renderPost(post)
              )} */}
            <Slider {...settings}>
              {PROFILE_POSTS.posts.map((post: string) => _renderPost(post))}
            </Slider>
          </ProductSlider>
        </section>
      </GridSection>
    </div>
  );
}
export default HomePage;
