import React, { useEffect, useRef, useState } from "react";
import Slider from "react-slick";
import Image from "next/image";

const SliderComponent = () => {
  const [nav1, setNav1] = useState<Slider | undefined>(undefined);
  const [nav2, setNav2] = useState<Slider | undefined>(undefined);
  const slider1Ref = useRef<Slider | null>(null);
  const slider2Ref = useRef<Slider | null>(null);

  useEffect(() => {
    setNav1(slider1Ref.current ?? undefined);
    setNav2(slider2Ref.current ?? undefined);
  }, []);

  const items = [
    { id: 1, postId: 1, image: "https://picsum.photos/1000/700", userId: 1 },
    {
      id: 2,
      postId: 1,
      image: "https://picsum.photos/1000/800",
      type: "PRODUCT",
      userId: 1,
    },
  ];

  // const sliderForSettings = {
  //   slidesToShow: 1,
  //   slidesToScroll: 1,
  //   arrows: true,
  //   fade: true,
  //   asNavFor={nav2}
  // };

  // const sliderNavSettings = {
  //   slidesToShow: 3,
  //   slidesToScroll: 1,
  //   asNavFor={nav1}
  //   arrows: true,
  //   focusOnSelect: true,
  // };

  const renderSliderItems = () => {
    return items.map((item) => (
      <div key={item.id}>
        <Image
          src={item?.image}
          width={300}
          height={300}
          objectFit={"contain"}
          alt="image"
        />
      </div>
    ));
  };

  return (
    <div>
      <Slider asNavFor={nav2} slidesToShow={1} arrows={false} ref={slider1Ref}>
        {renderSliderItems()}
      </Slider>

      <Slider
        asNavFor={nav1}
        ref={slider2Ref}
        slidesToShow={3}
        infinite={false}
        swipeToSlide={true}
        focusOnSelect={true}
      >
        {renderSliderItems()}
      </Slider>
    </div>
  );
};

export default SliderComponent;
