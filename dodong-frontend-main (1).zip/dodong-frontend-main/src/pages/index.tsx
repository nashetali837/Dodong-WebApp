import React, { useCallback, useEffect, useState } from "react";
import Image from "next/image";
import Link from "next/link";
import { MdLocationOn } from "react-icons/md";
import { FiHeart } from "react-icons/fi";
import { TbMessage, TbLink } from "react-icons/tb";
import StoreFrontPost from "@/components/storefront/post";
import { Heading } from "@/shared/texts";
import Spinner from "@/shared/loading/spinner";
import { TRENDING_CONTENT, LOCAL_MARKET_CONTENT } from "@/lib/constants";
import { EndPoints } from "@/lib/apiConstants";
import Modal from "@/shared/modal";
import { NextSeo } from "next-seo";

import ExpandedPost from "@/components/storefront/post/ui/ExpandedPost";
import { useRouter } from "next/router";

type TrendingProps = {
  name: string;
  designation: string;
  company: string;
  id: string;
  distance: string;
  imageURL: string;
  liked: boolean;
};

type LocalMarketProps = {
  name: string;
  designation: string;
  company: string;
  id: string;
  distance: string;
  imageURL: string;
  location: string;
  liked: boolean;
};

function HomePage() {
  const [page, setPage] = useState(1);
  const [isLoading, setLoading] = useState(true);
  const [trendingPosts, setTrendingPosts] = useState<any[]>([]);
  const [currentPost, setCurrentPost] = useState<any>(undefined);
  const [viewPostModal, setViewPostModal] = useState<boolean>(false);
  const router = useRouter();
  const { query, asPath } = useRouter();
  const postId = query.postID;

  const _renderTrendingPost = (post: TrendingProps): JSX.Element => {
    return (
      <div className="my-5 rounded-md" id={post.id}>
        <div className="relative">
          <div className="absolute right-0 text-trending-icon">
            <Link href="/#">
              <FiHeart className="text-xl m-2" />
            </Link>
          </div>
          <Image
            src={post.imageURL}
            width="1000"
            height={400}
            alt="data.post image"
            className="rounded-xl"
          />
        </div>
        <div className="text-gray-800 p-2">
          <div className="text-sm font-bold truncate">{post.name}</div>

          <div className="text-xs truncate">
            {post.designation} @ <span>{post.company}</span>
          </div>

          <div className="flex my-1">
            <Link href="/#m">
              <TbMessage className="text-xl text-trending-icon my-auto mr-2 cursor-pointer" />
            </Link>
            <Link href="/#">
              <TbLink className="text-xl text-trending-icon my-auto mr-2 cursor-pointer" />
            </Link>
          </div>

          <div className="flex my-1">
            <MdLocationOn className="text-lg my-auto cursor-pointer" />
            <div className="text-xs">{post.distance}</div>
          </div>

          <div>{post.liked}</div>
        </div>
      </div>
    );
  };

  const _renderLocalMarketProduct = (post: LocalMarketProps): JSX.Element => {
    return (
      <div className="my-5 px-2 rounded-md mx-auto" id={post.id}>
        <Image
          src={post.imageURL}
          width={400}
          height={400}
          alt="data.post image"
          className="rounded-xl w-full"
          style={{ width: "100%" }}
        />
        <div className="text-gray-800 m-2">
          <div className="text-sm font-bold truncate">{post.name}</div>

          <div className="flex my-1">
            <MdLocationOn className="text-lg my-auto" />
            <div className="text-xs">{post.location}</div>
          </div>
        </div>
      </div>
    );
  };

  useEffect(() => {
    fetchStoreFront(page).then((data) => {
      console.log("storefront", data);
      if (data) {
        setTrendingPosts(data.trendingPosts);
      }
      setLoading(false);
    });
  }, [page]);

  const fetchStoreFront = useCallback(async (page: number) => {
    setLoading(true);
    const response = await fetch(
      `${EndPoints.storefront}?page=${page}&device=web&type=post`
    )
      .then((res) => {
        if (res.status === 200) {
          return res.json();
        } else {
          throw new Error(res.statusText);
        }
      })
      .then((data) => {
        return data;
      })
      .catch((err) => {
        console.log(err);
        return null;
      });
    return response;
  }, []);

  const selectedPost = trendingPosts?.find(
    (post) => post?.productId?.toString() === postId
  );

  useEffect(() => {
    if (selectedPost) {
      setCurrentPost(selectedPost);
      setViewPostModal(true);
    }
  }, [selectedPost]);

  const handleCloseModal = () => {
    setCurrentPost(null);
    setViewPostModal(false);
  };

  return (
    <div className="relative">
      <NextSeo
        title="Dodong | Go online Do dong"
        description="This is the home page of the website"
      />
      <div className="max-w-md container mx-auto"></div>
      {isLoading ? (
        <Spinner />
      ) : (
        <div className="mx-auto max-w-5xl align-middle">
          {false && (
            <section
              id="trending-posts"
              className="hidden lg:block mr-3 lg:h-min lg:sticky lg:top-20 xs:hidden trending-container pr-4"
            >
              <div
                className="overflow-y-scroll px-2"
                style={{ height: "90vh" }}
              >
                {TRENDING_CONTENT.map((post: TrendingProps) =>
                  _renderTrendingPost(post)
                )}
              </div>
            </section>
          )}

          <section className="flex-1" id="posts">
            {/* <Statuses /> */}

            <div className="flex-1">
              {trendingPosts?.map((post: any, k: number) => (
                <StoreFrontPost
                  key={k}
                  post={post}
                  selectPost={() => {
                    setCurrentPost(post);
                  }}
                  openPost={() => {
                    setViewPostModal(true);
                  }}
                />
              ))}
            </div>
          </section>

          {false && (
            <section
              id="local-market"
              className="md:block lg:h-min lg:sticky lg:overflow-y-scroll lg:top-20 max-w-sm xs:hidden px-2"
            >
              <div className="flex-1 w-80" style={{ height: "90vh" }}>
                {false && <Heading title="Local Market" icon={<></>} />}
                {false &&
                  LOCAL_MARKET_CONTENT.map((post: LocalMarketProps) =>
                    _renderLocalMarketProduct(post)
                  )}
              </div>
            </section>
          )}
        </div>
      )}

      <Modal
        fullScreen={false}
        key="post_modal"
        open={viewPostModal}
        onClose={handleCloseModal}
      >
        {currentPost && <ExpandedPost currentPost={currentPost} />}
      </Modal>
    </div>
  );
}
export default HomePage;
