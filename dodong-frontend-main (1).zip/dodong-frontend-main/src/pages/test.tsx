import { useRouter } from "next/router";
import { useState } from "react";

interface Post {
  id: number;
  title: string;
}

interface PostsProps {
  posts: Post;
}

const Posts = ({ posts }: PostsProps) => {
  const router = useRouter();
  const [selectedPostID, setSelectedPostID] = useState<number | null>(null);

  const handlePostClick = (postID: number) => {
    setSelectedPostID(postID);
    router.push(`/posts?postID=${postID}`, undefined, { shallow: true });
  };

  const handleCloseClick = () => {
    setSelectedPostID(null);
    router.push("/posts", undefined, { shallow: true });
  };

  return (
    <div>
      <h1>List of Posts</h1>
      {Array.isArray(posts) && posts.length > 0 ? (
        posts.map((post) => (
          <div key={post.id} onClick={() => handlePostClick(post.id)}>
            {post.id}
          </div>
        ))
      ) : (
        <p>No posts available.</p>
      )}
      {selectedPostID && (
        <div>
          <h2>Selected Post</h2>
          <p>{`PostID: ${selectedPostID}`}</p>
          <button onClick={handleCloseClick}>Close</button>
        </div>
      )}
    </div>
  );
};

export async function getServerSideProps() {
  // Fetch posts from an API
  const res = await fetch("https://api.dodong.in/storefront?page=1&device=web");
  const test = await res.json();
  const posts = test?.trendingPosts;

  console.log(posts, "poat");

  return {
    props: {
      posts,
    },
  };
}

export default Posts;
