import React, { useCallback, useEffect, useState } from "react";
import Image from "next/image";
import Link from "next/link";

import { MdLocationOn } from "react-icons/md";
import { FiHeart } from "react-icons/fi";
import { TbMessage, TbLink } from "react-icons/tb";

function NotFoundPage() {
  return <div>Page Not found...</div>;
}
export default NotFoundPage;
