import { createSlice } from "@reduxjs/toolkit";
import type { PayloadAction } from "@reduxjs/toolkit";

const initialState: any = {
  //

  draft: null,
};

export const draftReducer = createSlice({
  name: "draft",

  initialState,

  reducers: {
    // drafts
    updateDraft: (state, action: PayloadAction<any>) => {
      console.log("[Post Draft Reducer] updating Draft =>", action.payload);
      state.draft = {
        ...state.draft,
        ...action.payload,
      };
    },

    deleteDraft: (state) => {
      console.log("[Post Draft Reducer] Logging User Out");
      state.draft = null;
    },
  },
});

// Action creators are generated for each case reducer function
export const { deleteDraft, updateDraft } = draftReducer.actions;

export default draftReducer.reducer;
