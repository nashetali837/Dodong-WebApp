import { createSlice, PayloadAction } from "@reduxjs/toolkit";
import moment from "moment";

const DEFAULT_EXPIRY_TIME = moment().add(12, "hours").valueOf();

interface AuthInterface {
  authToken: string;
  tokenExpiresAt: number;
  isLoggedIn?: boolean;
}

const initialState: AuthInterface = {
  authToken: "",
  tokenExpiresAt: new Date().valueOf(),
};

const authState = createSlice({
  name: "authConfig",
  initialState,
  reducers: {
    checkAuth: (state) => {
      console.log("[User Reducer] Checking Auth");

      if (state.authToken === "") {
        console.log("[User Reducer] No authToken found");
        state = initialState;
        return;
      }

      let currentDateTime = new Date().valueOf();
      if (currentDateTime > state.tokenExpiresAt) {
        console.log("[User Reducer] Token Expired");
        state = initialState;
      }
    },

    updateAuthState(state, action: PayloadAction<Partial<AuthInterface>>) {
      console.log("[User Reducer] Logging User In =>", action.payload);
      // if(!action.payload.authToken){}
      state.authToken = action.payload.authToken || "";
      state.tokenExpiresAt = DEFAULT_EXPIRY_TIME;
      state.isLoggedIn = true;
    },

    logoutUser: (state) => {
      console.log("[User Reducer] Logging User Out");
      state.isLoggedIn = false;
      state.authToken = "";
    },
  },
});

export const { checkAuth, logoutUser, updateAuthState } = authState.actions;

export default authState.reducer;
