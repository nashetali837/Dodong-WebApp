import { createSlice } from "@reduxjs/toolkit";
import type { PayloadAction } from "@reduxjs/toolkit";
import { UserType } from "@/components/storefront/post/types";

export interface UserProfile {
  id: number;
  userId: number;
  name: string | null;
  displayName: string | null;
  occupation: string | null;
  bio: string | null;
  dateOfBirth: string | null;
  avatar: string | null;
  facebookURL: string | null;
  LinkedInURL: string | null;
  twitterHandle: string | null;
  locationId: number | null;
  createdAt: Date;
  draft: any;
  updatedAt: Date;
  followers: number;
  following: number;
  totalPosts: number;
}

export interface UserState {
  user: UserType | null;
  userProfile: UserProfile | null;
  openLoginModal: boolean;
  createPostModal: boolean;
  openForgotPasswordModal: boolean;
  openEditProfileModal: boolean;
  draft: any;
}

const initialState: UserState = {
  user: null,
  userProfile: null,
  openLoginModal: false,
  createPostModal: false,
  openForgotPasswordModal: false,
  openEditProfileModal: false,
  draft: null,
};

export const userReducer = createSlice({
  name: "user",

  initialState,

  reducers: {
    saveUser: (state: UserState, action: PayloadAction<UserType>) => {
      console.log("[User Reducer] Updating user =>", action.payload);
      state.user = action.payload;
    },

    saveProfile: (state: UserState, action: PayloadAction<UserProfile>) => {
      console.log("[User Reducer] Updating user profile =>", action.payload);
      state.userProfile = action.payload;
    },

    toggleLoginModal: (state: UserState, action: PayloadAction<any>) => {
      console.log("[Post Draft Reducer] toggleLoginModal");
      state.openLoginModal = action.payload;
    },

    toggleCreatePostModal: (state: UserState, action: PayloadAction<any>) => {
      console.log(
        "[Post Draft Reducer] opening Create post modal: ",
        action.payload
      );
      state.createPostModal = action.payload;
    },

    toggleForgotPasswordModal: (
      state: UserState,
      action: PayloadAction<any>
    ) => {
      console.log("[Post Draft Reducer] opening Forgot password modal");
      state.openForgotPasswordModal = action.payload;
      if (action.payload) state.openLoginModal = !action.payload;
    },

    toggleEditProfileModal: (state: UserState, action: PayloadAction<any>) => {
      console.log("[Post Draft Reducer] opening Edit Profile modal");
      state.openEditProfileModal = action.payload;
    },
  },
});

// Action creators are generated for each case reducer function
export const {
  saveUser,
  saveProfile,
  toggleLoginModal,
  toggleCreatePostModal,
  toggleForgotPasswordModal,
  toggleEditProfileModal,
} = userReducer.actions;

export default userReducer.reducer;
