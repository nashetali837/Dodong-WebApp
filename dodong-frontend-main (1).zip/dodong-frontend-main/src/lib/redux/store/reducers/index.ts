import userReducer from "../../slices/user-slice";
import { combineReducers } from "@reduxjs/toolkit";
import authReducer from "../../slices/auth-slice";

export default combineReducers({
  user: userReducer,
  auth: authReducer,
});
