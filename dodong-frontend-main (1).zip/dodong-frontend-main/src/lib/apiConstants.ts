"use client";

export class EndPoints {
  static baseURL = process.env.NEXT_PUBLIC_BACKEND_URL + "/";

  //auth
  static signup = this.baseURL + "auth/register";
  static login = this.baseURL + "auth/login";
  static googleAuth = this.baseURL + "auth/google";
  static facebookAuth = this.baseURL + "auth/facebook";
  static profile = this.baseURL + "users/profile";
  static updateProfile = this.baseURL + "users/update-profile";
  static businessProfile = this.baseURL + "users/update-professional-profile";
  static forgotPassword = this.baseURL + "auth/forgot-password";
  static verifyEmail = this.baseURL + "auth/verify-email";
  static verifyOtp = this.baseURL + "auth/verify-otp";
  static resetPassword = this.baseURL + "auth/reset-password";

  // categories
  static categories = this.baseURL + "posts/categories/filter";
  static sub_categories = this.baseURL + "posts/sub-categories/filter";

  // storefront
  static storefront = this.baseURL + "storefront";
  static fetchNotifications = this.baseURL + "notifications/get";

  // post
  static posts = this.baseURL + "posts";
  static filterPosts = this.baseURL + "posts/filter";
  static createPost = this.baseURL + "posts/create";
  static likePost = this.baseURL + "posts/like";
  static unlikePost = this.baseURL + "posts/unlike";

  // shop
  static shops = this.baseURL + "shops";
  static createShop = this.baseURL + "shops/create";

  // follow
  static followUser = this.baseURL + "follow/follow-user";
  static unFollowUser = this.baseURL + "follow/unfollow-user";

  // comments
  static getComments = this.baseURL + "comments/get";
  static addComment = this.baseURL + "comments/add";
  static updateComment = this.baseURL + "comments/update";
  static deleteComment = this.baseURL + "comments/delete";
}
