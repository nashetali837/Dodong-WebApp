import * as z from "zod";

export const createPostProductSchema = z.object({
  email: z.string().email(),
  password: z.string(),
});
