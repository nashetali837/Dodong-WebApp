type PostProps = {
  profile: {
    name: string;
    followers: string;
    following: string;
    imageURL: string;
    distance: string;
    id: string;
  };
  shopURL: string;
  post: {
    imageURL: string;
    description: string;
    liked: boolean;
    likes: string;
    comments: string;
    shares: string;
  };
  liked: boolean;
};

type UserType = {
  id: number;
  email: string;
  mobileNumber: string;
  password: string;
  emailVerified: boolean;
  userType: Role;
  createdAt: Date;
  lastLogin: Date;
  OTP: string | null;
  OTPExpiry: Date | null;
};


interface userProfile{
  
}

enum Role {
  "ADMIN" = "ADMIN",
  "USER" = "USER",
}

export type { PostProps, UserType, Role };
