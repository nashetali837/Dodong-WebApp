import {NavigationContainer} from '@react-navigation/native';
import {ThemeProvider} from '@shopify/restyle';
import React, {useState} from 'react';
import {Provider} from 'react-redux';
import {lightTheme} from '@src/ui_kit/theme';
import useNavigationRef from '@src/hooks/useNavigationRef';
import store from '@src/redux/store';
import RootStackRoute from '@src/routes/rootStack';
import SplashScreen from '@src/screens/splash';
import StatusBarManager from '@components/statusBarManager';
import useShowSplash from '@src/hooks/useShowSplash';

interface IApp {}

const App: React.FC<IApp> = () => {
  const {navigationRef, routeNameRef, updateNavigationRef} = useNavigationRef();
  const [currentRoute, setCurrentRoute] = useState<string | undefined>(
    undefined,
  );

  const onReady = () => {};
  const onStateChange = async () => {
    const previousRouteName = routeNameRef.current;
    const currentRouteName =
      navigationRef?.current?.getCurrentRoute()?.name ?? '';
    if (previousRouteName !== currentRouteName) {
      setCurrentRoute(currentRouteName);
      updateNavigationRef(currentRouteName);
    }
  };

  const {showSplash} = useShowSplash();

  return (
    <NavigationContainer
      ref={navigationRef}
      onReady={onReady}
      onStateChange={onStateChange}>
      <ThemeProvider theme={lightTheme}>
        <SplashScreen showSplash={showSplash} />
        {showSplash ? <></> : <RootStackRoute />}
        <StatusBarManager currentRouteName={currentRoute} />
      </ThemeProvider>
    </NavigationContainer>
  );
};

const AppWrapper = () => {
  return (
    <Provider store={store}>
      <App />
    </Provider>
  );
};

export default AppWrapper;
