export enum AppPlatform {
  IOS = 'ios',
  ANDROID = 'android',
}

export enum FriendInviteOptions {
  FOLLOW_CONNECTS = 'Follow Connects',
  BY_WHATSAPP = 'Invite friends by whatsapp',
  BY_EMAIL = 'Invite friends by email',
  BY_SMS = 'Invite friends by sms',
  GENERIC = 'Invite friends by...',
}

export enum GoogleAuthType {
  LOGIN = 'login',
  SIGNUP = 'signup',
}

export enum ProfileCompletionSteps {
  UPDATE_PERSONAL_PROFILE = 'Update your personal profile',
  PERCENT = '100',
}

export enum ProfileCTAs {
  MESSAGE = 'Message',
  EDIT_PROFILE = 'Edit Profile',
  CONNECT = 'Connect',
}

export enum PROFILE_TYPE {
  PERSONAL = 'personal',
  PUBLIC = 'public,',
}

export enum SHORT_ACTIONS {
  WISHLIST = 'wishlist',
  LIKE = 'like',
  UNLIKE = 'unlike',
  COMMENT = 'comment',
  SHARE = 'share',
}

export enum SHOP_MODE {
  INSENSITIVE = 'insensitive',
}

export enum RESOURCE_TYPES {
  POST = 'POST',
  DISCOVERY = 'DISCOVERY',
  COLLECTION = 'COLLECTION',
  EXPERIENCE = 'EXPERIENC',
}

export enum NOTIFICATION_ACTIONS {
  ACCEPT = 'ACCEPT',
  DECLINE = 'DECLINE',
}
