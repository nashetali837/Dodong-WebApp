import {Box} from '@src/ui_kit/atoms';
import AppTopHeader from '@src/ui_kit/components/headers/appTopHeader';
import {theme} from '@src/ui_kit/theme';
import {dimensions} from '@src/utilities/helpers';
import React from 'react';
import {ActivityIndicator} from 'react-native';
import {WebView} from 'react-native-webview';
const GenericWebView = ({...props}) => {
  const {route} = props;
  const {
    params: {sourceUrl, addAuthorization, cacheEnabled = true, headerText},
  } = route;

  const webSource = {uri: sourceUrl};

  const onNavigationStateChange = (navState: object) => {
    if (__DEV__) {
      console.log('GenericWebView', navState);
    }
  };

  return (
    <Box flex={1}>
      <AppTopHeader headerText={headerText} />
      <WebView
        cacheEnabled={cacheEnabled}
        startInLoadingState
        renderLoading={() => (
          <Box
            height={dimensions.screenHeight}
            bg="lightWhite"
            justifyContent="center"
            alignItems="center">
            <ActivityIndicator color={theme.colors.orange500} size={'large'} />
          </Box>
        )}
        source={webSource}
        sharedCookiesEnabled={addAuthorization}
        onNavigationStateChange={onNavigationStateChange}
      />
    </Box>
  );
};
export default GenericWebView;
