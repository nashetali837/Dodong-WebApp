type TViewComponent = {
  component: React.ComponentType<any>;
  props: Record<string, any>;
};

export type TViewComponents = Record<string, TViewComponent>;
