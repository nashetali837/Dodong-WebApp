import React, {useRef} from 'react';
import {Box, Text} from '@atoms';
import AppTopHeader from '@components/headers/appTopHeader';
import SelectProfileImage from '../components/selectProfileImage';
import APP_ICON_NAMES from '@components/appIcons/iconNames';
import OptionBox from '@components/optionBox';
import {ScreensList} from '@src/routes/helpers';
import InviteFriendsModal from '../components/inviteFriends';
import {TOption} from '@src/ui_kit/components/optionBox/type';

const Steps = [
  {
    name: 'Update Profile',
    icon: APP_ICON_NAMES.Profile,
  },
  {
    name: 'Create Photos and Videos',
    icon: APP_ICON_NAMES.Photo,
  },
  {
    name: 'Invite Friends',
    icon: APP_ICON_NAMES.InviteFriend,
  },
];
const ProfileCompleteLandingScreen = ({...props}) => {
  const modalRef = useRef();

  const {
    navigation: {navigate},
  } = props;

  const handleOnPress = (step: TOption) => {
    switch (step.name) {
      case Steps[0].name:
        navigate(ScreensList.CompleteProfile);
        break;

      case Steps[1].name:
        navigate(ScreensList.ImageUpload);
        break;

      case Steps[2].name:
        modalRef.current.showModal();
        break;
      default:
        break;
    }
  };

  return (
    <Box bg={'white'} flex={1}>
      <AppTopHeader headerText={'Complete Profile'}>
        <Box alignSelf="center" mb={'_s48'}>
          <SelectProfileImage isDisabled={true} />
        </Box>
      </AppTopHeader>
      <Box mx={'_s24'} flex={1}>
        <Text color={'gray1'} variant={'body2.regular.14'}>
          You now have only 3 steps to complete to connect with your viewers on
          Dodong. Let’s get started.
        </Text>
        <Text variant={'body1.regular.16'} my={'_s24'} color={'gray2'}>
          0 to 3{' '}
          <Text variant={'body1.regular.16'} color={'gray1'}>
            Step to follow
          </Text>
        </Text>
        <Box>
          {Steps.map((step, index) => {
            return (
              <OptionBox
                key={`option${index}`}
                option={step}
                onPress={handleOnPress}
              />
            );
          })}
        </Box>
        <InviteFriendsModal ref={modalRef} />
      </Box>
    </Box>
  );
};

export default ProfileCompleteLandingScreen;
