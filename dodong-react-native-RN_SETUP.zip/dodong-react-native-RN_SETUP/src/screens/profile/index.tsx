import {Box} from '@src/ui_kit/atoms';
import React from 'react';
import Info from './components/info';
import {ProfileContent} from './profileContext';
import {IProfileView} from './type';
import {PROFILE_TYPE} from '@src/constants/Enums';
const ProfileView: React.FC<IProfileView> = ({
  type = PROFILE_TYPE.PUBLIC,
  userData,
}) => {
  const context = {userData, type};
  console.log('userData context', context);
  return (
    <ProfileContent.Provider value={context}>
      <Box flex={1} bg={'lightWhite'}>
        <Info />
      </Box>
    </ProfileContent.Provider>
  );
};

export default ProfileView;
