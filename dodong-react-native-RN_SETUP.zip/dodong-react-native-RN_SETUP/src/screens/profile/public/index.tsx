import React from 'react';
import ProfileView from '..';
import {usePublicUserData} from '@src/hooks/user/usePublicUserData';
import {ActivityIndicator} from 'react-native';
import {theme} from '@src/ui_kit/theme';
import {Box} from '@src/ui_kit/atoms';

const PublicProfileScreen = ({...props}) => {
  const profileId = props?.route?.params?.profileId ?? null;
  const {userData, loading} = usePublicUserData({profileId});
  if (!userData) {
    return <></>;
  }
  if (loading) {
    return (
      <Box flex={1} justifyContent="center" alignItems="center">
        <ActivityIndicator size={'small'} color={theme.colors.orange500} />
      </Box>
    );
  }
  return <ProfileView userData={userData} />;
};

export default PublicProfileScreen;
