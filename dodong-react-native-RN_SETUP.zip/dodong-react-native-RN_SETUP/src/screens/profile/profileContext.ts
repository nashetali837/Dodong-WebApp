import {PROFILE_TYPE} from '@src/constants/Enums';
import {TUserData} from '@src/redux/auth/type';
import React, {useContext} from 'react';

interface TProfileContext {
  type: string;
  userData: TUserData | undefined;
}

const initialContext = {
  type: PROFILE_TYPE.PUBLIC,
  userData: undefined,
};

export const ProfileContent =
  React.createContext<TProfileContext>(initialContext);

export const useProfileContext = () => {
  return useContext<TProfileContext>(ProfileContent);
};
