import React, {useImperativeHandle} from 'react';
import {useState} from 'react';
import Modal from 'react-native-modal';
import {Box} from '@atoms';
import {theme} from '@theme';
import {forwardRef} from 'react';
import {StyleSheet} from 'react-native';
import {InviteFriendView} from './InviteView';

const InviteFriendsModal = forwardRef((props, ref) => {
  const [showModal, setShowModal] = useState<boolean>(false);

  useImperativeHandle(ref, () => ({
    showModal() {
      _handleShow();
    },
  }));

  const _handleShow = () => setShowModal(true);
  const _handleHide = () => setShowModal(false);

  return (
    <Box>
      <Modal
        backdropColor={theme.colors.black20}
        hasBackdrop={true}
        statusBarTranslucent
        backdropOpacity={0.9}
        isVisible={showModal}
        onBackButtonPress={_handleHide}
        onBackdropPress={_handleHide}
        style={[styles.modalContainer]}
        animationIn={'fadeIn'}
        animationOut={'fadeOut'}
        hideModalContentWhileAnimating={true}
        useNativeDriver={true}
        useNativeDriverForBackdrop={true}
        backdropTransitionOutTiming={0}>
        <InviteFriendView hideModal={_handleHide} />
      </Modal>
    </Box>
  );
});

export default InviteFriendsModal;

const styles = StyleSheet.create({
  modalContainer: {
    margin: 0,
    padding: 0,
  },
});
