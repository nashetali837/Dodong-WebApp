import config from '@src/config';
import {FriendInviteOptions} from '@src/constants/Enums';
import {UseInviteFriends} from '@src/hooks/share/useInviteFriends';
import {Box, Text} from '@src/ui_kit/atoms';
import APP_ICON_NAMES from '@src/ui_kit/components/appIcons/iconNames';
import OptionBox from '@src/ui_kit/components/optionBox';
import WaveBox from '@src/ui_kit/components/waveBox';
import {IS_IOS} from '@src/utilities/helpers';
import React from 'react';
import {useSafeAreaInsets} from 'react-native-safe-area-context';

type TEachInvite = {
  name: string;
  icon: string;
  subject: string;
  message: string;
  url?: string;
};

const InviteList: TEachInvite[] = [
  {
    name: FriendInviteOptions.FOLLOW_CONNECTS,
    icon: APP_ICON_NAMES.InviteFriend,
    subject: '',
    message: '',
  },
  {
    name: FriendInviteOptions.BY_WHATSAPP,
    icon: APP_ICON_NAMES.Whatsaap,
    subject: '',
    message: '',
  },
  {
    name: FriendInviteOptions.BY_EMAIL,
    icon: APP_ICON_NAMES.Email,
    subject: '',
    message: '',
  },
  {
    name: FriendInviteOptions.BY_SMS,
    icon: APP_ICON_NAMES.Sms,
    subject: '',
    message: '',
  },
  {
    name: FriendInviteOptions.GENERIC,
    icon: APP_ICON_NAMES.More,
    subject: '',
    message: '',
    url: !IS_IOS ? config.stores.playStore : config.stores.appStore,
  },
];

export const InviteFriendView = ({hideModal}: {hideModal: () => void}) => {
  const inset = useSafeAreaInsets();

  return (
    <Box
      bg={'white'}
      flex={1}
      position={'absolute'}
      bottom={0}
      width={'100%'}
      style={{paddingBottom: inset.bottom}}>
      <WaveBox onPress={hideModal} />
      <Box mx={'_s24'}>
        <Text
          my={'_s32'}
          color={'gray2'}
          variant={'body1.semiBold.24'}
          lineHeight={34}>
          Invite Friends
        </Text>
        <Text mb={'_s16'} color={'gray1'} variant={'body2.regular.14'}>
          Invite your friends to grow your network to follow your account. You
          can also connect with them to let them add you to their network.
        </Text>
        {InviteList.map((list, index) => {
          return <EachOption list={list} key={`eachOption_${index}`} />;
        })}
      </Box>
    </Box>
  );
};

const EachOption = ({list}: {list: TEachInvite}) => {
  const onFollowConnect = () => {};

  const {inviteByWhatsaap, inviteByEmail, inviteBySms, genericInvite} =
    UseInviteFriends();
  const handleOnPress = () => {
    switch (list.name) {
      case FriendInviteOptions.FOLLOW_CONNECTS:
        onFollowConnect();
        break;
      case FriendInviteOptions.BY_EMAIL:
        inviteByEmail();
        break;
      case FriendInviteOptions.BY_WHATSAPP:
        inviteByWhatsaap();
        break;
      case FriendInviteOptions.BY_SMS:
        inviteBySms();
        break;
      case FriendInviteOptions.GENERIC:
        genericInvite();
        break;

      default:
        break;
    }
  };

  return <OptionBox option={list} onPress={handleOnPress} />;
};
