import {Box} from '@src/ui_kit/atoms';
import GradientButton from '@src/ui_kit/components/buttons/gradientButton';
import {theme} from '@src/ui_kit/theme';
import {dimensions} from '@src/utilities/helpers';
import React, {useState} from 'react';
import {ScrollView, StyleSheet} from 'react-native';
import CollectionView from './collections';
import DiscoveryView from './discoveries';
import ExperiencesView from './experiences';
import PostsView from './posts';

const Tabs = ['Posts', 'Experiences', 'Collections', 'Discoveries'];
const ViewData = () => {
  const [currentTab, setCurrentTab] = useState<string>(Tabs[0]);

  const _handlePress = (tab: string) => {
    if (tab !== currentTab) {
      setCurrentTab(tab);
    }
  };

  const ViewComponent = {
    [Tabs[0]]: {
      component: PostsView,
      props: {},
    },
    [Tabs[1]]: {
      component: ExperiencesView,
      props: {},
    },
    [Tabs[2]]: {
      component: CollectionView,
      props: {},
    },
    [Tabs[3]]: {
      component: DiscoveryView,
      props: {},
    },
  };

  const getTabText = (tab: string) => {
    switch (tab) {
      case Tabs[0]:
        return tab + ' (50)';
      case Tabs[1]:
        return tab + ' (50)';
      case Tabs[2]:
        return tab + ' (50)';
      case Tabs[3]:
        return tab + ' (50)';
      default:
        return '';
    }
  };

  const {component: Component, props} = ViewComponent[currentTab];

  return (
    <Box
      bg={'white'}
      borderTopLeftRadius={20}
      borderTopRightRadius={20}
      minHeight={dimensions.height}
      mt={'_s24'}
      pt={'_s24'}>
      <Box>
        <ScrollView
          horizontal
          showsHorizontalScrollIndicator={false}
          contentContainerStyle={{
            paddingLeft: theme.size.TWENTY_FOUR,
          }}>
          {Tabs.map((tab, index) => {
            return (
              <Box mr={'_s8'} key={`tab${index}`}>
                <GradientButton
                  gradientStyles={styles.gradientStyles}
                  containerStyles={{width: 'auto'}}
                  text={getTabText(tab)}
                  isOutlined={currentTab !== tab}
                  onPress={() => _handlePress(tab)}
                />
              </Box>
            );
          })}
        </ScrollView>
      </Box>
      <Box mx={'_s24'} mt={'_s16'}>
        <Component {...props} />
      </Box>
    </Box>
  );
};

export default ViewData;

const styles = StyleSheet.create({
  gradientStyles: {
    paddingVertical: 8,
    // flex: 'auto', // crash on android
    paddingHorizontal: theme.size.SIXTEEN,
  },
});
