import {Box, Text} from '@src/ui_kit/atoms';
import React from 'react';
const CollectionView = () => {
  return (
    <Box>
      <Text>COLLECTION VIEW</Text>
    </Box>
  );
};

export default CollectionView;
