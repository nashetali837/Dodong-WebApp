import {Box, Text} from '@src/ui_kit/atoms';
import React from 'react';
const ExperiencesView = () => {
  return (
    <Box>
      <Text>Experience VIEW</Text>
    </Box>
  );
};

export default ExperiencesView;
