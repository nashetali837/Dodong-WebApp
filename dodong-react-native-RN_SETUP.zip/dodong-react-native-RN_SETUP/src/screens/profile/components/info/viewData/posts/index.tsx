import {Box, Text} from '@src/ui_kit/atoms';
import React from 'react';
const PostsView = () => {
  return (
    <Box>
      <Text>POST VIEW</Text>
    </Box>
  );
};

export default PostsView;
