import {Box, Text} from '@src/ui_kit/atoms';
import React from 'react';
const DiscoveryView = () => {
  return (
    <Box>
      <Text>DISCOVERY VIEW</Text>
    </Box>
  );
};

export default DiscoveryView;
