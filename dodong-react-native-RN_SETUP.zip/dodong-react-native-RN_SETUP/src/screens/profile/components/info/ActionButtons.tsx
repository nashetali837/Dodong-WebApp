import {PROFILE_TYPE, ProfileCTAs} from '@src/constants/Enums';
import APP_ICON_NAMES from '@src/ui_kit/components/appIcons/iconNames';
import React from 'react';
import {useProfileContext} from '../../profileContext';
import {useNavigation} from '@react-navigation/native';
import {Box, Text} from '@src/ui_kit/atoms';
import {Pressable} from 'react-native';
import {theme} from '@src/ui_kit/theme';
import AppIcon from '@src/ui_kit/components/appIcons/AppIcon';
import {ScreensList} from '@src/routes/helpers';
const publicCTAs = [
  {name: ProfileCTAs.CONNECT, icon: APP_ICON_NAMES.Flash},
  {name: ProfileCTAs.MESSAGE, icon: APP_ICON_NAMES.Email},
];

const personalCTAs = [
  {name: ProfileCTAs.MESSAGE, icon: APP_ICON_NAMES.Email},
  {name: ProfileCTAs.EDIT_PROFILE, icon: APP_ICON_NAMES.Edit},
];

export const ActionButton = () => {
  const {type} = useProfileContext();
  const {navigate} = useNavigation();

  const _handlePress = (action: ProfileCTAs) => {
    switch (action) {
      case ProfileCTAs.EDIT_PROFILE:
        navigate(ScreensList.CompleteProfile);

        break;

      default:
        break;
    }
  };

  const Actions = type === PROFILE_TYPE.PERSONAL ? personalCTAs : publicCTAs;

  return (
    <Box
      mx={'_s24'}
      mt={'_s24'}
      flexDirection={'row'}
      justifyContent={'space-between'}>
      {Actions.map((action, index) => {
        return (
          <Pressable
            key={`action${index}`}
            onPress={() => _handlePress(action.name)}>
            <Box
              flexDirection={'row'}
              alignItems={'center'}
              bg={'white'}
              justifyContent={'center'}
              borderRadius={8}
              borderWidth={1}
              borderColor={'neutral100'}
              mx={'_s4'}
              py={'_s8'}
              width={theme.size.ONE_FIFTY}>
              <AppIcon name={action.icon} color={'transparent'} size={20} />
              <Text variant={'body2.semiBold.14'} ml={'_s8'}>
                {action.name}
              </Text>
            </Box>
          </Pressable>
        );
      })}
    </Box>
  );
};
