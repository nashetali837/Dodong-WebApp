import {AnimatedRing} from '@src/screens/splash/animated/centerCircle';
import {Box, Text} from '@src/ui_kit/atoms';
import {theme} from '@src/ui_kit/theme';
import React, {ReactElement} from 'react';
import {useSharedValue} from 'react-native-reanimated';
import {useSafeAreaInsets} from 'react-native-safe-area-context';
import {Pressable, StyleSheet} from 'react-native';
import {useProfileContext} from '../../profileContext';
import SelectProfileImage from '../selectProfileImage';
import {IS_IOS, dimensions, toTitleCase} from '@src/utilities/helpers';
import AppIcon from '@src/ui_kit/components/appIcons/AppIcon';
import APP_ICON_NAMES from '@src/ui_kit/components/appIcons/iconNames';
import {StatsInfo} from './StatsInfo';
import {PROFILE_TYPE} from '@src/constants/Enums';
import {useNavigation} from '@react-navigation/native';

const TOP_MARGIN = IS_IOS ? theme.size.SEVENTY_TWO : theme.size.TWENTY;

const Info = () => {
  const {
    userData: {profile},
    type,
  } = useProfileContext();
  const inset = useSafeAreaInsets();
  return (
    <Box>
      <CircleLayout>
        <Box style={{marginTop: inset.top}}>
          <Header displayName={profile?.displayName} type={type} />
          <StatsInfo profile={profile} type={type} />
        </Box>
      </CircleLayout>
    </Box>
  );
};
export default Info;

const CircleLayout = ({children}: {children: ReactElement}) => {
  const scaleXY = useSharedValue<number>(10);
  const {
    type,
    userData: {profile},
  } = useProfileContext();
  return (
    <Box>
      <Box>
        <AnimatedRing
          scaleXY={scaleXY}
          magnifier={0.05}
          customStyles={styles.customRingStyles}>
          <SelectProfileImage
            iconBoxSize={60}
            iconSize={40}
            isDisabled={type === PROFILE_TYPE.PUBLIC}
            externalUrl={profile?.avatar}
          />
        </AnimatedRing>
        <AnimatedRing
          scaleXY={scaleXY}
          magnifier={0.12}
          customStyles={styles.customRingStyles}
        />
        <AnimatedRing
          scaleXY={scaleXY}
          magnifier={0.25}
          customStyles={styles.customRingStyles}
        />
        <AnimatedRing
          scaleXY={scaleXY}
          magnifier={0.4}
          customStyles={styles.customRingStyles}
        />
      </Box>
      <Box position="absolute">{children}</Box>
    </Box>
  );
};

const Header = ({
  displayName = '',
  type,
}: {
  type: PROFILE_TYPE;
  displayName: string;
}) => {
  const {goBack} = useNavigation();
  const _handleOnBack = () => goBack();

  return (
    <>
      <Box
        px={'_s24'}
        py={'_s12'}
        flexDirection={'row'}
        alignItems="center"
        width={dimensions.screenWidth}>
        <Pressable onPress={_handleOnBack} style={{flex: 1}}>
          {type === PROFILE_TYPE.PUBLIC ? (
            <Box justifyContent="center" pt={'_s6'}>
              <AppIcon name={APP_ICON_NAMES.BackArrow} size={18} />
            </Box>
          ) : (
            <></>
          )}
        </Pressable>
        <Box flex={1.5} alignItems={'center'}>
          <Text variant={'body3.semiBold.18'} lineHeight={30} numberOfLines={1}>
            {toTitleCase(displayName)}
          </Text>
        </Box>
        <Box flex={1} alignItems={'flex-end'} justifyContent={'center'}>
          <AppIcon name={APP_ICON_NAMES.Menu} size={32} />
        </Box>
      </Box>
    </>
  );
};

const styles = StyleSheet.create({
  customRingStyles: {
    width: theme.size.ONE_SIXTY,
    height: theme.size.ONE_SIXTY,
    marginTop: TOP_MARGIN,
    left: -20,
    borderColor: theme.colors.neutral100,
    borderWidth: 0.4,
  },
});
