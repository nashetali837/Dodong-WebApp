import {TUserDataProfile} from '@src/redux/auth/type';
import {Box, Text} from '@src/ui_kit/atoms';
import React from 'react';
import {ActionButton} from './ActionButtons';
import ProfileCompleteNudge from '../profileCompleteNudge';
import ViewData from './viewData';
import {PROFILE_TYPE} from '@src/constants/Enums';
export const StatsInfo = ({
  profile,
  type,
}: {
  profile: TUserDataProfile;
  type: PROFILE_TYPE;
}) => {
  const Stats = [
    {name: 'Posts', value: profile?.totalPosts ?? 0},
    {name: 'Connects', value: profile?.followers ?? 0},
    {name: 'Connecting', value: profile?.following ?? 0},
  ];
  return (
    <Box mt={'_s28'}>
      <Box flexDirection={'row'}>
        <Box flex={3.5} />
        <Box
          flex={6.5}
          flexDirection="row"
          justifyContent="space-between"
          mr={'_s24'}>
          {Stats.map((stat, index) => (
            <Box
              key={`stat${index}`}
              justifyContent={'center'}
              alignItems={'center'}>
              <Text variant={'body3.semiBold.18'} lineHeight={24}>
                {stat.value}
              </Text>
              <Text color={'gray1'} variant={'body2.regular.14'}>
                {stat.name}
              </Text>
            </Box>
          ))}
        </Box>
      </Box>
      {profile?.bio ? (
        <Text
          mx={'_s24'}
          mt={'_s32'}
          variant={'body2.regular.14'}
          color={'gray1'}>
          {profile?.bio}
        </Text>
      ) : (
        <></>
      )}
      <ActionButton />
      {type === PROFILE_TYPE.PERSONAL ? <ProfileCompleteNudge /> : <></>}
      <ViewData />
    </Box>
  );
};
