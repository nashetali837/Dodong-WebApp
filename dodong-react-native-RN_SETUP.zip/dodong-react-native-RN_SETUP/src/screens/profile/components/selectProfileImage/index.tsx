import React from 'react';
import {Box} from '@atoms';
import AppIcon from '@components/appIcons/AppIcon';
import APP_ICON_NAMES from '@components/appIcons/iconNames';
import {theme} from '@theme';
import {Image, Pressable, StyleSheet} from 'react-native';
import {ISelectImage} from './type';
import useImageSelector from '@src/hooks/resourceHooks/useImageSelector';

const SelectProfileImage: React.FC<ISelectImage> = ({
  iconSize = 26,
  iconBoxSize = 44,
  containerStyles,
  isDisabled = false,
  externalUrl,
  onImagePicked,
}) => {
  const {currentAsset, handleOnImagePress} = useImageSelector({onImagePicked});

  const imageSource = currentAsset?.uri
    ? {uri: currentAsset.uri}
    : externalUrl
    ? {uri: externalUrl}
    : null;

  return (
    <Pressable disabled={isDisabled} onPress={handleOnImagePress}>
      <Box
        width={theme.size.ONE_FIFTY}
        height={theme.size.ONE_FIFTY}
        style={styles.container}
        bg={'neutral50'}>
        {imageSource ? (
          <Image
            source={imageSource}
            style={{width: null, height: null, flex: 1}}
          />
        ) : (
          <></>
        )}
      </Box>
      {isDisabled ? (
        <></>
      ) : (
        <Box
          position="absolute"
          bg={'orange500'}
          bottom={5}
          right={5}
          width={iconBoxSize}
          height={iconBoxSize}
          borderRadius={iconBoxSize / 2}
          justifyContent={'center'}
          alignItems={'center'}
          style={containerStyles}>
          <AppIcon
            name={APP_ICON_NAMES.Camera}
            size={iconSize}
            color={'transparent'}
          />
        </Box>
      )}
    </Pressable>
  );
};

export default SelectProfileImage;

const styles = StyleSheet.create({
  container: {
    shadowColor: 'rgba(17, 12, 34, 0.12)',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 1,
    shadowRadius: 4,
    elevation: 4,
    borderRadius: theme.size.ONE_FIFTY / 2,
    borderWidth: 4,
    borderColor: 'white',
    overflow: 'hidden',
  },
});
