import {StyleProp, ViewStyle} from 'react-native';

export type ImagePickerAsset = {
  fileName: string;
  height: number;
  fileSize?: number;
  type: string;
  uri: string;
  width: number;
};

interface ISelectImage {
  iconSize?: number;
  iconBoxSize?: number;
  containerStyles?: StyleProp<ViewStyle>;
  isDisabled?: boolean;
  externalUrl?: string;
  onImagePicked?: (imageAsset: ImageAsset) => void;
}
