import {useNavigation} from '@react-navigation/native';
import {ProfileCompletionSteps} from '@src/constants/Enums';
import useUserData from '@src/hooks/user/useUserData';
import {ScreensList} from '@src/routes/helpers';
import {Box, Text} from '@src/ui_kit/atoms';
import GradientButton from '@src/ui_kit/components/buttons/gradientButton';
import {theme} from '@src/ui_kit/theme';
import React, {useState} from 'react';
import {Pressable} from 'react-native';
const ProfileCompleteNudge = ({mx = '_s24', mb = '_s0', reverse = false}) => {
  const [siVisible, setIsVisible] = useState<boolean>(true);
  const navigation = useNavigation();
  const {userData} = useUserData();

  const _handlePress = () => setIsVisible(false);
  const handleOnCompletePress = () => {
    navigation.navigate(ScreensList.CompleteProfileLanding);
  };

  if (
    !siVisible ||
    userData?.profileCompletion?.percent === ProfileCompletionSteps.PERCENT
  ) {
    return <></>;
  }
  return (
    <Box
      borderColor={'neutral100'}
      bg={reverse ? 'orange500' : 'white'}
      mt={'_s24'}
      mx={mx}
      mb={mb}
      p={'_s20'}
      borderRadius={16}
      borderWidth={1}>
      <Box flexDirection="row">
        <Box flex={2.8}>
          <Box
            width={70}
            height={70}
            bg={'lightWhite'}
            borderRadius={40}
            justifyContent="center"
            alignItems="center">
            <Text variant={'body3.regular.18'} lineHeight={theme.size.THIRTY}>
              {userData?.profileCompletion?.percent}%
            </Text>
          </Box>
        </Box>
        <Box flex={7.2}>
          <Text
            variant={'body1.semiBold.24'}
            fontSize={20}
            color={reverse ? 'white' : 'gray2'}>
            Profile Information
          </Text>
          <Text
            color={reverse ? 'neutral10' : 'gray1'}
            variant={'body2.regular.14'}>
            Complete your profile to unlock all features
          </Text>
        </Box>
      </Box>
      <Box flexDirection="row" alignItems="center" mt={'_s16'}>
        <Box flex={7}>
          <GradientButton
            textProps={{
              variant: 'body2.semiBold.14',
            }}
            colors={reverse ? ['white', 'white'] : undefined}
            gradientStyles={{paddingVertical: 8}}
            containerStyles={{
              borderRadius: 8,
              backgroundColor: reverse ? 'white' : 'transparent',
            }}
            onPress={handleOnCompletePress}
            isOutlined
            text="Complete my profile "
          />
        </Box>
        <Box flex={3} alignItems={'flex-end'}>
          <Pressable onPress={_handlePress}>
            <Text
              variant={'body2.semiBold.14'}
              color={reverse ? 'white' : 'gray2'}>
              Dismiss
            </Text>
          </Pressable>
        </Box>
      </Box>
    </Box>
  );
};

export default ProfileCompleteNudge;
