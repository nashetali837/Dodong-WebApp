import React from 'react';
import {Box} from '@atoms';
import TextInput from '@components/customInputs/textInput';
import {theme} from '@theme';
import {ScrollView, StyleSheet} from 'react-native';
import AppIcon from '@components/appIcons/AppIcon';
import APP_ICON_NAMES from '@components/appIcons/iconNames';
import DatePicker from 'react-native-date-picker';
import {useState} from 'react';

const Personal = ({formik}) => {
  const [showDatePicker, setShowDatePicker] = useState<boolean>(false);
  const onDatePress = () => setShowDatePicker(true);

  return (
    <ScrollView
      showsVerticalScrollIndicator={false}
      contentContainerStyle={{paddingBottom: 150}}>
      <Box mt={'_s24'}>
        <TextInput
          headerText={'Name'}
          placeholder={'Enter your name'}
          onChangeText={(val: string) =>
            formik.handleChange({target: {name: 'name', value: val}})
          }
          value={formik.values.name}
          hasError={formik.errors.name && formik.touched.name}
        />
        <TextInput
          headerText={'Display Name'}
          placeholder={'Enter display name'}
          onChangeText={(val: string) =>
            formik.handleChange({target: {name: 'displayName', value: val}})
          }
          value={formik.values.displayName}
          hasError={formik.errors.displayName && formik.touched.displayName}
          containerWrapperStyle={styles.containerStyle}
        />
        <TextInput
          headerText={'Bio'}
          style={{height: 60}}
          textAlignVertical={'top'}
          multiline={true}
          placeholder={'Add a short bio'}
          onChangeText={(val: string) =>
            formik.handleChange({target: {name: 'bio', value: val}})
          }
          value={formik.values.bio}
          hasError={formik.errors.bio && formik.touched.bio}
          containerWrapperStyle={styles.containerStyle}
        />
        {/* <TextInput
          headerText={'Mobile Number'}
          placeholder={'Enter your mobile number'}
          onChangeText={(val: string) =>
            formik.handleChange({target: {name: 'personalNumber', value: val}})
          }
          value={formik.values.personalNumber}
          keyboardType={'number-pad'}
          hasError={
            formik.errors.personalNumber && formik.touched.personalNumber
          }
          containerWrapperStyle={styles.containerStyle}
          leftAccessory={
            <Text variant={'body3.regular.12'} mr={'_s10'}>
              +91
            </Text>
          }
        /> */}
        {/* <TextInput
          headerText={'Email Address'}
          placeholder={'Enter your email'}
          onChangeText={(val: string) =>
            formik.handleChange({target: {name: 'email', value: val}})
          }
          value={formik.values.email}
          hasError={formik.errors.email && formik.touched.email}
          containerWrapperStyle={styles.containerStyle}
        /> */}
        <TextInput
          headerText={'Occupation Type'}
          placeholder={'Manager'}
          onChangeText={(val: string) =>
            formik.handleChange({
              target: {name: 'occupation', value: val},
            })
          }
          value={formik.values.occupation}
          hasError={formik.errors.occupation && formik.touched.occupation}
          containerWrapperStyle={styles.containerStyle}
        />
        <TextInput
          headerText={'Date of Birth'}
          placeholder={'01/01/1990'}
          pressDisabled={false}
          onPress={onDatePress}
          value={formik.values.dateOfBirth}
          hasError={formik.errors.dateOfBirth && formik.touched.dateOfBirth}
          containerWrapperStyle={styles.containerStyle}
          editable={false}
          leftAccessory={
            <Box mr={'_s10'}>
              <AppIcon name={APP_ICON_NAMES.Calendar} color={'transparent'} />
            </Box>
          }
        />
        <DatePicker
          modal
          open={showDatePicker}
          mode={'date'}
          date={new Date(formik.values.dateOfBirth)}
          onConfirm={date => {
            setShowDatePicker(false);
            const pickedDate = new Date(date).toISOString().split('T')[0];
            console.log('date', date, pickedDate);
            formik.handleChange({
              target: {name: 'dateOfBirth', value: pickedDate},
            });
          }}
          onCancel={() => {
            setShowDatePicker(false);
          }}
        />
        {/* <TextInput
          headerText={'ID Details'}
          placeholder={'AXZEDR231424'}
          onChangeText={(val: string) =>
            formik.handleChange({
              target: {name: 'idDetails', value: val},
            })
          }
          value={formik.values.idDetails}
          hasError={formik.errors.idDetails && formik.touched.idDetails}
          containerWrapperStyle={styles.containerStyle}
        /> */}
        <TextInput
          headerText={'Facebook URL'}
          placeholder={'https://facebook.com/'}
          onChangeText={(val: string) =>
            formik.handleChange({
              target: {name: 'facebookURL', value: val},
            })
          }
          value={formik.values.facebookURL}
          hasError={formik.errors.facebookURL && formik.touched.facebookURL}
          containerWrapperStyle={styles.containerStyle}
        />
        <TextInput
          headerText={'LinkedIn URL'}
          placeholder={'https://linkedin.com/'}
          onChangeText={(val: string) =>
            formik.handleChange({
              target: {name: 'LinkedInURL', value: val},
            })
          }
          value={formik.values.LinkedInURL}
          hasError={formik.errors.LinkedInURL && formik.touched.LinkedInURL}
          containerWrapperStyle={styles.containerStyle}
        />
        <TextInput
          headerText={'Twitter URL'}
          placeholder={'https://twitter.com/'}
          onChangeText={(val: string) =>
            formik.handleChange({
              target: {name: 'twitterHandle', value: val},
            })
          }
          value={formik.values.twitterHandle}
          hasError={formik.errors.twitterHandle && formik.touched.twitterHandle}
          containerWrapperStyle={styles.containerStyle}
        />
      </Box>
    </ScrollView>
  );
};

export default Personal;

const styles = StyleSheet.create({
  containerStyle: {marginTop: theme.size.TWENTY_FOUR},
});
