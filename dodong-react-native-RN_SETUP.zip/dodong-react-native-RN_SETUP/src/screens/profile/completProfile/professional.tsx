import React from 'react';
import {Box, Text} from '@atoms';
import {ScrollView, StyleSheet} from 'react-native';
import TextInput from '@components/customInputs/textInput';
import {theme} from '@theme';
const Professional = ({formik}) => {
  return (
    <ScrollView
      showsVerticalScrollIndicator={false}
      contentContainerStyle={{paddingBottom: 150}}>
      <Box mt={'_s24'}>
        <TextInput
          headerText={'Occupation Type'}
          placeholder={'Manager'}
          onChangeText={(val: string) =>
            formik.handleChange({target: {name: 'occupation', value: val}})
          }
          value={formik.values.occupation}
          hasError={formik.errors.occupation && formik.touched.occupation}
        />
        <TextInput
          headerText={'Company Name'}
          placeholder={'Enter company name'}
          onChangeText={(val: string) =>
            formik.handleChange({target: {name: 'company', value: val}})
          }
          value={formik.values.company}
          hasError={formik.errors.company && formik.touched.company}
          containerWrapperStyle={styles.containerStyle}
        />
        <TextInput
          headerText={'Mobile Number'}
          placeholder={'Enter your mobile number'}
          maxLength={10}
          onChangeText={(val: string) =>
            formik.handleChange({
              target: {name: 'officialMobileNumber', value: val},
            })
          }
          value={formik.values.officialMobileNumber}
          keyboardType={'number-pad'}
          hasError={
            formik.errors.officialMobileNumber &&
            formik.touched.officialMobileNumber
          }
          containerWrapperStyle={styles.containerStyle}
          leftAccessory={
            <Text variant={'body3.regular.12'} mr={'_s10'}>
              +91
            </Text>
          }
        />
        <TextInput
          headerText={'Brand Details'}
          onChangeText={(val: string) =>
            formik.handleChange({target: {name: 'brandDetails', value: val}})
          }
          value={formik.values.brandDetails}
          hasError={formik.errors.brandDetails && formik.touched.brandDetails}
          containerWrapperStyle={styles.containerStyle}
        />
        <TextInput
          headerText={'Other'}
          onChangeText={(val: string) =>
            formik.handleChange({target: {name: 'others', value: val}})
          }
          value={formik.values.others}
          hasError={formik.errors.others && formik.touched.others}
          containerWrapperStyle={styles.containerStyle}
        />
      </Box>
    </ScrollView>
  );
};

export default Professional;

const styles = StyleSheet.create({
  containerStyle: {marginTop: theme.size.TWENTY_FOUR},
});
