import React, {useRef, useState} from 'react';
import {Box} from '@atoms';
import AppTopHeader from '@components/headers/appTopHeader';
import SelectProfileImage from '../components/selectProfileImage';
import DualTabs from '@components/dualTabs';
import Personal from './personal';
import Professional from './professional';
import GradientButton from '@components/buttons/gradientButton';
import {LOCALE} from '@constants/locale';
import {useSafeAreaInsets} from 'react-native-safe-area-context';
import {useFormik} from 'formik';
import {
  personalFormicValue,
  professionalFormicValue,
  personalScheme,
  professionalScheme,
} from './formicVal';
import {ScreensList} from '@src/routes/helpers';
import useUserData from '@src/hooks/user/useUserData';
import {objectToFormData} from '@src/utilities/helpers';

const tabs = [{name: 'Personal'}, {name: 'Professional'}];

const CompleteProfileScreen = ({...allProps}) => {
  const {
    navigation: {reset},
  } = allProps;

  const {
    userData,
    showLoader,
    updateUserProfile,
    updateUserProfessionalProfile,
    uploadUserProfileImage,
  } = useUserData();
  const avatarRef = useRef();
  const inset = useSafeAreaInsets();
  const [currentTab, setCurrentTab] = useState<tab>(tabs[0]);

  const _handleImagePicked = asset => {
    avatarRef.current = asset;
    console.log('avatarref', avatarRef);
  };

  const controllNavigation = () => {
    reset({
      index: 0,
      routes: [{name: ScreensList.Tabs}],
    });
  };

  const onUpdateSuccess = () => setCurrentTab(tabs[1]);

  const onPersonalSavePress = async () => {
    const dataSet = {
      ...personalFormik.values,
      userId: userData?.profile?.id,
    };

    if (avatarRef?.current?.uri) {
      const imgData = objectToFormData({
        name: avatarRef.current.fileName,
        type: avatarRef.current.type,
        uri: avatarRef.current.uri,
      });
      const imageRes = await uploadUserProfileImage(imgData); //@TODO : API NOT WORKING FOR IMAGE UPLOAD.
      dataSet.avatar = '';
    }
    updateUserProfile(dataSet, onUpdateSuccess);
  };

  const onProfessionalSavePress = () => {
    updateUserProfessionalProfile(professionalFormik.values);
    controllNavigation();
  };

  const personalFormik = useFormik({
    initialValues: personalFormicValue(userData?.profile),
    onSubmit: onPersonalSavePress,
    validationSchema: personalScheme,
  });

  const professionalFormik = useFormik({
    initialValues: professionalFormicValue(userData?.professional),
    onSubmit: onProfessionalSavePress,
    validationSchema: professionalScheme,
  });

  const _handleSave = () => {
    if (currentTab.name === tabs[0].name) {
      personalFormik.handleSubmit();
    } else {
      professionalFormik.handleSubmit();
    }
  };

  const handleTabChange = (tab: tab) => {
    setCurrentTab(tab);
  };

  const ViewComponent = {
    [tabs[0].name]: {
      Component: Personal,
      props: {formik: personalFormik},
    },
    [tabs[1].name]: {
      Component: Professional,
      props: {formik: professionalFormik},
    },
  };

  const {Component, props} = ViewComponent[currentTab.name];

  return (
    <Box bg={'white'} flex={1}>
      <AppTopHeader headerText={'Update Profile'}>
        <Box alignSelf="center" mb={'_s48'}>
          <SelectProfileImage onImagePicked={_handleImagePicked} />
        </Box>
      </AppTopHeader>
      <Box mx={'_s24'} flex={1}>
        <DualTabs
          tabs={tabs}
          onTabChange={handleTabChange}
          currentTab={currentTab}
        />
        <Component {...props} />
      </Box>
      <Box
        position="absolute"
        bg={'white'}
        width={'100%'}
        px={'_s24'}
        bottom={0}
        style={{paddingBottom: inset.bottom, paddingTop: 10}}>
        <GradientButton
          text={LOCALE.save}
          onPress={_handleSave}
          isLoading={showLoader}
        />
      </Box>
    </Box>
  );
};

export default CompleteProfileScreen;
