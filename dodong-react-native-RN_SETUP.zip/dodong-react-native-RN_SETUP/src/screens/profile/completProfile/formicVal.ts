import {TUserDataProfessional, TUserDataProfile} from '@src/redux/auth/type';
import * as Yup from 'yup';

export const personalScheme = Yup.object().shape({
  name: Yup.string().required('Required'),
  displayName: Yup.string().required('Required'),
});

export const professionalScheme = Yup.object().shape({
  occupation: Yup.string().required('Required'),
  officialMobileNumber: Yup.string().min(10).required('Required'),
});

const date = new Date().toISOString().split('T')[0];

export const personalFormicValue = (profile?: TUserDataProfile) => {
  return {
    name: profile?.name ?? '',
    displayName: profile?.displayName ?? '',
    // personalNumber: '',
    // email: '',
    dateOfBirth: date,
    occupation: profile?.occupation ?? '',
    // idDetails: '',
    facebookURL: profile?.facebookURL ?? '',
    LinkedInURL: profile?.LinkedInURL ?? '',
    twitterHandle: '',
    avatar: profile?.avatar ?? '',
    locationId: null,
    bio: profile?.bio ?? '',
  };
};

export const professionalFormicValue = (
  professional?: TUserDataProfessional,
) => {
  return {
    occupation: professional?.occupationType ?? '',
    company: professional?.companyName ?? '',
    officialMobileNumber: professional?.officialMobileNumber ?? '',
    brandDetails: professional?.brandDetails ?? '',
    others: professional?.others ?? '',
    jobLocation: professional?.jobLocation ?? '',
  };
};
