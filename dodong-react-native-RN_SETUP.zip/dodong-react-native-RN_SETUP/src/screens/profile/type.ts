import {PROFILE_TYPE} from '@src/constants/Enums';
import {TUserData} from '@src/redux/auth/type';

export interface IProfileView {
  type?: PROFILE_TYPE;
  userData?: TUserData;
}
