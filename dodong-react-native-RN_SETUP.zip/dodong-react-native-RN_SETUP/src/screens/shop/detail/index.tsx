import {Box, Text} from '@src/ui_kit/atoms';
import React from 'react';
const ShopDetailScreen = () => {
  return (
    <Box>
      <Text>Shop Detail Screen</Text>
    </Box>
  );
};

export default ShopDetailScreen;
