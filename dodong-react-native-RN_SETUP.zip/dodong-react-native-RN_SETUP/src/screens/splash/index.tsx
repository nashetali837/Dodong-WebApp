import React, {useState, useEffect} from 'react';

import Modal from 'react-native-modal';
import AnimatedSplash from './animated/animatedSplash';

const SplashScreen = ({showSplash = true}) => {
  const [isModalVisible, setIsModalVisible] = useState<boolean>(true);
  const [splashAnimateComplete, setSplashAnimateComplete] =
    useState<boolean>(false);

  useEffect(() => {
    if (!showSplash && splashAnimateComplete) {
      setIsModalVisible(false);
    }
  }, [splashAnimateComplete, showSplash]);

  return (
    <Modal
      isVisible={isModalVisible}
      statusBarTranslucent
      animationIn="fadeIn"
      animationOut={'fadeOut'}
      animationOutTiming={1}
      backdropColor="transparent"
      style={modalStyle}
      hideModalContentWhileAnimating
      backdropTransitionOutTiming={0}>
      <AnimatedSplash onLoadComplete={setSplashAnimateComplete} />
    </Modal>
  );
};

export default SplashScreen;

const modalStyle = {padding: 0, margin: 0};
