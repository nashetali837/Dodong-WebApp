import {ReactElement} from 'react';
import {SharedValue} from 'react-native-reanimated';
import {StyleProp, ViewStyle} from 'react-native/types';

interface ICenterCircle {
  scaleXY: SharedValue<number>;
}

interface IAnimatedRing extends ICenterCircle {
  magnifier?: number;
  customStyles?: StyleProp<ViewStyle>;
  children?: ReactElement;
}

interface IGradientCircle {
  translateX: SharedValue<number>;
  customStyle: StyleProp<ViewStyle>;
  isReverse?: boolean;
}

interface ITransitionCircle {
  transitionScaleXY: SharedValue<number>;
}
