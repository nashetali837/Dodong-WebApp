import {StyleSheet} from 'react-native';
import {theme} from '@theme';

export const circleWidth = theme.size.TWO_HUNDRED * 2;
export const circleRadius = circleWidth / 2;

export const styles = StyleSheet.create({
  yellowBox: {
    width: circleWidth,
    height: circleWidth,
    borderRadius: circleRadius,
    position: 'absolute',
    top: -circleRadius,
    right: -circleRadius,
  },
  blueBox: {
    width: circleWidth,
    height: circleWidth,
    borderRadius: circleRadius,
    position: 'absolute',
    bottom: -circleRadius,
    left: -circleRadius,
  },
  animatedRing: {
    width: theme.size.ONE_SIXTY,
    height: theme.size.ONE_SIXTY,
    backgroundColor: 'transparent',
    borderWidth: 0.24,
    borderColor: theme.colors.white20,
    position: 'absolute',
    borderRadius: theme.size.EIGHTY_TWO,
  },
  transitionCircle: {
    width: theme.size.ONE_SIXTY,
    height: theme.size.ONE_SIXTY,
    borderRadius: theme.size.EIGHTY_TWO,
    position: 'absolute',
    backgroundColor: 'red',
    justifyContent: 'center',
    alignItems: 'center',
    zIndex: 100,
  },
  innerTransitionCircle: {
    width: theme.size.ONE_SIXTY - 10,
    height: theme.size.ONE_SIXTY - 10,
    borderRadius: theme.size.EIGHTY_TWO,
    backgroundColor: theme.colors.black,
  },
});
