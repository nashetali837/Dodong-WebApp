import React from 'react';
import {Box} from '@src/ui_kit/atoms';
import {useAnimatedStyle} from 'react-native-reanimated';
import {styles} from '../styles';
import {AnimatedBox} from '@src/ui_kit/atoms/animated/helper';
import {Image} from 'react-native';
import {IAnimatedRing, ICenterCircle} from '../type';

const AppLogo = require('@assets/pngs/app_logo.png');

const CenterCircle: React.FC<ICenterCircle> = ({scaleXY}) => {
  return (
    <Box>
      <Box
        width={220}
        height={220}
        bg={'white20'}
        borderColor={'white'}
        borderWidth={0.24}
        justifyContent={'center'}
        alignItems="center"
        borderRadius={110}>
        <AnimatedRing scaleXY={scaleXY} />
        <AnimatedRing scaleXY={scaleXY} magnifier={0.5} />
        <AnimatedRing scaleXY={scaleXY} magnifier={0.3} />
        <Image source={AppLogo} />
      </Box>
    </Box>
  );
};

export default CenterCircle;

export const AnimatedRing: React.FC<IAnimatedRing> = ({
  scaleXY,
  magnifier = 1,
  customStyles,
  children,
}) => {
  const animatedStyle = useAnimatedStyle(() => {
    return {
      transform: [{scale: scaleXY.value * magnifier}],
    };
  });

  return (
    <>
      <AnimatedBox style={[styles.animatedRing, customStyles, animatedStyle]}>
        {children}
      </AnimatedBox>
    </>
  );
};
