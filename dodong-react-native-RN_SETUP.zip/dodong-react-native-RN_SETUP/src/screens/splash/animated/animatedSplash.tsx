import React from 'react';
import {AnimatedBox} from '@atoms/animated/helper';
import {
  Easing,
  runOnJS,
  useSharedValue,
  withDelay,
  withTiming,
} from 'react-native-reanimated';
import {useEffect} from 'react';
import {dimensions} from '@src/utilities/helpers';
import {styles, circleRadius} from '../styles';
import CenterCircle from './centerCircle';
import GradientCircle from './gradientCircle';
import TransitionCircle from './transitionCircle';
import {Box, Text} from '@atoms';
import {theme} from '@src/ui_kit/theme';
import {LOCALE} from '@src/constants/locale';

const circleTranslateDuration = 2000;
const bezierConfig = {
  controlPoint1: {x: 0.42, y: 0},
  controlPoint2: {x: 0.58, y: 1},
};
const easing = Easing.bezier(
  bezierConfig.controlPoint1.x,
  bezierConfig.controlPoint1.y,
  bezierConfig.controlPoint2.x,
  bezierConfig.controlPoint2.y,
);
const animationConfig = {
  duration: circleTranslateDuration,
  easing,
};

const AnimatedSplash = ({onLoadComplete}) => {
  const translateX = useSharedValue<number>(0);
  const scaleXY = useSharedValue<number>(0);
  const transitionScaleXY = useSharedValue<number>(0);

  const onAnimationEnd = () => {
    onLoadComplete(true);
  };

  // const startScreenTransition = () => {
  //   transitionScaleXY.value = withDelay(
  //     200,
  //     withTiming(6, animationConfig, () => runOnJS(onAnimationEnd)()),
  //   );
  // };

  const reverseAnimate = () => {
    translateX.value = withDelay(
      800,
      withTiming(-circleRadius / 2, animationConfig, () =>
        // runOnJS(startScreenTransition)(),
        runOnJS(onAnimationEnd)(),
      ),
    );
  };

  const startAnimation = () => {
    translateX.value = withDelay(
      200,
      withTiming(dimensions.width + circleRadius / 4, animationConfig, () =>
        runOnJS(reverseAnimate)(),
      ),
    );
    scaleXY.value = withDelay(200, withTiming(10, animationConfig));
  };

  useEffect(() => {
    startAnimation();
  }, []);

  return (
    <AnimatedBox
      bg={'black'}
      flex={1}
      justifyContent={'center'}
      alignItems={'center'}>
      <GradientCircle
        customStyle={styles.yellowBox}
        translateX={translateX}
        isReverse={true}
      />
      <CenterCircle scaleXY={scaleXY} />
      <TransitionCircle transitionScaleXY={transitionScaleXY} />
      <GradientCircle customStyle={styles.blueBox} translateX={translateX} />
      <Info />
    </AnimatedBox>
  );
};
export default AnimatedSplash;

const Info = () => {
  return (
    <Box position={'absolute'} bottom={theme.size.TWENTY}>
      <Text variant={'body2.regular.14'} color={'white'}>
        {LOCALE.copyright}
      </Text>
    </Box>
  );
};
