import React from 'react';
import {AnimatedBox} from '@src/ui_kit/atoms/animated/helper';
import {ITransitionCircle} from '../type';
import {useAnimatedStyle} from 'react-native-reanimated';
import {styles} from '../styles';

const TransitionCircle: React.FC<ITransitionCircle> = ({transitionScaleXY}) => {
  const animatedStyle = useAnimatedStyle(() => {
    return {
      transform: [{scale: transitionScaleXY.value}],
    };
  });

  return <AnimatedBox style={[styles.transitionCircle, animatedStyle]} />;
};

export default TransitionCircle;
