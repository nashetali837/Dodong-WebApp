import React from 'react';
import {useAnimatedStyle} from 'react-native-reanimated';
import {AnimatedBox} from '@src/ui_kit/atoms/animated/helper';
import {IGradientCircle} from '../type';
import {Image} from 'react-native';

const yellowEllipse = require('../../../assets/pngs/splash/orangeEllipse.png');
const blueEllipse = require('../../../assets/pngs/splash/blueEllipse.png');
const GradientCircle: React.FC<IGradientCircle> = ({
  translateX,
  customStyle,
  isReverse = false,
}) => {
  const animatedStyles = useAnimatedStyle(() => {
    return {
      transform: [
        {translateX: isReverse ? -translateX.value : translateX.value},
      ],
    };
  });
  return (
    <AnimatedBox style={[customStyle, animatedStyles]}>
      <Image
        source={isReverse ? yellowEllipse : blueEllipse}
        style={{width: null, height: null, flex: 1}}
      />
    </AnimatedBox>
  );
};

export default GradientCircle;
