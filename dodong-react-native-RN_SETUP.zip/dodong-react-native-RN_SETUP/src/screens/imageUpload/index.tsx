import {ScreensList} from '@src/routes/helpers';
import {Box} from '@src/ui_kit/atoms';
import AppIcon from '@src/ui_kit/components/appIcons/AppIcon';
import APP_ICON_NAMES from '@src/ui_kit/components/appIcons/iconNames';
import GradientButton from '@src/ui_kit/components/buttons/gradientButton';
import AppTopHeader from '@src/ui_kit/components/headers/appTopHeader';
import ImageSelector from '@src/ui_kit/widgets/imageSelector';
import React, {useRef} from 'react';
const ImageUpload = ({...props}) => {
  const {
    navigation: {navigate},
  } = props;

  const imageUrl = useRef('');

  const _onNextPress = () => {
    navigate(ScreensList.CreatePost, {imageUrl: imageUrl.current});
  };

  const _handleUploadSuccess = (image: string) => {
    console.log('image', image);
  };

  return (
    <Box bg={'white'} flex={1}>
      <AppTopHeader headerText={'Upload Image'} />
      <Box mx={'_s24'} mt={'_s16'}>
        <ImageSelector onUploadSuccess={_handleUploadSuccess} />
      </Box>
      <Box
        position="absolute"
        bottom={0}
        width={'100%'}
        p={'_s24'}
        pt={'_s16'}
        borderTopColor={'lightWhite'}
        borderWidth={1}>
        <GradientButton
          text="Next"
          onPress={_onNextPress}
          rightAccessory={
            <Box style={{transform: [{rotate: '180deg'}]}} ml={'_s10'}>
              <AppIcon name={APP_ICON_NAMES.BackArrow} color={'white'} />
            </Box>
          }
        />
      </Box>
    </Box>
  );
};

export default ImageUpload;
