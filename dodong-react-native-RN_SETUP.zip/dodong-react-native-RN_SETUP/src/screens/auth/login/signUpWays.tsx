import {Pressable} from 'react-native';
import React from 'react';
import {LOCALE} from '@src/constants/locale';
import {Box, Text} from '@src/ui_kit/atoms';
import GoogleAuth from '@src/ui_kit/components/auth/google';
import {useNavigation} from '@react-navigation/native';
import {ScreensList} from '@src/routes/helpers';
import {GoogleAuthType} from '@src/constants/Enums';

const SignUpWays = () => {
  const {navigate} = useNavigation();
  const onSignUpPress = () => {
    navigate(ScreensList.SignUp);
  };

  return (
    <Box alignItems={'center'} justifyContent={'center'} mt={'_s24'}>
      <Box flexDirection={'row'}>
        <Text color={'gray1'}>{LOCALE.dontAccount}</Text>
        <Pressable onPress={onSignUpPress}>
          <Text color={'orange'}>{'  ' + LOCALE.signUp}</Text>
        </Pressable>
      </Box>
      <Box my={'_s24'} alignItems={'center'}>
        <Box
          flexDirection={'row'}
          alignItems={'center'}
          justifyContent={'space-around'}>
          <Box width={50} height={0.5} bg={'gray1'} />
          <Text variant={'body2.regular.14'} color={'gray1'} mx={'_s16'}>
            Or Sign In With
          </Text>
          <Box width={50} height={0.5} bg={'gray1'} />
        </Box>
        <Box mt={'_s24'}>
          <GoogleAuth authType={GoogleAuthType.LOGIN} />
        </Box>
      </Box>
    </Box>
  );
};

export default SignUpWays;
