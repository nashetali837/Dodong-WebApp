import * as Yup from 'yup';

export const LoginVerificationScheme = Yup.object().shape({
  email: Yup.string().required('Required'),
  password: Yup.string().required('Required'),
});

// export const initialFormicValue = {
//   email: '',
//   password: '',
// };

export const initialFormicValue = {
  email: 'dev.rn.sukumar+8@gmail.com',
  password: 'test123',
};
