import React from 'react';
import {Box, Text} from '@atoms';
import AppTopHeader from '@components/headers/appTopHeader';
import Login from './login';
import SignUpWays from './signUpWays';
const LoginScreen = () => {
  return (
    <Box bg={'white'} flex={1}>
      <AppTopHeader headerText={'Sign In'}>
        <Box pt={'_s24'} pb={'_s14'}>
          <Text variant={'body1.semiBold.24'} lineHeight={34}>
            Hi, Welcome Back! 👋
          </Text>
        </Box>
      </AppTopHeader>
      <Box mx={'_s24'}>
        <Login />
        <SignUpWays />
      </Box>
    </Box>
  );
};

export default LoginScreen;
