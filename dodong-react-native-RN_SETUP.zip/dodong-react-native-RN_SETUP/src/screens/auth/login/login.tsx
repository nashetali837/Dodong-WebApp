import {LOCALE} from '@constants/locale';
import {Text} from '@atoms';
import GradientButton from '@components/buttons/gradientButton';
import React, {useState} from 'react';
import TextInput from '@components/customInputs/textInput';
import {theme} from '@theme';
import {useFormik} from 'formik';
import {initialFormicValue, LoginVerificationScheme} from './formicVal';
import {ScreensList} from '@src/routes/helpers';
import {useNavigation} from '@react-navigation/native';
import {AuthThunk} from '@src/redux';
import {useDispatch} from 'react-redux';
import Toast from 'react-native-simple-toast';
import AppIcon from '@src/ui_kit/components/appIcons/AppIcon';
import APP_ICON_NAMES from '@src/ui_kit/components/appIcons/iconNames';
import {Pressable} from 'react-native';
import useUserData from '@src/hooks/user/useUserData';

const Login = () => {
  const [loading, setLoading] = useState<boolean>(false);
  const {reset} = useNavigation();
  const dispatch = useDispatch();
  const {fetchUserData} = useUserData();
  const [secureEntry, setSecureEntry] = useState<boolean>(true);

  const _handleOnEyeHide = () => setSecureEntry(prev => !prev);

  const onLoginPress = async () => {
    setLoading(true);
    try {
      const response = await dispatch(AuthThunk.getAuthToken(formik.values));
      if (response?.payload?.token) {
        fetchUserData(response.payload.token, resetNavigation);
      } else {
        Toast.show('Invalid Credentials', Toast.LONG);
      }
    } catch (error) {
      Toast.show('Oops something went wrong', Toast.LONG);
    }
    setLoading(false);
  };

  const resetNavigation = () => {
    reset({
      index: 0,
      routes: [{name: ScreensList.Tabs}],
    });
  };

  const formik = useFormik({
    initialValues: initialFormicValue,
    onSubmit: onLoginPress,
    validationSchema: LoginVerificationScheme,
  });

  return (
    <>
      <Text variant={'body1.regular.16'} mb={'_s42'}>
        Welcome back, you've been missed!
      </Text>
      <TextInput
        headerText={'Email Address'}
        placeholder={'Enter email address'}
        onChangeText={(val: string) =>
          formik.handleChange({target: {name: 'email', value: val}})
        }
        value={formik.values.email}
        keyboardType={'email-address'}
        hasError={formik.errors.email && formik.touched.email}
      />
      <TextInput
        headerText={'Password'}
        secureTextEntry={secureEntry}
        containerWrapperStyle={{marginTop: theme.size.TWENTY_FOUR}}
        placeholder={'Enter your password'}
        onChangeText={(val: string) =>
          formik.handleChange({target: {name: 'password', value: val}})
        }
        rightAccessory={
          <Pressable onPress={_handleOnEyeHide}>
            <AppIcon name={APP_ICON_NAMES.EyeHide} />
          </Pressable>
        }
        value={formik.values.password}
        hasError={formik.errors.password && formik.touched.password}
      />
      <GradientButton
        text={LOCALE.Login}
        onPress={formik.handleSubmit}
        containerStyles={{marginTop: theme.size.THIRTY_TWO}}
        isLoading={loading}
      />
    </>
  );
};

export default Login;
