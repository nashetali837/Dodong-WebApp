import React from 'react';
import {Box, Text} from '@src/ui_kit/atoms';
import {ImageBackground, Pressable} from 'react-native';
import {dimensions} from '@src/utilities/helpers';
import {theme} from '@src/ui_kit/theme';
import GradientButton from '@src/ui_kit/components/buttons/gradientButton';
import {LOCALE} from '@src/constants/locale';
import {ScreensList} from '@src/routes/helpers';

const AuthLandingImage = require('@assets/pngs/auth/authLanding.png');
const AuthLandingScreen = ({...props}) => {
  const {navigate} = props.navigation;

  const onSignInPress = () => {
    navigate(ScreensList.LogIn);
  };

  const onSignupPress = () => {
    navigate(ScreensList.SignUp);
  };

  return (
    <Box>
      <ImageBackground
        source={AuthLandingImage}
        style={{
          width: dimensions.screenWidth,
          height: dimensions.screenHeight,
        }}>
        <Box
          position={'absolute'}
          bottom={0}
          height={theme.size.TWO_HUNDRED}
          pb={'_s40'}
          justifyContent="center"
          alignItems="center"
          width={'100%'}>
          <Text
            variant={'body1.semiBold.24'}
            textAlign={'center'}
            maxWidth={320}
            lineHeight={28}
            color={'white'}>
            {LOCALE.buyProductOnline}
          </Text>
          <Box mx={'_s24'} my={'_s32'}>
            <GradientButton text={LOCALE.SignUpFree} onPress={onSignupPress} />
          </Box>
          <Box flexDirection={'row'}>
            <Text variant={'body3.regular.18'} lineHeight={22} color={'gray1'}>
              {LOCALE.alreadyAccount}
            </Text>
            <Pressable onPress={onSignInPress}>
              <Text
                lineHeight={22}
                variant={'body3.regular.18'}
                color={'white'}>
                {'  ' + LOCALE.signIn}
              </Text>
            </Pressable>
          </Box>
        </Box>
      </ImageBackground>
    </Box>
  );
};
export default AuthLandingScreen;
