import * as Yup from 'yup';

export const SignUpVerificationScheme = Yup.object().shape({
  name: Yup.string().required('Required'),
  email: Yup.string().required('Required'),
  mobileNumber: Yup.string().min(10, 'Too Short!').required('Required'),
  password: Yup.string().required('Required'),
});

// export const initialFormicValue = {
//   name: '',
//   email: '',
//   mobileNumber: '',
//   password: '',
// };

export const initialFormicValue = {
  name: 'Sukumar',
  email: 'dev.rn.sukumar+test@gmail.com',
  mobileNumber: '1234567890',
  password: 'test123',
};
