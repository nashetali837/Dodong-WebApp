import React from 'react';
import {Box, Text} from '@src/ui_kit/atoms';
import GoogleAuth from '@src/ui_kit/components/auth/google';
import {GoogleAuthType} from '@src/constants/Enums';

const SignUpWays = () => {
  return (
    <Box alignItems={'center'} justifyContent={'center'} mt={'_s24'}>
      <Box
        flexDirection={'row'}
        alignItems={'center'}
        justifyContent={'space-around'}>
        <Box width={50} height={0.5} bg={'gray1'} />
        <Text variant={'body2.regular.14'} color={'gray1'} mx={'_s16'}>
          Or Sign Up With
        </Text>
        <Box width={50} height={0.5} bg={'gray1'} />
      </Box>
      <Box mt={'_s24'}>
        <GoogleAuth authType={GoogleAuthType.SIGNUP} />
      </Box>
    </Box>
  );
};

export default SignUpWays;
