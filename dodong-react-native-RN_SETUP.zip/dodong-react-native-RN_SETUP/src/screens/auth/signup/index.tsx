import React from 'react';
import {Box, Text} from '@src/ui_kit/atoms';
import AppTopHeader from '@src/ui_kit/components/headers/appTopHeader';
import SignInWays from './signInWays';
import SignUp from './signup';
import {ScrollView} from 'react-native';
const SignUpScreen = () => {
  return (
    <Box bg={'white'} flex={1}>
      <AppTopHeader headerText={'Sign Up'}>
        <Box pt={'_s24'} pb={'_s14'}>
          <Text variant={'body1.semiBold.24'} lineHeight={34}>
            Welcome to DoDong
          </Text>
        </Box>
      </AppTopHeader>
      <ScrollView
        showsVerticalScrollIndicator={false}
        contentContainerStyle={{paddingBottom: 100}}>
        <Box mx={'_s24'}>
          <SignUp />
          <SignInWays />
        </Box>
      </ScrollView>
    </Box>
  );
};

export default SignUpScreen;
