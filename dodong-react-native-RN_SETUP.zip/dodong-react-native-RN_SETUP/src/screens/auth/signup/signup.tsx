import {LOCALE} from '@src/constants/locale';
import {Text} from '@src/ui_kit/atoms';
import GradientButton from '@src/ui_kit/components/buttons/gradientButton';
import React from 'react';
import TextInput from '@src/ui_kit/components/customInputs/textInput';
import {theme} from '@src/ui_kit/theme';
import {useFormik} from 'formik';
import {initialFormicValue, SignUpVerificationScheme} from './formicVal';
import {useNavigation} from '@react-navigation/native';
import {ScreensList} from '@src/routes/helpers';
import authService from '@src/core/api/services/AuthService';
import {useState} from 'react';
import Toast from 'react-native-simple-toast';
import CustomCheckBox from '@src/ui_kit/components/checkbox';
import config from '@src/config';
import {Pressable} from 'react-native';
import AppIcon from '@src/ui_kit/components/appIcons/AppIcon';
import APP_ICON_NAMES from '@src/ui_kit/components/appIcons/iconNames';

const webViewParams = {
  headerText: 'Terms and Conditions',
  sourceUrl: config.webUrls.termsNCond,
};

const SignUp = () => {
  const {navigate} = useNavigation();
  const [loading, setLoading] = useState<boolean>(false);
  const [secureEntry, setSecureEntry] = useState<boolean>(true);

  const _handleOnEyeHide = () => setSecureEntry(prev => !prev);

  const _handleOnTermsPress = () => {
    navigate(ScreensList.GenericWebView, webViewParams);
  };

  const onSignUpPress = async () => {
    setLoading(true);
    try {
      const response = await authService.getEmailVerified(formik.values);
      if (response?.data?.data) {
        if (response?.data?.data?.alreadyUser) {
          Toast.show(response?.data?.message, Toast.LONG);
        } else {
          navigate(ScreensList.VerifyOtp, {data: formik.values});
        }
      }
      setLoading(false);
    } catch (error) {
      setLoading(false);
      Toast.show('Oops something went wromg', Toast.LONG);
    }
  };

  const formik = useFormik({
    initialValues: initialFormicValue,
    onSubmit: onSignUpPress,
    validationSchema: SignUpVerificationScheme,
  });

  return (
    <>
      <Text variant={'body1.regular.16'} mb={'_s42'}>
        Let's create your account first
      </Text>

      <TextInput
        headerText={'Full Name'}
        placeholder={'Enter full name'}
        onChangeText={(val: string) =>
          formik.handleChange({target: {name: 'name', value: val}})
        }
        value={formik.values.name}
        hasError={formik.errors.name && formik.touched.name}
      />

      <TextInput
        headerText={'Email Address'}
        placeholder={'Enter email address'}
        autoCapitalize={'none'}
        containerWrapperStyle={{marginTop: theme.size.TWENTY_FOUR}}
        onChangeText={(val: string) =>
          formik.handleChange({target: {name: 'email', value: val}})
        }
        value={formik.values.email}
        keyboardType={'email-address'}
        hasError={formik.errors.email && formik.touched.email}
      />

      <TextInput
        headerText={'Mobile Number'}
        containerWrapperStyle={{marginTop: theme.size.TWENTY_FOUR}}
        placeholder={'Enter your mobile number'}
        maxLength={10}
        onChangeText={(val: string) =>
          formik.handleChange({target: {name: 'mobileNumber', value: val}})
        }
        value={formik.values.mobileNumber}
        hasError={formik.errors.mobileNumber && formik.touched.mobileNumber}
      />

      <TextInput
        headerText={'Password'}
        containerWrapperStyle={{marginTop: theme.size.TWENTY_FOUR}}
        placeholder={'Enter your password'}
        onChangeText={(val: string) =>
          formik.handleChange({target: {name: 'password', value: val}})
        }
        value={formik.values.password}
        rightAccessory={
          <Pressable onPress={_handleOnEyeHide}>
            <AppIcon name={APP_ICON_NAMES.EyeHide} />
          </Pressable>
        }
        secureTextEntry={secureEntry}
        hasError={formik.errors.password && formik.touched.password}
      />
      <CustomCheckBox
        text={LOCALE.agreeToTerms}
        boxProps={{mt: '_s18'}}
        isChecked={true}
        isDisabled={true}
        onPress={_handleOnTermsPress}
      />
      <GradientButton
        text={LOCALE.createAccount}
        onPress={formik.handleSubmit}
        isLoading={loading}
        containerStyles={{marginTop: theme.size.THIRTY_TWO}}
      />
    </>
  );
};

export default SignUp;
