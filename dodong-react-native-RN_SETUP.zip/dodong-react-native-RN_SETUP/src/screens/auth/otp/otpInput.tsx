import React, {useState} from 'react';
import {Text} from '@atoms';
import GradientButton from '@components/buttons/gradientButton';
import {theme} from '@theme';
import {LOCALE} from '@constants/locale';
import OTPTextView from 'react-native-otp-textinput';
import {StyleSheet} from 'react-native';
import CountDownTimer from './countDown';
import {useNavigation, useRoute} from '@react-navigation/native';
import {ScreensList} from '@src/routes/helpers';
import authService from '@src/core/api/services/AuthService';
import Toast from 'react-native-simple-toast';
import useUserData from '@src/hooks/user/useUserData';
const OtpInput = ({}) => {
  const route = useRoute();
  const {reset} = useNavigation();
  const {getUserRegistered} = useUserData();
  const formicVal = route?.params?.data ?? {};
  const {email = ''} = formicVal;

  const [otp, setOtp] = useState<string>(0);
  const [loader, setLoader] = useState<boolean>(false);

  const onVerify = async () => {
    setLoader(true);
    try {
      const otpVerifyResp = await authService.verifyEmailOtp({email, OTP: otp});
      const temporaryToken = otpVerifyResp?.data?.data?.temporaryToken;
      if (temporaryToken?.length) {
        getUserRegistered(formicVal, temporaryToken, resetNavigation);
      } else {
        Toast.show(resp?.data?.message, Toast.LONG);
        setLoader(false);
      }
    } catch (error) {
      Toast.show('Oops something went wrong', Toast.LONG);
      setLoader(false);
    }
  };

  const resetNavigation = () => {
    setLoader(false);
    reset({
      index: 0,
      routes: [{name: ScreensList.ManualLocation}],
    });
  };

  const handleOnComplete = async () => {
    await authService.getEmailVerified(formicVal);
  };

  return (
    <>
      <Text variant={'body1.regular.16'} mb={'_s42'}>
        We've send verification code to {email}
      </Text>

      <OTPTextView
        textInputStyle={styles.roundedTextInput}
        handleTextChange={(text: string) => {
          if (text.length === 4) {
            setOtp(text);
          }
        }}
        inputCount={4}
        keyboardType="numeric"
        autoFocus
      />

      <GradientButton
        text={LOCALE.verifyAccount}
        onPress={onVerify}
        isLoading={loader}
        containerStyles={{marginTop: theme.size.THIRTY_TWO}}
      />
      <Text
        color={'gray1'}
        variant={'body3.regular.12'}
        textAlign={'center'}
        mt={'_s32'}>
        Didn't receive it?
      </Text>
      <CountDownTimer onComplete={handleOnComplete} />
    </>
  );
};

export default OtpInput;

const styles = StyleSheet.create({
  roundedTextInput: {
    borderRadius: 10,
    borderWidth: 1,
    borderColor: theme.colors.gray2,
  },
});
