import React, {useEffect, useState} from 'react';
import {Text} from '@atoms';
import {Pressable} from 'react-native';

const CountDownTimer = ({onComplete}) => {
  const [count, setCount] = useState<number>(60);
  let timer: NodeJS.Timeout | null = null;

  const handlePress = () => {
    onComplete?.();
    setCount(60);
    callTimer();
  };

  const callTimer = () => {
    timer = setInterval(() => {
      setCount(prevCount => {
        if (prevCount === 0) {
          timer && clearInterval(timer);
          return prevCount;
        }
        return prevCount - 1;
      });
    }, 1000);
  };

  useEffect(() => {
    callTimer();
    return () => {
      timer && clearInterval(timer);
    };
  }, []);

  if (count === 0) {
    return (
      <Pressable onPress={handlePress}>
        <Text
          color={'orange500'}
          textAlign="center"
          variant={'body3.semiBold.12'}
          textDecorationLine={'underline'}
          mt={'_s8'}>
          Resend OTP
        </Text>
      </Pressable>
    );
  }

  return (
    <Text
      color={'textBlack'}
      variant={'body3.regular.12'}
      textAlign={'center'}
      mt={'_s8'}>
      Request new code in {count === 60 ? count : '00 : ' + count}
    </Text>
  );
};

export default CountDownTimer;
