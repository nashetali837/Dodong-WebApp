import React from 'react';
import {Box, Text} from '@atoms';
import AppTopHeader from '@components/headers/appTopHeader';
import OtpInput from './otpInput';
const VerifyOtpScreen = () => {
  return (
    <Box bg={'white'} flex={1}>
      <AppTopHeader headerText={'OTP Verification'}>
        <Box pt={'_s24'} pb={'_s14'}>
          <Text variant={'body1.semiBold.24'} lineHeight={34}>
            Verify Your Account
          </Text>
        </Box>
      </AppTopHeader>
      <Box mx={'_s24'}>
        <OtpInput />
      </Box>
    </Box>
  );
};

export default VerifyOtpScreen;
