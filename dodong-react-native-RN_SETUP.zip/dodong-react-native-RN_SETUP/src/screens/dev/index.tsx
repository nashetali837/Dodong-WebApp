import {Box, Text} from '@src/ui_kit/atoms';
import {Pressable} from 'react-native';
import React from 'react';
import {resetStore} from '@src/redux/reset';
import {useDispatch} from 'react-redux';
import {ScreensList} from '@src/routes/helpers';
import {useNavigation} from '@react-navigation/native';
import {isTestingEnv} from '@src/utilities/helpers';
import AsyncStorage from '@react-native-async-storage/async-storage';
import appContstants from '@src/core/api/appContstants';

const DevWrapper = ({children}) => {
  const navigation = useNavigation();
  const dispatch = useDispatch();
  const handleResetStore = async () => {
    navigation.navigate(ScreensList.Onboarding);
    await AsyncStorage.removeItem(appContstants.token);
    dispatch(resetStore());
  };

  return (
    <Box flex={1}>
      {isTestingEnv() ? (
        <Box
          position="absolute"
          top={600}
          left={5}
          borderRadius={5}
          borderColor={'red'}
          borderWidth={1}
          zIndex={9999}
          p="_s6"
          py={'_s3'}>
          <Pressable onPress={handleResetStore}>
            <Text variant={'body3.semiBold.12'} color={'red'}>
              Dev Control
            </Text>
          </Pressable>
        </Box>
      ) : (
        <></>
      )}
      {children}
    </Box>
  );
};

export default DevWrapper;
