import {Box} from '@src/ui_kit/atoms';
import Comment from '@src/ui_kit/widgets/comment';
import React from 'react';

const Comments = ({commentList}) => {
  console.log('commentList', commentList);

  if (!commentList.length) {
    return <></>;
  }

  return (
    <Box px={'_s24'}>
      {commentList.map((comment, idx) => (
        <Box key={`comment${idx}`} mb={'_s8'}>
          <Comment comment={comment} />
        </Box>
      ))}
    </Box>
  );
};

export default Comments;
