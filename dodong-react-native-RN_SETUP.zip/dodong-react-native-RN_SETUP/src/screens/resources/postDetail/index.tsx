import {Box} from '@src/ui_kit/atoms';
import React from 'react';
import {useResourceDetails} from '../../../hooks/resourceHooks/useResourceDetails';
import CommentInput from '@src/ui_kit/widgets/commentInput';
import {ActivityIndicator, ScrollView} from 'react-native';
import Comments from './comments';
import {useSafeAreaInsets} from 'react-native-safe-area-context';
import UserInfoUI from '@src/ui_kit/widgets/userInfo';
import ImageGallery from '@src/ui_kit/components/imageGallery';
import Info from './info';
import {dimensions, extractImageArray} from '@src/utilities/helpers';
const PostDetailScreen = ({...props}) => {
  const {postId = ''} = props?.route?.params ?? {};

  const {resourceDetails, onCommentSubmit, commentList, addCommentLoad} =
    useResourceDetails({
      resourceId: postId,
    });
  const inset = useSafeAreaInsets();

  const galleryImages = extractImageArray(resourceDetails?.mediaURLs ?? []);

  if (!resourceDetails) {
    return <ActivityIndicator size={'small'} color={'orange500'} />;
  }

  return (
    <Box flex={1} style={{paddingTop: inset.top}}>
      <Box flex={9}>
        <Box py={'_s8'}>
          <UserInfoUI author={resourceDetails?.author} showBackButton />
        </Box>
        <ScrollView showsVerticalScrollIndicator={false}>
          <ImageGallery
            images={galleryImages}
            imageContainerStyles={{width: dimensions.screenWidth}}
          />
          <Info resourceDetails={resourceDetails} />
          <Comments commentList={commentList} />
        </ScrollView>
      </Box>
      <Box
        flex={1}
        borderTopColor={'lightWhite'}
        borderTopWidth={1}
        p={'_s24'}
        pt={'_s12'}>
        <CommentInput callback={onCommentSubmit} isLoading={addCommentLoad} />
      </Box>
    </Box>
  );
};

export default PostDetailScreen;
