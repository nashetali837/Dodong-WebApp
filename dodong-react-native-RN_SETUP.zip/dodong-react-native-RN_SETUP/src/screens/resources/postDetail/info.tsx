import {useNavigation} from '@react-navigation/native';
import {SHORT_ACTIONS} from '@src/constants/Enums';
import {TResourceDetail} from '@src/core/api/services/schema.type';
import {ScreensList} from '@src/routes/helpers';
import {Box, Text} from '@src/ui_kit/atoms';
import AppIcon from '@src/ui_kit/components/appIcons/AppIcon';
import APP_ICON_NAMES from '@src/ui_kit/components/appIcons/iconNames';
import {theme} from '@src/ui_kit/theme';
import React from 'react';
import {Pressable, StyleSheet} from 'react-native';
import LinearGradient from 'react-native-linear-gradient';

const ClickActions = [
  {name: SHORT_ACTIONS.LIKE, icon: APP_ICON_NAMES.Liked},
  {name: SHORT_ACTIONS.COMMENT, icon: APP_ICON_NAMES.Comment},
  {name: SHORT_ACTIONS.SHARE, icon: APP_ICON_NAMES.Share},
];

const Info = ({resourceDetails}: {resourceDetails: TResourceDetail}) => {
  const {navigate} = useNavigation();
  const {resourceDetails: details, stats} = resourceDetails;
  console.log('resourceDetails', resourceDetails);

  const _handleShopPress = () => {
    navigate(ScreensList.ShopDetail, {
      shopId: resourceDetails?.shop?.shopID ?? null,
    });
  };

  const getText = (action: SHORT_ACTIONS) => {
    if (action === SHORT_ACTIONS.LIKE) {
      return stats.likes;
    }
    if (action === SHORT_ACTIONS.COMMENT) {
      return stats.comments;
    }
    if (action === SHORT_ACTIONS.SHARE) {
      return stats.shares;
    }
    return '';
  };

  return (
    <Box pb={'_s16'}>
      <Box py={'_s4'}>
        <LinearGradient
          colors={[theme.colors.orange, theme.colors.orange]}
          style={styles.gradient}>
          <Text color={'white'} variant={'body2.semiBold.14'}>
            ₹ 500{' '}
            <Text
              variant={'body2.regular.14'}
              color={'white'}
              textDecorationLine="line-through">
              {' '}
              800{' '}
            </Text>
          </Text>
          <Pressable onPress={_handleShopPress}>
            <Box flexDirection="row" alignItems="center">
              <Text variant={'body2.semiBold.14'} color={'white'} mr={'_s8'}>
                Shop
              </Text>
              <AppIcon
                name={APP_ICON_NAMES.ShortArrow}
                size={12}
                color="white"
              />
            </Box>
          </Pressable>
        </LinearGradient>
      </Box>
      <Box px={'_s24'}>
        <Box flexDirection="row" py={'_s16'}>
          {ClickActions.map((action, index) => {
            return (
              <Box
                key={index}
                mr={'_s32'}
                flexDirection="row"
                alignItems="center">
                <AppIcon name={action.icon} size={20} />
                <Text variant={'body2.regular.14'} ml={'_s6'}>
                  {getText(action.name)}
                </Text>
              </Box>
            );
          })}
        </Box>
        <Text color={'gray2'} variant={'body2.regular.14'}>
          {details?.body}
        </Text>
      </Box>
    </Box>
  );
};
export default Info;

const styles = StyleSheet.create({
  gradient: {
    justifyContent: 'space-between',
    alignItems: 'center',
    flexDirection: 'row',
    paddingHorizontal: 16,
  },
});
