import React from 'react';
import {Box} from '@atoms';
import AppTopHeader from '@components/headers/appTopHeader';

import CurrentLocation from './currentLocation';
import {ScreensList} from '@src/routes/helpers';
import SearchedLocations from './searchedLocations';
import SearchAutoComplete from './searchAutoComplete';
import {TLocation} from './type';
import {extractCountryAndCityFromAddress} from '@src/utilities/locationHelper';
import locationService from '@src/core/api/services/LocationService';
import useUserData from '@src/hooks/user/useUserData';
import {ScrollView} from 'react-native';
import {useDispatch} from 'react-redux';
import {AppSlice} from '@src/redux';

const ManualLocationScreen = ({...props}) => {
  const {token} = useUserData();
  const dispatch = useDispatch();
  const willRouteBack = props?.route?.params?.willRouteBack ?? false;

  const {
    navigation: {navigate, goBack},
  } = props;
  const onLocationSelect = (location: TLocation) => {
    const {state = '', country = ''} = extractCountryAndCityFromAddress(
      location?.address_components ?? [],
    );
    const locationData = {
      country,
      state,
      latitude: location?.geometry?.location?.lat ?? null,
      longitude: location?.geometry?.location?.lng ?? null,
      name: location?.formatted_address ?? '',
    };
    dispatch(AppSlice.actions.setUserCurrentLocation(location));
    locationService.updateUserLocation(token, locationData);
    if (willRouteBack) {
      goBack();
    } else {
      onCreateProfile();
    }
  };

  const onCreateProfile = () => navigate(ScreensList.CompleteProfileLanding);

  return (
    <Box bg={'white'} flex={1}>
      <AppTopHeader headerText={'Select Location'}>
        <Box pb={'_s32'}>
          <SearchAutoComplete onSelect={onLocationSelect} />
        </Box>
      </AppTopHeader>
      <ScrollView>
        <CurrentLocation onSelect={onLocationSelect} />
        <SearchedLocations onSelect={onLocationSelect} />
      </ScrollView>
    </Box>
  );
};

export default ManualLocationScreen;
