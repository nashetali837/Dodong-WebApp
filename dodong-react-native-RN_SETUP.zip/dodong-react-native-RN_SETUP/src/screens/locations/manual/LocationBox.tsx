import {Box, Text} from '@src/ui_kit/atoms';
import AppIcon from '@src/ui_kit/components/appIcons/AppIcon';
import APP_ICON_NAMES from '@src/ui_kit/components/appIcons/iconNames';
import {theme} from '@src/ui_kit/theme';
import React from 'react';
import {Pressable} from 'react-native';

export const LocationBox = ({location, header, onPress}) => {
  const _handlePress = () => onPress(location);
  return (
    <Pressable onPress={_handlePress}>
      <Box
        flexDirection={'row'}
        alignItems={'center'}
        borderBottomWidth={0.5}
        pb={'_s16'}
        borderBottomColor={'lightWhite'}>
        <AppIcon
          name={APP_ICON_NAMES.LocationOutline}
          color={theme.colors.orange500}
          size={20}
        />
        <Box ml={'_s10'}>
          <Text variant={'body2.semiBold.14'} lineHeight={24}>
            {header}
          </Text>
          <Text variant={'body3.regular.12'} color={'gray1'}>
            {location?.formatted_address ?? ''}
          </Text>
        </Box>
      </Box>
    </Pressable>
  );
};
