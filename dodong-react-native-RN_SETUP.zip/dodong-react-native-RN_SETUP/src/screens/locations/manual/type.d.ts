export type TLocation = {
  formatted_address: string;
  geometry: {
    location: {
      lat: number | null;
      lng: number | null;
    };
  };
  place_id: string;
  vicinity: string;
  address_components: TAddressComponent[];
};

export type TAddressComponent = {
  long_name: string;
  short_name: string;
  types: string[];
};

export type TAddressInfo = {
  country?: string;
  city?: string;
  state?: string;
};
