import React, {useState} from 'react';
import {Box, Text} from '@atoms';
import AppIcon from '@components/appIcons/AppIcon';
import APP_ICON_NAMES from '@components/appIcons/iconNames';
import {ActivityIndicator, Pressable} from 'react-native';
import Toast from 'react-native-simple-toast';
import {getLocationAndAddress} from '@src/utilities/locationHelper';
import {LocationBox} from './LocationBox';
import {theme} from '@src/ui_kit/theme';
import {TLocation} from './type';
const CurrentLocation = ({onSelect}) => {
  const [currentLocation, setCurrentLocation] = useState<TLocation[]>([]);
  const [loading, setLoading] = useState<boolean>(false);

  const handleCurrentLocation = () => {
    setLoading(true);
    getLocationAndAddress()
      .then(data => {
        if (data) {
          setCurrentLocation([data]);
          onSelect?.(data);
        }
      })
      .catch(error => {
        Toast.show(error);
      })
      .finally(() => {
        setLoading(false);
      });
  };

  const _handleOnPress = () => {
    onSelect?.(currentLocation[0]);
  };

  return (
    <>
      <Pressable onPress={handleCurrentLocation}>
        <Box
          mx={'_s24'}
          flexDirection={'row'}
          justifyContent={'space-between'}
          alignItems={'center'}>
          <Box flexDirection={'row'} alignItems={'center'}>
            <AppIcon
              name={APP_ICON_NAMES.Crosshair}
              color={'transparent'}
              size={24}
            />
            <Box ml={'_s10'}>
              <Text variant={'body3.semiBold.18'} lineHeight={24}>
                Use your current location
              </Text>
              <Text variant={'body2.regular.14'} color={'gray1'} mt={'_s6'}>
                {currentLocation?.[0]?.formatted_address}
              </Text>
            </Box>
          </Box>
          {loading ? (
            <ActivityIndicator size={'small'} color={theme.colors.orange500} />
          ) : (
            <AppIcon name={APP_ICON_NAMES.ShortArrow} />
          )}
        </Box>
      </Pressable>
      {currentLocation?.length ? (
        <Box mx={'_s24'} mt={'_s32'}>
          <Text color={'gray1'} mb={'_s16'} variant={'body3.regular.12'}>
            Your Location
          </Text>
          <LocationBox
            onPress={_handleOnPress}
            location={currentLocation[0]}
            header={'My Place'}
          />
        </Box>
      ) : (
        <></>
      )}
    </>
  );
};

export default CurrentLocation;
