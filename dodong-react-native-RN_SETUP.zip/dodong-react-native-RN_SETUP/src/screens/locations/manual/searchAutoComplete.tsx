import React, {useState} from 'react';
import SearchBar from '@components/searchBar';
import {Pressable} from 'react-native';
import {Box, Text} from '@src/ui_kit/atoms';
import googleService from '@src/core/api/services/GoogleService';
import {useDispatch} from 'react-redux';
import {AppSlice} from '@src/redux';
import {getLocationFromPlaceId} from '@src/utilities/locationHelper';
const SearchAutoComplete = ({onSelect, textInputProps}) => {
  const [searchSuggestion, setSearchSuggestion] = useState([]);
  const dispatch = useDispatch();

  const handleAutoComplete = async (text: string) => {
    const res = await googleService.getGoogleAutoComplete(text);
    setSearchSuggestion(res?.data?.predictions ?? []);
  };

  const onSuggestionSelect = async item => {
    const res = await getLocationFromPlaceId(item.place_id);
    setSearchSuggestion([]);
    const result = res?.data?.result ?? null;
    if (result) {
      onSelect?.(result);
      dispatch(AppSlice.actions.updateSearchedLocations(result));
    }
  };

  const renderItem = ({item}) => {
    return (
      <Pressable onPress={() => onSuggestionSelect(item)}>
        <Box
          p={'_s8'}
          px={'_s12'}
          borderBottomWidth={0.5}
          borderColor={'neutral100'}>
          <Text variant={'body3.regular.12'}>{item?.description}</Text>
        </Box>
      </Pressable>
    );
  };

  const searchListProps = {
    renderItem,
    data: searchSuggestion,
    keyExtractor: item => item?.place_id,
  };

  const onChange = (text: string) => handleAutoComplete(text);

  return (
    <SearchBar
      handleTextChange={onChange}
      flatlistProps={searchListProps}
      textInputProps={textInputProps}
    />
  );
};

export default SearchAutoComplete;
