import {RootState} from '@src/redux';
import {Box, Text} from '@src/ui_kit/atoms';
import React from 'react';
import {useSelector} from 'react-redux';
import {LocationBox} from './LocationBox';
import {TLocation} from './type';
const SearchedLocations = ({onSelect}) => {
  const searchedLocations = useSelector(
    (state: RootState) => state.app?.searchedLocations,
  );

  const _handlePress = (location: TLocation) => onSelect?.(location);

  if (!searchedLocations?.length) {
    return <></>;
  }

  return (
    <Box mx={'_s24'} mt={'_s32'}>
      <Text color={'gray1'} mb={'_s16'} variant={'body3.regular.12'}>
        Search History
      </Text>
      {searchedLocations.map((location: TLocation, index: number) => {
        const newLocation = {
          ...location,
          formattedAddress: location.formatted_address,
        };
        return (
          <Box key={`searched_location${index}`} mb={'_s16'}>
            <LocationBox
              location={newLocation}
              onPress={_handlePress}
              header={location?.vicinity ?? ''}
            />
          </Box>
        );
      })}
    </Box>
  );
};
export default SearchedLocations;
