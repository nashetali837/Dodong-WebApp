import notificationService from '@src/core/api/services/NotificationService';
import {useEffect, useState} from 'react';

export const useNotificationData = () => {
  const [loading, setLoading] = useState<boolean>(false);
  const [notifications, setNotifications] = useState([]);

  const fetchNotifications = async () => {
    const resp = await notificationService.getUserNotification(1);
    const dataSet = resp?.data?.notifications ?? [];
    if (resp?.data?.notifications) {
      setNotifications([...notifications, ...dataSet]);
    }
    console.log('resp', resp);
  };

  useEffect(() => {
    fetchNotifications();
  }, []);

  return {
    notifications,
  };
};
