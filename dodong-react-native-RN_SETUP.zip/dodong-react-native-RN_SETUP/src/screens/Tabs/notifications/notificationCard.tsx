import {NOTIFICATION_ACTIONS} from '@src/constants/Enums';
import {Box, Text} from '@src/ui_kit/atoms';
import GradientButton from '@src/ui_kit/components/buttons/gradientButton';
import React from 'react';
const NotificationCard = ({item}) => {
  return (
    <Box mt={'_s16'}>
      <Box flexDirection="row" justifyContent="space-between">
        <Box flexDirection="row">
          <Box width={48} height={48} bg={'lightWhite'} borderRadius={24} />
          <Box ml={'_s16'}>
            <Box>
              <Text variant={'body3.regular.18'} lineHeight={22}>
                {item.name}
              </Text>
              <Text variant={'body3.regular.12'} color={'neutral400'}>
                {item.text}{' '}
                <Text variant={'body3.semiBold.12'} color={'gray2'}>
                  {' '}
                  {item.subText}{' '}
                </Text>
              </Text>
            </Box>
            {item?.showActions ? (
              <Box flexDirection="row" mt={'_s14'}>
                {Object.keys(NOTIFICATION_ACTIONS).map((action, idx) => {
                  return <Action action={action} key={idx} />;
                })}
              </Box>
            ) : (
              <></>
            )}
          </Box>
        </Box>
        <Box>
          <Text variant={'body3.regular.12'} color={'gray1'}>
            8:00 AM
          </Text>
        </Box>
      </Box>
    </Box>
  );
};

export default NotificationCard;

const Action = ({action}: {action: string}) => {
  const onActionPress = () => {};
  const isDecline = action === NOTIFICATION_ACTIONS.DECLINE;
  return (
    <Box width={85} height={32} mr={'_s12'}>
      <GradientButton
        text={action}
        isOutlined={isDecline}
        onPress={onActionPress}
        gradientStyles={{
          paddingVertical: 0,
        }}
        textProps={{
          variant: 'body3.regular.12',
          color: isDecline ? 'gray1' : 'white',
        }}
      />
    </Box>
  );
};
