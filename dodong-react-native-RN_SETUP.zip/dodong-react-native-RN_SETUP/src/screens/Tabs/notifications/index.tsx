import {Box, Text} from '@atoms';
import React from 'react';
import {SafeAreaView} from 'react-native-safe-area-context';
import {useNotificationData} from './useNotificationData';
import {FlatList} from 'react-native';
import {dimensions} from '@src/utilities/helpers';
import NotificationCard from './notificationCard';

const notifications = [
  {
    name: 'Anna Srzand',
    text: 'add new product',
    subText: 'Sofa Chair',
    showActions: false,
  },
  {
    name: 'Eleanor Pena',
    text: 'mention you in',
    subText: 'Sofa Chair post',
    showActions: false,
  },
  {
    name: 'Annette Black',
    text: 'is send you a message',
    subText: 'Hello Whats up??',
    showActions: false,
  },
  {
    name: 'Ronald Richards',
    text: 'you received reward',
    subText: '',
    showActions: false,
  },
  {
    name: 'Eleanor Pena',
    text: 'is requesting to connect',
    subText: '',
    showActions: true,
  },
  {
    name: 'Savannah Nguyen',
    text: 'mention you in',
    subText: 'Sofa Chair post',
    showActions: false,
  },
  {
    name: 'Albert Flores',
    text: 'is send you a message',
    subText: 'Hello Whats up??',
    showActions: false,
  },
  {
    name: 'Theresa Webb',
    text: 'is requesting to connect',
    subText: '',
    showActions: true,
  },
];

const NotificationsScreen = () => {
  // const {notifications} = useNotificationData();

  const _renderItem = ({item}) => <NotificationCard item={item} />;

  return (
    <SafeAreaView>
      <Text textAlign="center" my={'_s16'}>
        Notifications
      </Text>
      <Box
        minHeight={dimensions.screenHeight}
        bg={'white'}
        borderTopLeftRadius={20}
        p={'_s16'}
        borderTopRightRadius={20}>
        <FlatList
          data={notifications}
          renderItem={_renderItem}
          keyExtractor={_keyExtractor}
        />
      </Box>
    </SafeAreaView>
  );
};

export default NotificationsScreen;

const _keyExtractor = (_, index: number) => `notification_${index}`;
