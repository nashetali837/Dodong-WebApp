import {Box, Text} from '@atoms';
import React from 'react';

const ExploreScreen = () => {
  return (
    <Box flex={1}>
      <Text>EXPLORE SCREEN</Text>
    </Box>
  );
};

export default ExploreScreen;
