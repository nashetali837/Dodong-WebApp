import {PROFILE_TYPE} from '@src/constants/Enums';
import useUserData from '@src/hooks/user/useUserData';
import ProfileView from '@src/screens/profile';
import {Box, Text} from '@src/ui_kit/atoms';
import React from 'react';

const ProfileScreen = () => {
  const {userData} = useUserData();
  // if (userData?.profile?.userID) {
  //   return <ProfileView userData={userData} type={PROFILE_TYPE.PERSONAL} />;
  // }

  return (
    <Box flex={1} justifyContent={'center'} alignItems={'center'}>
      <Text>Oops Something is wrong </Text>
    </Box>
  );
};

export default ProfileScreen;
