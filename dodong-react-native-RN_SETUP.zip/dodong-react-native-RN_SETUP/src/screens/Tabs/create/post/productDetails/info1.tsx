import React from 'react';
import {Box} from '@atoms';
import TextInput from '@components/customInputs/textInput';
import {ScrollView, StyleSheet} from 'react-native';
import {theme} from '@theme';
import DropDown from '@components/customDropDown';
import ShopTag from './shop/shopTag';
import useCatSubCat from '@src/hooks/resourceHooks/useCategorySubcategory';
const Info1 = ({formik}) => {
  const handleCategoryChange = (category: TCatSubcatItem) => {
    formik.handleChange({target: {name: 'categoryId', value: category.id}});
    getSubCatByCat(category.id);
  };
  const handleSubCategoryChange = (subCategoryId: TCatSubcatItem) => {
    formik.handleChange({
      target: {name: 'subCategoryId', value: subCategoryId.id},
    });
  };

  const {topCategories, subCategories, getSubCatByCat} = useCatSubCat();

  return (
    <ScrollView
      showsVerticalScrollIndicator={false}
      contentContainerStyle={{paddingBottom: 200}}>
      <Box>
        <TextInput
          headerText={'Product Name'}
          placeholder={'iPhone'}
          onChangeText={(val: string) =>
            formik.handleChange({target: {name: 'name', value: val}})
          }
          value={formik.values.name}
          hasError={formik.errors.name && formik.touched.name}
        />
        <TextInput
          headerText={'Brand Name'}
          placeholder={'Apple'}
          onChangeText={(val: string) =>
            formik.handleChange({target: {name: 'brandName', value: val}})
          }
          value={formik.values.brandName}
          hasError={formik.errors.brandName && formik.touched.brandName}
          containerWrapperStyle={styles.wrapperStyle}
        />
        <TextInput
          headerText={'Description'}
          placeholder={'write a short description'}
          multiline={true}
          style={{height: 60}}
          textAlignVertical={'top'}
          numberOfLines={5}
          onChangeText={(val: string) =>
            formik.handleChange({target: {name: 'description', value: val}})
          }
          value={formik.values.description}
          hasError={formik.errors.description && formik.touched.description}
          containerWrapperStyle={styles.wrapperStyle}
        />
        <ShopTag formik={formik} />
        <TextInput
          headerText={'Price (Rs) *'}
          keyboardType="decimal-pad"
          onChangeText={(val: string) =>
            formik.handleChange({target: {name: 'price', value: val}})
          }
          value={formik.values.price}
          hasError={formik.errors.price && formik.touched.price}
          containerWrapperStyle={styles.wrapperStyle}
        />
        <Box flexDirection={'row'}>
          <Box flex={1} pr={'_s12'}>
            <TextInput
              headerText={'Quantity'}
              onChangeText={(val: string) =>
                formik.handleChange({target: {name: 'quantity', value: val}})
              }
              value={formik.values.quantity}
              hasError={formik.errors.quantity && formik.touched.quantity}
              containerWrapperStyle={styles.wrapperStyle}
            />
          </Box>
          <Box flex={1} pl={'_s12'}>
            <TextInput
              headerText={'Weight (KG)'}
              placeholder="0.5"
              onChangeText={(val: string) =>
                formik.handleChange({target: {name: 'weight', value: val}})
              }
              value={formik.values.weight}
              hasError={formik.errors.weight && formik.touched.weight}
              containerWrapperStyle={styles.wrapperStyle}
            />
          </Box>
        </Box>
        <DropDown
          headerText={'Category'}
          containerWrapperStyle={styles.wrapperStyle}
          data={topCategories}
          onChange={handleCategoryChange}
          hasError={formik.errors.categoryId}
        />
        <DropDown
          headerText={'Sub - Category'}
          containerWrapperStyle={styles.wrapperStyle}
          data={subCategories}
          onChange={handleSubCategoryChange}
          hasError={formik.errors.subCategoryId}
        />
      </Box>
    </ScrollView>
  );
};
export default Info1;

const styles = StyleSheet.create({
  wrapperStyle: {
    marginTop: theme.size.TWENTY_FOUR,
  },
});
