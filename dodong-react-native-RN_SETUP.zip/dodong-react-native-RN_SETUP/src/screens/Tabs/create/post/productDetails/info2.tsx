import React from 'react';
import {Box, Text} from '@atoms';
import OptionBox from '@components/optionBox';
const Info3 = () => {
  const handleSettingPress = () => {};

  return (
    <Box>
      <OptionBox
        option={{name: 'Settings'}}
        textProps={{color: 'gray1', variant: 'body3.semiBold.18'}}
        onPress={handleSettingPress}
      />
      <Text variant={'body2.semiBold.14'}>
        Hide like and view counts on this post
      </Text>
      <Text mb={'_s32'} mt={'_s8'} variant={'body2.regular.14'} color={'gray1'}>
        Only you will see the total number of likes and views on this post. You
        can change this later.To hide like counts on other people's posts, go to
        your account settings.
      </Text>
      <OptionBox
        option={{name: 'Accessibility'}}
        textProps={{color: 'gray1', variant: 'body3.semiBold.18'}}
      />
    </Box>
  );
};
export default Info3;
