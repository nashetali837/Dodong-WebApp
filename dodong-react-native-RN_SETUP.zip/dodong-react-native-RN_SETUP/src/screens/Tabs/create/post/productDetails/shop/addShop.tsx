import {Box} from '@src/ui_kit/atoms';
import AppIcon from '@src/ui_kit/components/appIcons/AppIcon';
import APP_ICON_NAMES from '@src/ui_kit/components/appIcons/iconNames';
import GradientButton from '@src/ui_kit/components/buttons/gradientButton';
import React, {useState} from 'react';
import Modal from 'react-native-modal';
import ShopInfoModal from './shopInfoModal';

const AddShop = () => {
  const [showModal, setShowModal] = useState<boolean>(false);

  const _handleOnPress = () => setShowModal(true);

  return (
    <Box>
      <GradientButton
        text="Add Shop"
        onPress={_handleOnPress}
        leftAccessory={
          <Box mr={'_s4'}>
            <AppIcon name={APP_ICON_NAMES.Shop} size={24} color="transparent" />
          </Box>
        }
      />
      <Modal
        isVisible={showModal}
        statusBarTranslucent
        animationIn="fadeIn"
        animationOut={'fadeOut'}
        animationOutTiming={1}
        backdropColor="transparent"
        style={modalStyle}
        hideModalContentWhileAnimating
        backdropTransitionOutTiming={0}>
        <ShopInfoModal setShowModal={setShowModal} />
      </Modal>
    </Box>
  );
};

export default AddShop;

const modalStyle = {padding: 0, margin: 0};
