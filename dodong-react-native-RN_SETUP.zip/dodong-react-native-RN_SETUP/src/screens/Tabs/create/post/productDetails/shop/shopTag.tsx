import resourceService from '@src/core/api/services/ResourceService';
import {Box, Text} from '@src/ui_kit/atoms';
import AppIcon from '@src/ui_kit/components/appIcons/AppIcon';
import APP_ICON_NAMES from '@src/ui_kit/components/appIcons/iconNames';
import Chip from '@src/ui_kit/components/chip';
import TextInput from '@src/ui_kit/components/customInputs/textInput';
import {theme} from '@src/ui_kit/theme';
import React, {useState} from 'react';
import {Pressable, StyleSheet} from 'react-native';
import AddShop from './addShop';
const ShopTag = ({formik}) => {
  const [shopList, setShopList] = useState([]);
  const [currentShop, setCurrentShop] = useState();

  const _handleShopSearch = async (text: string) => {
    const res = await resourceService.getShops(text);
    if (res?.data?.shops?.length) {
      setShopList(res.data.shops);
    }
    console.log('text', res);
  };

  const _handleCurrentShop = shop => {
    setShopList([]);
    setCurrentShop(shop);
    formik.handleChange({target: {name: 'shopID', value: shop?.shopID}});
  };

  return (
    <>
      <TextInput
        headerText={'Tag The Shop'}
        placeholder={'Enter shop name'}
        hasError={formik.errors.shopID && formik.touched.shopID}
        containerWrapperStyle={styles.wrapperStyle}
        onChangeText={_handleShopSearch}
        leftAccessory={
          <Box mr={'_s10'}>
            <AppIcon
              name={APP_ICON_NAMES.LocationOutline}
              color={'black'}
              size={20}
            />
          </Box>
        }
      />
      {shopList?.length ? (
        <>
          <Box
            borderWidth={1}
            borderBottomWidth={0}
            borderRadius={4}
            borderColor={'lightWhite'}
            mt={'_s8'}
            mb={'_s8'}>
            {shopList?.map((shop, idx) => {
              return (
                <Pressable key={idx} onPress={() => _handleCurrentShop(shop)}>
                  <Box
                    p={'_s12'}
                    borderBottomWidth={1}
                    borderColor={'lightWhite'}>
                    <Text>{shop?.name ?? ''}</Text>
                  </Box>
                </Pressable>
              );
            })}
          </Box>
          <AddShop />
        </>
      ) : (
        <></>
      )}
      {currentShop ? (
        <Chip text={currentShop?.name ?? ''} containerProps={{mt: '_s16'}} />
      ) : (
        <></>
      )}
    </>
  );
};

export default ShopTag;

const styles = StyleSheet.create({
  wrapperStyle: {
    marginTop: theme.size.TWENTY_FOUR,
  },
});
