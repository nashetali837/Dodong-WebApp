import React, {useState} from 'react';
import {Box, Text} from '@atoms';
import TextInput from '@components/customInputs/textInput';
import {ScrollView, StyleSheet} from 'react-native';
import {theme} from '@theme';
import DropDown from '@components/customDropDown';
import {useFormik} from 'formik';
import {initialShopAddFormicValue, shopAddScheme} from '../../formicVal';
import AppTopHeader from '@src/ui_kit/components/headers/appTopHeader';
import SearchAutoComplete from '@src/screens/locations/manual/searchAutoComplete';
import GradientButton from '@src/ui_kit/components/buttons/gradientButton';
import {TLocation} from '@src/screens/locations/manual/type';
import Chip from '@src/ui_kit/components/chip';
import useCatSubCat from '@src/hooks/resourceHooks/useCategorySubcategory';
import resourceService from '@src/core/api/services/ResourceService';
import Toast from 'react-native-simple-toast';

const ShopInfoModal = ({
  setShowModal,
}: {
  setShowModal: (val: boolean) => void;
}) => {
  const [loading, setLoading] = useState<boolean>(false);

  const onSavePress = async () => {
    setLoading(true);
    const res = await resourceService.createShop(formik.values);
    if (res?.data?.id) {
      Toast.show('Shop Added Successfully', Toast.LONG);
      setShowModal(false);
    }
    setLoading(false);
  };
  const _customBackPress = () => setShowModal(false);
  const {topCategories, subCategories, getSubCatByCat} = useCatSubCat();

  const formik = useFormik({
    initialValues: initialShopAddFormicValue,
    onSubmit: onSavePress,
    validationSchema: shopAddScheme,
  });

  const onLocationPress = (location: TLocation) => {
    const locationData = {
      latitude: location?.geometry?.location?.lat ?? null,
      longitude: location?.geometry?.location?.lng ?? null,
      name: location?.formatted_address ?? '',
    };
    formik.handleChange({target: {name: 'location', value: locationData}});
    formik.handleChange({target: {name: 'address', value: locationData.name}});
  };
  const handleCategoryChange = (category: TCatSubcatItem) => {
    formik.handleChange({target: {name: 'categoryId', value: category.id}});
    getSubCatByCat(category.id);
  };
  const handleSubCategoryChange = (subCategoryId: TCatSubcatItem) => {
    formik.handleChange({
      target: {name: 'subCategoryId', value: subCategoryId.id},
    });
  };

  return (
    <Box flex={1} bg={'white'}>
      <AppTopHeader headerText={'Add Shop'} onBackPress={_customBackPress} />
      <ScrollView
        showsVerticalScrollIndicator={false}
        contentContainerStyle={{paddingBottom: 100}}>
        <Box px={'_s24'}>
          <SearchAutoComplete
            onSelect={onLocationPress}
            textInputProps={{
              headerText: 'Search Shop Area',
              hasError: formik.errors.location,
            }}
          />
          <Chip text={formik.values.location?.name ?? ''} />
          <TextInput
            headerText={'Shop Name'}
            placeholder="Enter shop name"
            onChangeText={(val: string) =>
              formik.handleChange({target: {name: 'name', value: val}})
            }
            value={formik.values.name}
            hasError={formik.errors.name && formik.touched.name}
            containerWrapperStyle={styles.wrapperStyle}
          />
          <TextInput
            headerText={'Contact Details'}
            placeholder={'Enter your mobile number'}
            onChangeText={(val: string) =>
              formik.handleChange({target: {name: 'contact', value: val}})
            }
            value={formik.values.contact}
            keyboardType={'number-pad'}
            hasError={formik.errors.contact && formik.touched.contact}
            containerWrapperStyle={styles.wrapperStyle}
            maxLength={10}
            leftAccessory={
              <Text variant={'body3.regular.12'} mr={'_s10'}>
                +91
              </Text>
            }
          />
          <TextInput
            headerText={'Description'}
            placeholder={'Enter a short bio'}
            multiline={true}
            textAlignVertical={'top'}
            style={{height: 60}}
            onChangeText={(val: string) =>
              formik.handleChange({target: {name: 'bio', value: val}})
            }
            value={formik.values.bio}
            hasError={formik.errors.bio && formik.touched.bio}
            containerWrapperStyle={styles.wrapperStyle}
          />

          <DropDown
            headerText={'Category'}
            containerWrapperStyle={styles.wrapperStyle}
            data={topCategories}
            onChange={handleCategoryChange}
            hasError={Boolean(
              formik.errors.categoryId && formik.touched.categoryId,
            )}
          />
          <DropDown
            headerText={'Sub - Category'}
            containerWrapperStyle={styles.wrapperStyle}
            data={subCategories}
            onChange={handleSubCategoryChange}
            hasError={Boolean(
              formik.errors.subCategoryId && formik.touched.subCategoryId,
            )}
          />

          <TextInput
            headerText={'Email'}
            placeholder={'Enter shop email'}
            onChangeText={(val: string) =>
              formik.handleChange({target: {name: 'email', value: val}})
            }
            value={formik.values.email}
            hasError={formik.errors.email && formik.touched.email}
            containerWrapperStyle={styles.wrapperStyle}
          />

          <TextInput
            headerText={'Website'}
            placeholder={'Enter shop website'}
            onChangeText={(val: string) =>
              formik.handleChange({target: {name: 'website', value: val}})
            }
            value={formik.values.website}
            hasError={formik.errors.website && formik.touched.website}
            containerWrapperStyle={styles.wrapperStyle}
          />
        </Box>
      </ScrollView>
      <Box p={'_s24'} borderTopWidth={1} borderColor={'lightWhite'}>
        <GradientButton
          text="Add"
          onPress={formik.handleSubmit}
          isLoading={loading}
        />
      </Box>
    </Box>
  );
};
export default ShopInfoModal;

const styles = StyleSheet.create({
  wrapperStyle: {
    marginTop: theme.size.TWENTY_FOUR,
  },
});
