import React, {useState} from 'react';
import {Box} from '@atoms';
import DualButton from '@components/buttons/dualButtons';
import {useSafeAreaInsets} from 'react-native-safe-area-context';
import Info1 from './info1';
import Info2 from './info2';
import {useFormik} from 'formik';
import {initialProductFormicValue, productDetailScheme} from '../formicVal';
import {usePostCreation} from '@src/hooks/resourceHooks/usePostCreation';
import {useNavigation} from '@react-navigation/native';
import {ScreensList} from '@src/routes/helpers';
import {IS_IOS} from '@src/utilities/helpers';

const Steps = [1, 2, 3];

const stepText = {
  [1]: 'Create',
  [2]: 'Finish',
};

const ProductDetails = ({_handleOnButtonPress, imageUrl}) => {
  const inset = useSafeAreaInsets();
  const {navigate} = useNavigation();
  const {createPost, loading} = usePostCreation();
  const [currentStep, setCurrentStep] = useState<number>(Steps[0]);

  const onSuccess = () => {
    setCurrentStep(currentStep + 1);
  };

  const onSavePress = () => {
    formik.handleChange({
      target: {name: 'imageUrl', value: imageUrl},
    });
    console.log('calling', formik.values);
    createPost(formik.values, onSuccess);
  };

  const formik = useFormik({
    initialValues: initialProductFormicValue,
    onSubmit: onSavePress,
    validationSchema: productDetailScheme,
  });

  const handleLeftPress = () => {
    if (currentStep === Steps[0]) {
      _handleOnButtonPress();
    } else {
      setCurrentStep(currentStep - 1);
    }
  };

  const handleRightPress = () => {
    if (currentStep === Steps[0]) {
      formik.handleSubmit();
      return;
    }
    navigate(ScreensList.Tabs);
  };

  const ViewComponent = {
    [Steps[0]]: {
      Component: Info1,
      props: {formik},
    },
    [Steps[1]]: {
      Component: Info2,
      props: {formik},
    },
  };

  const {Component, props} = ViewComponent[currentStep];
  console.log('currentStep', currentStep);
  return (
    <Box bg={'white'} mt={'_s24'} flex={1}>
      <Box mx={'_s24'}>
        <Component {...props} />
      </Box>
      <Box
        position="absolute"
        bg={'white'}
        borderTopColor={'lightWhite'}
        borderTopWidth={1}
        width={'100%'}
        px={'_s24'}
        bottom={0}
        style={{
          paddingBottom: IS_IOS ? inset.bottom : 10,
          paddingTop: 10,
        }}>
        <DualButton
          onLeftPress={handleLeftPress}
          onRightPress={handleRightPress}
          loading={loading}
          leftButtonText={'Back'}
          rightButtonText={stepText[currentStep]}
        />
      </Box>
    </Box>
  );
};

export default ProductDetails;
