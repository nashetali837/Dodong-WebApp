import React from 'react';
import {Box} from '@atoms';
import TextInput from '@components/customInputs/textInput';
import DropDown from '@components/customDropDown';
import {StyleSheet} from 'react-native';
import {theme} from '@theme';
import GradientButton from '@components/buttons/gradientButton';
import AppIcon from '@components/appIcons/AppIcon';
import APP_ICON_NAMES from '@components/appIcons/iconNames';
import {LOCALE} from '@constants/locale';
import {useSafeAreaInsets} from 'react-native-safe-area-context';
import Genders from '@AppJsons/gender.json';
import ForType from '@AppJsons/forType.json';
import {IS_IOS, ObjectToArrayConversion} from '@utilities/helpers';

const GenderData = ObjectToArrayConversion(Genders);
const ForData = ObjectToArrayConversion(ForType);

const UserDetails = ({formik, _handleOnButtonPress}) => {
  const inset = useSafeAreaInsets();
  const handleGenderChange = (gender: {label: string}) => {
    formik.handleChange({target: {name: 'gender', value: gender.label}});
  };

  const handleForChange = (value: {label: string}) => {
    formik.handleChange({target: {name: 'for', value: value.label}});
  };

  const _onNextPress = () => {
    console.log('formik.values.for', formik.values.for);
    if (formik.values.for !== 'For Me') {
      formik.handleSubmit();
    } else {
      _handleOnButtonPress();
    }
  };

  return (
    <Box mt={'_s24'} flex={1}>
      <Box mx={'_s24'}>
        <DropDown
          headerText={'For*'}
          onChange={handleForChange}
          data={ForData}
        />
        {formik.values.for !== 'For Me' ? (
          <>
            <TextInput
              headerText={'User Name*'}
              placeholder={'Enter your name'}
              onChangeText={(val: string) =>
                formik.handleChange({target: {name: 'userName', value: val}})
              }
              value={formik.values.userName}
              hasError={formik.errors.userName && formik.touched.userName}
              containerWrapperStyle={styles.wrapperStyle}
            />
            <DropDown
              headerText={'Gender*'}
              containerWrapperStyle={styles.wrapperStyle}
              data={GenderData}
              onChange={handleGenderChange}
            />
            <TextInput
              headerText={'Age*'}
              placeholder={'Enter your age'}
              onChangeText={(val: string) =>
                formik.handleChange({target: {name: 'age', value: val}})
              }
              value={formik.values.age}
              hasError={formik.errors.age && formik.touched.age}
              containerWrapperStyle={styles.wrapperStyle}
              keyboardType={'number-pad'}
            />
          </>
        ) : (
          <></>
        )}
      </Box>
      <Box
        position="absolute"
        bg={'white'}
        borderTopColor={'lightWhite'}
        borderTopWidth={1}
        width={'100%'}
        px={'_s24'}
        bottom={0}
        style={{
          paddingBottom: IS_IOS ? inset.bottom : 10,
          paddingTop: 10,
        }}>
        <GradientButton
          rightAccessory={
            <Box style={{transform: [{rotate: '180deg'}]}} ml={'_s10'}>
              <AppIcon name={APP_ICON_NAMES.BackArrow} color={'white'} />
            </Box>
          }
          text={LOCALE.next}
          onPress={_onNextPress}
        />
      </Box>
    </Box>
  );
};

export default UserDetails;

const styles = StyleSheet.create({
  wrapperStyle: {
    marginTop: theme.size.TWENTY_FOUR,
  },
});
