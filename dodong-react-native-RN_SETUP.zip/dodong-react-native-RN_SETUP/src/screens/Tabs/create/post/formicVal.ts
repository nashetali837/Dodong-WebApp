import * as Yup from 'yup';

export const userDetailScheme = Yup.object().shape({
  userName: Yup.string().required('Required'),
  gender: Yup.string().required('Required'),
  age: Yup.string().required('Required'),
});

export const productDetailScheme = Yup.object().shape({
  name: Yup.string().required('Required'),
  brandName: Yup.string().required('Required'),
  categoryId: Yup.number().required('Required'),
  shopID: Yup.number().required('Required'),
  // subCategoryId: Yup.number().required('Required'),
  price: Yup.number().required('Required'),
  quantity: Yup.number().required('Required'),
  weight: Yup.number().required('Required'),
});

export const shopAddScheme = Yup.object().shape({
  name: Yup.string().required('Required'),
  location: Yup.object().required('Required'),
  contact: Yup.number().min(10).required('Required'),
  categoryId: Yup.number().required('Required'),
  // subCategoryId: Yup.number().required('Required'),
});

export const initialUserFormicValue = {
  //USER DETAILS
  for: '',
  userName: '',
  gender: '',
  age: '',
};

export const initialProductFormicValue = {
  //PRODUCT DETAILS - info1
  name: '',
  brandName: '',
  description: '',
  price: '',
  quantity: '',
  weight: '',
  categoryId: '',
  subCategoryId: '',
  shopID: '',
  imageUrl: '',
};

export const initialShopAddFormicValue = {
  //info2
  name: '',
  address: '',
  contact: '',
  email: '',
  bio: '',
  website: '',
  categoryId: '',
  subCategoryId: '',
  location: null,
};
