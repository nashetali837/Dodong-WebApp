import React, {useState} from 'react';
import {Box} from '@atoms';
import AppTopHeader from '@components/headers/appTopHeader';
import DualTabs from '@components/dualTabs';
import {initialUserFormicValue, userDetailScheme} from './formicVal';
import {useFormik} from 'formik';
import UserDetails from './userDetail';
import ProductDetails from './productDetails';

const tabs = [{name: 'User Details'}, {name: 'Product Details'}];

const CreatePost = ({...extraProps}) => {
  const imageUrl = extraProps?.route?.params?.imageUrl ?? '';
  const [currentTab, setCurrentTab] = useState<tab>(tabs[0]);
  const handleTabChange = (tab: tab) => {
    setCurrentTab(tab);
  };

  const _handleOnButtonPress = () => {
    if (currentTab.name === tabs[0].name) {
      setCurrentTab(tabs[1]);
    }
    if (currentTab.name === tabs[1].name) {
      setCurrentTab(tabs[0]);
    }
  };

  const userDetailformik = useFormik({
    initialValues: initialUserFormicValue,
    onSubmit: _handleOnButtonPress,
    validationSchema: userDetailScheme,
  });

  const ViewComponent = {
    [tabs[0].name]: {
      Component: UserDetails,
      props: {formik: userDetailformik, _handleOnButtonPress},
    },
    [tabs[1].name]: {
      Component: ProductDetails,
      props: {_handleOnButtonPress, imageUrl},
    },
  };

  const {Component, props} = ViewComponent[currentTab.name];

  return (
    <Box bg={'white'} flex={1}>
      <AppTopHeader headerText={'Create Post'} />
      <Box flex={1}>
        <Box mx={'_s24'}>
          <DualTabs
            tabs={tabs}
            onTabChange={handleTabChange}
            currentTab={currentTab}
          />
        </Box>
        <Component {...props} />
      </Box>
    </Box>
  );
};

export default CreatePost;
