import {Box, Text} from '@atoms';
import React from 'react';

const CreateScreen = () => {
  return (
    <Box flex={1}>
      <Text>CREATE SCREEN</Text>
    </Box>
  );
};

export default CreateScreen;
