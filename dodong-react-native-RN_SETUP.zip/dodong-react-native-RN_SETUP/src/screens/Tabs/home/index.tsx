import DevWrapper from '@src/screens/dev';
import React from 'react';
import StoreFront from './components/storeFront';
import HomeHeader from './components/header';
import {Box} from '@src/ui_kit/atoms';
import Discoveries from './components/discoveries';

const HomeScreen = () => {
  return (
    <DevWrapper>
      <Box flex={1}>
        <HomeHeader />
        <Discoveries />
        <StoreFront />
      </Box>
    </DevWrapper>
  );
};

export default HomeScreen;
