import {Box, Text} from '@src/ui_kit/atoms';
import React from 'react';
import styles from '../styles';
import GradientButton from '@src/ui_kit/components/buttons/gradientButton';
import AppIcon from '@src/ui_kit/components/appIcons/AppIcon';
import APP_ICON_NAMES from '@src/ui_kit/components/appIcons/iconNames';
import ImageGallery from '@src/ui_kit/components/imageGallery';
import ShortActions from './shortActions';
import {ScreensList} from '@src/routes/helpers';
import {useNavigation} from '@react-navigation/native';
import UserInfoUI from '@src/ui_kit/widgets/userInfo';
import {IStoreCard} from '../type';
import {Pressable} from 'react-native';
const StoreCard: React.FC<IStoreCard> = ({item: Resource}) => {
  const {navigate} = useNavigation();
  console.log('Post', Resource);

  const images = Resource?.post?.imageURL ?? [];
  const description = Resource?.post?.description ?? '';
  const productID = Resource?.productID ?? null;
  const shopID = Resource?.shopID ?? null;
  const geohash = Resource?.geohash ?? '';

  const actionData = {
    isLiked: Resource?.liked ?? false,
    id: Resource?.resourceID ?? '',
  };

  const screenParams = {
    productID: productID,
    shopID: shopID,
    geohash,
  };

  const _handleOnCardPress = () => {
    navigate(ScreensList.ProductDetail, screenParams);
  };

  const _handleOnShopPress = () =>
    navigate(ScreensList.ShopDetail, {shopID, geohash});

  return (
    <Pressable onPress={_handleOnCardPress}>
      <Box mb={'_s16'} style={styles.storeCard} p={'_s10'}>
        <UserInfoUI author={Resource?.author} />
        <Box
          bg={'lightWhite'}
          overflow="hidden"
          width={'100%'}
          height={320}
          borderRadius={10}
          my={'_s16'}>
          <ImageGallery images={images} />

          <Box position="absolute" bottom={10} left={10}>
            <ShortActions {...actionData} />
          </Box>
        </Box>
        {description ? (
          <Text variant={'body3.regular.12'}>{description}</Text>
        ) : (
          <></>
        )}
        <Box
          flexDirection="row"
          justifyContent="space-between"
          alignItems="center">
          <Box>
            <Text variant={'body3.semiBold.12'}>
              {Resource?.product?.productName ?? ''}
            </Text>
            <Text variant={'body2.semiBold.14'}>
              ₹ {Resource?.product?.price}{' '}
              <Text
                variant={'body2.regular.14'}
                textDecorationLine="line-through">
                800
              </Text>
            </Text>
          </Box>
          <Box width={115} height={50}>
            <GradientButton
              text="Shop"
              gradientStyles={{borderRadius: 30}}
              textProps={{
                variant: 'body2.semiBold.14',
                ml: '_s8',
                lineHeight: 19,
              }}
              onPress={_handleOnShopPress}
              leftAccessory={
                <AppIcon name={APP_ICON_NAMES.Shop} color="transparent" />
              }
            />
          </Box>
        </Box>
      </Box>
    </Pressable>
  );
};

export default React.memo(StoreCard);
