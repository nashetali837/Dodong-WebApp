import useCustomScrollHandler from '@src/hooks/scrollHandler/useCustomScrollHandler';
import {useStoreFront} from '@src/hooks/storeFront/useStoreFront';
import {AnimatedFlatList} from '@src/ui_kit/atoms/animated/helper';
import React, {useCallback} from 'react';
import StoreCard from './card';
import styles from './styles';
import {RefreshControl} from 'react-native';
import {getWrapperComponentByIndex} from './wrapperComponent';

const StoreFront = () => {
  const {resources, refreshData, refreshing, onEndReached} = useStoreFront();
  const {
    animatedScrollHandler,
    itemViewabilityConfigRef,
    handleViewableItemsChanged,
  } = useCustomScrollHandler({
    viewPortIndex: 2,
  });

  const _renderItem = useCallback(
    ({item, index}: {item: TResourcePost; index: number}) => {
      return (
        <>
          {getWrapperComponentByIndex(index)}
          <StoreCard item={item} />
        </>
      );
    },
    [resources?.length],
  );

  return (
    <AnimatedFlatList
      data={resources}
      style={styles.wrapperStyles}
      contentContainerStyle={styles.containerStyles}
      renderItem={_renderItem}
      refreshControl={
        <RefreshControl refreshing={refreshing} onRefresh={refreshData} />
      }
      keyExtractor={_keyExtractor}
      showsVerticalScrollIndicator={false}
      onEndReachedThreshold={0.5}
      scrollEventThrottle={20}
      onEndReached={onEndReached}
      onScroll={animatedScrollHandler}
      viewabilityConfig={itemViewabilityConfigRef.current}
      onViewableItemsChanged={handleViewableItemsChanged.current}
      initialNumToRender={3}
    />
  );
};

export default StoreFront;

const _keyExtractor = (_: string, idx: number) => `home_key_${idx}`;
