import ProfileCompleteNudge from '@src/screens/profile/components/profileCompleteNudge';
import React from 'react';

export const getWrapperComponentByIndex = (index: number) => {
  switch (index) {
    case 0:
      return <ProfileCompleteNudge mx={'_s0'} mb={'_s16'} reverse />;

    default:
      return <></>;
  }
};
