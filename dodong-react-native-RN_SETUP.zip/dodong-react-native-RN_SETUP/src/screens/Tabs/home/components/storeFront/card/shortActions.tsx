import {Box} from '@src/ui_kit/atoms';
import AppIcon from '@src/ui_kit/components/appIcons/AppIcon';
import APP_ICON_NAMES from '@src/ui_kit/components/appIcons/iconNames';
import React, {useEffect, useState} from 'react';
import {BlurView} from '@react-native-community/blur';
import {SHORT_ACTIONS} from '@src/constants/Enums';
import {Pressable, StyleSheet} from 'react-native';
import {theme} from '@src/ui_kit/theme';
import {useClickActions} from '@src/hooks/resourceHooks/useClickActions';
import {ScreensList} from '@src/routes/helpers';
import {useNavigation} from '@react-navigation/native';

const Actions = [
  {
    name: SHORT_ACTIONS.LIKE,
    icon: APP_ICON_NAMES.Like,
    color: 'white',
  },
  {
    name: SHORT_ACTIONS.COMMENT,
    icon: APP_ICON_NAMES.Comment,
    color: 'transparent',
  },
  {
    name: SHORT_ACTIONS.SHARE,
    icon: APP_ICON_NAMES.Share,
    color: 'transparent',
  },
];

function updateLikeIcon(willShowLike = false) {
  return Actions.map(action => {
    if (action.name === SHORT_ACTIONS.LIKE) {
      return {
        ...action,
        icon: willShowLike ? APP_ICON_NAMES.Like : APP_ICON_NAMES.Liked,
        color: willShowLike ? 'white' : theme.colors.orange500,
      };
    }
    return action;
  });
}

const ShortActions = ({id, isLiked}: {id: number; isLiked: boolean}) => {
  const {onLikeDislikeResource} = useClickActions({id});
  const {navigate} = useNavigation();
  const [actionSet, updateActionSet] = useState(Actions);
  const [liked, setIsLiked] = useState(isLiked);

  useEffect(() => {
    if (isLiked) {
      updateActionSet(updateLikeIcon(!isLiked));
    }
  }, []);

  const _handlePress = (action: SHORT_ACTIONS) => {
    if (action === SHORT_ACTIONS.LIKE) {
      onLikeDislikeResource(liked);
      updateActionSet(updateLikeIcon(liked));
      setIsLiked(!liked);
    }
    if (action === SHORT_ACTIONS.COMMENT) {
      navigate(ScreensList.PostDetail, {postId: id});
    }
  };

  return (
    // <BlurView
    //   blurType="light"
    //   blurAmount={1}
    //   style={styles.container}
    //   blurRadius={20}>
    <Box flexDirection="row" pl={'_s4'} py={'_s4'} borderRadius={20}>
      {actionSet.map((action, index) => {
        return (
          <Pressable
            onPress={() => _handlePress(action.name)}
            key={`shortAction_${index}`}>
            <Box
              width={40}
              height={40}
              borderRadius={20}
              justifyContent="center"
              alignItems="center"
              mr={'_s4'}
              bg={'black'}>
              <AppIcon name={action.icon} size={20} color={action.color} />
            </Box>
          </Pressable>
        );
      })}
    </Box>
    // </BlurView>
  );
};

export default ShortActions;

const styles = StyleSheet.create({
  container: {
    borderRadius: theme.size.TWENTY,
    overflow: 'hidden',
  },
});
