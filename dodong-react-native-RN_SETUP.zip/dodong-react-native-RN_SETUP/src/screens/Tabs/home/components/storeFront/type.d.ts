export interface IStoreCard {
  item: TResourcePost;
}
