import {theme} from '@src/ui_kit/theme';
import {StyleSheet} from 'react-native';

const styles = StyleSheet.create({
  storeCard: {
    borderRadius: 30,
    backgroundColor: theme.colors.white,
    shadowColor: 'rgba(167, 174, 193, 0.15)',
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowOpacity: 1,
    shadowRadius: 70,
    elevation: 5,
  },
  wrapperStyles: {flex: 1, paddingHorizontal: theme.size.SIXTEEN},
  containerStyles: {paddingBottom: 70},
});

export default styles;
