import {Box} from '@src/ui_kit/atoms';
import React from 'react';
import {ScrollView} from 'react-native';
import Card from './card';
import {useDiscoveryData} from '@src/hooks/resourceHooks/useDiscoveryData';
const Discoveries = () => {
  const {discoveries} = useDiscoveryData();

  return (
    <Box>
      <ScrollView
        showsHorizontalScrollIndicator={false}
        horizontal
        style={{paddingLeft: 16}}>
        {discoveries?.map((_, index) => {
          return <Card key={`discovery${index}`} />;
        })}
      </ScrollView>
    </Box>
  );
};

export default Discoveries;
