import {Box} from '@src/ui_kit/atoms';
import React from 'react';
const Card = () => {
  return (
    <Box
      width={70}
      height={70}
      bg={'lightWhite'}
      mr={'_s8'}
      borderRadius={16}
    />
  );
};

export default Card;
