import {useNavigation} from '@react-navigation/native';
import {RootState} from '@src/redux';
import {ScreensList} from '@src/routes/helpers';
import {Box, Text} from '@src/ui_kit/atoms';
import AppIcon from '@src/ui_kit/components/appIcons/AppIcon';
import APP_ICON_NAMES from '@src/ui_kit/components/appIcons/iconNames';
import {theme} from '@src/ui_kit/theme';
import React from 'react';
import {Pressable} from 'react-native';
import {useSafeAreaInsets} from 'react-native-safe-area-context';
import {useSelector} from 'react-redux';
const minInset = 10;
const HomeHeader = () => {
  const {navigate} = useNavigation();
  const currentLocation = useSelector(
    (state: RootState) => state.app.currentLocation,
  );
  const inset = useSafeAreaInsets();
  const paddingTop = inset?.top > minInset ? inset.top : minInset;

  const _handleOnLocationPress = () => {
    navigate(ScreensList.ManualLocation, {willRouteBack: true});
  };

  return (
    <Box
      flexDirection="row"
      px={'_s16'}
      justifyContent="space-between"
      alignItems="center"
      mb={'_s10'}
      style={{paddingTop}}>
      <Pressable onPress={_handleOnLocationPress}>
        <Box flexDirection="row" alignItems="center">
          <AppIcon name={APP_ICON_NAMES.Cart} color="transparent" size={24} />
          <Text
            ml={'_s12'}
            variant={'body3.regular.18'}
            lineHeight={26}
            style={{maxWidth: theme.size.ONE_EIGHTY}}
            numberOfLines={1}>
            {currentLocation?.formatted_address ?? 'Location'}
          </Text>
        </Box>
      </Pressable>
      {/* <Pressable>
        <Box>
          <Box
            width={theme.size.FOURTY_EIGHT}
            height={theme.size.FOURTY_EIGHT}
            borderRadius={24}
            justifyContent="center"
            borderWidth={0.3}
            borderColor={'neutral300'}
            alignItems="center">
            <AppIcon name={APP_ICON_NAMES.Cart} color="transparent" size={26} />
          </Box>
        </Box>
      </Pressable> */}
    </Box>
  );
};
export default HomeHeader;
