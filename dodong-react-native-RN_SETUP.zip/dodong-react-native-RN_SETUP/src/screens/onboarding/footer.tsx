import React from 'react';
import {Pressable} from 'react-native';
import {Box, Text} from '@atoms';
import ScrollIndicatorDot from '@components/scrollIndicator';
import {theme} from '@theme';
import {PAGES} from './data';
import {LOCALE} from '@constants/locale';
import {StyleSheet} from 'react-native';
import {IFooter} from './type';
const Footer: React.FC<IFooter> = ({
  onNextPress,
  activeDotIndex,
  onSkipPress,
}) => {
  return (
    <Box
      position={'absolute'}
      bottom={0}
      width={'100%'}
      height={theme.size.EIGHTY_TWO}
      flexDirection="row">
      <Box flex={1} justifyContent={'center'} alignItems={'center'}>
        <Pressable onPress={onSkipPress} style={styles.touchable}>
          <Text variant={'body3.regular.18'} lineHeight={28} color={'gray1'}>
            {LOCALE.Skip}
          </Text>
        </Pressable>
      </Box>
      <Box
        flex={1}
        justifyContent={'center'}
        alignItems={'center'}
        flexDirection={'row'}>
        {PAGES.map((_, index) => (
          <ScrollIndicatorDot
            activeDotIndex={activeDotIndex}
            index={index}
            key={`scrollIndicator_${index}`}
          />
        ))}
      </Box>
      <Box flex={1}>
        <Pressable onPress={onNextPress} style={styles.touchable}>
          <Text variant={'body3.regular.18'} lineHeight={28}>
            {LOCALE.Next}
          </Text>
        </Pressable>
      </Box>
    </Box>
  );
};

export default Footer;

const styles = StyleSheet.create({
  touchable: {
    ...StyleSheet.absoluteFill,
    justifyContent: 'center',
    alignItems: 'center',
  },
});
