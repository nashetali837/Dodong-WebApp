export const PAGES: TOnboardingPage[] = [
  {
    image: require('@assets/pngs/onboard/page1.png'),
    title: 'Buy products online from local store',
    text: 'Share your discoveries, collection, and many more to gain followers',
  },
  {
    image: require('@assets/pngs/onboard/page2.png'),
    title: 'Buy products online from local store',
    text: 'Share your discoveries, collection, and many more to gain followers',
  },
  {
    image: require('@assets/pngs/onboard/page3.png'),
    title: 'Buy products online from local store',
    text: 'Share your discoveries, collection, and many more to gain followers',
  },
];
