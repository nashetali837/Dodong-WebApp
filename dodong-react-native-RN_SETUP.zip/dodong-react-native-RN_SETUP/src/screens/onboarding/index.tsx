import React, {useEffect} from 'react';
import {Box} from '@atoms';
import OnboardingPage from './page';
import Animated, {
  useAnimatedRef,
  useAnimatedScrollHandler,
  useDerivedValue,
  useSharedValue,
} from 'react-native-reanimated';
import Footer from './footer';
import {PAGES} from './data';
import {dimensions} from '@src/utilities/helpers';
import {ScreensList} from '@src/routes/helpers';
import {useDispatch} from 'react-redux';
import {AppSlice} from '@src/redux';

const PAGE_WIDTH = dimensions.screenWidth;

const OnboardingScreen = ({...props}) => {
  const {reset} = props.navigation;
  const dispatch = useDispatch();
  const translateX = useSharedValue<number>(0);
  const scrollViewRef = useAnimatedRef<Animated.ScrollView>();

  useEffect(() => {
    dispatch(AppSlice.actions.setOnboardingVisited(true));
  }, []);

  const scrollHandler = useAnimatedScrollHandler(event => {
    translateX.value = event.contentOffset.x;
  });

  const activeIndex = useDerivedValue(() => {
    return Math.round(translateX.value / PAGE_WIDTH);
  });

  const handleSkip = () => {
    reset({
      index: 0,
      routes: [{name: ScreensList.AuthLanding}],
    });
  };

  const onNextPress = () => {
    if (activeIndex?.value === PAGES.length - 1) {
      handleSkip();
    }
    scrollViewRef?.current?.scrollTo({
      x: PAGE_WIDTH * (activeIndex?.value + 1),
    });
  };

  return (
    <Box flex={1}>
      <Animated.ScrollView
        horizontal
        ref={scrollViewRef}
        pagingEnabled
        style={{flex: 1}}
        onScroll={scrollHandler}
        scrollEventThrottle={16}
        showsHorizontalScrollIndicator={false}>
        {PAGES.map((page, index) => (
          <OnboardingPage key={`onboarding_${index}`} page={page} />
        ))}
      </Animated.ScrollView>
      <Footer
        onNextPress={onNextPress}
        onSkipPress={handleSkip}
        activeDotIndex={activeIndex}
      />
    </Box>
  );
};

export default OnboardingScreen;
