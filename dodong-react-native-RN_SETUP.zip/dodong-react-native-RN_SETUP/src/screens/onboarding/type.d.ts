import {SharedValue} from 'react-native-reanimated';

type TOnboardingPage = {
  image: number;
  title: string;
  text: string;
};

interface IOnboardingPage {
  page: TOnboardingPage;
}

interface IFooter {
  onNextPress: () => void;
  activeDotIndex: SharedValue<number>;
  onSkipPress: () => void;
}
