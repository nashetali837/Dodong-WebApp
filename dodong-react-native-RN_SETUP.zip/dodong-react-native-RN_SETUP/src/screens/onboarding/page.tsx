import React from 'react';
import {Box, Text} from '@src/ui_kit/atoms';
import {Image, ImageBackground, StyleSheet} from 'react-native';
import {dimensions} from '@src/utilities/helpers';
import {theme} from '@src/ui_kit/theme';

const screenBase = require('../../assets/pngs/onboard/base.png');

const OnboardingPage: React.FC<IOnboardingPage> = ({page}) => {
  return (
    <Box width={dimensions.screenWidth} height={dimensions.screenHeight}>
      <Box flex={6.5}>
        <Image source={page.image} style={styles.image} />
      </Box>
      <Box flex={3.5}>
        <Box
          position={'absolute'}
          height={'100%'}
          width={dimensions.screenWidth}
          zIndex={100}
          style={styles.boxWrapper}>
          <ImageBackground source={screenBase} style={styles.imageBackground}>
            <Text
              variant={'body1.semiBold.24'}
              textAlign={'center'}
              maxWidth={300}
              lineHeight={28}
              mt={'_s56'}>
              {page.title}
            </Text>
            <Text
              variant={'body2.regular.14'}
              textAlign={'center'}
              color={'gray1'}
              mt={'_s20'}
              maxWidth={280}>
              {page.text}
            </Text>
          </ImageBackground>
        </Box>
      </Box>
    </Box>
  );
};
export default OnboardingPage;

const styles = StyleSheet.create({
  image: {width: null, height: null, flex: 1},
  boxWrapper: {marginTop: -theme.size.TWELVE},
  imageBackground: {
    width: null,
    height: null,
    flex: 1,
    alignItems: 'center',
  },
});
