import {useNavigation} from '@react-navigation/native';
import {TProductDetail} from '@src/core/api/services/schema.type';
import {ScreensList} from '@src/routes/helpers';
import {Box, Text} from '@src/ui_kit/atoms';
import AppIcon from '@src/ui_kit/components/appIcons/AppIcon';
import APP_ICON_NAMES from '@src/ui_kit/components/appIcons/iconNames';
import React from 'react';
import {Pressable} from 'react-native';
const Info = ({productData}: {productData: TProductDetail}) => {
  console.log('productData', productData);
  const {navigate} = useNavigation();

  const screenParams = {
    shopID: productData?.shop?.id,
    geohash: '',
  };

  const _handleOnShopPress = () => {
    navigate(ScreensList.ShopDetail, screenParams);
  };

  return (
    <Box mx={'_s16'} mt={'_s16'}>
      <Text variant={'body2.regular.14'}>{productData?.brandName ?? ''}</Text>
      <Text variant={'body2.regular.22'} lineHeight={30} fontSize={20}>
        {productData?.productName ?? ''}
      </Text>
      <Text variant={'body2.regular.14'} my={'_s16'} color={'gray1'}>
        {productData?.description ?? ''}
      </Text>
      <Box mb={'_s32'} flexDirection="row" alignItems="center">
        <Text variant={'heading4.30'} lineHeight={45}>
          ₹ {productData?.price ?? ''}
        </Text>
        <Box width={0.3} height={24} mx={'_s24'} bg={'gray1'} />
        <Text variant={'body1.regular.16'}>
          Quantity{' '}
          <Text variant={'body1.regular.16'} color={'gray1'}>
            {productData?.quantity ?? ''}
          </Text>
        </Text>
        {/* <Text variant={'body1.regular.16'} ml={'_s32'}>
          Pc{' '}
          <Text variant={'body1.regular.16'} color={'gray1'}>
            2
          </Text>
        </Text> */}
      </Box>
      <Pressable onPress={_handleOnShopPress}>
        <Box
          p={'_s20'}
          borderColor={'lightWhite'}
          borderWidth={1}
          borderRadius={16}>
          <Text variant={'body2.regular.14'} fontSize={15} color={'gray1'}>
            {productData?.shop?.name ?? ''}
          </Text>
          <Box mt={'_s4'}>
            <Box flexDirection="row" alignItems="center">
              <Box width={40} height={40} bg={'gray1'} borderRadius={12} />
              <Text
                ml={'_s8'}
                color={'black'}
                variant={'body3.regular.18'}
                lineHeight={27}>
                {productData?.shop?.bio ?? ''}
              </Text>
            </Box>
          </Box>
          <Box mt={'_s16'} flexDirection="row">
            <Box>
              <AppIcon name={APP_ICON_NAMES.LocationOutline} />
            </Box>
            <Box ml={'_s4'}>
              <Text variant={'body3.regular.12'} lineHeight={16}>
                2.8 km
              </Text>
              <Text
                variant={'body3.regular.12'}
                lineHeight={16}
                color={'gray1'}>
                {productData?.shop?.address ?? ''}
              </Text>
            </Box>
          </Box>
        </Box>
      </Pressable>
    </Box>
  );
};
export default Info;
