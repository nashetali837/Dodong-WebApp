import {Box} from '@src/ui_kit/atoms';
import AppIcon from '@src/ui_kit/components/appIcons/AppIcon';
import APP_ICON_NAMES from '@src/ui_kit/components/appIcons/iconNames';
import GradientButton from '@src/ui_kit/components/buttons/gradientButton';
import React from 'react';

const DetailFooter = () => {
  const _handleOnBuyNiw = () => {};

  return (
    <Box
      flexDirection="row"
      p={'_s24'}
      pt={'_s12'}
      borderTopWidth={1}
      borderColor={'lightWhite'}>
      <Box
        flex={0.8}
        flexDirection="row"
        justifyContent="center"
        alignItems="center"
        mr={'_s8'}>
        <Box
          borderColor={'lightWhite'}
          borderRadius={16}
          mr={'_s8'}
          p={'_s16'}
          borderWidth={1}>
          <AppIcon name={APP_ICON_NAMES.LikeBlack} size={28} />
        </Box>
        <Box
          borderColor={'lightWhite'}
          borderRadius={16}
          p={'_s16'}
          borderWidth={1}>
          <AppIcon name={APP_ICON_NAMES.Cart} size={28} color={'transparent'} />
        </Box>
      </Box>
      <Box flex={1.2}>
        <GradientButton text="Buy Now" onPress={_handleOnBuyNiw} />
      </Box>
    </Box>
  );
};

export default DetailFooter;
