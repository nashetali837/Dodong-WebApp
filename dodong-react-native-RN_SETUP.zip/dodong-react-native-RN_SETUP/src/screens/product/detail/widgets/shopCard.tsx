import {useNavigation} from '@react-navigation/native';
import {ScreensList} from '@src/routes/helpers';
import {Box, Text} from '@src/ui_kit/atoms';
import AppIcon from '@src/ui_kit/components/appIcons/AppIcon';
import APP_ICON_NAMES from '@src/ui_kit/components/appIcons/iconNames';
import React from 'react';
import {Image, Pressable} from 'react-native';
const Card = ({item}) => {
  console.log('item', item);

  const {push} = useNavigation();

  const _handleOnCardPress = () => {
    push(ScreensList.ShopDetail, {
      shopId: item?.shopID ?? null,
      geohash: item?.geohash ?? '',
    });
  };

  return (
    <Pressable onPress={_handleOnCardPress}>
      <Box
        width={212}
        height={260}
        borderRadius={16}
        mr={'_s24'}
        overflow={'hidden'}
        borderWidth={1}
        borderColor={'lightWhite'}>
        <Image
          source={{
            uri: 'https://w0.peakpx.com/wallpaper/18/968/HD-wallpaper-zoro-luffy-one-piece-zoro.jpg',
          }}
          style={{width: '100%', height: 175}}
        />
        <Box p={'_s16'}>
          <Text numberOfLines={1} variant={'body2.semiBold.14'}>
            {item?.name ?? ''}
          </Text>

          <Box flexDirection="row">
            <Box>
              <AppIcon name={APP_ICON_NAMES.LocationOutline} />
            </Box>
            <Box ml={'_s4'}>
              <Text
                numberOfLines={2}
                variant={'body3.regular.12'}
                lineHeight={16}
                color={'gray1'}>
                {item?.address ?? ''}
              </Text>
            </Box>
          </Box>
        </Box>
      </Box>
    </Pressable>
  );
};

export default Card;
