import {useNavigation} from '@react-navigation/native';
import {ScreensList} from '@src/routes/helpers';
import {Box, Text} from '@src/ui_kit/atoms';
import AppIcon from '@src/ui_kit/components/appIcons/AppIcon';
import APP_ICON_NAMES from '@src/ui_kit/components/appIcons/iconNames';
import React from 'react';
import {Image, Pressable} from 'react-native';
const Card = ({item}) => {
  const {push} = useNavigation();

  const _handleOnCardPress = () => {
    push(ScreensList.ShopDetail, {
      shopId: item?.shopID ?? null,
      geohash: item?.geohash ?? '',
    });
  };

  return (
    <Pressable onPress={_handleOnCardPress}>
      <Box
        width={330}
        borderRadius={16}
        mr={'_s24'}
        overflow={'hidden'}
        borderWidth={1}
        borderColor={'lightWhite'}>
        <Image
          source={{
            uri: 'https://w0.peakpx.com/wallpaper/18/968/HD-wallpaper-zoro-luffy-one-piece-zoro.jpg',
          }}
          style={{width: '100%', height: 175}}
        />
        <Box p={'_s16'} pt={'_s8'}>
          <Text color={'gray1'} variant={'body3.regular.12'}>
            {item?.bio ?? ''}
          </Text>
          <Text>{item?.name ?? ''}</Text>

          {/* <Box mt={'_s8'} flexDirection="row" alignItems="center">
            <Box
              flexDirection="row"
              alignItems="center"
              justifyContent="space-between">
              <Text variant={'body3.semiBold.18'} lineHeight={27}>
                60.00
              </Text>
              <Box width={0.3} height={24} mx={'_s16'} bg={'gray1'} />
              <Text variant={'body2.regular.14'}>
                Quantity{' '}
                <Text variant={'body2.regular.14'} color={'gray1'}>
                  20
                </Text>
              </Text>
              <Text variant={'body2.regular.14'} ml={'_s32'}>
                KG{' '}
                <Text variant={'body2.regular.14'} color={'gray1'}>
                  2
                </Text>
              </Text>
            </Box>
            <Box ml={'_s36'}>
              <AppIcon name={APP_ICON_NAMES.Filter} size={24} />
            </Box>
          </Box> */}
        </Box>
      </Box>
    </Pressable>
  );
};

export default Card;
