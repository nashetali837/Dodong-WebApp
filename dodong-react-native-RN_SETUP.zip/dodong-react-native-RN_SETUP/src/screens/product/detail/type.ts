export enum SHOP_DETAILS {
  Gallery = 'gallery',
  Info = 'info',
  NearByShops = 'nearByShops',
  SimilarShops = 'similarShops',
  ProductsBySameUser = 'productsBySameUser',
}

export const ShopDetailViewMap: string[] = [
  SHOP_DETAILS.Gallery,
  SHOP_DETAILS.Info,
  SHOP_DETAILS.NearByShops,
  SHOP_DETAILS.SimilarShops,
  SHOP_DETAILS.ProductsBySameUser,
];
