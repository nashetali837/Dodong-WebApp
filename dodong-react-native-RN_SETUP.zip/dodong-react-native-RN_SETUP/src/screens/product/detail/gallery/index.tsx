import {useNavigation} from '@react-navigation/native';
import {TProductDetail} from '@src/core/api/services/schema.type';
import {ScreensList} from '@src/routes/helpers';
import {Box, Text} from '@src/ui_kit/atoms';
import ImageGallery from '@src/ui_kit/components/imageGallery';
import {dimensions} from '@src/utilities/helpers';
import React from 'react';
import {Pressable} from 'react-native';
const ShopGallery = ({productData}: {productData: TProductDetail}) => {
  const {navigate} = useNavigation();
  const images = productData?.images ?? [];

  // const _handleOnPostPress = () => {
  //   navigate(ScreensList.PostDetail, {postId: id});
  // };

  return (
    <Box>
      <ImageGallery
        images={images}
        imageContainerStyles={{width: dimensions.screenWidth, height: 440}}
        indicatorStyles={{
          right: dimensions.screenWidth / 3,
        }}
      />
      {/* <Pressable onPress={_handleOnPostPress}>
        <Box
          position="absolute"
          zIndex={100}
          bottom={20}
          right={24}
          bg={'white'}
          borderRadius={8}
          p={'_s8'}>
          <Text variant={'body3.regular.12'}>View Post</Text>
        </Box>
      </Pressable> */}
    </Box>
  );
};
export default ShopGallery;
