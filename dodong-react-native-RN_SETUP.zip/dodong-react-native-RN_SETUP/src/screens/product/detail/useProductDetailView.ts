import {TViewComponents} from '@src/screens/type';
import {SHOP_DETAILS} from './type';
import ShopGallery from './gallery';
import Info from './info';
import NearByShops from './nearByShops';
import SimilarShops from './similarShops';
import ProductsBySameUser from './productBySameUser';
import {useProductData} from './useProductData';

export const useShopDetailView = ({
  productID,
  shopID,
  geohash,
}: {
  productID: string;
  shopID: string;
  geohash: string;
}) => {
  const {productData, loading} = useProductData({productID});
  const ViewComponents: TViewComponents = {
    [SHOP_DETAILS.Gallery]: {
      component: ShopGallery,
      props: {productData},
    },
    [SHOP_DETAILS.Info]: {
      component: Info,
      props: {productData},
    },
    [SHOP_DETAILS.NearByShops]: {
      component: NearByShops,
      props: {shopID, geohash},
    },
    [SHOP_DETAILS.SimilarShops]: {
      component: SimilarShops,
      props: {shopID, geohash},
    },
    [SHOP_DETAILS.ProductsBySameUser]: {
      component: ProductsBySameUser,
      props: {},
    },
  };
  return {
    ViewComponents,
    productData,
    loading,
  };
};
