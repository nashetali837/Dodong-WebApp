import {Box, Text} from '@src/ui_kit/atoms';
import React, {useCallback} from 'react';
import {FlatList} from 'react-native';

import {theme} from '@src/ui_kit/theme';
import Card from '../widgets/shopCard';
import {useNearbyShops} from '../nearByShops/useNearbyShops';

const data = [1, 2, 3, 4, 5];

const SimilarShops = ({shopID, geohash}: {shopID: number; geohash: string}) => {
  const {shopData} = useNearbyShops({shopID, geohash});

  const _renderItem = useCallback(({item}) => {
    return <Card item={item} />;
  }, []);

  return (
    <Box>
      <Text mt={'_s32'} mb={'_s16'} ml={'_s16'}>
        Similar Shops nearby
      </Text>
      <FlatList
        horizontal
        contentContainerStyle={{paddingLeft: theme.size.SIXTEEN}}
        showsHorizontalScrollIndicator={false}
        data={shopData}
        renderItem={_renderItem}
        keyExtractor={_keyExtractor}
        initialNumToRender={3}
      />
    </Box>
  );
};
export default SimilarShops;

const _keyExtractor = (_, index: number) => `card${index}`;
