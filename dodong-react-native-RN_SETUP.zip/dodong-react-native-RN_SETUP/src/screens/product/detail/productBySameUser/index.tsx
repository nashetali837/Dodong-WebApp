import {Box, Text} from '@src/ui_kit/atoms';
import React, {useCallback} from 'react';
import {FlatList} from 'react-native';

import {theme} from '@src/ui_kit/theme';
import Card from '../widgets/productCard';

const data = [1, 2, 3, 4, 5];

const ProductsBySameUser = ({item, index}) => {
  const _renderItem = useCallback(({item}) => {
    return <Card />;
  }, []);

  return (
    <Box>
      <Text mt={'_s32'} mb={'_s16'} ml={'_s16'}>
        Products used by the same user
      </Text>
      <FlatList
        horizontal
        contentContainerStyle={{paddingLeft: theme.size.SIXTEEN}}
        showsHorizontalScrollIndicator={false}
        data={data}
        renderItem={_renderItem}
        keyExtractor={_keyExtractor}
        initialNumToRender={3}
      />
    </Box>
  );
};
export default ProductsBySameUser;

const _keyExtractor = (_, index: number) => `card${index}`;
