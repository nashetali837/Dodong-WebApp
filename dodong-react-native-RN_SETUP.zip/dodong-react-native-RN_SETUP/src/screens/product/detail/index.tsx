import {Box} from '@src/ui_kit/atoms';
import React, {useCallback, useEffect} from 'react';
import {AnimatedFlatList} from '@src/ui_kit/atoms/animated/helper';
import {ShopDetailViewMap} from './type';
import useCustomScrollHandler from '@src/hooks/scrollHandler/useCustomScrollHandler';
import {useShopDetailView} from './useProductDetailView';
import DetailFooter from './footer';
import Toast from 'react-native-simple-toast';
import {TouchableOpacity} from 'react-native';
import {theme} from '@src/ui_kit/theme';
import APP_ICON_NAMES from '@src/ui_kit/components/appIcons/iconNames';
import AppIcon from '@src/ui_kit/components/appIcons/AppIcon';

const ProductDetailScreen = ({...props}) => {
  const {productID = null, geohash = '', shopID} = props?.route?.params ?? {};
  const {
    navigation: {goBack},
  } = props;
  const {ViewComponents, loading, productData} = useShopDetailView({
    productID,
    shopID,
    geohash,
  });

  const _handleBack = () => goBack();

  const {
    itemViewabilityConfigRef,
    handleViewableItemsChanged,
    animatedScrollHandler,
  } = useCustomScrollHandler({
    viewPortIndex: 5,
    isBottomTabsVisible: true,
  });

  useEffect(() => {
    if (!productID) {
      goBack();
      Toast.show('Oops Could not fetch Shop details', Toast.LONG);
    }
  }, [productID]);

  const _renderItem = useCallback(
    ({item}) => {
      const viewComponent = ViewComponents[item];
      if (viewComponent) {
        const {component: Component, props} = viewComponent;
        return <Component {...props} />;
      }
      return <></>;
    },
    [productData],
  );

  return (
    <Box flex={1} bg={'white'}>
      <TouchableOpacity
        style={{position: 'absolute', zIndex: 100}}
        onPress={_handleBack}>
        <Box
          top={50}
          left={theme.size.TWENTY_FOUR}
          bg={'gray1'}
          borderRadius={24}
          justifyContent="center"
          alignItems="center"
          width={theme.size.FOURTY_EIGHT}
          height={theme.size.FOURTY_EIGHT}>
          <AppIcon name={APP_ICON_NAMES.BackArrow} color="white" />
        </Box>
      </TouchableOpacity>
      <AnimatedFlatList
        data={ShopDetailViewMap}
        renderItem={_renderItem}
        keyExtractor={_keyExtractor}
        showsVerticalScrollIndicator={false}
        contentContainerStyle={{paddingBottom: 44}}
        onScroll={animatedScrollHandler}
        viewabilityConfig={itemViewabilityConfigRef.current}
        onViewableItemsChanged={handleViewableItemsChanged.current}
        initialNumToRender={3}
      />
      <DetailFooter />
    </Box>
  );
};
export default ProductDetailScreen;

const _keyExtractor = (item: string) => `detail_key_${item}`;
