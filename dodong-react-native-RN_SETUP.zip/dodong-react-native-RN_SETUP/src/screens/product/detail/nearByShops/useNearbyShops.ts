import storeService from '@src/core/api/services/StoreService';
import {useEffect, useState} from 'react';

export const useNearbyShops = ({
  shopID,
  geohash,
}: {
  shopID: number;
  geohash: string;
}) => {
  const [loading, setLoading] = useState<boolean>(true);
  const [shopData, setShopData] = useState([]);

  const fetchNearByShops = async () => {
    setLoading(true);
    const resp = await storeService.getNerbyShopById(shopID, geohash);
    if (resp?.data?.shop) {
      setShopData(resp?.data?.shop);
    }
    setLoading(false);
  };

  useEffect(() => {
    fetchNearByShops();
  }, []);

  return {
    shopData,
    loading,
  };
};
