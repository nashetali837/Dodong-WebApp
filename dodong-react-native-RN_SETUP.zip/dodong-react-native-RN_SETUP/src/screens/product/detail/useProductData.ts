import storeService from '@src/core/api/services/StoreService';
import {useEffect, useState} from 'react';

export const useProductData = ({productID}: {productID: string}) => {
  const [loading, setLoading] = useState<boolean>(true);
  const [productData, setProductData] = useState(null);

  const fetchDetails = async () => {
    setLoading(true);
    const resp = await storeService.getProductById(productID);
    if (resp?.data?.product) {
      setProductData(resp.data.product);
    }
    setLoading(false);
  };

  useEffect(() => {
    fetchDetails();
  }, []);

  return {
    productData,
    loading,
  };
};
