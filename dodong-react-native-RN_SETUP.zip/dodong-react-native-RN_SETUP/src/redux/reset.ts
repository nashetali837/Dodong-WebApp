export const RESET_STORE = 'RESET_STORE';
export const resetStore = () => ({
  type: RESET_STORE,
});
