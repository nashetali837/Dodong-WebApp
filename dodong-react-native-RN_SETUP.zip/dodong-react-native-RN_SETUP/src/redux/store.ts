import AsyncStorage from '@react-native-async-storage/async-storage';
import {
  combineReducers,
  configureStore,
  getDefaultMiddleware,
} from '@reduxjs/toolkit';
import {useDispatch} from 'react-redux';

import {persistReducer, persistStore} from 'redux-persist';
import {AppSlice} from './app';

import {AuthSlice} from './auth';
import {HomeSlice} from './home';

const middlewares = [
  ...getDefaultMiddleware({
    serializableCheck: false,
    immutableCheck: false,
  }),
];

if (__DEV__) {
  const createDebugger = require('redux-flipper').default;
  middlewares.push(createDebugger());
}

const persistAppReducerConfig = {
  key: 'app',
  storage: AsyncStorage,
};

const persistAuthReducerConfig = {
  key: 'auth',
  storage: AsyncStorage,
};

const persistHomeReducerConfig = {
  key: 'home',
  storage: AsyncStorage,
};

const reducer = combineReducers({
  auth: persistReducer(persistAuthReducerConfig, AuthSlice.reducer),
  app: persistReducer(persistAppReducerConfig, AppSlice.reducer),
  home: persistReducer(persistHomeReducerConfig, HomeSlice.reducer),
});

const store = configureStore({
  reducer,
  middleware: middlewares,
});

export type RootState = ReturnType<typeof reducer>;

export type AppDispatch = typeof store.dispatch;

export const useAppDispatch = () => useDispatch<AppDispatch>();

export const dispatch = store?.dispatch;
export const persistedStore = persistStore(store);

export default store;
