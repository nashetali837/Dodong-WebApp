import {createSlice} from '@reduxjs/toolkit';
import {RESET_STORE} from '../reset';

import * as AppThunk from './appThunk';
import {TLocation} from '@src/screens/locations/manual/type';
import {AppInitialState, TAppConfig} from './type';

const defaultLocation = {
  formatted_address: 'Location',
  geometry: {
    location: {
      lat: null,
      lng: null,
    },
  },
  place_id: '',
  vicinity: '',
  address_components: [],
};

const initialAppState: AppInitialState = {
  isOnboardingDone: false,
  searchedLocations: [],
  currentLocation: defaultLocation,
  appConfig: {
    allowedRegion: [],
    popularTags: [],
    resourceTypes: [],
    topCategories: [],
  },
};

export const AppSlice = createSlice({
  name: 'app',
  initialState: initialAppState,
  reducers: {
    setOnboardingVisited: (state, {payload}: {payload: boolean}) => {
      state.isOnboardingDone = payload;
    },

    setAppConfig: (state, {payload}: {payload: TAppConfig}) => {
      state.appConfig = payload;
    },

    setUserCurrentLocation: (state, {payload}: {payload: TLocation}) => {
      state.currentLocation = payload;
    },

    updateSearchedLocations: (state, {payload}: {payload: TLocation}) => {
      if (
        state.searchedLocations.findIndex(
          (location: TLocation) => location?.place_id === payload?.place_id,
        ) === -1
      ) {
        state.searchedLocations.push(payload);
      }
    },
  },
  extraReducers: builder => {
    builder.addCase(RESET_STORE, () => initialAppState);
  },
});

export {AppThunk};
