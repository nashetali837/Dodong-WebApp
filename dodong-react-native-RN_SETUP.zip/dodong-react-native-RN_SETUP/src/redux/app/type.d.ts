import {TLocation} from '@src/screens/locations/manual/type';

type AppInitialState = {
  isOnboardingDone: boolean;
  searchedLocations: Array;
  appConfig: TAppConfig;
  currentLocation: TLocation;
};

type TAppConfig = {
  allowedRegion: [];
  popularTags: [];
  resourceTypes: [];
  topCategories: [];
};
