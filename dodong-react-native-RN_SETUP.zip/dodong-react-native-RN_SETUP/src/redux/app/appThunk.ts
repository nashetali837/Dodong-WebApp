import {MasterDataService} from '@apis/services';
import {createAsyncThunk} from '@reduxjs/toolkit';

export const getAllLocations = createAsyncThunk(
  'app/getAllLocations',
  async (_, {rejectWithValue, dispatch}) => {
    try {
      const data = await MasterDataService.getLocations();
    } catch (e) {
      return rejectWithValue(e);
    }
  },
);
