import AsyncStorage from '@react-native-async-storage/async-storage';
import {createAsyncThunk} from '@reduxjs/toolkit';
import authService from '@api/services/AuthService';
import appConstants from '@src/core/api/appContstants';

export const getAuthToken = createAsyncThunk('auth/getToken', async data => {
  try {
    const response = await authService.getAuthToken(data);
    if (response?.data?.token) {
      await AsyncStorage.setItem(appConstants.token, response?.data.token);
    }

    return response.data;
  } catch (error) {
    console.log('error', error);
    throw error;
  }
});

export default {
  getAuthToken,
};
