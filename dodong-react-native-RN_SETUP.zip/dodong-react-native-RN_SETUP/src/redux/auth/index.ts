import {createSlice} from '@reduxjs/toolkit';

import AuthThunk from './authThunk';
import {AuthInitialState, PayloadType} from '../auth/type';
import {RESET_STORE} from '../reset';

export const initialState: AuthInitialState = {
  token: null,
  isFetching: false,
  error: '',
  userData: null,
};

const authSlice = createSlice({
  name: 'auth',
  initialState,
  reducers: {
    setToken: (state, action: PayloadType) => {
      state.token = action.payload.access_token;
    },
    setUserData: (state, action: PayloadType) => {
      state.userData = action.payload;
    },
  },

  extraReducers: builder => {
    builder.addCase(RESET_STORE, () => initialState);
    builder.addCase(
      AuthThunk?.getAuthToken?.fulfilled,
      (state, action: PayloadType) => {
        state.token = action.payload?.access_token;
        state.error = '';
        state.isFetching = false;
      },
    ),
      builder.addCase(
        AuthThunk?.getAuthToken?.pending,
        (state, action: PayloadType) => {
          state.token = action.payload?.access_token;
          state.error = '';
          state.isFetching = false;
        },
      ),
      builder.addCase(
        AuthThunk?.getAuthToken?.rejected,
        (state, action: PayloadType) => {
          state.error =
            action.payload?.errorMessage ||
            action.payload?.data?.message ||
            'Something went wrong';
          state.isFetching = false;
        },
      );
  },
});
export {authSlice as AuthSlice, AuthThunk};
