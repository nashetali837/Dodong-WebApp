type AuthInitialState = {
  token: string | null;
  isFetching: boolean;
  error: string;
  userData: null | TUserData;
};

type payload = {
  access_token: string;
};
interface PayloadType {
  payload: payload & ErrorResponse;
}
interface SupportPayloadType {
  payload: {authData: payload & ErrorResponse; isSupportCalled: boolean};
}

export type TUserDataProfile = {
  LinkedInURL: string | null;
  avatar: string | null;
  bio: string;
  createdAt: string;
  dateOfBirth: string | null;
  displayName: string;
  facebookURL: string | null;
  followers: number;
  following: number;
  id: number;
  locationId: string | null;
  name: string;
  occupation: string | null;
  totalPosts: number;
  twitterHandle: string | null;
  updatedAt: string;
  userID: number;
};

export type TUserDataProfileCompletion = {
  nextStep: string;
  percent: number;
};

export type TUserDataUser = {
  createdAt: string;
  email: string;
  emailVerified: boolean;
  id: number;
  isActive: boolean;
  lastLogin: string;
  mobileNumber: string;
  mobileNumberVerified: boolean;
  userTypeID: number;
};

export type TUserDataProfessional = {
  occupationType: string;
  companyName: string;
  officialMobileNumber: string;
  brandDetails: string;
  others: string;
  jobLocation: string;
};

export type TUserData = {
  professional?: TUserDataProfessional;
  profile: TUserDataProfile;
  user?: TUserDataUser;
  status?: string;
  profileCompletion: TProfileCompletion;
};
