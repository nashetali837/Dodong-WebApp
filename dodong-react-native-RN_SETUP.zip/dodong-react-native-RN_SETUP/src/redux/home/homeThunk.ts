import {createAsyncThunk} from '@reduxjs/toolkit';
import storeService from '@src/core/api/services/StoreService';

export const getStoreFrontList = createAsyncThunk(
  'home/getStoreFrontList',
  async (data, {rejectWithValue}) => {
    try {
      console.log('try', data);
      const response = await storeService.getStoreFrontList(data.page);
      return response.data;
    } catch (e) {
      return rejectWithValue(e);
    }
  },
);
