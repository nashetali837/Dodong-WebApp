type HomeInitialState = {
  storeFront: TStoreFront;
};

type TCategory = {
  id: number;
  name: string;
  displayName: string;
};

type TLocalShop = {
  address: string;
  bio: string;
  categoryId: number;
  contact: string;
  email: string;
  id: number;
  locationId: number;
  name: string;
  subCategoryId: number;
  updatedAt;
  website: string;
};

type TSubCategory = {
  id: number;
  name: string;
  categoryId: number;
  displayName: string;
};

type TResourcePost = {
  authorId: number;
  body: string;
  categoryId: number;
  id: number;
  liked: boolean;
  locationsId: number;
  post: {imageURL: string[]; description: ''; liked: boolean};
  shop: {shopID: number};
  geohash: string;
  productId: number;
  product: {price: number; productName: string};
  profile: any;
  published: boolean;
  rating: number;
  shopId: number;
  shopURL: string;
  subCategoryId: number;
  title: string;
  type: string;
  userMeasurementId: number;
  author: TAuthor;
  resourceID: number;
  productID: number;
  shopID: number;
};

type TAuthor = {
  avatar: string;
  displayName: string;
  id: number;
  name: string;
  userProfilePicture?: string;
};

type TStoreResource = {
  Locations: {country: null; geohash: null; name; state: null};
  ResourceCategories: [];
  ResourceMedia: [];
  author: TAuthor;
  authorID: number;
  geohash: string;
  isActive: true;
  liked: true;
  post: Record;
  product: Record;
  productID: number;
  profile: Record;
  resourceID: number;
  resourceType: number;
  shop: TLocalShop;
  shopID: number;
  shopURL: string;
};

type TStoreFront = {
  loading?: boolean;
  resources?: TStoreResource[];
  totalPosts?: number;
  page?: number;
};
