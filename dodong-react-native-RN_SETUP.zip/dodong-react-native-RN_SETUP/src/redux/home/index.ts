import {createSlice} from '@reduxjs/toolkit';
import {RESET_STORE} from '../reset';

import * as HomeThunk from './homeThunk';
import {PayloadType} from '../auth/type';

const initialState: HomeInitialState = {
  storeFront: {
    loading: true,
    resources: [],
    totalPosts: 0,
    page: 1,
  },
};

export const homeSlice = createSlice({
  name: 'home',
  initialState: initialState,
  reducers: {},
  extraReducers: builder => {
    builder.addCase(RESET_STORE, () => initialState),
      builder.addCase(
        HomeThunk?.getStoreFrontList?.fulfilled,
        (state, action: PayloadType) => {
          state.storeFront = action.payload;
          state.storeFront.loading = false;
        },
      ),
      builder.addCase(
        HomeThunk?.getStoreFrontList?.pending,
        (state, action: PayloadType) => {
          state.storeFront.loading = true;
        },
      ),
      builder.addCase(
        HomeThunk?.getStoreFrontList?.rejected,
        (state, action: PayloadType) => {
          state.storeFront.loading = true;
        },
      );
  },
});

export {homeSlice as HomeSlice, HomeThunk};
