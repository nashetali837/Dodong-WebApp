import {AxiosError} from 'axios';

export interface ErrorResponse {
  status?: string;
  errorMessage: string;
  code?: string;
  data: any;
  success: false;
}
export interface ServerError {
  code: string;
  success: false;
  data: any;
  message: string;
}
export class APIError extends Error {
  data: ErrorResponse;
  constructor(error: AxiosError) {
    super(error?.message ?? '');
    this.data = this.parseErrorData(error);
  }
  public parseErrorData(errResp: AxiosError<ServerError>) {
    const errorData: ErrorResponse = {
      errorMessage: errResp?.message ?? '',
      success: false,
      data: null,
    };
    if (errResp?.response) {
      errorData.status = `${errResp.response?.status || errResp.code}`;
      errorData.errorMessage =
        errResp.response?.data?.message || errResp.message;
      errorData.code = errResp.response?.data.code || errResp.code;
      errorData.data = errResp?.data || null;
    } else if (errResp?.request) {
      errorData.status = errResp.request?.status;
      errorData.errorMessage = errResp.request?.data;
      errorData.code = errResp.request?.code;
      errorData.data = errResp?.data || null;
    } else {
      errorData.status = (errResp?.code || errResp?.status) ?? '500';
    }
    return errorData;
  }
}
