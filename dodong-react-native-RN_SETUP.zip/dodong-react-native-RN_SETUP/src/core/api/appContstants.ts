export default {
  token: 'AUTH-TOKEN',
  refreshToken: 'REFRESH-TOKEN',
};
