import axios, {AxiosError, AxiosInstance, AxiosResponse} from 'axios';
import config from '@src/config';
import {store} from '@redux';
import {APIError} from '../model';

export declare type Headers = {
  authorization?: string;
  Authorization?: string;
  extraHeaders?: any;
};

export type Config = {
  baseUrl: string;
  headers?: Headers;
};

export interface ResponseBody<T> {
  status: number;
  data: T;
  success: boolean;
  errorMessage?: string | undefined;
}

export default abstract class BaseApi {
  public api: AxiosInstance;
  constructor() {
    this.api = axios.create({
      baseURL: config.baseUrl,
      withCredentials: true,
    });
    this.applyRequestInterceptor(this.api);
  }

  private applyRequestInterceptor(axiosIns: AxiosInstance) {
    axiosIns.interceptors.request.use(async reqConfig => {
      const {auth} = store.getState();
      let token = auth?.token;
      if (token?.length) {
        reqConfig.headers.Authorization = `Bearer ${token || ''}`;
      }
      return reqConfig;
    });
  }

  protected abstract getExtraHeaders(): Headers;

  private _prepareHeaders(inlineHeaders: any = {}) {
    const {extraHeaders = {}, ...headers} = this.getExtraHeaders();
    return {...headers, ...extraHeaders, ...inlineHeaders};
  }

  protected getStatusCode(resp: AxiosResponse | AxiosError): number {
    let resultResp: AxiosResponse<any>;

    const failureResp = resp as AxiosError;

    if (failureResp?.response?.status) {
      resultResp = failureResp.response;
    } else if (failureResp?.request?.status) {
      resultResp = failureResp.request.status;
    } else {
      resultResp = resp as AxiosResponse;
    }

    return resultResp?.status;
  }

  protected handleResponse(resp: AxiosResponse) {
    console.info(
      `%c RESPONSE ${resp?.config?.url}`,
      'color: white; background-color: green',
      resp,
    );
    const result = {
      data: resp?.data,
      status: resp?.status,
      success: true,
    };
    return result;
  }

  protected handleFailure(errResp: AxiosError): any {
    console.info(
      '%c ERROR ',
      'color: white; background-color: #FF0000',
      errResp,
    );
    const errorCode = this.getStatusCode(errResp);
    if (errorCode === 401) {
      //   this.callback?.();
    }
    if (errorCode === 404 || errorCode === 400) {
    }
    throw new APIError(errResp);
  }

  protected async post<T>(
    endpoint: string,
    data?: any,
    inlineHeader?: any,
  ): Promise<ResponseBody<T>> {
    try {
      const resp = await this.api.post(endpoint, data, {
        headers: this._prepareHeaders(inlineHeader),
      });
      return this.handleResponse(resp);
    } catch (err) {
      return this.handleFailure(err);
    }
  }

  protected async get(
    endpoint: string,
    data?: {params?: any; inlineHeader?: any},
  ) {
    const {inlineHeader = {}, params} = data ?? {};
    try {
      const resp = await this.api.get(endpoint, {
        headers: this._prepareHeaders(inlineHeader),
        params,
      });
      return this.handleResponse(resp);
    } catch (err) {
      return this.handleFailure(err);
    }
  }
}
