import config from '@src/config';
import BaseApi from '../index';
import {
  TLoginData,
  TUpdateProfessionalProfile,
  TUpdateProfile,
  TUserRegister,
  TVerifyEmailData,
  TVerifyEmailOtp,
} from './schema.type';

class AuthService extends BaseApi {
  protected getExtraHeaders(): Headers {
    return {};
  }

  getAppConfig() {
    return this.get(config.endPoints.appConfig);
  }

  getAuthToken(data: TLoginData) {
    return this.post(config.endPoints.login, data);
  }
  getUserProfile(token: string) {
    return this.get(config.endPoints.profile, {
      inlineHeader: {Authorization: `Bearer ${token}`},
    });
  }

  getPublicUserProfile(profileId: number, token: string) {
    return this.get(`${config.endPoints.profile}/${profileId}`, {
      inlineHeader: {Authorization: `Bearer ${token}`},
    });
  }

  getEmailVerified(data: TVerifyEmailData) {
    return this.post(config.endPoints.verifyEmail, data);
  }

  verifyEmailOtp(data: TVerifyEmailOtp) {
    return this.post(config.endPoints.verifyEmailOtp, data);
  }

  getUserRegistered(data: TUserRegister, token: string) {
    return this.post(config.endPoints.registerUser, data, {
      Authorization: `Bearer ${token}`,
    });
  }

  updateUserProfile(token: string, data: TUpdateProfile) {
    console.log('token', token);
    return this.post(config.endPoints.updateProfile, data, {
      Authorization: `Bearer ${token}`,
    });
  }

  updateUserProfessionalProfile(
    token: string,
    data: TUpdateProfessionalProfile,
  ) {
    console.log('token', token);
    return this.post(config.endPoints.updateProfessionalProfile, data, {
      Authorization: `Bearer ${token}`,
    });
  }
}

const authService = new AuthService();
export default authService;
