import config from '@src/config';
import BaseApi from '../index';
import {TImageUploadData} from './schema.type';

class UploadService extends BaseApi {
  protected getExtraHeaders(): Headers {
    return {};
  }

  uploadImageToServer = (data: TImageUploadData, token?: string) => {
    return this.post(config.endPoints.imageUpload, data, {
      Authorization: `Bearer ${token}`,
      'Content-Type': 'multipart/form-data',
    });
  };
}

const uploadService = new UploadService();
export default uploadService;
