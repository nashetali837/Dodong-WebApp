import config from '@src/config';
import BaseApi from '../index';
import {TLocationUpdateData} from './schema.type';

class LocationService extends BaseApi {
  protected getExtraHeaders(): Headers {
    return {};
  }

  updateUserLocation(token: string, data: TLocationUpdateData) {
    return this.post(config.endPoints.updateLocation, data, {
      Authorization: `Bearer ${token}`,
    });
  }
}

const locationService = new LocationService();
export default locationService;
