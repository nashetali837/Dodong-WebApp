import config from '@src/config';
import BaseApi from '../index';

class NotificationService extends BaseApi {
  protected getExtraHeaders(): Headers {
    return {};
  }

  getUserNotification(page = 1) {
    return this.get(`${config.endPoints.notificationList}page=${page}`);
  }
}

const notificationService = new NotificationService();
export default notificationService;
