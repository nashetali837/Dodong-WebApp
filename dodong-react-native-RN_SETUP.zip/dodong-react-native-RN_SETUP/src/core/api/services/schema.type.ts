export type TLoginData = {
  email: string;
  pass: string;
};

export type TGoogleLoginData = {
  tokenId: string;
};

export type TVerifyEmailData = {
  email: string;
  mobileNumber: string;
};

export type TUserRegister = {
  password: string;
  name: string;
};

export type TVerifyEmailOtp = {
  email: string;
  OTP: string | number;
};

export type TUpdateProfile = {
  userId: number;
  name: string;
  displayName: string;
  occupation: string;
  bio: string;
  dateOfBirth: null;
  avatar: string;
  facebookURL: string;
  LinkedInURL: string;
  twitterHandle: string;
  locationId: null;
};

export type TUpdateProfessionalProfile = {
  brandDetails: string;
  jobLocation: string;
  company: string;
  occupation: string;
  others: string;
  name: string;
  officialMobileNumber: number;
};

export type TLocationUpdateData = {
  latitude: number;
  longitude: number;
  name: string;
  state: string;
  country: string;
};

export type TImageUploadData = {
  name: string;
  type: string;
  uri: string;
};

export type TResourceDetail = {
  addedToFavorites: false;
  alreadyLiked: false;
  alreadySaved: false;
  author: TAuthor;
  categories: TCategory[];
  location: Object;
  mediaURLs: [];
  resourceDetails: {
    body: string;
    id: number;
    published: boolean;
    rating: number;
    resourceID: number;
    title: null;
    userMeasurementId: number;
  };
  resourceID: 10;
  resourceType: 'POST';
  shop: any;
  stats: TStats;
  subCategories: TSubCategory[];
};

export type TStats = {
  likes: number;
  comments: number;
  shares: number;
};

export type TProductDetail = {
  author: Object;
  authorID: number;
  brandName: string;
  description: string;
  price: number;
  productID: number;
  productName: string;
  published: boolean;
  quantity: number;
  shop: TLocalShop;
  shopID: string;
  size: string;
  weight: number;
};
