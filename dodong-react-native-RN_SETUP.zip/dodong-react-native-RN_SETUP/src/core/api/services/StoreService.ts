import config from '@src/config';
import BaseApi from '../index';
import {RESOURCE_TYPES} from '@src/constants/Enums';

class StoreService extends BaseApi {
  protected getExtraHeaders(): Headers {
    return {};
  }

  getStoreFrontList(page = 1, type = RESOURCE_TYPES.POST) {
    return this.get(
      `${config.endPoints.storeFront}&page=${page}&type=${type.toLowerCase()}`,
    );
  }

  getShopById(shopId: string) {
    return this.get(`${config.endPoints.shopDetail}/${shopId}`);
  }

  getProductById(productId: string) {
    return this.get(`${config.endPoints.productDetail}productID=${productId}`);
  }

  getNerbyShopById(shopID: string, geohash: string) {
    return this.get(
      `${config.endPoints.nearbyShops}?shopID=${shopID}&geohash=${geohash}`,
    );
  }
}

const storeService = new StoreService();
export default storeService;
