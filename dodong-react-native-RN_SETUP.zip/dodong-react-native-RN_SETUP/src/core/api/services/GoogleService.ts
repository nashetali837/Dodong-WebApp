import config from '@src/config';
import BaseApi from '../index';
import {TGoogleLoginData} from './schema.type';

class GoogleService extends BaseApi {
  protected getExtraHeaders(): Headers {
    return {};
  }
  getGoogleAutoComplete = (input: string) => {
    return this.get(
      `${config.endPoints.googleAutoComplete}input=${input}&key=${config.apiKeys.googlePlacesAPIKey}`,
    );
  };

  getAuthToken(data: TGoogleLoginData) {
    return this.post(config.endPoints.googleAuth, data);
  }

  getGooglePlaceDetail = (input: string) => {
    return this.get(
      `${config.endPoints.googlePlaceDetail}place_id=${input}&key=${config.apiKeys.googlePlacesAPIKey}`,
    );
  };
}

const googleService = new GoogleService();
export default googleService;
