import config from '@src/config';
import BaseApi from '../index';
import {RESOURCE_TYPES, SHOP_MODE, SHORT_ACTIONS} from '@src/constants/Enums';

class ResourceService extends BaseApi {
  protected getExtraHeaders(): Headers {
    return {};
  }
  getPostSubCategory(categoryId: number) {
    return this.post(config.endPoints.postSubCategory, {categoryId});
  }

  getShops(text: string) {
    const data = {name: {contains: text, mode: SHOP_MODE.INSENSITIVE}};
    return this.post(config.endPoints.shopDetail, data);
  }

  createShop(data: any) {
    return this.post(config.endPoints.createShop, data);
  }

  createPost(data: any) {
    return this.post(config.endPoints.createPost, data);
  }

  getCommentsById(id: number, page = 1) {
    return this.get(`${config.endPoints.getComments}postID=${id}&page=${page}`);
  }
  getResourceById(id: number) {
    return this.get(`${config.endPoints.getResourceById}resourceID=${id}`);
  }

  addCommentById(data: {commentBody: string; resourceID: number}) {
    return this.post(config.endPoints.addComment, data);
  }

  likeUnlikeResourceById(
    data: {postID: number},
    type = SHORT_ACTIONS.LIKE,
    resourceType = `${RESOURCE_TYPES.POST}s`.toLocaleLowerCase(),
  ) {
    return this.post(`${resourceType}/${type}`, data);
  }
}

const resourceService = new ResourceService();
export default resourceService;
