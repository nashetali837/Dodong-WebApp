import {Box, Text} from '@atoms';
import React from 'react';
import {FlatListProps, FlatList} from 'react-native';
import {PanGestureHandler} from 'react-native-gesture-handler';
import Animated from 'react-native-reanimated';

export const ShowDiffContext = React.createContext(false);

export const AnimatedFlatList =
  Animated.createAnimatedComponent<FlatListProps<any>>(FlatList);
export const AnimatedPanGestureHandler =
  Animated.createAnimatedComponent(PanGestureHandler);
export const AnimatedText = Animated.createAnimatedComponent(Text);
export const AnimatedBox = Animated.createAnimatedComponent(Box);
