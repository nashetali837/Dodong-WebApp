import {createText} from '@shopify/restyle';

import {Theme} from '../theme';

const Text = createText<Theme>();

Text.defaultProps = {
  variant: 'body1.semiBold.16',
  color: 'gray2',
};

export default Text;
