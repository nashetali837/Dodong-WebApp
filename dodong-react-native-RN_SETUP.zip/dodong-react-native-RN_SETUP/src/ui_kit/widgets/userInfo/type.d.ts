interface IUserInfo {
  showBackButton?: boolean;
  author: TAuthor;
}
