import {useNavigation} from '@react-navigation/native';
import useUserData from '@src/hooks/user/useUserData';
import {ScreensList, TabScreensList} from '@src/routes/helpers';
import {Box, Text} from '@src/ui_kit/atoms';
import AppIcon from '@src/ui_kit/components/appIcons/AppIcon';
import APP_ICON_NAMES from '@src/ui_kit/components/appIcons/iconNames';
import React from 'react';
import {Image, Pressable, StyleSheet} from 'react-native';

const UserInfoUI: React.FC<IUserInfo> = ({showBackButton = false, author}) => {
  const {goBack, navigate} = useNavigation();
  const {userData} = useUserData();
  const _handleBack = () => goBack();

  const isLoggedInUser = userData?.profile?.id === author?.id ?? false;

  const _handleOnAuthorPress = () => {
    if (isLoggedInUser) {
      navigate(TabScreensList.Profile);
    } else {
      navigate(ScreensList.PublicProfile, {profileId: author?.id});
    }
  };

  if (!author) {
    return <></>;
  }

  return (
    <Box flexDirection="row" alignItems="center">
      {showBackButton ? (
        <Pressable onPress={_handleBack}>
          <Box mr={'_s10'} ml={'_s24'}>
            <AppIcon name={APP_ICON_NAMES.BackArrow} />
          </Box>
        </Pressable>
      ) : (
        <></>
      )}
      <Box flex={9}>
        <Pressable
          onPress={_handleOnAuthorPress}
          style={styles.pressableContainer}>
          <Box
            width={32}
            height={32}
            bg={'lightWhite'}
            borderRadius={16}
            overflow="hidden">
            <Image
              source={{uri: author?.avatar || author?.userProfilePicture}}
              style={{width: null, height: null, flex: 1}}
            />
          </Box>
          <Box ml={'_s8'}>
            <Text variant={'body3.regular.12'}>{author?.displayName}</Text>
            <Text variant={'body4.regular.10'}>2.5 km</Text>
          </Box>
        </Pressable>
      </Box>
      <Box flex={1}>
        <AppIcon name={APP_ICON_NAMES.More} />
      </Box>
    </Box>
  );
};

export default UserInfoUI;

const styles = StyleSheet.create({
  pressableContainer: {flexDirection: 'row', alignItems: 'center'},
});
