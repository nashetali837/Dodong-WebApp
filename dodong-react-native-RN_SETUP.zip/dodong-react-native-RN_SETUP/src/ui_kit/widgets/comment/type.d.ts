interface IComment {
  comment: {
    body: string;
    commentID: number;
    profile: {
      displayName: 'Prem';
      name: 'Prem';
    };
    userProfileID: number;
    resourceID: number;
    userProfileID: number;
  };
}
