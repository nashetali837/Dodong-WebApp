import {Box, Text} from '@src/ui_kit/atoms';
import AppIcon from '@src/ui_kit/components/appIcons/AppIcon';
import APP_ICON_NAMES from '@src/ui_kit/components/appIcons/iconNames';
import React from 'react';
import {Image, Pressable} from 'react-native';
const Comment: React.FC<IComment> = ({comment}) => {
  return (
    <Box flexDirection="row">
      <Box>
        <Image
          source={{uri: ''}}
          width={32}
          height={32}
          borderRadius={16}
          style={{backgroundColor: 'black'}}
        />
      </Box>
      <Box flex={1} ml={'_s8'}>
        <Box
          flexDirection="row"
          justifyContent="space-between"
          mb={'_s4'}
          alignItems="center">
          <Text variant={'body3.regular.12'}>
            {comment?.profile?.displayName ?? ''}
          </Text>
          <Pressable>
            <Box px={'_s10'}>
              <AppIcon
                name={APP_ICON_NAMES.More}
                color="transparent"
                size={24}
              />
            </Box>
          </Pressable>
        </Box>
        <Text variant={'body2.regular.14'} color={'gray1'}>
          {comment?.body ?? ''}
        </Text>
      </Box>
    </Box>
  );
};

export default Comment;
