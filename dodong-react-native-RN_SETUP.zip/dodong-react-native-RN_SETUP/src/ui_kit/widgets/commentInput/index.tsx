import {Box} from '@src/ui_kit/atoms';
import AppIcon from '@src/ui_kit/components/appIcons/AppIcon';
import APP_ICON_NAMES from '@src/ui_kit/components/appIcons/iconNames';
import TextInput from '@src/ui_kit/components/customInputs/textInput';
import React, {useRef} from 'react';
import {ActivityIndicator, Pressable} from 'react-native';
const CommentInput: React.FC<ICommentInput> = ({callback, isLoading}) => {
  const comment = useRef('');

  const onCommentAddPress = () => {
    callback?.(comment.current);
  };

  return (
    <Box>
      <TextInput
        headerText={''}
        style={{minWidth: '70%'}}
        placeholder={'Write a comment'}
        onChangeText={(val: string) => (comment.current = val)}
        onSubmitEditing={onCommentAddPress}
        leftAccessory={
          <Box mr={'_s8'}>
            <AppIcon
              name={APP_ICON_NAMES.CommentFace}
              color="transparent"
              size={24}
            />
          </Box>
        }
        rightAccessory={
          <Pressable onPress={onCommentAddPress} disabled={isLoading}>
            <Box
              bg={isLoading ? 'gray1' : 'orange500'}
              borderRadius={8}
              p={'_s8'}>
              {!isLoading ? (
                <AppIcon
                  name={APP_ICON_NAMES.Send}
                  size={24}
                  color="transparent"
                />
              ) : (
                <ActivityIndicator size={'small'} color={'white'} />
              )}
            </Box>
          </Pressable>
        }
      />
    </Box>
  );
};

export default CommentInput;
