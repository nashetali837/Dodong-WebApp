interface ICommentInput {
  callback: (comment: string) => void;
  isLoading: boolean;
}
