import useImageSelector from '@src/hooks/resourceHooks/useImageSelector';
import {Box, Text} from '@src/ui_kit/atoms';
import AppIcon from '@src/ui_kit/components/appIcons/AppIcon';
import APP_ICON_NAMES from '@src/ui_kit/components/appIcons/iconNames';
import React from 'react';
import {
  ActivityIndicator,
  ImageBackground,
  Pressable,
  StyleSheet,
} from 'react-native';
import {IImageSelector} from './type';
const ImageSelector: React.FC<IImageSelector> = ({
  onImagePicked,
  onImageRemoved,
  onUploadSuccess,
}) => {
  const {
    currentAsset,
    setCurrentAsset,
    handleOnImagePress,
    uploadImageToServer,
    loading,
  } = useImageSelector({
    onImagePicked,
  });

  const _handleOnClosePress = () => {
    setCurrentAsset(null);
    onImageRemoved?.(currentAsset);
  };

  const _handleImageUpload = () => {
    uploadImageToServer(onUploadSuccess);
  };

  const imageSource = currentAsset?.uri ? {uri: currentAsset.uri} : null;

  return (
    <Pressable onPress={handleOnImagePress}>
      <Box
        width={'100%'}
        alignItems="center"
        height={320}
        borderWidth={imageSource ? 0 : 1}
        borderRadius={16}
        borderStyle="dashed"
        overflow="hidden"
        borderColor={'gray1'}>
        {imageSource ? (
          <ImageBackground source={imageSource} style={styles.imageContainer}>
            <Pressable
              disabled={loading}
              onPress={_handleOnClosePress}
              style={styles.closeContainer}>
              <Box
                bg={'black'}
                alignSelf="flex-end"
                m={'_s8'}
                p={'_s8'}
                borderRadius={8}>
                <AppIcon
                  name={APP_ICON_NAMES.Close}
                  color={'white'}
                  size={12}
                />
              </Box>
            </Pressable>
            <Pressable disabled={loading} onPress={_handleImageUpload}>
              <Box
                width={100}
                height={40}
                bg={'white'}
                flexDirection="row"
                justifyContent="center"
                borderRadius={12}
                alignItems="center">
                <Text variant={'body3.semiBold.12'}>
                  {loading ? 'Uploading' : 'Upload'}
                </Text>
                {loading && (
                  <ActivityIndicator size={'small'} color={'orange600'} />
                )}
              </Box>
            </Pressable>
          </ImageBackground>
        ) : (
          <AppIcon
            name={APP_ICON_NAMES.ImageSelect}
            size={150}
            color="transparent"
          />
        )}
      </Box>
    </Pressable>
  );
};

export default ImageSelector;

const styles = StyleSheet.create({
  imageContainer: {
    width: '100%',
    height: 320,
    justifyContent: 'center',
    alignItems: 'center',
  },
  closeContainer: {position: 'absolute', right: 12, top: 12},
});
