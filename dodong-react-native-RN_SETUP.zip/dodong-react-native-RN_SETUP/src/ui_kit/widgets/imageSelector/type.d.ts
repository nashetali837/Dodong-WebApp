import {ImagePickerAsset} from '@src/screens/profile/components/selectProfileImage/type';

interface IImageSelector {
  onImagePicked?: (asset: ImagePickerAsset) => void;
  onImageRemoved?: (asset: ImagePickerAsset | null) => void;
  onUploadSuccess: (image: string) => void;
}
