interface IAppTopHeader {
  colors?: string[];
  headerText: string;
  children?: React.Children;
  headerHeight?: number;
  onBackPress?: () => void;
}
