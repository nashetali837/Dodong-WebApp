import React from 'react';
import LinearGradient from 'react-native-linear-gradient';
import {Box, Text} from '@src/ui_kit/atoms';
import {theme} from '@src/ui_kit/theme';
import {useSafeAreaInsets} from 'react-native-safe-area-context';
import {Pressable} from 'react-native';
import {useNavigation} from '@react-navigation/native';
import AppIcon from '../../appIcons/AppIcon';
import APP_ICON_NAMES from '../../appIcons/iconNames';
const AppTopHeader: React.FC<IAppTopHeader> = ({
  colors = ['rgba(245, 181, 68, 0.2)', '#FFFFFF'],
  headerText = '',
  children,
  headerHeight = theme.size.FIFTY_SIX,
  onBackPress,
}) => {
  const inset = useSafeAreaInsets();
  const {goBack, canGoBack} = useNavigation();

  const handleBackPress = () => {
    onBackPress ? onBackPress() : canGoBack() ? goBack() : () => {};
  };

  return (
    <LinearGradient
      colors={colors}
      style={{
        paddingTop: inset.top,
        paddingHorizontal: theme.size.TWENTY_FOUR,
      }}>
      <Box
        height={headerHeight}
        justifyContent={'center'}
        flexDirection={'row'}>
        <Box
          width={'20%'}
          flexDirection={'row'}
          justifyContent={'space-between'}
          alignItems={'center'}>
          <Pressable onPress={handleBackPress}>
            <Box
              width={32}
              height={32}
              justifyContent={'center'}
              pt={'_s6'}
              alignItems="center">
              <AppIcon name={APP_ICON_NAMES.BackArrow} size={24} />
            </Box>
          </Pressable>
        </Box>
        <Box width={'60%'} alignItem={'center'} justifyContent={'center'}>
          <Text alignSelf={'center'} variant={'body1.regular.16'}>
            {headerText}
          </Text>
        </Box>
        <Box width={'20%'} />
      </Box>
      {children}
    </LinearGradient>
  );
};

export default AppTopHeader;
