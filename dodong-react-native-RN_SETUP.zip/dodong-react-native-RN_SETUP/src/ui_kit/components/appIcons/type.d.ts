export interface AppIconProps {
  name: string | undefined;
  strokeColor?: string;
  color?: string;
  size?: number;
  width?: number;
  height?: number;
  donotFill?: boolean;
  dataTestID?: string;
}
