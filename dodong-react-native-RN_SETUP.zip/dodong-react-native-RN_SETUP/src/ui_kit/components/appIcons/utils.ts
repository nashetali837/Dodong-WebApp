import APP_ICON_NAMES from './iconNames';

export const getSvg = (iconIdentifier: string) => {
  switch (iconIdentifier) {
    case APP_ICON_NAMES.BackArrow:
      return require('@assets/svgs/icons/backArrow.svg').default;
    case APP_ICON_NAMES.EyeHide:
      return require('@assets/svgs/icons/eyeHide.svg').default;
    case APP_ICON_NAMES.Search:
      return require('@assets/svgs/icons/search.svg').default;
    case APP_ICON_NAMES.Crosshair:
      return require('@assets/svgs/icons/crosshair.svg').default;
    case APP_ICON_NAMES.LocationOutline:
      return require('@assets/svgs/icons/locationOutline.svg').default;
    case APP_ICON_NAMES.ShortArrow:
      return require('@assets/svgs/icons/shortArrow.svg').default;
    case APP_ICON_NAMES.Camera:
      return require('@assets/svgs/icons/camera.svg').default;
    case APP_ICON_NAMES.Calendar:
      return require('@assets/svgs/icons/calendar.svg').default;
    case APP_ICON_NAMES.Profile:
      return require('@assets/svgs/icons/profile.svg').default;
    case APP_ICON_NAMES.Photo:
      return require('@assets/svgs/icons/photo.svg').default;
    case APP_ICON_NAMES.InviteFriend:
      return require('@assets/svgs/icons/inviteFriend.svg').default;
    case APP_ICON_NAMES.Whatsaap:
      return require('@assets/svgs/icons/whatsaap.svg').default;
    case APP_ICON_NAMES.Email:
      return require('@assets/svgs/icons/email.svg').default;
    case APP_ICON_NAMES.Sms:
      return require('@assets/svgs/icons/sms.svg').default;
    case APP_ICON_NAMES.More:
      return require('@assets/svgs/icons/more.svg').default;
    case APP_ICON_NAMES.Close:
      return require('@assets/svgs/icons/close.svg').default;
    case APP_ICON_NAMES.Home:
      return require('@assets/svgs/icons/home.svg').default;
    case APP_ICON_NAMES.Explore:
      return require('@assets/svgs/icons/explore.svg').default;
    case APP_ICON_NAMES.Notification:
      return require('@assets/svgs/icons/notification.svg').default;
    case APP_ICON_NAMES.Menu:
      return require('@assets/svgs/icons/menu.svg').default;
    case APP_ICON_NAMES.Flash:
      return require('@assets/svgs/icons/flash.svg').default;
    case APP_ICON_NAMES.Edit:
      return require('@assets/svgs/icons/edit.svg').default;
    case APP_ICON_NAMES.Cart:
      return require('@assets/svgs/icons/cart.svg').default;
    case APP_ICON_NAMES.Shop:
      return require('@assets/svgs/icons/shop.svg').default;
    case APP_ICON_NAMES.Like:
      return require('@assets/svgs/icons/like.svg').default;
    case APP_ICON_NAMES.Liked:
      return require('@assets/svgs/icons/liked.svg').default;
    case APP_ICON_NAMES.LikeBlack:
      return require('@assets/svgs/icons/likeBlack.svg').default;
    case APP_ICON_NAMES.Comment:
      return require('@assets/svgs/icons/comment.svg').default;
    case APP_ICON_NAMES.Share:
      return require('@assets/svgs/icons/share.svg').default;
    case APP_ICON_NAMES.Filter:
      return require('@assets/svgs/icons/filter.svg').default;
    case APP_ICON_NAMES.ImageSelect:
      return require('@assets/svgs/icons/imageSelect.svg').default;
    case APP_ICON_NAMES.CommentFace:
      return require('@assets/svgs/icons/commentFace.svg').default;
    case APP_ICON_NAMES.Send:
      return require('@assets/svgs/icons/send.svg').default;
    default:
      return require('@assets/svgs/icons/backArrow.svg').default;
  }
};
