import {theme} from '@theme';
import React from 'react';

import {AppIconProps} from './type';
import {getSvg} from './utils';

const AppIcon = ({...props}: AppIconProps) => {
  const {
    name,
    color = theme.colors.black,
    size = 16,
    width,
    height,
    strokeColor,
    donotFill,
    dataTestID = 'appIconTestId',
  } = props;

  if (!name?.length) {
    console.warn('AppIcon needs icon name');
    return <></>;
  }
  const Icon = getSvg(name);
  return (
    <Icon
      {...props}
      stoke={strokeColor}
      fill={donotFill ? undefined : color}
      width={width ?? size}
      height={height ?? size}
      testID={dataTestID}
    />
  );
};
export default AppIcon;
