import React, {useEffect, useState} from 'react';
import Animated, {
  useSharedValue,
  useAnimatedStyle,
  withTiming,
  interpolate,
  interpolateColor,
  runOnJS,
} from 'react-native-reanimated';

import {getDotStyle} from './dotUtils';
import EmptyDot from './emptyDot';
import {IDot} from './type';

const Dot: React.FC<IDot> = props => {
  const [animate, setAnimate] = useState(false);
  const [type, setType] = useState(() =>
    getDotStyle({
      idx: props.idx,
      curPage: props.curPage,
      maxPage: props.maxPage,
    }),
  );

  const [dotColor, setDotColor] = useState<string>(() => {
    if (props.curPage === props.idx) {
      return props.activeColor;
    }
    return props.inactiveColor ?? props.activeColor;
  });

  useEffect(() => {
    const nextType = getDotStyle({
      idx: props.idx,
      curPage: props.curPage,
      maxPage: props.maxPage,
    });

    const nextAnimate =
      nextType.size !== (type?.size || 3) ||
      nextType.opacity !== (type?.opacity || 0.2);

    if (props.curPage === props.idx) {
      setDotColor(props.activeColor);
    } else {
      setDotColor(props.inactiveColor ?? props.activeColor);
    }

    setType(nextType);
    setAnimate(nextAnimate);
  }, [
    props.activeColor,
    props.curPage,
    props.idx,
    props.inactiveColor,
    props.maxPage,
    type,
  ]);

  const animVal = useSharedValue(0);

  useEffect(() => {
    if (!animate) {
      return;
    }

    animVal.value = withTiming(1, {duration: 300}, () => {
      runOnJS(setAnimate)(false);
    });
  }, [animate, animVal]);

  const animStyle = useAnimatedStyle(() => {
    const size = interpolate(
      animVal.value,
      [0, 1],
      [(type?.size || 3) * props.sizeRatio, type.size * props.sizeRatio],
    );

    const backgroundColor = interpolateColor(
      animVal.value,
      [0, 1],
      [dotColor, props.activeColor],
    );

    return {
      width: size,
      height: size,
      backgroundColor,
      borderRadius: (type?.size || 3) * props.sizeRatio * 0.5,
      opacity: interpolate(animVal.value, [0, 1], [0.2, type?.opacity || 0.2]),
    };
  });

  if (props.curPage < 3) {
    if (props.idx >= 5) {
      return <EmptyDot sizeRatio={props.sizeRatio} />;
    }
  } else if (props.curPage < 4) {
    if (props.idx > 5) {
      return <EmptyDot sizeRatio={props.sizeRatio} />;
    }
  }

  return (
    <Animated.View
      style={[
        {
          margin: 3 * props.sizeRatio,
        },
        animStyle,
      ]}
    />
  );
};

export default Dot;
