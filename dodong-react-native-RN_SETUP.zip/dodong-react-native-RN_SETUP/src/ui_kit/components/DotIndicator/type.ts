import {ReactElement} from 'react';
import {FlatListProps, ViewStyle, ViewToken} from 'react-native';

export interface IDotContainer {
  curPage: number;
  maxPage: number;
  sizeRatio?: number;
  activeDotColor?: string;
  inactiveDotColor?: string;
  vertical?: boolean;
  dotContainerStyles?: ViewStyle;
}

export type IDotStyle = {
  size: number;
  opacity: number;
};

export enum EnumDotType {
  ACTIVE,
  INACTIVE,
  MEDIUM,
  SMALL,
}

export type getDotStylePayload = {
  idx: number;
  curPage: number;
  maxPage: number;
};

export interface IDot {
  idx: number;
  curPage: number;
  maxPage: number;
  activeColor: string;
  inactiveColor?: string;
  sizeRatio: number;
}

export type TCustomFlatList = FlatListProps<T> & {
  getViewableItems?: ({
    viewableItems,
    direction,
  }: {
    viewableItems: ViewToken[];
    direction: SwipeDirection;
  }) => void;
};

export interface IDotIndicator
  extends Omit<IDotContainer, 'curPage' | 'maxPage'> {}

export interface IFlatListWithDotIndicator {
  flatListProps: TCustomFlatList;
  indicatorProps?: IDotIndicator;
  children?: ReactElement;
  customIndicatorStyles?: ViewStyle;
}

export enum SwipeDirection {
  LEFT = 'left',
  RIGHT = 'right',
}
