import {Box} from '@atoms';
import React, {useRef, useState} from 'react';
import {ViewToken} from 'react-native';
import DotContainer from './dotContainer';
import {IFlatListWithDotIndicator, SwipeDirection} from './type';
import useCustomScrollHandler from '@src/hooks/scrollHandler/useCustomScrollHandler';
import {AnimatedFlatList} from '@src/ui_kit/atoms/animated/helper';

const FlatListWithDotIndicator: React.FC<IFlatListWithDotIndicator> = ({
  flatListProps,
  indicatorProps,
  customIndicatorStyles,
  children,
}) => {
  const [currentIndex, setCurrentIndex] = useState<number>(0);
  const indexRef = useRef<number>(0);

  const handleViewableExternalChange = (viewableItems: ViewToken[]) => {
    const index = viewableItems[0]?.index ?? 0;
    if (index > indexRef.current) {
      flatListProps?.getViewableItems?.({
        viewableItems,
        direction: SwipeDirection.RIGHT,
      });
    } else {
      indexRef.current !== 0 &&
        flatListProps?.getViewableItems?.({
          viewableItems,
          direction: SwipeDirection.LEFT,
        });
    }
    setCurrentIndex(index);
    indexRef.current = index;
  };

  const {
    itemViewabilityConfigRef,
    handleViewableItemsChanged,
    animatedScrollHandler,
  } = useCustomScrollHandler({
    viewPortIndex: 5,
    isBottomTabsVisible: true,
    handleViewableExternalChange,
  });

  const dataLength = flatListProps?.data?.length;

  const clonedChildren = React.Children.map(children, child =>
    React.isValidElement(child)
      ? React.cloneElement(child, {currentIndex, setCurrentIndex}) // Pass props here
      : child,
  );

  if (!dataLength) {
    return <></>;
  }

  return (
    <Box>
      <AnimatedFlatList
        showsHorizontalScrollIndicator={false}
        pagingEnabled
        scrollEnabled={dataLength > 1}
        horizontal
        {...flatListProps}
        onScroll={animatedScrollHandler}
        viewabilityConfig={itemViewabilityConfigRef.current}
        onViewableItemsChanged={handleViewableItemsChanged.current}
      />
      {dataLength > 1 ? (
        <Box style={customIndicatorStyles}>
          <DotContainer
            curPage={currentIndex}
            maxPage={dataLength}
            {...indicatorProps}
          />
        </Box>
      ) : (
        <></>
      )}
      {clonedChildren}
    </Box>
  );
};

export default FlatListWithDotIndicator;
