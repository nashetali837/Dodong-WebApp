import {Box} from '@atoms';
import React, {useCallback, useEffect, useMemo, useRef} from 'react';
import {ScrollView, ViewStyle, StyleProp, StyleSheet} from 'react-native';
import usePrevious from '@src/hooks/reactUse/usePrevious';

import Dot from './dot';
import {DefaultEmptyDotSize} from './dotUtils';
import EmptyDot from './emptyDot';
import {IDotContainer} from './type';
import {theme} from '@src/ui_kit/theme';

const ONE_EMPTY_DOT_SIZE = DefaultEmptyDotSize * DefaultEmptyDotSize;

const DotContainer: React.FC<IDotContainer> = props => {
  const {
    curPage,
    maxPage,
    activeDotColor = theme.colors.white,
    inactiveDotColor = theme.colors.black20,
    dotContainerStyles,
    vertical,
  } = props;
  const scrollRef = useRef<ScrollView>(null);
  const prevPage = usePrevious(curPage);

  let normalizedPage = curPage;
  if (curPage < 0) {
    normalizedPage = 0;
  }
  if (curPage > maxPage - 1) {
    normalizedPage = maxPage - 1;
  }

  const getSizeRatio = useCallback<() => number>(() => {
    if (!props.sizeRatio) {
      return 1.0;
    }
    return Math.max(1.0, props.sizeRatio);
  }, [props.sizeRatio]);

  const getContainerStyle = useCallback<() => StyleProp<ViewStyle>>(() => {
    const {vertical} = props;
    const sizeRatio = getSizeRatio();
    const containerSize = 84 * sizeRatio;

    return {
      ...styles.defaultStyles,
      flexDirection: vertical ? 'column' : 'row',
      maxHeight: vertical ? containerSize : undefined,
      maxWidth: vertical ? undefined : containerSize,
    };
  }, [getSizeRatio, props]);

  const sizeRatio = getSizeRatio();
  const container = getContainerStyle();

  const _handleOnLayout = () => scrollTo(curPage, false);

  const scrollTo = useCallback<(index: number, animated?: boolean) => void>(
    (index, animated = true) => {
      if (!scrollRef.current) {
        return;
      }

      const sizeRatio = getSizeRatio();
      const FIRST_EMPTY_DOT_SPACE = ONE_EMPTY_DOT_SIZE * 2;
      const MOVE_DISTANCE = ONE_EMPTY_DOT_SIZE * sizeRatio;

      const moveTo = Math.max(
        0,
        FIRST_EMPTY_DOT_SPACE + (index - 4) * MOVE_DISTANCE,
      );

      if (vertical) {
        scrollRef.current.scrollTo({
          x: 0,
          y: moveTo,
          animated,
        });
        return;
      }

      scrollRef.current.scrollTo({
        x: moveTo,
        y: 0,
        animated,
      });
    },
    [getSizeRatio, vertical],
  );

  useEffect(() => {
    if (maxPage > 4 && prevPage !== curPage) {
      scrollTo(curPage);
    }
  }, [prevPage, curPage, maxPage, scrollTo]);

  const list = useMemo(() => [...Array(maxPage).keys()], [maxPage]);

  if (maxPage < 5) {
    return (
      <Box style={[container, dotContainerStyles]}>
        {list.map(i => {
          return (
            <Dot
              key={i}
              idx={i}
              sizeRatio={sizeRatio}
              curPage={normalizedPage}
              maxPage={maxPage}
              activeColor={activeDotColor}
              inactiveColor={inactiveDotColor}
            />
          );
        })}
      </Box>
    );
  }

  return (
    <Box style={[container, dotContainerStyles]} onLayout={_handleOnLayout}>
      <ScrollView
        ref={scrollRef}
        contentContainerStyle={styles.scrollViewContainer}
        bounces={false}
        horizontal={!vertical}
        scrollEnabled={false}
        showsVerticalScrollIndicator={false}
        showsHorizontalScrollIndicator={false}>
        <EmptyDot sizeRatio={sizeRatio} />
        <EmptyDot sizeRatio={sizeRatio} />

        {list.map(i => {
          return (
            <Dot
              sizeRatio={sizeRatio}
              key={i}
              idx={i}
              curPage={normalizedPage}
              maxPage={maxPage}
              activeColor={activeDotColor}
              inactiveColor={inactiveDotColor}
            />
          );
        })}
        <EmptyDot sizeRatio={sizeRatio} />
        <EmptyDot sizeRatio={sizeRatio} />
      </ScrollView>
    </Box>
  );
};

const styles = StyleSheet.create({
  defaultStyles: {
    alignItems: 'center',
    alignSelf: 'center',
    paddingVertical: theme.size.SIXTEEN,
  },
  scrollViewContainer: {
    alignItems: 'center',
  },
});

export default DotContainer;
