import {EnumDotType, IDotStyle, getDotStylePayload} from './type';

const DotStyle = {
  [EnumDotType.INACTIVE]: {
    size: 8,
    opacity: 0.2,
  },
  [EnumDotType.ACTIVE]: {
    size: 8,
    opacity: 1.0,
  },
  [EnumDotType.MEDIUM]: {
    size: 5,
    opacity: 0.2,
  },
  [EnumDotType.SMALL]: {
    size: 3,
    opacity: 0.2,
  },
};

export const DefaultEmptyDotSize = 3;

export const getDotStyle = ({
  idx,
  curPage,
  maxPage,
}: getDotStylePayload): IDotStyle => {
  let type = EnumDotType.SMALL;

  if (maxPage < 5) {
    return DotStyle[
      idx === curPage ? EnumDotType.ACTIVE : EnumDotType.INACTIVE
    ];
  }

  if (curPage < DefaultEmptyDotSize) {
    if (idx < DefaultEmptyDotSize) {
      type = EnumDotType.INACTIVE;
      if (curPage === idx) {
        type = EnumDotType.ACTIVE;
      }
    } else if (idx < DefaultEmptyDotSize + 1) {
      type = EnumDotType.MEDIUM;
    } else {
      type = EnumDotType.SMALL;
    }
  } else if (curPage === DefaultEmptyDotSize) {
    if (idx < 4) {
      if (idx === 0) {
        type = EnumDotType.MEDIUM;
      } else {
        type = EnumDotType.INACTIVE;

        if (curPage === idx) {
          type = EnumDotType.ACTIVE;
        }
      }
    } else if (curPage + 1 === idx) {
      type = EnumDotType.MEDIUM;
    } else {
      type = EnumDotType.SMALL;
    }
  } else {
    if (idx > curPage) {
      if (idx === curPage + 1) {
        type = EnumDotType.MEDIUM;
      }
    } else if (idx < curPage) {
      if (idx >= curPage - 2) {
        type = EnumDotType.INACTIVE;
      } else if (idx === curPage - 3) {
        type = EnumDotType.MEDIUM;
      }
    } else {
      type = EnumDotType.ACTIVE;
    }
  }

  return DotStyle[type];
};
