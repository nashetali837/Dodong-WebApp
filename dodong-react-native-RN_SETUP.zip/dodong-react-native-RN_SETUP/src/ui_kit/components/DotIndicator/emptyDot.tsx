import React from 'react';
import {StyleSheet, View} from 'react-native';

import {DefaultEmptyDotSize} from './dotUtils';

const EmptyDot: React.FC<{
  sizeRatio: number;
}> = props => {
  return (
    <View
      style={[
        styles.base,
        {
          width: DefaultEmptyDotSize * props.sizeRatio,
          height: DefaultEmptyDotSize * props.sizeRatio,
          margin: DefaultEmptyDotSize * props.sizeRatio,
        },
      ]}
    />
  );
};

const styles = StyleSheet.create({
  base: {
    backgroundColor: 'white',
    opacity: 0.0,
  },
});

export default EmptyDot;
