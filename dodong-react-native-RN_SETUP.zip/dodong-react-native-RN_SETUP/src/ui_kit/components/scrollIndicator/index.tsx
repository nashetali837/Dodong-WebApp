import React from 'react';
import {useAnimatedStyle, withTiming} from 'react-native-reanimated';
import {AnimatedBox} from '@atoms/animated/helper';
import {theme} from '@theme';
import {StyleSheet} from 'react-native';
import {IScrollIndicatorDot} from './type';
const ScrollIndicatorDot: React.FC<IScrollIndicatorDot> = ({
  activeDotIndex,
  index,
}) => {
  const rDotStyle = useAnimatedStyle(() => {
    const isActive = activeDotIndex?.value === index;
    return {
      backgroundColor: withTiming(
        isActive ? theme.colors.black : theme.colors.gray1,
        {duration: 150},
      ),
    };
  });

  return <AnimatedBox style={[styles.dot, rDotStyle]} />;
};

export default ScrollIndicatorDot;

const styles = StyleSheet.create({
  dot: {
    width: 8,
    height: 8,
    borderRadius: 5,
    marginHorizontal: 5,
  },
});
