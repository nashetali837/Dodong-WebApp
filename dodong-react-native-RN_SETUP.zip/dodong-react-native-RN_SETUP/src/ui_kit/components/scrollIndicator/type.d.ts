import {SharedValue} from 'react-native-reanimated';

interface IScrollIndicatorDot {
  activeDotIndex: SharedValue<number>;
  index: number;
}
