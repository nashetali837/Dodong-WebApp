interface IWaveBox {
  onPress?: () => void;
}
