import React from 'react';
import {Path, Svg} from 'react-native-svg';
import {Pressable} from 'react-native';
import {Box} from '@atoms';
import {theme} from '@theme';
import {dimensions} from '@src/utilities/helpers';
import AppIcon from '../appIcons/AppIcon';
import APP_ICON_NAMES from '../appIcons/iconNames';
const WaveBox: React.FC<IWaveBox> = ({onPress}) => {
  const _handleOnPress = () => onPress?.();

  return (
    <Box position={'absolute'} top={-50}>
      <Pressable onPress={_handleOnPress}>
        <WaveSvg />
        <Box position="absolute" alignSelf={'center'} top={theme.size.TWENTY}>
          <AppIcon name={APP_ICON_NAMES.Close} />
        </Box>
      </Pressable>
    </Box>
  );
};

export default WaveBox;

const WaveSvg = () => {
  return (
    <Svg
      xmlns="http://www.w3.org/2000/svg"
      width={dimensions.screenWidth}
      height="50"
      viewBox="0 0 410 50"
      fill="none">
      <Path
        fillRule="evenodd"
        clipRule="evenodd"
        d="M0 30.2986H126.223C140.701 30.2986 154.681 25.0051 165.528 15.4148V15.4148C187.811 -4.28608 221.237 -4.44693 243.708 15.0386L244.317 15.5662C255.274 25.0678 269.291 30.2986 283.795 30.2986H410V623H0V30.2986Z"
        fill="white"
      />
    </Svg>
  );
};
