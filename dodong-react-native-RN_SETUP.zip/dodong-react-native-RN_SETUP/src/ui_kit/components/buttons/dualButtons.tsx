import React from 'react';
import {Box} from '@atoms';

import AppIcon from '../appIcons/AppIcon';
import APP_ICON_NAMES from '../appIcons/iconNames';
import GradientButton from './gradientButton';

interface IDualButtons {
  onLeftPress: () => void;
  onRightPress: () => void;
  rightButtonText: string;
  leftButtonText: string;
  loading?: boolean;
}

const DualButton: React.FC<IDualButtons> = ({
  onRightPress,
  onLeftPress,
  leftButtonText,
  rightButtonText,
  loading,
}) => {
  const _handleRightButtonPress = () => {
    onRightPress?.();
  };

  const _handleLeftButtonPress = () => {
    onLeftPress?.();
  };

  return (
    <Box flexDirection={'row'}>
      <Box flex={1} px={'_s4'}>
        <GradientButton
          text={leftButtonText}
          isOutlined
          isLoading={loading}
          leftAccessory={
            <Box mr={'_s8'}>
              <AppIcon name={APP_ICON_NAMES.BackArrow} />
            </Box>
          }
          onPress={_handleLeftButtonPress}
        />
      </Box>
      <Box flex={1} px={'_s4'}>
        <GradientButton
          text={rightButtonText}
          isLoading={loading}
          rightAccessory={
            <Box style={{transform: [{rotate: '180deg'}]}} ml={'_s10'}>
              <AppIcon name={APP_ICON_NAMES.BackArrow} color={'white'} />
            </Box>
          }
          onPress={_handleRightButtonPress}
        />
      </Box>
    </Box>
  );
};
export default DualButton;
