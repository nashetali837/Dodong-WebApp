import React, {ReactElement} from 'react';
import {
  TouchableOpacity,
  StyleSheet,
  StyleProp,
  ViewStyle,
  TextStyle,
  ActivityIndicator,
} from 'react-native';
import LinearGradient from 'react-native-linear-gradient';
import {theme} from '@theme';
import {Text} from '@atoms';

interface IGradientButton {
  containerStyles?: StyleProp<ViewStyle>;
  gradientStyles?: StyleProp<ViewStyle>;
  textStyles?: StyleProp<TextStyle>;
  text: string;
  onPress: () => void;
  isLoading?: boolean;
  leftAccessory?: ReactElement;
  rightAccessory?: ReactElement;
  isOutlined?: boolean;
  textProps?: any;
  colors?: string[];
}

const GradientButton: React.FC<IGradientButton> = ({
  containerStyles,
  gradientStyles,
  textStyles,
  text,
  onPress,
  isLoading = false,
  leftAccessory,
  rightAccessory,
  isOutlined = false,
  textProps,
  colors: ExternalColors,
}) => {
  const colors = ExternalColors
    ? ExternalColors
    : isOutlined
    ? ['transparent', 'transparent']
    : isLoading
    ? [theme.colors.neutral300, theme.colors.neutral300]
    : [theme.colors.orange, theme.colors.orange];

  return (
    <TouchableOpacity
      disabled={isLoading}
      style={[styles.button, isOutlined && styles.outlined, containerStyles]}
      onPress={onPress}>
      <LinearGradient colors={colors} style={[styles.gradient, gradientStyles]}>
        {leftAccessory}
        <Text
          variant={'body3.regular.18'}
          lineHeight={28}
          color={isOutlined ? 'gray2' : 'white'}
          mr={isLoading ? '_s4' : '_s0'}
          style={[textStyles]}
          {...textProps}>
          {text}
        </Text>
        {rightAccessory}
        {isLoading ? (
          <ActivityIndicator
            size={'small'}
            color={isOutlined ? theme.colors.lightWhite : theme.colors.white}
          />
        ) : (
          <></>
        )}
      </LinearGradient>
    </TouchableOpacity>
  );
};

const styles = StyleSheet.create({
  button: {
    borderRadius: 16,
    shadowColor: '#110C22',
    shadowOffset: {width: 0, height: 1},
    shadowOpacity: 0.08,
    shadowRadius: 2,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    width: '100%',
  },
  gradient: {
    flex: 1,
    borderRadius: theme.size.SIXTEEN,
    paddingVertical: theme.size.SIXTEEN,
    justifyContent: 'center',
    alignItems: 'center',
    flexDirection: 'row',
  },
  buttonText: {
    color: theme.colors.white,
  },
  outlined: {
    borderWidth: 1,
    borderColor: theme.colors.lightWhite,
  },
});

export default GradientButton;
