import {theme} from '@theme';
import React, {useEffect} from 'react';
import {Platform, StatusBar} from 'react-native';
import {ScreensList} from '@src/routes/helpers';

interface Props {
  currentRouteName: undefined | string;
}

export const isStatusBarLight = (
  isLight?: boolean,
  isTranslucent = false,
  customBackgroundColor?: string,
) => {
  Platform.OS === 'android' && StatusBar.setTranslucent(isTranslucent);
  Platform.OS === 'android' &&
    StatusBar.setBackgroundColor(
      customBackgroundColor
        ? customBackgroundColor
        : isLight
        ? theme.colors.black
        : theme.colors.white,
    );
  StatusBar.setBarStyle(isLight ? 'light-content' : 'dark-content');
};

const StatusBarManager = (props: Props) => {
  const {currentRouteName} = props;
  console.log('currentRouteName', currentRouteName);
  useEffect(() => {
    set();
  }, [currentRouteName]);

  const set = () => {
    switch (currentRouteName) {
      case ScreensList.AuthLanding:
      case undefined:
        isStatusBarLight(true, true, 'transparent');
        break;
      default:
        isStatusBarLight(false);
        break;
    }
  };

  return <></>;
};

export default StatusBarManager;
