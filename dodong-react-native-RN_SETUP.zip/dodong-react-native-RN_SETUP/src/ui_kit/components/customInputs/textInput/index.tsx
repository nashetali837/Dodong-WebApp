import React from 'react';
import {TextInput as RNTextInput, StyleSheet} from 'react-native';
import {Box, Text} from '@atoms';
import {ITextInput} from './type';
import {theme} from '@theme';
import {Pressable} from 'react-native';
import {IS_IOS} from '@src/utilities/helpers';
const TextInput: React.FC<ITextInput> = ({
  headerText,
  containerStyle,
  containerWrapperStyle,
  leftAccessory,
  rightAccessory,
  hasError = false,
  pressDisabled = true,
  onPress,
  ...props
}) => {
  const _handlePress = () => {
    onPress?.();
  };

  return (
    <Pressable disabled={pressDisabled} onPress={_handlePress}>
      <Box style={containerWrapperStyle}>
        {headerText ? (
          <Text variant={'body2.regular.14'} mb={'_s4'}>
            {headerText}
          </Text>
        ) : (
          <></>
        )}
        <Box
          borderColor={hasError ? 'red' : 'lightWhite'}
          borderWidth={1}
          borderRadius={theme.size.TEN}
          py={IS_IOS ? '_s14' : '_s2'}
          px={'_s14'}
          flexDirection={'row'}
          style={[styles.defaultStyles, containerStyle]}>
          {leftAccessory}
          <RNTextInput
            style={[styles.defaultInputStyles, props?.style]}
            placeholderTextColor={theme.colors.gray1}
            {...props}
          />
          {rightAccessory}
        </Box>
      </Box>
    </Pressable>
  );
};

export default TextInput;

const styles = StyleSheet.create({
  defaultStyles: {
    alignItems: 'center',
  },
  defaultInputStyles: {
    color: theme.colors.textBlack,
    minWidth: '85%',
  },
});
