import {ReactElement} from 'react';
import {StyleProp, TextInputProps, ViewStyle} from 'react-native/types';

interface ITextInput extends TextInputProps {
  headerText?: string;
  containerStyle?: StyleProp<ViewStyle>;
  containerWrapperStyle?: StyleProp<ViewStyle>;
  leftAccessory?: ReactElement;
  rightAccessory?: ReactElement;
  hasError?: boolean | '' | undefined;
  onPress?: () => void;
  pressDisabled?: boolean;
}
