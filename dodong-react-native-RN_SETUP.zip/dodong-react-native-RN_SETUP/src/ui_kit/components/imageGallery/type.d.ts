import {StyleProp, ViewStyle} from 'react-native';

export interface IImageGallery {
  images: string[];
  imageContainerStyles?: StyleProp<ViewStyle>;
  indicatorStyles?: StyleProp<ViewStyle>;
}
