import React, {useRef} from 'react';
import FlatListWithDotIndicator from '../DotIndicator';
import {FlatList, Image, StyleSheet} from 'react-native';
import {IImageGallery} from './type';
import {Box, Text} from '@src/ui_kit/atoms';
const ImageGallery: React.FC<IImageGallery> = ({
  images,
  imageContainerStyles,
  indicatorStyles,
}) => {
  const flatlistRef = useRef<FlatList>(null);

  const renderItem = ({item}: {item: string}) => {
    return (
      <Image
        resizeMode="cover"
        source={{
          uri: item,
        }}
        style={[styles.defaultContainer, imageContainerStyles]}
      />
    );
  };

  const flatListProps = {
    renderItem,
    data: images,
    ref: flatlistRef,
    keyExtractor,
  };

  if (!images.length) {
    return (
      <Box
        style={[imageContainerStyles]}
        justifyContent="center"
        alignItems="center"
        bg={'lightWhite'}>
        <Text variant={'body5.regular.8'}>Could not load image</Text>
      </Box>
    );
  }

  return (
    <FlatListWithDotIndicator
      flatListProps={flatListProps}
      customIndicatorStyles={[styles.indicatorStyles, indicatorStyles]}
    />
  );
};

export default ImageGallery;

const keyExtractor = (_: any, index: number) => `image_gallery_${index}`;

const styles = StyleSheet.create({
  indicatorStyles: {
    position: 'absolute',
    bottom: 10,
    right: 20,
  },
  defaultContainer: {width: 335, height: 320},
});
