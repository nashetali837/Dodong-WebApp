import {Box, Text} from '@src/ui_kit/atoms';
import React from 'react';
import {IChip} from './type';
const Chip: React.FC<IChip> = ({
  text,
  textProps,
  containerProps,
  leftAccessory,
  rightAccessory,
}) => {
  if (!text.length) {
    return <></>;
  }
  return (
    <Box
      justifyContent="center"
      alignItems="center"
      alignSelf="flex-start"
      borderWidth={0.5}
      px={'_s8'}
      py={'_s4'}
      borderRadius={8}
      borderColor={'lightWhite'}
      {...containerProps}>
      {leftAccessory}
      <Text variant={'body3.regular.12'} color={'neutral900'} {...textProps}>
        {text}
      </Text>
      {rightAccessory}
    </Box>
  );
};

export default Chip;
