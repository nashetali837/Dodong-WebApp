import {ReactElement} from 'react';
import {StyleProp, TextStyle, ViewStyle} from 'react-native';

export interface IChip {
  text: string;
  textProps?: StyleProp<TextStyle>;
  containerProps?: StyleProp<ViewStyle>;
  leftAccessory?: ReactElement;
  rightAccessory?: ReactElement;
}
