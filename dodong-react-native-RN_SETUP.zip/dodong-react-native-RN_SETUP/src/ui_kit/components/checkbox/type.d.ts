import {CheckBoxProps} from '@react-native-community/checkbox';
import {TextStyle, ViewStyle} from 'react-native';

interface ICustomCheckBox {
  text?: string;
  textProps?: TextStyle;
  boxProps?: ViewStyle;
  isDisabled?: boolean;
  isChecked?: boolean;
  onPress?: () => void;
  checkBoxProps: CheckBoxProps;
}
