import React, {useState} from 'react';
import CheckBox from '@react-native-community/checkbox';
import {Box, Text} from '@src/ui_kit/atoms';
import {ICustomCheckBox} from './type';
import {Pressable, StyleSheet} from 'react-native';
import {theme} from '@src/ui_kit/theme';
const CustomCheckBox: React.FC<ICustomCheckBox> = ({
  text,
  textProps,
  boxProps,
  isDisabled = false,
  isChecked = false,
  checkBoxProps,
  onPress,
}) => {
  const [toggleCheckBox, setToggleCheckBox] = useState<boolean>(isChecked);

  const _handleTextPress = () => onPress?.();

  return (
    <Box flexDirection="row" alignItems="center" {...boxProps}>
      <CheckBox
        disabled={isDisabled}
        value={toggleCheckBox}
        style={styles.customStyles}
        boxType={'square'}
        onCheckColor={theme.colors.orange500}
        onTintColor={theme.colors.orange500}
        tintColors={{
          true: theme.colors.orange500,
          false: theme.colors.lightWhite,
        }}
        lineWidth={1.5}
        onValueChange={newValue => setToggleCheckBox(newValue)}
        {...checkBoxProps}
      />
      <Pressable onPress={_handleTextPress}>
        <Text ml={'_s12'} variant={'body2.semiBold.14'} {...textProps}>
          {text}
        </Text>
      </Pressable>
    </Box>
  );
};

export default CustomCheckBox;

const styles = StyleSheet.create({
  customStyles: {
    width: 20,
    height: 20,
  },
});
