import React from 'react';
import {Box, Text} from '@atoms';
import {useState} from 'react';
import {Pressable, StyleSheet} from 'react-native';
import {theme} from '@theme';
import {useEffect} from 'react';
const DualTabs: React.FC<IDualTabs> = ({tabs, onTabChange, currentTab}) => {
  const [selectedTab, setSelectedTab] = useState<tab>();

  useEffect(() => {
    if (currentTab?.name !== selectedTab?.name) {
      setSelectedTab(currentTab);
    }
  }, [currentTab]);

  return (
    <Box
      bg={'neutral50'}
      flexDirection={'row'}
      justifyContent={'space-between'}
      p={'_s4'}
      borderRadius={16}>
      {tabs.map((tab: tab, index: number) => {
        const _handlePress = () => {
          if (selectedTab !== tab) {
            setSelectedTab(tab);
            onTabChange?.(tab);
          }
        };

        const isSelected = tab === selectedTab;

        return (
          <Pressable
            key={`tab${index}`}
            style={isSelected && styles.container}
            onPress={_handlePress}>
            <Box py={'_s4'} px={'_s12'} minWidth={theme.size.ONE_FOURTY}>
              <Text
                color={isSelected ? 'textBlack' : 'gray1'}
                mt={isSelected ? '_s0' : '_s4'}
                variant={'body2.regular.14'}
                textAlign="center">
                {tab.name}
              </Text>
            </Box>
          </Pressable>
        );
      })}
    </Box>
  );
};

export default DualTabs;

const styles = StyleSheet.create({
  container: {
    shadowColor: 'rgba(17, 12, 34, 0.12)',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 1,
    shadowRadius: 4,
    elevation: 4,
    borderRadius: 16,
    borderWidth: 4,
    borderColor: 'white',
    backgroundColor: 'white',
  },
});
