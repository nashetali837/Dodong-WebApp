type tab = {
  name: string;
};
interface IDualTabs {
  tabs: tab[];
  onTabChange?: (tab: tab) => void;
  currentTab?: tab;
}
