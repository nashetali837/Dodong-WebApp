import React from 'react';
import {Pressable} from 'react-native';
import {Box, Text} from '@atoms';
import {theme} from '@theme';
import AppIcon from '../appIcons/AppIcon';
import APP_ICON_NAMES from '../appIcons/iconNames';
const OptionBox: React.FC<IOptionBox> = ({
  option,
  onPress,
  showArrow = true,
  textProps,
}) => {
  const _onPress = () => {
    onPress?.(option);
  };

  return (
    <Pressable onPress={_onPress}>
      <Box
        flexDirection={'row'}
        alignItems={'center'}
        justifyContent={'space-between'}
        mb={'_s16'}>
        <Box flexDirection="row" alignItems="center">
          {option?.icon ? (
            <Box
              mr={'_s12'}
              borderColor={'lightWhite'}
              borderWidth={1}
              borderRadius={theme.size.SIXTEEN}
              p={'_s12'}>
              <AppIcon name={option.icon} color={'transparent'} size={20} />
            </Box>
          ) : (
            <></>
          )}
          <Text
            variant={'body3.regular.18'}
            lineHeight={theme.size.TWENTY_TWO}
            {...textProps}>
            {option.name}
          </Text>
        </Box>
        {showArrow ? (
          <Box style={{transform: [{rotate: '180deg'}]}}>
            <AppIcon name={APP_ICON_NAMES.BackArrow} />
          </Box>
        ) : (
          <></>
        )}
      </Box>
    </Pressable>
  );
};
export default OptionBox;
