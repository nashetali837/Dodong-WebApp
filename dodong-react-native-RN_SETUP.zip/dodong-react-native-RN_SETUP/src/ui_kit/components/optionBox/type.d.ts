import {StyleProp, TextStyle} from 'react-native/types';

interface IOptionBox {
  option: TOption;
  onPress?: (option: TOption) => void;
  showArrow?: boolean;
  textProps?: StyleProp<TextStyle>;
}

type TOption = {
  name: string;
  icon?: string;
};
