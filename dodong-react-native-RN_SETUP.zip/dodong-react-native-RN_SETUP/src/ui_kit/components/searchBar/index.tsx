import React from 'react';
import {Box} from '@atoms';
import TextInput from '../customInputs/textInput';
import {FlatList} from 'react-native';
import {theme} from '@theme';
import AppIcon from '../appIcons/AppIcon';
import APP_ICON_NAMES from '../appIcons/iconNames';
import {ISearchBar} from './type';

const SearchBar: React.FC<ISearchBar> = ({
  handleTextChange,
  flatlistProps,
  textInputProps,
}) => {
  const _handleTextChange = value => handleTextChange?.(value);

  return (
    <Box>
      <TextInput
        placeholder="Search Location"
        containerStyle={{backgroundColor: theme.colors.white}}
        onChangeText={_handleTextChange}
        leftAccessory={
          <Box mr={'_s8'}>
            <AppIcon name={APP_ICON_NAMES.Search} />
          </Box>
        }
        {...textInputProps}
      />
      <Box bg={'white'} borderRadius={theme.size.EIGHT} mt={'_s4'}>
        <FlatList contentContainerStyle={{maxHeight: 300}} {...flatlistProps} />
      </Box>
    </Box>
  );
};

export default SearchBar;
