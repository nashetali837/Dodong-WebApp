import {FlatList} from 'react-native';
import {ITextInput} from '../customInputs/textInput/type';

interface ISearchBar {
  handleTextChange: (value: string) => void;
  flatlistProps: FlatList<FlatList>;
  textInputProps?: ITextInput;
}
