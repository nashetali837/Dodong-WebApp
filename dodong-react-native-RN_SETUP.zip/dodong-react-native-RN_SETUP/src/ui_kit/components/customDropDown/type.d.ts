import {StyleProp, ViewStyle} from 'react-native/types';

interface IDropDown {
  data: DropDownData[];
  ref?;
  onChange: (item: DropDownData) => void;
  customRenderItem?: (item: DropDownData) => JSX.Element | null | undefined;
  headerText: string;
  placeholder?: string;
  containerWrapperStyle?: StyleProp<ViewStyle>;
  hasError?: boolean;
}

type DropDownData = {
  label: string;
  value: string;
};
