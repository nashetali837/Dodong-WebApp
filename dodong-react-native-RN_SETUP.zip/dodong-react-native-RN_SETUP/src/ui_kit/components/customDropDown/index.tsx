import React, {RefObject} from 'react';
import {useState, useRef} from 'react';
import {Dropdown} from 'react-native-element-dropdown';
import {StyleSheet} from 'react-native';
import {theme} from '@theme';
import {Box, Text} from '@atoms';
import {DropDownData, IDropDown} from './type';

const DropDown: React.FC<IDropDown> = ({
  data = [],
  ref,
  onChange,
  customRenderItem,
  headerText,
  placeholder = '',
  containerWrapperStyle,
  hasError,
}) => {
  const [value, setValue] = useState<string>();
  const defaultRef: RefObject<any> = ref ?? useRef(null);
  const _handleOnChange = (item: DropDownData) => {
    setValue(item.value);
    onChange?.(item);
  };

  const renderItem = (item: any) => {
    return (
      <Box
        py={'_s16'}
        mx={'_s12'}
        borderBottomWidth={1}
        borderBottomColor={'lightWhite'}>
        <Text variant={'body3.regular.12'}>{item.label}</Text>
      </Box>
    );
  };

  return (
    <Box style={containerWrapperStyle}>
      {headerText ? (
        <Text variant={'body2.regular.14'} mb={'_s4'}>
          {headerText}
        </Text>
      ) : (
        <></>
      )}
      <Dropdown
        ref={defaultRef}
        style={[styles.dropdown, hasError && styles.errorStyle]}
        placeholderStyle={styles.placeholderStyle}
        selectedTextStyle={styles.selectedTextStyle}
        iconStyle={styles.iconStyle}
        data={data}
        maxHeight={300}
        labelField="label"
        valueField="value"
        placeholder={placeholder}
        value={value}
        onChange={_handleOnChange}
        renderItem={customRenderItem ?? renderItem}
      />
    </Box>
  );
};
export default DropDown;

const styles = StyleSheet.create({
  dropdown: {
    height: 50,
    backgroundColor: theme.colors.neutral10,
    borderRadius: 12,
    padding: 12,
    borderWidth: 1,
    borderColor: theme.colors.lightWhite,
  },
  icon: {
    marginRight: 5,
  },
  placeholderStyle: {
    fontSize: 16,
  },
  selectedTextStyle: {
    ...theme.textVariants['body2.regular.14'],
    color: theme.colors.textBlack,
  },
  iconStyle: {
    width: 20,
    height: 20,
  },
  errorStyle: {
    borderColor: theme.colors.red,
  },
});
