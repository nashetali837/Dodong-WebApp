import React from 'react';
import {Box, Text} from '@atoms';
import {theme} from '@theme';
import {ActivityIndicator, Image, Pressable} from 'react-native';
import {
  GoogleSignin,
  NativeModuleError,
  statusCodes,
} from '@react-native-google-signin/google-signin';
import Toast from 'react-native-simple-toast';
import useUserData from '@src/hooks/user/useUserData';
import {GoogleAuthType} from '@src/constants/Enums';
import {ScreensList} from '@src/routes/helpers';
import {useNavigation} from '@react-navigation/native';

const GoogleLogo = require('../../../../assets/pngs/googleLogo.png');

interface IGoogleAuth {
  authType: GoogleAuthType;
}

const ExternalToken =
  'eyJhbGciOiJSUzI1NiIsImtpZCI6ImZkNDhhNzUxMzhkOWQ0OGYwYWE2MzVlZjU2OWM0ZTE5NmY3YWU4ZDYiLCJ0eXAiOiJKV1QifQ.eyJpc3MiOiJodHRwczovL2FjY291bnRzLmdvb2dsZS5jb20iLCJhenAiOiI1OTI0MzY4MDc4NzQtdmdic2IxbzA3bWE4YWlhMGpwbW8xbDA5cnV2Z2ZwNjMuYXBwcy5nb29nbGV1c2VyY29udGVudC5jb20iLCJhdWQiOiI1OTI0MzY4MDc4NzQtdmdic2IxbzA3bWE4YWlhMGpwbW8xbDA5cnV2Z2ZwNjMuYXBwcy5nb29nbGV1c2VyY29udGVudC5jb20iLCJzdWIiOiIxMDEyNjMxODM3OTg0MzE2NTExNTgiLCJlbWFpbCI6ImRldi5ybi5zdWt1bWFyQGdtYWlsLmNvbSIsImVtYWlsX3ZlcmlmaWVkIjp0cnVlLCJuYmYiOjE2OTEwNjY3NTgsIm5hbWUiOiJTdWt1bWFyIEFiaGlqZWV0IiwicGljdHVyZSI6Imh0dHBzOi8vbGgzLmdvb2dsZXVzZXJjb250ZW50LmNvbS9hL0FBY0hUdGNaVWNfU1NiYnUzVDZob0liOV9BTUFweE4wdU9NY1VYTXRaWi1jNE10S3dRPXM5Ni1jIiwiZ2l2ZW5fbmFtZSI6IlN1a3VtYXIiLCJmYW1pbHlfbmFtZSI6IkFiaGlqZWV0IiwibG9jYWxlIjoiZW4iLCJpYXQiOjE2OTEwNjcwNTgsImV4cCI6MTY5MTA3MDY1OCwianRpIjoiMTE1ZWFjZjFiMTQwY2E4OTEwMjk0NGQ1MzM0N2UxNDkyMTY2OWIyMiJ9.ID5czbtV-7xYybvYYh030CQH6iWzJu4-iByvLCy5lqVYDZnIGJ7dXghhX4MseHEjtpgDNum938DDhA0OhANMtQamQi4wfumcSiVGJ0w5R3iYuQpQ3qOLn_BJB3Kak13uorj1VWIStWGsewoZ4DwAmgoK75FyBqX_Nislj6GrJPrpU53G4tN4t8LtINjnaVqZgA9ND4f56YTCxl-ZIb0fnUMTgaVdAvCSgLr11exkmuTFPv8g6cJ-qqf2bswUydgNbkRj_jp0U0YtOxKdKjS6bAZSG2bDdQftjk-KxWEhuK1-rB4tVZ7tuUfwPgrOZwaxOxeWQqDDea5X4sd4a7tRJw';

const GoogleAuth: React.FC<IGoogleAuth> = ({authType}) => {
  const {authByGoogle, showLoader} = useUserData();
  const {reset} = useNavigation();
  const handleOnPress = async () => {
    checkIfSignedIn();
  };

  const resetLoginNavigation = () => {
    reset({
      index: 0,
      routes: [{name: ScreensList.Tabs}],
    });
  };

  const resetSignUpNavigation = () => {
    reset({
      index: 0,
      routes: [{name: ScreensList.ManualLocation}],
    });
  };

  const onAuthSuccess = () => {
    switch (authType) {
      case GoogleAuthType.LOGIN:
        resetLoginNavigation();
        break;

      case GoogleAuthType.SIGNUP:
        resetSignUpNavigation();
        break;

      default:
        break;
    }
  };

  const checkIfSignedIn = async () => {
    const isSignedIn = await GoogleSignin.isSignedIn();
    if (!isSignedIn) {
      _signIn();
    } else {
      const data = await GoogleSignin.getCurrentUser();
      if (!data) {
        await GoogleSignin.signOut();
        checkIfSignedIn();
      }
      if (data?.idToken) {
        authByGoogle(ExternalToken, onAuthSuccess);
      }
      console.log('data', data, isSignedIn);
    }
  };

  const _signIn = async () => {
    try {
      await GoogleSignin.hasPlayServices();
      const userInfo = await GoogleSignin.signIn();
      if (userInfo?.idToken) {
        authByGoogle(userInfo.idToken, onAuthSuccess);
      } else {
        throw 'Data Exception';
      }
    } catch (error) {
      const typedError = error as NativeModuleError;
      switch (typedError.code) {
        case statusCodes.SIGN_IN_CANCELLED:
          Toast.show('Cancelled', Toast.SHORT);
          break;
        case statusCodes.IN_PROGRESS:
          Toast.show('In Progress', Toast.SHORT);
          break;
        case statusCodes.PLAY_SERVICES_NOT_AVAILABLE:
          Toast.show('Play services not available or outdated', Toast.SHORT);
          break;
        default:
          Toast.show('Something went wrong', Toast.SHORT);
      }
    }
  };

  return (
    <Pressable onPress={handleOnPress}>
      <Box
        borderRadius={theme.size.TEN}
        bg={'neutral10'}
        borderColor={'lightWhite'}
        borderWidth={1}
        px={'_s48'}
        flexDirection={'row'}
        justifyContent={'center'}
        alignItems={'center'}
        py={'_s16'}>
        {showLoader ? (
          <ActivityIndicator color={theme.colors.orange500} />
        ) : (
          <>
            <Image source={GoogleLogo} style={{width: 20, height: 20}} />
            <Text variant={'body3.regular.12'} ml={'_s6'}>
              Google
            </Text>
          </>
        )}
      </Box>
    </Pressable>
  );
};

export default GoogleAuth;
