import {Size} from './Size';
import SpacingType from './types/Spacing.type';

export const Spacing: SpacingType = {
  _s0: Size.ZERO,
  _s1: Size.ONE,
  _s2: Size.TWO,
  _s3: Size.THREE,
  _s4: Size.FOUR,
  _s5: Size.FIVE,
  _s7: Size.SEVEN,
  _s6: Size.SIX,
  _s8: Size.EIGHT,
  _s10: Size.TEN,
  _s12: Size.TWELVE,
  _s14: Size.FOURTEEN,
  _s16: Size.SIXTEEN,
  _s18: Size.EIGHTEEN,
  _s20: Size.TWENTY,
  _s24: Size.TWENTY_FOUR,
  _s28: Size.TWENTY_EIGTH,
  _s34: Size.THIRTY_FOUR,
  _s32: Size.THIRTY_TWO,
  _s36: Size.THIRTY_SIX,
  _s42: Size.FOURTY_TWO,
  _s48: Size.FOURTY_EIGHT,
  _s40: Size.FOURTY,
  _s56: Size.FIFTY_SIX,
};

export default Spacing;
