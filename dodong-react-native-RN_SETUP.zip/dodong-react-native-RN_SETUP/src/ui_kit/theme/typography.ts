import {moderateScale} from '../../utilities/scaling';
import {fontSpecs} from './FontSpecs';
import TypographyType from './types/Typography.type';

const commonFontFamily = [
  {
    name: 'regular',
    value: fontSpecs.Primary,
  },
  {
    name: 'medium',
    value: fontSpecs.PrimaryMedium,
  },
  {
    name: 'semiBold',
    value: fontSpecs.PrimarySemiBold,
  },
  {
    name: 'bold',
    value: fontSpecs.PrimaryBold,
  },
];

const Typos = [
  {
    name: 'heading1',
    fontFamily: fontSpecs.PrimarySemiBold,
    sizes: [42, 28],
    style: {
      lineHeight: moderateScale(42),
    },
  },
  {
    name: 'heading2',
    fontFamily: fontSpecs.PrimarySemiBold,
    sizes: [24, 36],
    style: {
      lineHeight: moderateScale(36),
    },
  },
  {
    name: 'heading3',
    fontFamily: fontSpecs.PrimarySemiBold,
    sizes: [22, 34],
    style: {
      lineHeight: moderateScale(34),
    },
  },
  {
    name: 'heading4',
    fontFamily: fontSpecs.PrimarySemiBold,
    sizes: [20, 30],
    style: {
      lineHeight: moderateScale(30),
    },
  },
  {
    name: 'heading5',
    fontFamily: fontSpecs.PrimarySemiBold,
    sizes: [18, 28],
    style: {
      lineHeight: moderateScale(28),
    },
  },

  {
    name: 'body1',
    fontFamily: commonFontFamily,
    sizes: [16, 24],
    style: {
      lineHeight: moderateScale(24),
    },
  },

  {
    name: 'body2',
    fontFamily: commonFontFamily,
    sizes: [14, 22],
    style: {
      lineHeight: moderateScale(22),
    },
  },

  {
    name: 'body3',
    fontFamily: commonFontFamily,
    sizes: [12, 18],
    style: {
      lineHeight: moderateScale(18),
    },
  },

  {
    name: 'body4',
    fontFamily: commonFontFamily,
    sizes: [10, 16],
    style: {
      lineHeight: moderateScale(16),
    },
  },

  {
    name: 'body5',
    fontFamily: commonFontFamily,
    sizes: [5, 8],
    style: {
      lineHeight: moderateScale(12),
    },
  },
];

const Typography: TypographyType = {};

Typos.map(each => {
  if (Array.isArray(each.fontFamily)) {
    each.fontFamily.map(eachFontFamily => {
      each.sizes.map((eachSize: number) => {
        //@ts-ignore
        Typography[`${each.name}.${eachFontFamily.name}.${eachSize}`] = {
          fontFamily: eachFontFamily.value,
          fontSize: moderateScale(eachSize),
          ...each.style,
        };
      });
    });
  } else {
    each.sizes.map(eachSize => {
      //@ts-ignore
      Typography[`${each.name}.${eachSize}`] = {
        fontFamily: each.fontFamily,
        fontSize: moderateScale(eachSize),
        ...each.style,
      };
    });
  }
});

export default Typography;
