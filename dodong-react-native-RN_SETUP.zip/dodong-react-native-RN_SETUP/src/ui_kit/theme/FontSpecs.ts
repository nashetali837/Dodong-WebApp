import FontSpecType from './types/FontSpec.type';

export const fontSpecs: FontSpecType = {
  Primary: 'Kanit-Regular',
  PrimaryMedium: 'Kanit-Medium',
  PrimaryBold: 'Kanit-Bold',
  PrimarySemiBold: 'Kanit-SemiBold',
};
