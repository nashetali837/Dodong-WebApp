import {createTheme} from '@shopify/restyle';

import colorPalette from './ColorPalette';
import Size from './Size';
import Spacing from './Spacing';
import Typography from './typography';

const {orange, neutral, misc, gradients} = colorPalette;

export const theme = createTheme({
  colors: {
    ...orange,
    ...neutral,
    ...misc,
    ...gradients,
  },
  spacing: Spacing,
  size: Size,
  breakpoints: {},
  textVariants: Typography,
});

export type Theme = typeof theme;

export const lightTheme: Theme = {
  ...theme,
};
