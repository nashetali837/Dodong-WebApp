import ColorPalleteType from './types/ColorPalette.type';

const colorPalette: ColorPalleteType = {
  neutral: {
    neutral10: '#FDFDFD',
    neutral50: '#f2f2f2',
    neutral100: '#d8d8d8',
    neutral200: '#c5c5c5',
    neutral300: '#aaaaaa',
    neutral400: '#999999',
    neutral500: '#808080',
    neutral600: '#747474',
    neutral700: '#5b5b5b',
    neutral800: '#464646',
    neutral900: '#363636',
  },
  orange: {
    orange50: '#fff5e6',
    orange100: '#ffdfb0',
    orange200: '#ffd08a',
    orange300: '#ffba54',
    orange400: '#ffad33',
    orange500: '#ff9800',
    orange600: '#e88a00',
    orange700: '#b56c00',
    orange800: '#8c5400',
    orange900: '#6b4000',
  },
  misc: {
    white: '#ffffff',
    white20: 'rgba(255,255,255,0.20)',
    black20: 'rgba(4, 4, 21, 1)',
    black: '#000000',
    orange: '#FA9600',
    shurf: '#0198A7',
    gray1: '#8D8A95',
    gray2: '#110C22',
    lightWhite: '#ECECED',
    red: 'red',
    textBlack: '#041727',
    black: '#000',
  },
  gradients: {
    grad1: '#0265C0',
  },
};

export default colorPalette;
