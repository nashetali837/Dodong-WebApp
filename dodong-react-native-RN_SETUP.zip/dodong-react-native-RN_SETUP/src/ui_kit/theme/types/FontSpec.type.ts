export default interface FontSpecType {
  Primary: string;
  PrimaryMedium: string;
  PrimaryBold: string;
  PrimarySemiBold: string;
};
