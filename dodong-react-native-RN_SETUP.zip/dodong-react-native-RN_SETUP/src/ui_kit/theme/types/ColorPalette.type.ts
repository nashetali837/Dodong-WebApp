export default interface ColorPalleteType {
  neutral: {
    neutral10: string;
    neutral50: string;
    neutral100: string;
    neutral200: string;
    neutral300: string;
    neutral400: string;
    neutral500: string;
    neutral600: string;
    neutral700: string;
    neutral800: string;
    neutral900: string;
  };
  orange: {
    orange50: string;
    orange100: string;
    orange200: string;
    orange300: string;
    orange400: string;
    orange500: string;
    orange600: string;
    orange700: string;
    orange800: string;
    orange900: string;
  };
  misc: {
    white: string;
    white20: string;
    black: string;
    orange: string;
    shurf: string;
    gray1: string;
    lightWhite: string;
  };
  gradients: {
    grad1: string;
  };
}
