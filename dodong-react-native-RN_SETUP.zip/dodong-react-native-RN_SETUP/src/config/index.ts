export enum ENV {
  PROD = 'production',
  DEV = 'dev',
}

export const ENV_LIVE = ENV.DEV;

const GOOGLE_MAP_API_KEY = 'AIzaSyAjzJ24t6KAnbJ_H3buz96PHmnFeK9ZZ78';
const FACEBOOK_CLIENT_ID = '708703114198422';
const FACEBOOK_CLIENT_SECRET = '0b919a425443f0f65ca5363ebe2848ce';

const environments = {
  production: {
    baseUrl: 'https://api.dodong.in',
    apiKeys: {
      googlePlacesAPIKey: GOOGLE_MAP_API_KEY,
    },
    appConfig: '/config?device=mobile',
    stores: {
      playStore: '',
      appStore: '',
    },
    endpoints: {
      auth: {
        login: '/auth/login',
        forgotPass: '/auth/forgot-password',
        profile: 'users/profile',
        googleAuth: '/auth/google',
        verifyEmail: 'auth/verify-email',
        verifyEmailOtp: '/auth/verify-otp',
        register: 'auth/register',
        updateProfile: 'users/update-profile',
        updateProfessionalProfile: 'users/update-professional-profile',
      },
      google: {
        googleAutoComplete:
          'https://maps.googleapis.com/maps/api/place/autocomplete/json?',
        googlePlaceDetail:
          'https://maps.googleapis.com/maps/api/place/details/json?',
        googleLogin: 'auth/google',
      },
      locations: {
        updateLocation: '/locations/create',
      },
      upload: {
        imageUpload: '/api/upload-s3',
      },
      store: {
        storeFront: '/storefront?device=web',
      },
      shop: {
        shopDetail: '/shops',
        createShop: '/shops/create',
        nearbyShops: '/shops/near-by?',
      },
      product: {
        productDetail: '/products?',
      },
      category: {
        postSubCategory: '/posts/sub-categories/filter',
      },
      resources: {
        createPost: '/posts/create',
        getComments: '/comments/get?',
        getResourceById: '/resources/get?',
        addComment: '/comments/add',
      },
      notifications: {
        notificationList: '/notifications/get?',
      },
    },
    webUrls: {
      termsNCond: 'https://www.dodong.in',
    },
  },
  dev: {
    baseUrl: 'https://dev.dodong.in',
    apiKeys: {
      googlePlacesAPIKey: GOOGLE_MAP_API_KEY,
    },
    appConfig: '/config?device=mobile',
    stores: {
      playStore: '',
      appStore: '',
    },
    endpoints: {
      auth: {
        login: '/auth/login',
        forgotPass: '/auth/forgot-password',
        profile: 'users/profile',
        googleAuth: '/auth/google',
        verifyEmail: 'auth/verify-email',
        verifyEmailOtp: '/auth/verify-otp',
        register: 'auth/register',
        updateProfile: 'users/update-profile',
        updateProfessionalProfile: 'users/update-professional-profile',
      },
      google: {
        googleAutoComplete:
          'https://maps.googleapis.com/maps/api/place/autocomplete/json?',
        googlePlaceDetail:
          'https://maps.googleapis.com/maps/api/place/details/json?',
        googleLogin: 'auth/google',
      },
      locations: {
        updateLocation: '/locations/create',
      },
      upload: {
        imageUpload: '/api/upload-s3',
      },
      store: {
        storeFront: '/storefront?device=web',
      },
      shop: {
        shopDetail: '/shops',
        createShop: '/shops/create',
        nearbyShops: '/shops/near-by?',
      },
      product: {
        productDetail: '/products?',
      },
      category: {
        postSubCategory: '/posts/sub-categories/filter',
      },
      resources: {
        createPost: '/posts/create',
        getComments: '/comments/get?',
        getResourceById: '/resources/get?',
        addComment: '/comments/add',
      },
      notifications: {
        notificationList: '/notifications/get?',
      },
    },
    webUrls: {
      termsNCond: 'https://www.dodong.in',
    },
  },
};

const config = {
  baseUrl: environments[ENV_LIVE].baseUrl,
  endPoints: {
    login: environments[ENV_LIVE].endpoints.auth.login,
    googleLogin: environments[ENV_LIVE].endpoints.google.googleLogin,
    forgotPass: environments[ENV_LIVE].endpoints.auth.forgotPass,
    profile: environments[ENV_LIVE].endpoints.auth.profile,
    googleAuth: environments[ENV_LIVE].endpoints.auth.googleAuth,
    verifyEmail: environments[ENV_LIVE].endpoints.auth.verifyEmail,
    verifyEmailOtp: environments[ENV_LIVE].endpoints.auth.verifyEmailOtp,
    registerUser: environments[ENV_LIVE].endpoints.auth.register,
    updateProfile: environments[ENV_LIVE].endpoints.auth.updateProfile,
    updateProfessionalProfile:
      environments[ENV_LIVE].endpoints.auth.updateProfessionalProfile,
    googleAutoComplete:
      environments[ENV_LIVE].endpoints.google.googleAutoComplete,
    googlePlaceDetail:
      environments[ENV_LIVE].endpoints.google.googlePlaceDetail,
    updateLocation: environments[ENV_LIVE].endpoints.locations.updateLocation,
    storeFront: environments[ENV_LIVE].endpoints.store.storeFront,
    imageUpload: environments[ENV_LIVE].endpoints.upload.imageUpload,
    shopDetail: environments[ENV_LIVE].endpoints.shop.shopDetail,
    nearbyShops: environments[ENV_LIVE].endpoints.shop.nearbyShops,
    createShop: environments[ENV_LIVE].endpoints.shop.createShop,
    appConfig: environments[ENV_LIVE].appConfig,
    postSubCategory: environments[ENV_LIVE].endpoints.category.postSubCategory,
    createPost: environments[ENV_LIVE].endpoints.resources.createPost,
    notificationList:
      environments[ENV_LIVE].endpoints.notifications.notificationList,
    getComments: environments[ENV_LIVE].endpoints.resources.getComments,
    getResourceById: environments[ENV_LIVE].endpoints.resources.getResourceById,
    addComment: environments[ENV_LIVE].endpoints.resources.addComment,
    productDetail: environments[ENV_LIVE].endpoints.product.productDetail,
  },
  apiKeys: {
    googlePlacesAPIKey: environments[ENV_LIVE].apiKeys.googlePlacesAPIKey,
  },
  stores: {
    playStore: environments[ENV_LIVE].stores.playStore,
    appStore: environments[ENV_LIVE].stores.appStore,
  },
  webUrls: {
    termsNCond: environments[ENV_LIVE].webUrls.termsNCond,
  },
};

export default config;
