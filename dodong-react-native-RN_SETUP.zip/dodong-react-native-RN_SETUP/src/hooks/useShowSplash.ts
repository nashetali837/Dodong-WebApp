import AsyncStorage from '@react-native-async-storage/async-storage';
import appContstants from '@src/core/api/appContstants';
import {AuthSlice} from '@src/redux';
import {useEffect, useState} from 'react';
import {useDispatch} from 'react-redux';
import useUserData from './user/useUserData';
import {GoogleSignin} from '@react-native-google-signin/google-signin';
import config from '@src/config';
import Geocoder from 'react-native-geocoding';
import {useAppConfig} from './app/useAppConfig';

const useShowSplash = () => {
  const dispatch = useDispatch();
  const {fetchUserData} = useUserData();
  useAppConfig();
  const [showSplash, setShowSplash] = useState<boolean>(true);

  const sdkConfigurations = () => {
    GoogleSignin.configure();
    Geocoder.init(config.apiKeys.googlePlacesAPIKey);
  };

  const checkAppConfigs = async () => {
    sdkConfigurations();
    const token = await AsyncStorage.getItem(appContstants.token);
    console.log('token', token);
    if (token) {
      dispatch(
        AuthSlice.actions.setToken({access_token: token, errorMessage: ''}),
      );
      fetchUserData(token);
    }
    setShowSplash(false);
  };

  useEffect(() => {
    checkAppConfigs();
  }, []);

  return {
    showSplash,
  };
};

export default useShowSplash;
