import uploadService from '@src/core/api/services/UploadService';
import {ImagePickerAsset} from '@src/screens/profile/components/selectProfileImage/type';
import {IS_IOS} from '@src/utilities/helpers';
import {
  processAndroidImagePick,
  processIOSImagePick,
} from '@src/utilities/imageVideoHelper';
import {useState} from 'react';
import {
  Callback,
  ImageLibraryOptions,
  launchImageLibrary,
} from 'react-native-image-picker';
import Toast from 'react-native-simple-toast';

const libraryOptions: ImageLibraryOptions = {
  mediaType: 'photo',
};

const useImageSelector = ({
  onImagePicked,
}: {
  onImagePicked: (asset: ImagePickerAsset) => void;
}) => {
  const [currentAsset, setCurrentAsset] = useState<ImagePickerAsset | null>(
    null,
  );
  const [loading, setloading] = useState<boolean>(false);

  const onImageSelected = (response: Callback) => {
    const imageAsset = IS_IOS
      ? processIOSImagePick(response)
      : processAndroidImagePick(response);
    if (imageAsset) {
      setCurrentAsset(imageAsset);
      onImagePicked?.(imageAsset);
    }
  };

  const handleOnImagePress = () => {
    launchImageLibrary(libraryOptions, onImageSelected);
  };

  const uploadImageToServer = async (callBack?: () => void) => {
    try {
      setloading(true);
      const imgData = {
        name: currentAsset?.fileName ?? '',
        type: currentAsset?.type ?? '',
        uri: currentAsset?.uri ?? '',
      };
      const resp = await uploadService.uploadImageToServer(imgData);
      console.log('resp', resp);
      setloading(false);
    } catch (error) {
      Toast.show('Something went wrong', Toast.LONG);
      setloading(false);
    }
  };

  return {
    loading,
    currentAsset,
    setCurrentAsset,
    handleOnImagePress,
    uploadImageToServer,
  };
};
export default useImageSelector;
