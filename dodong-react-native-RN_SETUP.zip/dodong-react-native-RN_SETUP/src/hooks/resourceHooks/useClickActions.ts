import {SHORT_ACTIONS} from '@src/constants/Enums';
import resourceService from '@src/core/api/services/ResourceService';
import {useState} from 'react';
import Toast from 'react-native-simple-toast';

export const useClickActions = ({
  onCommentSubmitCallback,
  id,
}: TClickActions) => {
  const [addCommentLoad, setAddCommentLoad] = useState<boolean>(false);

  const onCommentSubmit = async (comment: string) => {
    if (comment.length) {
      setAddCommentLoad(true);
      try {
        const resp = await resourceService.addCommentById({
          resourceID: id,
          commentBody: comment,
        });
        Toast.show(resp?.data?.message ?? '', Toast.LONG);
        setAddCommentLoad(false);
        onCommentSubmitCallback?.();
      } catch (error) {
        setAddCommentLoad(false);
      }
    }
  };

  const onLikeDislikeResource = async (isLiked = false) => {
    const type = isLiked ? SHORT_ACTIONS.UNLIKE : SHORT_ACTIONS.LIKE;
    const res = await resourceService.likeUnlikeResourceById(
      {postID: id},
      type,
    );
    Toast.show(res?.data?.message, Toast.LONG);
  };

  return {
    addCommentLoad,
    onCommentSubmit,
    onLikeDislikeResource,
  };
};
