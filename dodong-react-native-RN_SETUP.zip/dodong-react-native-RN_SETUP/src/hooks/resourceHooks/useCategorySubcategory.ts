import resourceService from '@src/core/api/services/ResourceService';
import {RootState} from '@src/redux';
import {useState} from 'react';
import {useSelector} from 'react-redux';

const transformArray = (inputArray: TCatSubcatItem[]) => {
  return inputArray.map(item => ({
    id: item.id,
    value: item.id,
    label: item.displayName,
  }));
};

const useCatSubCat = () => {
  const topCategories = useSelector(
    (state: RootState) => state?.app?.appConfig?.topCategories,
  );
  const [subCategories, setSubCategories] = useState([]);

  const getSubCatByCat = async (categoryId: number) => {
    const res = await resourceService.getPostSubCategory(categoryId);
    if (res?.data?.categories) {
      setSubCategories(res.data.categories);
    }
  };

  const transformedCategories = transformArray(topCategories);
  const transoformedSubCats = transformArray(subCategories);

  return {
    topCategories: transformedCategories,
    getSubCatByCat,
    subCategories: transoformedSubCats,
  };
};

export default useCatSubCat;
