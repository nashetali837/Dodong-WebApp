import {RESOURCE_TYPES} from '@src/constants/Enums';
import resourceService from '@src/core/api/services/ResourceService';
import Toast from 'react-native-simple-toast';
import {useState} from 'react';

export const usePostCreation = () => {
  const [loading, setLoading] = useState<boolean>(false);
  const createPost = async (dataSet: any, callback?: () => void) => {
    try {
      setLoading(true);
      const data = {
        isNewProduct: true,
        isNewUserMeasurements: true,
        newProduct: {
          ...dataSet,
          subCategory: dataSet.subCategoryId,
          // location: '',
        },
        resourceType: RESOURCE_TYPES.POST,
        shopID: dataSet.shopID,
        // userMeasurementId: null,
        userMeasurements: {},
      };
      console.log('data', data);
      const res = await resourceService.createPost(data);
      if (res?.data?.postID) {
        Toast.show('Post Created Successfully', Toast.LONG);
        callback?.();
      }
      console.log('dataSet', res);
      setLoading(false);
    } catch (error) {
      Toast.show('Something went wrong', Toast.LONG);
      setLoading(false);
    }
  };

  return {
    createPost,
    loading,
  };
};
