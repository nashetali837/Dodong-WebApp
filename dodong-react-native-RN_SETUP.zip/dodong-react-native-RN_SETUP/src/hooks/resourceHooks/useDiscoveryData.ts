import {RESOURCE_TYPES} from '@src/constants/Enums';
import storeService from '@src/core/api/services/StoreService';
import {useEffect, useState} from 'react';

export const useDiscoveryData = () => {
  const [discoveryData, setDiscoveryData] = useState<TStoreFront>({
    trendingPosts: [],
    localShops: [],
  });

  const fetchDiscoveries = async () => {
    const res = await storeService.getStoreFrontList(
      1,
      RESOURCE_TYPES.DISCOVERY,
    );
    if (res?.data) {
      setDiscoveryData(res.data);
    }
    console.log('res', res);
  };

  useEffect(() => {
    fetchDiscoveries();
  }, []);

  return {
    discoveries: discoveryData?.trendingPosts ?? [],
  };
};
