import {useNavigation} from '@react-navigation/native';
import resourceService from '@src/core/api/services/ResourceService';
import Toast from 'react-native-simple-toast';
import {useEffect, useState} from 'react';
import {TResourceDetail} from '@src/core/api/services/schema.type';
import {useClickActions} from './useClickActions';

export const useResourceDetails = ({resourceId}: {resourceId: number}) => {
  const {goBack} = useNavigation();
  const [commentList, setCommentList] = useState([]);

  const fetchComments = async () => {
    const res = await resourceService.getCommentsById(resourceId);
    if (res?.data?.comments) {
      setCommentList(res.data.comments);
    }
  };

  console.log('fetchComments -->', commentList);
  const {addCommentLoad, onCommentSubmit} = useClickActions({
    id: resourceId,
    onCommentSubmitCallback: fetchComments,
  });

  const [resourceDetails, setResourceDetails] =
    useState<TResourceDetail | null>(null);

  const fetchDetail = async () => {
    const res = await resourceService.getResourceById(resourceId);
    if (res?.data?.resource) {
      setResourceDetails(res.data.resource);
    } else {
      Toast.show('Couldnot fetch resource', Toast.LONG);
      goBack();
    }
  };

  useEffect(() => {
    fetchDetail();
    fetchComments();
  }, []);

  return {
    resourceDetails,
    onCommentSubmit,
    commentList,
    addCommentLoad,
  };
};
