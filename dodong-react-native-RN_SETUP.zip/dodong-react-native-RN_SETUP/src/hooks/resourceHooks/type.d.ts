type TCatSubcatItem = {
  id: number;
  displayName: string;
};

type TClickActions = {
  onCommentSubmitCallback?: () => void;
  id: number;
};
