import authService from '@src/core/api/services/AuthService';
import {RootState} from '@src/redux';
import {TUserData} from '@src/redux/auth/type';
import {useEffect, useState} from 'react';
import {useSelector} from 'react-redux';

export const usePublicUserData = ({profileId}: {profileId: number}) => {
  const [userData, setUserData] = useState<TUserData>([]);
  const [loading, setLoading] = useState<boolean>(false);

  const token = useSelector((state: RootState) => state.auth?.token);

  const fetchPublicUser = async () => {
    setLoading(true);
    const res = await authService.getPublicUserProfile(profileId, token);
    if (res?.data?.profile?.id) {
      setUserData(res?.data);
    }
    setLoading(false);
    console.log('res', res);
  };

  useEffect(() => {
    fetchPublicUser();
  }, []);

  return {
    userData,
    loading,
  };
};
