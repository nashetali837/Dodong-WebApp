import authService from '@src/core/api/services/AuthService';
import {
  TImageUploadData,
  TUpdateProfessionalProfile,
  TUpdateProfile,
  TUserRegister,
} from '@src/core/api/services/schema.type';
import {AuthSlice, RootState} from '@src/redux';
import {useState} from 'react';
import {useDispatch, useSelector} from 'react-redux';
import Toast from 'react-native-simple-toast';
import googleService from '@src/core/api/services/GoogleService';
import AsyncStorage from '@react-native-async-storage/async-storage';
import appContstants from '@src/core/api/appContstants';
import uploadService from '@src/core/api/services/UploadService';

const useUserData = () => {
  const [showLoader, setShowLoader] = useState<boolean>(false);

  const userData = useSelector((state: RootState) => state.auth?.userData);
  const token = useSelector((state: RootState) => state.auth?.token);

  const dispatch = useDispatch();

  const getUserRegistered = async (
    data: TUserRegister,
    tempToken: string,
    callback?: () => void,
  ) => {
    const regResp = await authService.getUserRegistered(data, tempToken);
    const regToken = regResp?.data.token ?? '';
    if (regToken?.length) {
      await AsyncStorage.setItem(appContstants.token, regToken);
      fetchUserData(regToken, callback);
    } else {
      Toast.show('Something went wrong while registering', Toast.LONG);
    }
  };

  const fetchUserData = async (access_token: string, callback?: () => void) => {
    if (!token) {
      dispatch(
        AuthSlice.actions.setToken({
          access_token,
          errorMessage: '',
        }),
      );
    }
    const resp = await authService.getUserProfile(access_token);
    if (resp?.data) {
      callback?.();
      dispatch(AuthSlice.actions.setUserData(resp.data));
    }
  };

  const authByGoogle = async (googleToken: string, callback: () => void) => {
    setShowLoader(true);
    try {
      const resp = await googleService.getAuthToken({tokenId: googleToken});
      if (resp?.data?.token) {
        await AsyncStorage.setItem(appContstants.token, resp?.data.token);
        callback?.();
        fetchUserData(resp.data.token);
      } else {
        throw '';
      }
    } catch (error) {
      Toast.show('Oops Something went wrong', Toast.LONG);
      setShowLoader(false);
    }
  };

  const updateUserProfile = async (
    dataSet: TUpdateProfile,
    callback?: () => void,
  ) => {
    setShowLoader(true);
    const resp = await authService.updateUserProfile(token, dataSet);
    if (resp?.data?.id) {
      Toast.show('Profile Updated', Toast.LONG);
      callback?.();
      fetchUserData(token);
    } else {
      Toast.show('Oops somethine went wrong', Toast.LONG);
      setShowLoader(false);
    }
    setShowLoader(false);
  };

  const uploadUserProfileImage = async (data: TImageUploadData) => {
    const resp = await uploadService.uploadImageToServer(data, token);
    console.log('res', resp);
    return resp;
  };

  const updateUserProfessionalProfile = async (
    dataSet: TUpdateProfessionalProfile,
  ) => {
    setShowLoader(true);
    const resp = await authService.updateUserProfessionalProfile(
      token,
      dataSet,
    );
    if (resp?.data) {
      Toast.show('Profile Updated', Toast.LONG);
      fetchUserData(token);
    } else {
      Toast.show('Oops somethine went wrong', Toast.LONG);
    }
    setShowLoader(false);
  };

  return {
    userData,
    isLoggedIn: token?.length ? true : false,
    fetchUserData,
    updateUserProfile,
    showLoader,
    setShowLoader,
    updateUserProfessionalProfile,
    authByGoogle,
    getUserRegistered,
    uploadUserProfileImage,
    token,
  };
};

export default useUserData;
