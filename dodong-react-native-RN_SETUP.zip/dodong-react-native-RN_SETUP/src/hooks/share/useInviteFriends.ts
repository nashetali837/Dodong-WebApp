import config from '@src/config';
import {IS_IOS} from '@src/utilities/helpers';
import {Linking, Share} from 'react-native';
import Toast from 'react-native-simple-toast';

const defaultInviteMessage = `📣 Discover with dodong! 🌟🛍️💡

${IS_IOS ? config.stores.appStore : config.stores.playStore}

Follow me for local shop finds, product experiences, and collections on dodong. Let's explore together and make amazing discoveries! 🤝🌍✨
 
#dodongApp #ShopLocal #DiscoverWithDodong`;

export const UseInviteFriends = () => {
  const inviteByWhatsaap = (message = defaultInviteMessage) => {
    const url = `https://wa.me/?text=${encodeURIComponent(message)}`;
    Linking.openURL(url).catch(error =>
      Toast.show('Error opening whatsapp ', Toast.LONG),
    );
  };

  const inviteByEmail = (
    subject = '',
    body = defaultInviteMessage,
    recipient = '',
  ) => {
    const url = `mailto:${recipient}?subject=${encodeURIComponent(
      subject,
    )}&body=${encodeURIComponent(body)}`;
    Linking.openURL(url).catch(error =>
      Toast.show('Error opening email app', Toast.LONG),
    );
  };

  const inviteBySms = (message = defaultInviteMessage, phoneNumber = '') => {
    const url = `sms:${phoneNumber}?body=${encodeURIComponent(message)}`;
    Linking.openURL(url).catch(error =>
      Toast.show('Error opening SMS app', Toast.LONG),
    );
  };
  const genericInvite = async (message = defaultInviteMessage, url = '') => {
    try {
      const options = {message, url};
      await Share.share(options);
    } catch (error) {
      Toast.show(error.message, Toast.LONG);
    }
  };

  return {
    inviteByWhatsaap,
    inviteByEmail,
    inviteBySms,
    genericInvite,
    defaultInviteMessage,
  };
};
