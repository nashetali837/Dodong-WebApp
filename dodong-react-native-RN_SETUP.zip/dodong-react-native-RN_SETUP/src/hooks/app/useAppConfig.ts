import authService from '@src/core/api/services/AuthService';
import {AppSlice} from '@src/redux';
import {useEffect} from 'react';
import {useDispatch} from 'react-redux';

export const useAppConfig = () => {
  const dispatch = useDispatch();

  const getAppConfig = async () => {
    const res = await authService.getAppConfig();
    if (res?.data?.config) {
      dispatch(AppSlice.actions.setAppConfig(res.data.config));
    }
  };

  useEffect(() => {
    getAppConfig();
  }, []);

  return {};
};
