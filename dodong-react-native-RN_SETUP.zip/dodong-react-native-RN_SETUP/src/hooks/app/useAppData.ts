import {RootState} from '@src/redux';
import {useSelector} from 'react-redux';

const useAppData = () => {
  const isOnboardingDone = useSelector(
    (state: RootState) => state.app?.isOnboardingDone,
  );
  return {
    isOnboardingDone,
  };
};

export default useAppData;
