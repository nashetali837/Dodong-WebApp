import {NavigationContainerRef} from '@react-navigation/native';
import {useRef} from 'react';

const useNavigationRef = () => {
  const navigationRef: React.RefObject<NavigationContainerRef> = useRef(null);
  const routeNameRef = useRef<string | undefined>(
    navigationRef.current?.getCurrentRoute()?.name,
  );
  const prevRouteNameRef = useRef<string | undefined>(routeNameRef.current);

  const updateNavigationRef = (currentRoute: string) => {
    prevRouteNameRef.current = routeNameRef.current;
    routeNameRef.current = currentRoute;
  };

  return {
    updateNavigationRef,
    navigationRef,
    routeNameRef,
    prevRouteNameRef,
  };
};

export default useNavigationRef;
