import {RootState} from '@src/redux';
import {HomeThunk} from '@src/redux/home';
import {useEffect, useRef, useState} from 'react';
import {useDispatch, useSelector} from 'react-redux';

export const useStoreFront = () => {
  let pageCount = useRef(1);
  const storeFront = useSelector((state: RootState) => state.home?.storeFront);
  const dispatch = useDispatch();
  const [refreshing, setRefreshing] = useState<boolean>(false);

  const fetchData = (page = 1) => dispatch(HomeThunk.getStoreFrontList({page}));

  const refreshData = () => {
    setRefreshing(true);
    fetchData();
    setRefreshing(false);
  };

  const onEndReached = () => {
    if (storeFront?.totalPosts > storeFront?.resources?.length) {
      fetchData(pageCount.current);
      pageCount.current = pageCount.current + 1;
    }
  };

  useEffect(() => {
    fetchData();
  }, []);

  return {
    resources: storeFront?.resources ?? [],
    fetchData,
    refreshing,
    refreshData,
    onEndReached,
  };
};
