import {useNavigation} from '@react-navigation/native';
import {useRef} from 'react';
import {
  runOnJS,
  useAnimatedScrollHandler,
  useSharedValue,
} from 'react-native-reanimated';

import {IScrollHandler} from './type';

const useCustomScrollHandler = ({
  viewPortIndex,
  handleViewableExternalChange,
  isBottomTabsVisible = false,
  onScrollDragEnd,
  onScrollDragBegin,
  onScroll: onExternalScroll,
}: IScrollHandler) => {
  const navigation = useNavigation();

  const lastContentOffset = useSharedValue(0);
  const isScrolling = useSharedValue(false);
  const isScrollingUp = useSharedValue(true);
  const scrollYDiffRef = useSharedValue(0);
  const scrollYRef = useSharedValue(0);
  const showScrollToTop = useSharedValue(false);

  const flatListRef = useRef(null);

  const itemViewabilityConfigRef = useRef({itemVisiblePercentThreshold: 50});
  const handleViewableItemsChanged = useRef(
    ({viewableItems, changed}: {viewableItems: any[]; changed: any[]}) => {
      handleViewableExternalChange?.(viewableItems, changed);
      if (Array.isArray(viewableItems) && viewableItems.length) {
        const viewItemIndex = viewableItems[0].index ?? 0;
        if (viewItemIndex >= viewPortIndex && isScrollingUp.value) {
          showScrollToTop.value = true;
        } else {
          showScrollToTop.value = false;
        }
      }
    },
  );

  const handleUpScrolling = () => {
    isScrollingUp.value = true;
  };

  const handleDownScrolling = () => {
    isScrollingUp.value = false;
  };

  const handleBottomTabs = ({...extraData}) => {
    if (isBottomTabsVisible) {
      navigation.setOptions({tabBarStyle: {...extraData}});
    }
  };

  const animatedScrollHandler = useAnimatedScrollHandler({
    onScroll: (event, ctx: {prevScrollY?: number | undefined}) => {
      if (onExternalScroll) {
        runOnJS(onExternalScroll)(event);
      }
      if (scrollYRef) {
        scrollYRef.value = event.contentOffset.y;
      }
      ctx.prevScrollY = event.contentOffset.y;
      if (lastContentOffset.value > event.contentOffset.y) {
        if (isScrolling.value) {
          runOnJS(handleUpScrolling)();
        }
      } else if (lastContentOffset.value < event.contentOffset.y) {
        if (isScrolling.value) {
          runOnJS(handleDownScrolling)();
        }
      }
      lastContentOffset.value = event.contentOffset.y;
    },
    onBeginDrag: () => {
      isScrolling.value = true;
      if (onScrollDragBegin) {
        runOnJS(onScrollDragBegin)();
      }
    },
    onEndDrag: () => {
      isScrolling.value = false;
      if (onScrollDragEnd) {
        runOnJS(onScrollDragEnd)();
      }
    },
  });

  return {
    animatedScrollHandler,
    itemViewabilityConfigRef,
    handleViewableItemsChanged,
    showScrollToTop,
    scrollYDiffRef,
    scrollYRef,
    isScrolling,
    isScrollingUp,
    handleBottomTabs,
    flatListRef,
  };
};

export default useCustomScrollHandler;
