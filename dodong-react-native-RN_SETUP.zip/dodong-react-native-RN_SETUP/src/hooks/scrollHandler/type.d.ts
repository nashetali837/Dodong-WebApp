import {NativeScrollEvent} from 'react-native';
import {SharedValue} from 'react-native-reanimated';

export interface IScrollHandler {
  viewPortIndex: number;
  handleViewableExternalChange?: (viewableItems: any[], changed: any[]) => void;
  isBottomTabsVisible?: boolean;
  scrollYRef?: SharedValue<number>;
  barHeight?: number;
  onScrollDragEnd?: () => void;
  onScrollDragBegin?: () => void;
  onScroll?: (event: NativeScrollEvent) => void;
}
