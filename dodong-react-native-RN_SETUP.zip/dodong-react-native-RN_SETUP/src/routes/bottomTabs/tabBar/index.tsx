import React from 'react';
import {Box} from '@atoms';

import Tab from './tab';

const CustomTabBar = ({...props}) => {
  const {state, descriptors, navigation} = props;

  const tabProps = {
    descriptors,
    state,
    navigation,
  };
  return (
    <Box
      bottom={32}
      position="absolute"
      width={'90%'}
      alignSelf={'center'}
      flexDirection={'row'}
      justifyContent={'space-between'}
      alignItems={'center'}
      bg={'black'}
      p={'_s10'}
      borderRadius={100}>
      {state.routes.map((route: any, index: number) => (
        <Tab
          route={route}
          index={index}
          key={`customTab${index}`}
          {...tabProps}
        />
      ))}
    </Box>
  );
};

export default CustomTabBar;
