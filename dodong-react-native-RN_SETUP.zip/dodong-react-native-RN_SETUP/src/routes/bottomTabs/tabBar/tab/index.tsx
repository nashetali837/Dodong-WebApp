import React from 'react';

import AppIcon from '@components/appIcons/AppIcon';
import {TabIconsMap, TabScreensList, ScreensList} from '@src/routes/helpers';
import {ImageBackground, Pressable} from 'react-native';
import {StyleSheet} from 'react-native';
import {theme} from '@theme';

const DefaultTab = ({isFocused, label}) => {
  return (
    <>
      {isFocused ? (
        <ImageBackground
          source={require('../../../../assets/pngs/tabs/selectedBack.png')}
          style={styles.tabStyle}>
          <AppIcon name={TabIconsMap[label]} color={'transparent'} size={24} />
        </ImageBackground>
      ) : (
        <AppIcon name={TabIconsMap[label]} color={'transparent'} size={24} />
      )}
    </>
  );
};

const CreateTab = () => {
  return (
    <ImageBackground
      source={require('../../../../assets/pngs/tabs/createTab.png')}
      style={[styles.tabStyle]}
    />
  );
};

const ProfileTab = () => {
  return (
    <ImageBackground
      source={require('../../../../assets/pngs/tabs/profileMale.png')}
      style={styles.tabStyle}
    />
  );
};

const TabViewMapper = {
  [TabScreensList.Home]: DefaultTab,
  [TabScreensList.Explore]: DefaultTab,
  [TabScreensList.Create]: CreateTab,
  [TabScreensList.Notifications]: DefaultTab,
  [TabScreensList.Profile]: ProfileTab,
};

const Tab = ({...props}) => {
  const {descriptors, route, state, index, navigation} = props;
  const {options} = descriptors[route.key];
  const isFocused = state.index === index;
  const label = options.tabBarLabel;

  const onPress = () => {
    const event = navigation.emit({
      type: 'tabPress',
      target: route.key,
      canPreventDefault: true,
    });
    if (!isFocused && !event.defaultPrevented) {
      navigation.navigate(
        label === TabScreensList.Create ? ScreensList.ImageUpload : route.name,
      );
    }
  };
  const TabComponent = TabViewMapper[label];
  return (
    <Pressable onPress={onPress}>
      <TabComponent isFocused={isFocused} label={label} />
    </Pressable>
  );
};
export default Tab;

const styles = StyleSheet.create({
  tabStyle: {
    width: theme.size.FOURTY_FOUR,
    height: theme.size.FOURTY_FOUR,
    justifyContent: 'center',
    alignItems: 'center',
  },
});
