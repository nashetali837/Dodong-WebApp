import {createBottomTabNavigator} from '@react-navigation/bottom-tabs';
import {NavigationOptions, TabScreensList} from '../helpers';
import {TTabNavigationScreenList} from '../type';
import React from 'react';
import CustomTabBar from './tabBar';
import HomeScreen from '@screens/Tabs/home';
import ExploreScreen from '@screens/Tabs/explore';
import CreateScreen from '@screens/Tabs/create';
import NotificationsScreen from '@screens/Tabs/notifications';
import ProfileScreen from '@screens/Tabs/profile';

const Tabs = createBottomTabNavigator<TTabNavigationScreenList>();

const BottomTabStackRoute = () => {
  return (
    <Tabs.Navigator
      initialRouteName={TabScreensList.Home}
      screenOptions={NavigationOptions.stackOptions}
      tabBar={props => <CustomTabBar {...props} />}>
      <Tabs.Screen
        name={TabScreensList.Home}
        component={HomeScreen}
        options={{tabBarLabel: TabScreensList.Home}}
      />
      <Tabs.Screen
        name={TabScreensList.Explore}
        component={ExploreScreen}
        options={{tabBarLabel: TabScreensList.Explore}}
      />
      <Tabs.Screen
        name={TabScreensList.Create}
        component={CreateScreen}
        options={{tabBarLabel: TabScreensList.Create}}
      />
      <Tabs.Screen
        name={TabScreensList.Notifications}
        component={NotificationsScreen}
        options={{tabBarLabel: TabScreensList.Notifications}}
      />
      <Tabs.Screen
        name={TabScreensList.Profile}
        component={ProfileScreen}
        options={{tabBarLabel: TabScreensList.Profile}}
      />
    </Tabs.Navigator>
  );
};

export default BottomTabStackRoute;
