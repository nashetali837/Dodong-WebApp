export type TNavigationScreenList = {
  Tabs: undefined;
  Onboarding: undefined;
  AuthLanding: undefined;
  Login: undefined;
  SignUp: undefined;
  VerifyOtp: undefined;
  ManualLocation: undefined;
  CompleteProfile: undefined;
  CompleteProfileLanding: undefined;
  CreatePost: undefined;
  PublicProfile: undefined;
  ShopDetail: {
    shopId: number;
    geohash: string;
  };
  GenericWebView: {
    sourceUrl: string;
    addAuthorization?: boolean;
    cacheEnabled?: boolean;
  };
  ImageUpload: undefined;
  PostDetail: undefined;
  ProductDetail: {
    productId: number;
  };
};

export type TTabNavigationScreenList = {
  Home: undefined;
  Explore: undefined;
  Create: undefined;
  Notifications: undefined;
  Profile: undefined;
};

export type TParamList = keyof TNavigationScreenList;
export type TTabParamList = keyof TTabNavigationScreenList;

export type TScreensList = {[key: string]: TParamList};
export type TTabScreensList = {[key: string]: TTabParamList};
