import {createStackNavigator} from '@react-navigation/stack';
import React from 'react';
import {NavigationOptions, ScreensList} from './helpers';
import OnboardingScreen from '@screens/onboarding';
import AuthLandingScreen from '@screens/auth/landing';
import LoginScreen from '@screens/auth/login';
import SignUpScreen from '@screens/auth/signup';
import VerifyOtpScreen from '@screens/auth/otp';
import ManualLocationScreen from '@screens/locations/manual';
import CompleteProfileScreen from '@screens/profile/completProfile';
import ProfileCompleteLandingScreen from '@screens/profile/landing';
import BottomTabStackRoute from './bottomTabs';
import CreatePost from '@screens/Tabs/create/post';
import useUserData from '@src/hooks/user/useUserData';
import useAppData from '@src/hooks/app/useAppData';
import PublicProfileScreen from '@src/screens/profile/public';
import ShopDetailScreen from '@src/screens/shop/detail';
import GenericWebView from '@src/screens/webView';
import ImageUpload from '@src/screens/imageUpload';
import PostDetailScreen from '@src/screens/resources/postDetail';
import ProductDetailScreen from '@src/screens/product/detail';

const RootStack = createStackNavigator();

const RootStackRoute = () => {
  const {isLoggedIn} = useUserData();
  const {isOnboardingDone} = useAppData();
  const getInitialRoute = () => {
    return isLoggedIn
      ? ScreensList.Tabs
      : isOnboardingDone
      ? ScreensList.AuthLanding
      : ScreensList.Onboarding;
  };

  return (
    <RootStack.Navigator
      screenOptions={NavigationOptions.stackOptions}
      initialRouteName={getInitialRoute()}>
      <RootStack.Screen
        name={ScreensList.Tabs}
        component={BottomTabStackRoute}
      />

      <RootStack.Screen
        name={ScreensList.Onboarding}
        component={OnboardingScreen}
      />
      <RootStack.Screen
        name={ScreensList.AuthLanding}
        component={AuthLandingScreen}
      />
      <RootStack.Screen name={ScreensList.LogIn} component={LoginScreen} />
      <RootStack.Screen name={ScreensList.SignUp} component={SignUpScreen} />
      <RootStack.Screen
        name={ScreensList.VerifyOtp}
        component={VerifyOtpScreen}
      />
      <RootStack.Screen
        name={ScreensList.ManualLocation}
        component={ManualLocationScreen}
      />
      <RootStack.Screen
        name={ScreensList.CompleteProfile}
        component={CompleteProfileScreen}
      />
      <RootStack.Screen
        name={ScreensList.CompleteProfileLanding}
        component={ProfileCompleteLandingScreen}
      />
      <RootStack.Screen
        name={ScreensList.PublicProfile}
        component={PublicProfileScreen}
      />
      <RootStack.Screen name={ScreensList.CreatePost} component={CreatePost} />
      <RootStack.Screen
        name={ScreensList.GenericWebView}
        component={GenericWebView}
      />
      <RootStack.Screen
        name={ScreensList.ShopDetail}
        component={ShopDetailScreen}
      />
      <RootStack.Screen
        name={ScreensList.ProductDetail}
        component={ProductDetailScreen}
      />
      <RootStack.Screen
        name={ScreensList.ImageUpload}
        component={ImageUpload}
      />
      <RootStack.Screen
        name={ScreensList.PostDetail}
        component={PostDetailScreen}
      />
    </RootStack.Navigator>
  );
};

export default RootStackRoute;
