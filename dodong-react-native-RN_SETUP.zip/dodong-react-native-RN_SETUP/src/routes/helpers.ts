import APP_ICON_NAMES from '@components/appIcons/iconNames';
import {TScreensList, TTabScreensList} from './type';

export const ScreensList: TScreensList = {
  Tabs: 'Tabs',
  Onboarding: 'Onboarding',
  AuthLanding: 'AuthLanding',
  LogIn: 'Login',
  SignUp: 'SignUp',
  VerifyOtp: 'VerifyOtp',
  ManualLocation: 'ManualLocation',
  CompleteProfile: 'CompleteProfile',
  CompleteProfileLanding: 'CompleteProfileLanding',
  CreatePost: 'CreatePost',
  PublicProfile: 'PublicProfile',
  ShopDetail: 'ShopDetail',
  GenericWebView: 'GenericWebView',
  ImageUpload: 'ImageUpload',
  PostDetail: 'PostDetail',
  ProductDetail: 'ProductDetail',
};

export const TabScreensList: TTabScreensList = {
  Home: 'Home',
  Explore: 'Explore',
  Create: 'Create',
  Notifications: 'Notifications',
  Profile: 'Profile',
};

export const NavigationOptions = {
  stackOptions: {
    headerShown: false,
  },
};

export const TabIconsMap = {
  [TabScreensList.Home]: APP_ICON_NAMES.Home,
  [TabScreensList.Explore]: APP_ICON_NAMES.Explore,
  [TabScreensList.Create]: APP_ICON_NAMES.Explore,
  [TabScreensList.Notifications]: APP_ICON_NAMES.Notification,
  [TabScreensList.Profile]: APP_ICON_NAMES.Profile,
};
