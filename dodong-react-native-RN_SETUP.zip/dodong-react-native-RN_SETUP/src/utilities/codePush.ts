import CodePush from 'react-native-code-push';

export const codePushOptions = {
  checkFrequency: CodePush.CheckFrequency.ON_APP_RESUME,
  installMode: CodePush.InstallMode.ON_NEXT_RESTART,
  rollbackRetryOptions: {
    delayInHours: 1,
    maxRetryAttempts: 100,
  },
};

const onCodePushStatusDidChange = (status: CodePush.SyncStatus) => {
  console.log('codepush update', status);
};

const onCodePushDownloadDidProgress = () => {};

export const codePushUpdate = () => {
  CodePush.sync(
    codePushOptions,
    onCodePushStatusDidChange,
    onCodePushDownloadDidProgress,
  );
};
