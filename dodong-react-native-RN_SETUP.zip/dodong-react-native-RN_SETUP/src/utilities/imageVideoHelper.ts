export const processIOSImagePick = imagePicked => {
  return imagePicked?.assets?.[0];
};
export const processAndroidImagePick = imagePicked => {
  return imagePicked?.assets?.[0];
};
