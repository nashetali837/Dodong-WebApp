import {ENV, ENV_LIVE} from '@src/config';
import {Dimensions, Platform} from 'react-native';
import {AppPlatform} from '../constants/Enums';

export const IS_IOS = Platform.OS === AppPlatform.IOS;

export const dimensions = {
  width: Dimensions.get('window').width,
  height: Dimensions.get('window').height,
  screenHeight: Dimensions.get('screen').height,
  screenWidth: Dimensions.get('screen').width,
};

export const isTestingEnv = () => __DEV__ || ENV_LIVE === ENV.DEV;

export const ObjectToArrayConversion = (data: any) => {
  const dataArray = Object.entries(data).map(([key, value]) => ({
    key,
    ...value,
  }));
  return dataArray;
};

export const toTitleCase = (str: string) => {
  if (!str) {
    return '';
  }
  return str?.charAt(0)?.toUpperCase() + str?.slice(1).toLowerCase();
};

export const objectToFormData = (object: any) => {
  const formData = new FormData();

  for (const key in object) {
    if (Object.hasOwnProperty.call(object, key)) {
      formData.append(key, object[key]);
    }
  }

  return formData;
};

export const extractImageArray = (arrayOfObjects: any, key = 'mediaURL') => {
  return arrayOfObjects.map((item: any) => item[key]);
};
