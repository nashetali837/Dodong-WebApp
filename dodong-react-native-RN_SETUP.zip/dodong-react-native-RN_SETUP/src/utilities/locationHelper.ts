import googleService from '@src/core/api/services/GoogleService';
import {
  TAddressComponent,
  TAddressInfo,
} from '@src/screens/locations/manual/type';
import {PermissionsAndroid, Platform} from 'react-native';
import Geocoder from 'react-native-geocoding';
import Geolocation from 'react-native-geolocation-service';

export const getLocationAndAddress: () => Promise<TLocationResponse> = () => {
  return new Promise(async (resolve, reject) => {
    const result =
      Platform.OS === 'android'
        ? await PermissionsAndroid.request(
            PermissionsAndroid.PERMISSIONS.ACCESS_FINE_LOCATION,
          )
        : await Geolocation.requestAuthorization('whenInUse');

    if (result !== 'granted') {
      reject('Permission denied');
    }

    Geolocation.getCurrentPosition(
      position => {
        const {latitude, longitude} = position.coords;
        Geocoder.from({
          latitude,
          longitude,
        })
          .then(async json => {
            console.log('getCurrentPosition json', json);
            const placeId = json?.results?.[0]?.place_id;
            const res = await getLocationFromPlaceId(placeId);
            resolve(res?.data?.result ?? null);
          })
          .catch(error => {
            reject(error);
          });
      },
      error => {
        reject(error?.message);
      },
      {enableHighAccuracy: true, timeout: 15000, maximumAge: 10000},
    );
  });
};

export const getLocationFromPlaceId = async (place_id: string) =>
  await googleService.getGooglePlaceDetail(place_id);

export function extractCountryAndCityFromAddress(
  addressComponents: TAddressComponent[],
): TAddressInfo {
  let country: string | undefined;
  let state: string | undefined;
  let city: string | undefined;

  for (const component of addressComponents) {
    if (country && state && city) {
      break;
    }

    if (component.types.includes('country') && !country) {
      country = component.long_name;
    } else if (
      component.types.includes('administrative_area_level_1') &&
      !state
    ) {
      state = component.long_name;
    } else if (component.types.includes('locality') && !city) {
      city = component.long_name;
    }
  }

  return {country, state, city};
}

export enum LOCATION_PERMISSIONS {
  granted = 'granted',
  denied = 'denied',
  never_ask_again = 'never_ask_again',
  disabled = 'disabled',
  restricted = 'restricted',
}

export type TLocationResponse = {
  latitude: number;
  longitude: number;
  formattedAddress: string;
};
